
package ie.aib.credit.api.composer.application.service.translation;

import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Component;

@Component
public class TranslationRegistry {

    private final Map<String, FieldValueTranslator> translators = new HashMap<>();

    public TranslationRegistry() {
        translators.put("none", input -> input);
        translators.put("dateToString", new DateToStringTranslator());
        translators.put("uppercase", new UppercaseTranslator());
        translators.put("commaToList", new CommaToListTranslator());
        translators.put("aibToCollateStatus", new StatusTranslator());

    }

    public FieldValueTranslator get(String key) {
        return translators.getOrDefault(key, input -> input);
    }
}
