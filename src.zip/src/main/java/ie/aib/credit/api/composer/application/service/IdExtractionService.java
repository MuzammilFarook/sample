
package ie.aib.credit.api.composer.application.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Service to extract IDs from Phase 1 Collate API response and map them
 * for use in Phase 2 linking operations.
 */
@Service
@Slf4j
public class IdExtractionService {

    /**
     * Extracts all IDs from Phase 1 response, organized by entity type and reference values.
     *
     * Returns a map structure like:
     * {
     *   "legalEntitiesPersonal": {
     *     "refs": {
     *       "CustID|12345": "LE-UUID-1",
     *       "CustID|67890": "LE-UUID-2"
     *     }
     *   },
     *   "assetLifeInsurances": {
     *     "refs": {
     *       "INSURANCE|INS123": "ASSET-UUID-1"
     *     }
     *   }
     * }
     */
    public Map<String, Map<String, Map<String, String>>> extractIdsFromPhase1Response(
            Map<String, Object> phase1Response) {

        Map<String, Map<String, Map<String, String>>> idMappings = new HashMap<>();

        if (phase1Response == null || phase1Response.isEmpty()) {
            log.warn("Phase 1 response is empty. No IDs to extract.");
            return idMappings;
        }

        // Process each entity type in the response
        phase1Response.forEach((entityType, value) -> {
            if (value instanceof List) {
                Map<String, Map<String, String>> entityMappings = extractIdsFromEntityList(entityType,
                        (List<?>) value);
                if (!entityMappings.isEmpty()) {
                    idMappings.put(entityType, entityMappings);
                }
            }
        });

        log.info("Extracted IDs from Phase 1 response. Entity types: {}", idMappings.keySet());
        return idMappings;
    }

    /**
     * Extracts IDs from a list of entities (e.g., list of legalEntitiesPersonal)
     */
    @SuppressWarnings("unchecked")
    private Map<String, Map<String, String>> extractIdsFromEntityList(String entityType, List<?> entities) {
        Map<String, Map<String, String>> mappings = new HashMap<>();
        Map<String, String> refMappings = new HashMap<>();

        for (Object entity : entities) {
            if (!(entity instanceof Map)) {
                continue;
            }

            Map<String, Object> entityMap = (Map<String, Object>) entity;
            String entityId = extractStringValue(entityMap.get("id"));

            if (entityId == null) {
                log.warn("Entity in {} does not have an 'id' field", entityType);
                continue;
            }

            // Extract refs and create mappings
            Object refsObj = entityMap.get("refs");
            if (refsObj instanceof List) {
                List<Map<String, Object>> refs = (List<Map<String, Object>>) refsObj;
                for (Map<String, Object> ref : refs) {
                    String source = extractStringValue(ref.get("source"));
                    String value = extractStringValue(ref.get("value"));
                    Boolean primary = (Boolean) ref.get("primary");

                    if (source != null && value != null) {
                        // Create a unique key: source|value
                        String refKey = source + "|" + value;
                        refMappings.put(refKey, entityId);

                        // If this is primary, also map just the value without source
                        if (Boolean.TRUE.equals(primary)) {
                            refMappings.put(value, entityId);
                        }

                        log.debug("Mapped reference {} -> {} (entityType: {})", refKey, entityId, entityType);
                    }
                }
            }

            // Also map by entity ID itself for direct lookups
            refMappings.put(entityId, entityId);
        }

        if (!refMappings.isEmpty()) {
            mappings.put("refs", refMappings);
        }

        return mappings;
    }

    /**
     * Extracts string value from various types
     */
    private String extractStringValue(Object value) {
        if (value == null) {
            return null;
        }
        return value.toString();
    }

    /**
     * Creates a reverse lookup map for quick ID resolution
     * Returns a flattened map: referenceValue -> actualId
     */
    public Map<String, String> createReverseLookupMap(Map<String, Map<String, Map<String, String>>> idMappings) {
        Map<String, String> reverseLookup = new HashMap<>();

        idMappings.forEach((entityType, mappings) -> {
            Map<String, String> refMappings = mappings.get("refs");
            if (refMappings != null) {
                reverseLookup.putAll(refMappings);
            }
        });

        log.info("Created reverse lookup map with {} entries", reverseLookup.size());
        return reverseLookup;
    }
}
