
package ie.aib.credit.api.composer.application.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class PayloadSplitterService {

    // All link entity types that need IDs from phase 1
    private static final List<String> LINK_ENTITIES = List.of(
            "linksCollectionAsset",
            "linksCollectionExposure",
            "linksCollectionLegalEntity",
            "linksLegalEnforceableDocumentAsset",
            "linksLegalEnforceableDocumentCollection",
            "linksLegalEnforceableDocumentExposure",
            "linksLegalEnforceableDocumentLegalEntity",
            "linksLegalEntityAsset",
            "linksLegalEntityDocument",
            "linksLegalEntityExposure"
    );

    /**
     * Splits the payload into two parts:
     * Phase 1: Resource creation (entities, assets, documents, etc.)
     * Phase 2: Links between resources (requires IDs from phase 1)
     */
    public Map<String, Map<String, Object>> splitPayload(Map<String, Object> fullPayload) {
        Map<String, Object> phase1Payload = new HashMap<>();
        Map<String, Object> phase2Payload = new HashMap<>();

        fullPayload.forEach((key, value) -> {
            if (LINK_ENTITIES.contains(key)) {
                log.debug("Adding '{}' to phase 2 (linking)", key);
                phase2Payload.put(key, value);
            } else {
                log.debug("Adding '{}' to phase 1 (resource creation)", key);
                phase1Payload.put(key, value);
            }
        });

        Map<String, Map<String, Object>> splitPayloads = new HashMap<>();
        splitPayloads.put("phase1", phase1Payload);
        splitPayloads.put("phase2", phase2Payload);

        log.info("Payload split complete. Phase 1 entities: {}, Phase 2 links: {}",
                phase1Payload.size(), phase2Payload.size());

        return splitPayloads;
    }

    /**
     * Checks if the payload contains any linking entities
     */
    public boolean hasLinkingEntities(Map<String, Object> payload) {
        return payload.keySet().stream().anyMatch(LINK_ENTITIES::contains);
    }
}
