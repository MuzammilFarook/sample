
package ie.aib.credit.api.composer.application.service;

import ie.aib.credit.api.composer.config.EnrichmentApiCall;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class DefaultEnrichmentService implements EnrichmentService {

    private final RestTemplate restTemplate = new RestTemplate();

    @Override
    public Map<String, Object> enrich(String inputValue, List<EnrichmentApiCall> enrichmentApiCalls) {
        Map<String, Object> enrichmentMap = new HashMap<>();

        for (EnrichmentApiCall enrichmentApiCall : enrichmentApiCalls) {
            String url = enrichmentApiCall.getUrl().replace("{input}", inputValue);
            try {
                ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
                Object value = extractJsonPath(response.getBody(), enrichmentApiCall.getResponsePath());
                enrichmentMap.put(enrichmentApiCall.getFieldAs(), value);
            } catch (Exception e) {
                // log and continue
                log.error("Enrichment API call failed for: " + url);
            }
        }

        return enrichmentMap;
    }

    private Object extractJsonPath(Map<String, Object> json, String path) {
        String[] parts = path.split("\\.");
        Object current = json;
        for (String part : parts) {
            if (current instanceof Map<?, ?> map) {
                current = map.get(part);
            } else {
                return null;
            }
        }
        return current;
    }
}
