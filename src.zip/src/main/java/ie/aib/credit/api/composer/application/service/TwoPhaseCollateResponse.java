
package ie.aib.credit.api.composer.application.service;

import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.ResponseEntity;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TwoPhaseCollateResponse {

    private Map<String, Object> phase1Request;
    private Map<String, Object> phase1Response;
    private Integer phase1StatusCode;
    private String phase1Status;

    private Map<String, Object> phase2Request;
    private Map<String, Object> phase2Response;
    private Integer phase2StatusCode;
    private String phase2Status;

    private boolean twoPhaseRequired;
}
