
package ie.aib.credit.api.composer.config;

import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class FieldEnrichmentConfig {

    private List<EnrichmentApiCall> apis;
    private Map<String, Object> objectTemplate;
}
