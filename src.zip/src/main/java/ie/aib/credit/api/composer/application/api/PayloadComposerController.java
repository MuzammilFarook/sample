
package ie.aib.credit.api.composer.application.api;

import ie.aib.credit.api.composer.application.service.CollateApiOrchestratorService;
import ie.aib.credit.api.composer.application.service.PayloadOrchestrationService;
import ie.aib.credit.api.composer.application.service.TwoPhaseCollateResponse;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@RequestMapping("{region}/v1/api-composer")
@Slf4j
public class PayloadComposerController {

    private final PayloadOrchestrationService payloadOrchestrationService;
    private final CollateApiOrchestratorService collateApiOrchestratorService;

    @PostMapping({"/submit", "/submit/{actionCode}", "/submit/{actionCode}/{actionSubCode}"})
    public ResponseEntity<Map<String, Object>> composeAndSyncToCollate(
            @PathVariable(required = false) String actionCode,
            @PathVariable(required = false) String actionSubCode,
            @RequestBody Map<String, Object> requestBody
    ) {
        log.info("Processing request with actionCode: {}, actionSubCode: {}", actionCode, actionSubCode);

        // Transform the input payload to Collate API format
        Map<String, Object> transformedPayload = payloadOrchestrationService.processData(requestBody, actionCode,
                actionSubCode);

        // Execute two-phase sync to Collate API
        TwoPhaseCollateResponse twoPhaseResponse = collateApiOrchestratorService.sendToCollateWithTwoPhase(
                transformedPayload);

        // Build comprehensive response
        Map<String, Object> composerResponse = buildComposerResponse(transformedPayload, twoPhaseResponse);

        log.info("Successfully processed request. Two-phase required: {}", twoPhaseResponse.isTwoPhaseRequired());
        return ResponseEntity.ok(composerResponse);
    }

    private Map<String, Object> buildComposerResponse(Map<String, Object> originalTransformedPayload,
            TwoPhaseCollateResponse twoPhaseResponse) {
        Map<String, Object> response = new HashMap<>();

        // Add metadata
        response.put("twoPhaseRequired", twoPhaseResponse.isTwoPhaseRequired());
        response.put("fullTransformedPayload", originalTransformedPayload);

        // Phase 1 details
        Map<String, Object> phase1 = new HashMap<>();
        phase1.put("request", twoPhaseResponse.getPhase1Request());
        phase1.put("response", twoPhaseResponse.getPhase1Response());
        phase1.put("statusCode", twoPhaseResponse.getPhase1StatusCode());
        phase1.put("status", twoPhaseResponse.getPhase1Status());
        response.put("phase1", phase1);

        // Phase 2 details (only if two-phase was required)
        if (twoPhaseResponse.isTwoPhaseRequired() && twoPhaseResponse.getPhase2Request() != null) {
            Map<String, Object> phase2 = new HashMap<>();
            phase2.put("request", twoPhaseResponse.getPhase2Request());
            phase2.put("response", twoPhaseResponse.getPhase2Response());
            phase2.put("statusCode", twoPhaseResponse.getPhase2StatusCode());
            phase2.put("status", twoPhaseResponse.getPhase2Status());
            response.put("phase2", phase2);
        }

        return response;
    }
}
