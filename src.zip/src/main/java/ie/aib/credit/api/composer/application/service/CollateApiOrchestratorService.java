
package ie.aib.credit.api.composer.application.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import ie.aib.credit.api.composer.infrastructure.clients.CollateApiClient;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
@Slf4j
public class CollateApiOrchestratorService {

    private final KeycloakTokenService tokenService;
    private final CollateApiClient collateApiClient;
    private final PayloadSplitterService payloadSplitterService;
    private final IdExtractionService idExtractionService;
    private final IdMappingService idMappingService;
    private final ResourceLookupService resourceLookupService;
    private final ObjectMapper objectMapper;

    /**
     * Two-phase sync to Collate API:
     * Phase 1: Create resources and get their IDs
     * Phase 2: Create links using the IDs from phase 1
     */
    public TwoPhaseCollateResponse sendToCollateWithTwoPhase(Map<String, Object> fullPayload) {
        TwoPhaseCollateResponse.TwoPhaseCollateResponseBuilder responseBuilder = TwoPhaseCollateResponse.builder();

        // Check if two-phase is needed
        boolean haslLinks = payloadSplitterService.hasLinkingEntities(fullPayload);
        responseBuilder.twoPhaseRequired(haslLinks);

        if (!haslLinks) {
            // Single phase - just create resources
            log.info("No linking entities detected. Executing single-phase API call.");

            // Lookup existing resources and enrich with IDs
            log.info("Looking up existing resources...");
            Map<String, Object> enrichedPayload = resourceLookupService.enrichWithExistingIds(fullPayload);
            log.info("Resource lookup complete. Proceeding with API call.");

            ResponseEntity<String> phase1Response = sendToCollate(enrichedPayload);

            return responseBuilder
                    .phase1Request(enrichedPayload)
                    .phase1Response(parseResponseBody(phase1Response.getBody()))
                    .phase1StatusCode(phase1Response.getStatusCode().value())
                    .phase1Status(phase1Response.getStatusCode().toString())
                    .build();
        }

        // Two-phase process
        log.info("Linking entities detected. Executing two-phase API call.");

        // Split payload
        Map<String, Map<String, Object>> splitPayloads = payloadSplitterService.splitPayload(fullPayload);
        Map<String, Object> phase1Payload = splitPayloads.get("phase1");
        Map<String, Object> phase2Payload = splitPayloads.get("phase2");

        // Lookup existing resources and enrich with IDs
        log.info("Looking up existing resources before Phase 1...");
        phase1Payload = resourceLookupService.enrichWithExistingIds(phase1Payload);
        log.info("Resource lookup complete. Proceeding with Phase 1.");

        // Phase 1: Create resources (or update if IDs are present)
        log.info("Phase 1: Creating/Updating resources...");
        ResponseEntity<String> phase1Response = sendToCollate(phase1Payload);
        Map<String, Object> phase1ResponseBody = parseResponseBody(phase1Response.getBody());

        responseBuilder
                .phase1Request(phase1Payload)
                .phase1Response(phase1ResponseBody)
                .phase1StatusCode(phase1Response.getStatusCode().value())
                .phase1Status(phase1Response.getStatusCode().toString());

        // Only proceed to phase 2 if phase 1 was successful and we have links to create
        if (phase1Response.getStatusCode().is2xxSuccessful() && !phase2Payload.isEmpty()) {
            log.info("Phase 1 successful. Proceeding to Phase 2: Linking resources...");

            // Extract IDs from Phase 1 response
            log.info("Extracting IDs from Phase 1 response...");
            Map<String, Map<String, Map<String, String>>> idMappings = idExtractionService.extractIdsFromPhase1Response(
                    phase1ResponseBody);
            Map<String, String> idLookupMap = idExtractionService.createReverseLookupMap(idMappings);

            log.info("ID extraction complete. Found {} ID mappings", idLookupMap.size());
            log.debug("ID mappings: {}", idLookupMap);

            // Map the extracted IDs into Phase 2 payload
            log.info("Mapping IDs to Phase 2 linking payload...");
            Map<String, Object> updatedPhase2Payload = idMappingService.mapIdsToPhase2Payload(phase2Payload,
                    idLookupMap);

            // Phase 2: Create links with resolved IDs
            ResponseEntity<String> phase2Response = sendToCollate(updatedPhase2Payload);

            responseBuilder
                    .phase2Request(updatedPhase2Payload)
                    .phase2Response(parseResponseBody(phase2Response.getBody()))
                    .phase2StatusCode(phase2Response.getStatusCode().value())
                    .phase2Status(phase2Response.getStatusCode().toString());

            log.info("Phase 2 completed successfully.");
        } else if (!phase1Response.getStatusCode().is2xxSuccessful()) {
            log.error("Phase 1 failed with status {}. Skipping Phase 2.", phase1Response.getStatusCode());
        }

        return responseBuilder.build();
    }

    /**
     * Single-phase API call (kept for backward compatibility or when no links are present)
     */
    public ResponseEntity<String> sendToCollate(Map<String, Object> payload) {
        String token = tokenService.getAccessToken();
        String bearerToken = "Bearer " + token;

        try {
            ResponseEntity<String> response = collateApiClient.callCollateApi(bearerToken, payload);
            log.info("Collate API response status: {}", response.getStatusCode());
            log.debug("Collate API response body: {}", response.getBody());
            return response;
        } catch (Exception exception) {
            log.error("Error calling Collate API: {}", exception.getMessage(), exception);
            throw new RuntimeException("Failed to sync with Collate API: " + exception.getMessage(), exception);
        }
    }

    /**
     * Parse response body string into Map
     */
    private Map<String, Object> parseResponseBody(String responseBody) {
        if (responseBody == null || responseBody.trim().isEmpty()) {
            return new HashMap<>();
        }

        try {
            return objectMapper.readValue(responseBody, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) {
            log.warn("Failed to parse response body as JSON. Returning raw string.", e);
            Map<String, Object> fallback = new HashMap<>();
            fallback.put("rawResponse", responseBody);
            return fallback;
        }
    }
}
