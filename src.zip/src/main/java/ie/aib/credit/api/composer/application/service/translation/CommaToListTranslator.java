
package ie.aib.credit.api.composer.application.service.translation;

import java.util.Arrays;
import java.util.List;

public class CommaToListTranslator implements FieldValueTranslator {

    @Override
    public Object translate(Object input) {
        if (input == null) {
            return List.of();
        }
        return Arrays.stream(input.toString().split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();
    }
}
