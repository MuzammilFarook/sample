
package ie.aib.credit.api.composer.application.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Service to map extracted IDs from Phase 1 into Phase 2 linking payload.
 * Resolves placeholder IDs and references to actual Collate-generated IDs.
 */
@Service
@Slf4j
public class IdMappingService {

    /**
     * Maps IDs from Phase 1 response into Phase 2 linking payload.
     *
     * @param phase2Payload The payload containing link entities
     * @param idLookupMap   Map of reference values to actual IDs from Phase 1
     * @return Updated phase2Payload with resolved IDs
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> mapIdsToPhase2Payload(Map<String, Object> phase2Payload,
            Map<String, String> idLookupMap) {

        if (phase2Payload == null || phase2Payload.isEmpty()) {
            log.info("Phase 2 payload is empty. Nothing to map.");
            return phase2Payload;
        }

        if (idLookupMap == null || idLookupMap.isEmpty()) {
            log.warn("ID lookup map is empty. Cannot resolve IDs for Phase 2 payload.");
            return phase2Payload;
        }

        log.info("Mapping IDs to Phase 2 payload. Link types: {}", phase2Payload.keySet());

        Map<String, Object> updatedPayload = new HashMap<>();

        // Process each link type
        phase2Payload.forEach((linkType, value) -> {
            if (value instanceof List) {
                List<Map<String, Object>> updatedLinks = mapIdsInLinkList(linkType, (List<?>) value, idLookupMap);
                updatedPayload.put(linkType, updatedLinks);
            } else {
                updatedPayload.put(linkType, value);
            }
        });

        return updatedPayload;
    }

    /**
     * Maps IDs in a list of link entities
     */
    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> mapIdsInLinkList(String linkType, List<?> links,
            Map<String, String> idLookupMap) {

        List<Map<String, Object>> updatedLinks = new ArrayList<>();
        int mappedCount = 0;

        for (Object link : links) {
            if (!(link instanceof Map)) {
                continue;
            }

            Map<String, Object> linkMap = new HashMap<>((Map<String, Object>) link);
            boolean wasMapped = false;

            // Map all ID fields in the link
            wasMapped |= resolveIdField(linkMap, "assetId", idLookupMap);
            wasMapped |= resolveIdField(linkMap, "collectionId", idLookupMap);
            wasMapped |= resolveIdField(linkMap, "exposureId", idLookupMap);
            wasMapped |= resolveIdField(linkMap, "legalEnforceableDocumentId", idLookupMap);
            wasMapped |= resolveIdField(linkMap, "legalEntityId", idLookupMap);
            wasMapped |= resolveIdField(linkMap, "documentId", idLookupMap);

            if (wasMapped) {
                mappedCount++;
            }

            updatedLinks.add(linkMap);
        }

        log.info("Mapped IDs in {}: {} out of {} links updated", linkType, mappedCount, links.size());
        return updatedLinks;
    }

    /**
     * Resolves a single ID field by looking it up in the ID map
     *
     * @return true if the field was resolved, false otherwise
     */
    private boolean resolveIdField(Map<String, Object> linkMap, String fieldName, Map<String, String> idLookupMap) {
        Object currentValue = linkMap.get(fieldName);

        if (currentValue == null) {
            return false;
        }

        String currentValueStr = currentValue.toString();

        // Try to resolve the ID
        String resolvedId = resolveId(currentValueStr, idLookupMap);

        if (resolvedId != null && !resolvedId.equals(currentValueStr)) {
            linkMap.put(fieldName, resolvedId);
            log.debug("Resolved {}: {} -> {}", fieldName, currentValueStr, resolvedId);
            return true;
        }

        // If no resolution found, check if it might be a placeholder that needs resolution
        if (isPlaceholder(currentValueStr)) {
            log.warn("Could not resolve placeholder {} for field {}. Available keys: {}",
                    currentValueStr, fieldName, idLookupMap.keySet());
        }

        return false;
    }

    /**
     * Resolves an ID using multiple lookup strategies
     */
    private String resolveId(String value, Map<String, String> idLookupMap) {
        if (value == null || value.trim().isEmpty()) {
            return null;
        }

        // Strategy 1: Direct lookup
        if (idLookupMap.containsKey(value)) {
            return idLookupMap.get(value);
        }

        // Strategy 2: Try removing common prefixes (e.g., "AIB/12345" -> "12345")
        if (value.contains("/")) {
            String withoutPrefix = value.substring(value.lastIndexOf("/") + 1);
            if (idLookupMap.containsKey(withoutPrefix)) {
                return idLookupMap.get(withoutPrefix);
            }
        }

        // Strategy 3: Try with different source prefixes
        for (String source : List.of("SIN", "CustID", "INSURANCE", "C", "SIN-")) {
            String keyWithSource = source + "|" + value;
            if (idLookupMap.containsKey(keyWithSource)) {
                return idLookupMap.get(keyWithSource);
            }

            // Try without prefix
            if (value.startsWith(source + "|") || value.startsWith(source + "-") || value.startsWith(source + "/")) {
                String withoutSource = value.substring(source.length() + 1);
                if (idLookupMap.containsKey(withoutSource)) {
                    return idLookupMap.get(withoutSource);
                }
            }
        }

        // No resolution found - return original value
        return null;
    }

    /**
     * Checks if a value appears to be a placeholder that should be resolved
     */
    private boolean isPlaceholder(String value) {
        // If it contains common separators or prefixes, it's likely a placeholder
        return value.contains("|") || value.contains("-") || value.contains("/")
                || value.startsWith("SIN") || value.startsWith("C-") || value.startsWith("INSURANCE");
    }
}
