package com.aib.securities.api;

import com.aib.securities.engine.MappingEngine;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/transform")
public class TransformController {

    private final MappingEngine engine = new MappingEngine();

    @PostMapping(value="/{service}/{operation}", consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity<String> transform(
            @PathVariable("service") String service,
            @PathVariable("operation") String operation,
            @RequestHeader(value="X-Region", required=false) String region,
            @RequestHeader(value="X-UsrID", required=false) String usrId,
            @RequestBody String body) throws Exception {

        Map<String,String> ctx = new HashMap<>();
        if (region != null) ctx.put("region", region);
        if (usrId != null) ctx.put("UsrID", usrId);
        String xml = engine.transform(service, operation, body, ctx);
        return ResponseEntity.ok(xml);
    }
}
