# Securities Transformer (JSON → XML)

Production-grade Spring Boot service that transforms REST JSON payloads into legacy XML messages using **config-driven YAML mappings**.

## How to run
```bash
mvn -q -DskipTests package
java -jar target/securities-transformer-1.0.0.jar
```

## API
```
POST /transform/{service}/{operation}
Headers:
  X-Region: ROI
  X-UsrID: 86070
Body: JSON per Swagger (e.g., Assignment of Life)
```

## Example
```
curl -X POST "http://localhost:8080/transform/SecuritiesService004/create"   -H "Content-Type: application/json" -H "X-Region: ROI"   -d @examples/create_life_policy.json
```

## Mapping
Mappings live in `src/main/resources/mappings/*.yaml`. Add new files for each service/op pair.
- `fields`: scalar mappings (dot-path → XPath)
- `arrays`: array-to-group mappings with counts and listitem elements
- `format`: `date_ddMMyyyy` | `timestamp_yyyyMMddHHmmssSSSSSS` | `decimal` | `passthrough`

## Extend
- Add new YAML for each service (e.g., SecuritiesService007_create.yaml)
- No code change required unless you need new formatters.
