
package com.example.demo.config;

public interface DataTranslator {
    Object translate(Object input);
}
