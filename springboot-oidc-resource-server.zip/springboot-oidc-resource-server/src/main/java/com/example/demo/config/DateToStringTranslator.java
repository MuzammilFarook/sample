
package com.example.demo.config;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateToStringTranslator implements DataTranslator {
    @Override
    public Object translate(Object input) {
        if (input instanceof LocalDate) {
            return ((LocalDate) input).format(DateTimeFormatter.ISO_DATE);
        }
        return input;
    }
}
