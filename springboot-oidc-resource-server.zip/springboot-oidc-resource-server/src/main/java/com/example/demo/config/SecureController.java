package com.example.demo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class SecureController {

  private final YourService yourService;

  @Autowired
  public SecureController(YourService yourService) {
    this.yourService = yourService;
  }

  @PostMapping("/submit")
  public Map<String, Object> handleActionItem(@RequestBody Map<String, Object> dbRowData) {
    return yourService.processData(dbRowData);
  }
}
