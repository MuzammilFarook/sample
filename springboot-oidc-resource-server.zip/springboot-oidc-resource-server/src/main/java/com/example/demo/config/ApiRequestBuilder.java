
package com.example.demo.config;


import java.util.HashMap;
import java.util.Map;

public class ApiRequestBuilder {
    private final Map<String, Map<String, MappingConfig>> config;
    private final TranslatorRegistry translatorRegistry;

    public ApiRequestBuilder(Map<String, Map<String, MappingConfig>> config, TranslatorRegistry translatorRegistry) {
        this.config = config;
        this.translatorRegistry = translatorRegistry;
    }

    public Map<String, Object> build(Map<String, Object> dbRowMap) {
        Map<String, Object> requestBody = new HashMap<>();

        for (Map.Entry<String, Map<String, MappingConfig>> tableEntry : config.entrySet()) {
            for (Map.Entry<String, MappingConfig> columnEntry : tableEntry.getValue().entrySet()) {
                String fullKey = tableEntry.getKey() + "." + columnEntry.getKey();
                Object rawValue = dbRowMap.get(fullKey);
                MappingConfig mapping = columnEntry.getValue();
                if (rawValue == null) continue; // Skip null input
                DataTranslator translator = translatorRegistry.get(mapping.getTranslation());
                Object translatedValue = translator.translate(rawValue);
                if (translatedValue == null) continue; // Skip null after translation too

                injectIntoRequest(requestBody, mapping.getApiPath(), translatedValue);
            }
        }

        return requestBody;
    }

    private void injectIntoRequest(Map<String, Object> root, String path, Object value) {
        String[] parts = path.split("\\.");
        Map<String, Object> current = root;
        for (int i = 0; i < parts.length - 1; i++) {
            current = (Map<String, Object>) current.computeIfAbsent(parts[i], k -> new HashMap<>());
        }
        current.put(parts[parts.length - 1], value);
    }
}
