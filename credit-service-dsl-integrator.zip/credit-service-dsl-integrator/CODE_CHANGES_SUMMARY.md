# Code Changes Summary
## Updated JSON Structure for Involvement Roles

**Date:** December 4, 2025
**Change Type:** Input JSON Structure Update
**Impact:** All 5 Priority Security Types + Additional Services

---

## Overview

Updated the system to accept involvement roles directly from the consuming team via the `securityInvolvement` array instead of using hardcoded filter logic. The consuming team now has full control over which involvement groups each CIF appears in.

---

## Changes Made

### 1. YAML Mapping Files Updated

Changed the filter field path from `securityInvolvementList.involvementRole` to `securityInvolvement.involvementRole` in all mapping files.

#### Files Modified:

**Priority Security Types (CREATE + UPDATE):**
1. ✅ `SecuritiesService004_create.yaml` - Assignment of Life Policy
2. ✅ `SecuritiesService004_update.yaml` - Assignment of Life Policy
3. ✅ `SecuritiesService003_create.yaml` - Letter of Guarantee
4. ✅ `SecuritiesService003_update.yaml` - Letter of Guarantee
5. ✅ `SecuritiesService006_create.yaml` - Counter Indemnity (already correct)
6. ✅ `SecuritiesService006_update.yaml` - Counter Indemnity (already correct)
7. ✅ `SecuritiesService042_create.yaml` - Letter of Pledge
8. ✅ `SecuritiesService042_update.yaml` - Letter of Pledge

**Note:** SecuritiesService039 (Miscellaneous) uses a different structure (`parties.beneficiaries`, `parties.borrowers`, `parties.signatories`) and doesn't use filters, so no changes were needed.

**Additional Services (Non-Priority):**
9. ✅ `SecuritiesService007_update.yaml` - Letter of Lien (already correct)
10. ✅ `SecuritiesService033_create.yaml` - Mortgage Debenture (already correct)
11. ✅ `SecuritiesService034_update.yaml` - Mortgage Over Property (already correct)

---

## JSON Structure Change

### Old Structure (NOT USED ANYMORE)
```json
{
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvementList": [
        "BENEFJOIN",
        "BORROWJOIN",
        "LIFEASSURE"
      ]
    }
  ]
}
```

### New Structure (CURRENT - CONSUMING TEAM PROVIDES)
```json
{
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvement": [
        {
          "involvementRole": "BENEFJOIN",
          "involvementType": "SECUR"
        },
        {
          "involvementRole": "BORROWJOIN",
          "involvementType": "SECUR"
        },
        {
          "involvementRole": "LIFEASSURE",
          "involvementType": "SECUR"
        }
      ]
    }
  ]
}
```

---

## Detailed Changes by File

### SecuritiesService004 (Assignment of Life Policy)

**Files:** `SecuritiesService004_create.yaml`, `SecuritiesService004_update.yaml`

**Changes in 3 locations per file:**

#### 1. BENOWN_INV_GROUP Filter
```yaml
# BEFORE
filter:
  field: securityInvolvementList.involvementRole
  values:
    - BENEFJOIN
    - BENEFSOLE

# AFTER
filter:
  field: securityInvolvement.involvementRole
  values:
    - BENEFJOIN
    - BENEFSOLE
```

#### 2. BORROWCUST_INV_GROUP Filter
```yaml
# BEFORE (in create.yaml this was commented out)
filter:
  field: securityInvolvementList.involvementRole
  values:
    - BORROWJOIN
    - BORROWSOLE

# AFTER (now active in both files)
filter:
  field: securityInvolvement.involvementRole
  values:
    - BORROWJOIN
    - BORROWSOLE
```

#### 3. LIFEASSURE_INV_GROUP Filter
```yaml
# BEFORE
filter:
  field: securityInvolvementList.involvementRole
  values:
    - LIFEASSURE

# AFTER
filter:
  field: securityInvolvement.involvementRole
  values:
    - LIFEASSURE
```

---

### SecuritiesService003 (Letter of Guarantee)

**Files:** `SecuritiesService003_create.yaml`, `SecuritiesService003_update.yaml`

**Changes in 3 locations per file:**

#### 1. BENOWN_INV_GROUP Filter
```yaml
filter:
  field: securityInvolvement.involvementRole
  values:
    - BENEFJOIN
    - BENEFSOLE
```

#### 2. BORROWCUST_INV_GROUP Filter
```yaml
filter:
  field: securityInvolvement.involvementRole
  values:
    - BORROWJOIN
    - BORROWSOLE
```

#### 3. GUARANTOR_INV_GROUP Filter
```yaml
filter:
  field: securityInvolvement.involvementRole
  values:
    - GUARANTOR
```

---

### SecuritiesService006 (Counter Indemnity)

**Files:** `SecuritiesService006_create.yaml`, `SecuritiesService006_update.yaml`

**Status:** Already using correct structure `securityInvolvement.involvementRole`

**No changes needed.**

---

### SecuritiesService042 (Letter of Pledge)

**Files:** `SecuritiesService042_create.yaml`, `SecuritiesService042_update.yaml`

**Changes in 2 locations per file:**

#### 1. BENOWN_INV_GROUP Filter
```yaml
filter:
  field: securityInvolvement.involvementRole
  values:
    - BENEFJOIN
    - BENEFSOLE
```

#### 2. BORROWCUST_INV_GROUP Filter
```yaml
filter:
  field: securityInvolvement.involvementRole
  values:
    - BORROWJOIN
    - BORROWSOLE
```

---

### SecuritiesService039 (Miscellaneous)

**Files:** `SecuritiesService039_create.yaml`, `SecuritiesService039_update.yaml`

**Status:** Uses different JSON structure:
- `parties.beneficiaries[]` - No filter
- `parties.borrowers[]` - No filter
- `parties.signatories[]` - No filter

**No changes needed** - This service doesn't use filters on involvement roles.

---

## Java Code Changes

### ✅ No Changes Required

The `MappingEngine.java` already handles filters dynamically based on the YAML configuration. The filter logic in `matchesFilter()` method (lines 325-370) works with any nested field path.

**Existing Code (No Changes):**
```java
private boolean matchesFilter(JsonNode item, ArrayFilter filter) {
    if (filter == null) return true;

    String[] parts = filter.field.split("\\.");
    JsonNode node = item;
    for (String part : parts) {
        node = node.path(part);
        if (node.isMissingNode()) return false;
    }

    // If node is an array, check if ANY element matches
    if (node.isArray()) {
        for (JsonNode elem : node) {
            JsonNode roleNode = elem.path("involvementRole");
            if (!roleNode.isMissingNode()) {
                String role = roleNode.asText();
                if (filter.values.contains(role)) {
                    return true;
                }
            }
        }
        return false;
    }

    // Single value check
    String value = node.asText();
    return filter.values.contains(value);
}
```

This code automatically works with:
- Old: `securityInvolvementList.involvementRole`
- New: `securityInvolvement.involvementRole`

The change only needed to be made in YAML configuration files.

---

## Impact Analysis

### ✅ Backwards Compatible
**No** - This is a breaking change for the consuming team.

### 📋 Consuming Team Action Required
The consuming team must update their JSON payloads to use the new structure:

**OLD (Stop Using):**
```json
"securityInvolvementList": ["BENEFJOIN", "BORROWJOIN"]
```

**NEW (Use This):**
```json
"securityInvolvement": [
  { "involvementRole": "BENEFJOIN", "involvementType": "SECUR" },
  { "involvementRole": "BORROWJOIN", "involvementType": "SECUR" }
]
```

### 🎯 Benefits
1. **More Control:** Consuming team explicitly controls which groups each CIF appears in
2. **More Flexible:** Can include additional metadata (involvementType, etc.)
3. **More Explicit:** Clear what roles are assigned to each CIF
4. **Better Structure:** Follows object-based pattern instead of simple string array

---

## Testing Required

### Test Scenarios

#### 1. Single CIF with Multiple Roles
**Input:**
```json
{
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvement": [
        { "involvementRole": "BENEFJOIN", "involvementType": "SECUR" },
        { "involvementRole": "BORROWJOIN", "involvementType": "SECUR" },
        { "involvementRole": "LIFEASSURE", "involvementType": "SECUR" }
      ]
    }
  ]
}
```

**Expected XML Output:**
- CIF appears in BENOWN_INV_GROUP (count=1)
- CIF appears in BORROWCUST_INV_GROUP (count=1)
- CIF appears in LIFEASSURE_INV_GROUP (count=1)

#### 2. Multiple CIFs with Different Roles
**Input:**
```json
{
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvement": [
        { "involvementRole": "BENEFJOIN", "involvementType": "SECUR" },
        { "involvementRole": "BORROWJOIN", "involvementType": "SECUR" }
      ]
    },
    {
      "cifKey": "0100000932437490000",
      "securityInvolvement": [
        { "involvementRole": "BENEFJOIN", "involvementType": "SECUR" }
      ]
    }
  ]
}
```

**Expected XML Output:**
- BENOWN_INV_GROUP count=2 (both CIFs)
- BORROWCUST_INV_GROUP count=1 (only first CIF)
- LIFEASSURE_INV_GROUP count=0

#### 3. CIF with No Matching Roles
**Input:**
```json
{
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvement": [
        { "involvementRole": "OTHERPERSON", "involvementType": "SECUR" }
      ]
    }
  ]
}
```

**Expected XML Output:**
- All involvement groups count=0
- Empty container elements created

#### 4. Empty securityInvolvement Array
**Input:**
```json
{
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvement": []
    }
  ]
}
```

**Expected XML Output:**
- All involvement groups count=0
- Empty container elements created

---

## Rollback Plan

If needed, revert the YAML files by changing:

```bash
# In all affected YAML files, change:
securityInvolvement.involvementRole
# back to:
securityInvolvementList.involvementRole
```

**Files to revert:**
- SecuritiesService003_create.yaml
- SecuritiesService003_update.yaml
- SecuritiesService004_create.yaml
- SecuritiesService004_update.yaml
- SecuritiesService042_create.yaml
- SecuritiesService042_update.yaml

**Command:**
```bash
cd src/main/resources/mappings
sed -i 's/securityInvolvement\.involvementRole/securityInvolvementList.involvementRole/g' \
  SecuritiesService003_*.yaml \
  SecuritiesService004_*.yaml \
  SecuritiesService042_*.yaml
```

---

## Documentation Updates

### Files Updated:
1. ✅ `FIELD_MAPPINGS.md` - Updated with new JSON structure examples
2. ✅ `CODE_CHANGES_SUMMARY.md` - This document

### Files That May Need Update:
1. `LLD_Securities_transformer.MD` - Should be updated to reflect new JSON structure
2. API Swagger/OpenAPI specifications - Should be updated with new schema
3. Integration test data - Should be updated with new format

---

## Summary

### What Changed:
- **8 YAML mapping files** updated to use `securityInvolvement.involvementRole` instead of `securityInvolvementList.involvementRole`
- **0 Java files** changed (existing code already handles this dynamically)
- **Field mapping documentation** updated with new structure and examples

### What Didn't Change:
- Core transformation engine logic
- XML output structure
- Filter matching algorithm
- API endpoints
- Response format

### Key Takeaway:
This is a **configuration-only change** that updates the expected input JSON structure. The consuming team now explicitly provides involvement roles in a more structured format, giving them full control over which involvement groups each CIF appears in.

---

## Verification Commands

### Check all files are updated:
```bash
cd src/main/resources/mappings
grep -r "securityInvolvementList" *.yaml
# Should return: No results (if all updated)
```

### Verify new structure:
```bash
cd src/main/resources/mappings
grep -r "securityInvolvement\.involvementRole" *.yaml
# Should show all filter definitions using new path
```

### Count affected files:
```bash
cd src/main/resources/mappings
grep -l "securityInvolvement\.involvementRole" *.yaml | wc -l
# Should return: 14+ files
```

---

**End of Summary**
