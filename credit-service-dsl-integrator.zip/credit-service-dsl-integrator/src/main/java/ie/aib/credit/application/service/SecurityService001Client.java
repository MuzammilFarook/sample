package ie.aib.credit.application.service;

import ie.aib.credit.infrastructure.DSLService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.StringReader;
import java.io.StringWriter;

/**
 * Service to retrieve security details using SecuritiesService001
 */
@Service
@AllArgsConstructor
@Slf4j
public class SecurityService001Client {

    private final DSLService dslService;

    /**
     * Retrieves the A0LAST_UPDATED_TIMESTAMP for a given item number
     *
     * @param itemNumber The security item number
     * @param regionCode The region code (e.g., "ROI")
     * @param sourceNSC The source NSC
     * @param staffNumber The staff number
     * @return The A0LAST_UPDATED_TIMESTAMP value or null if not found
     * @throws Exception If the service call fails
     */
    public String getLastUpdatedTimestamp(String itemNumber, String regionCode, String sourceNSC, String staffNumber) throws Exception {
        log.info("Fetching last updated timestamp for item number: {}", itemNumber);

        // Build SecuritiesService001 XML request
        String requestXml = buildSecuritiesService001Request(itemNumber, regionCode, sourceNSC, staffNumber);

        log.debug("SecuritiesService001 request XML: {}", requestXml);

        // Call DSL service
        String responseXml = dslService.executeDsl("SecuritiesService001", "read", requestXml);

        log.debug("SecuritiesService001 response XML: {}", responseXml);

        // Parse response and extract A0LAST_UPDATED_TIMESTAMP
        String timestamp = extractLastUpdatedTimestamp(responseXml);

        log.info("Extracted timestamp: {} for item number: {}", timestamp, itemNumber);

        return timestamp;
    }

    /**
     * Builds the XML request for SecuritiesService001
     */
    private String buildSecuritiesService001Request(String itemNumber, String regionCode, String sourceNSC, String staffNumber) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.newDocument();

        // Create Request root
        Element request = doc.createElement("Request");
        doc.appendChild(request);

        // Add Log
        Element log = doc.createElement("Log");
        log.setTextContent("N");
        request.appendChild(log);

        // Add ID section
        Element id = doc.createElement("ID");
        request.appendChild(id);

        createElement(doc, id, "version", "1.0");
        createElement(doc, id, "AppID", "NBP");
        createElement(doc, id, "AppName", "SysTest_CAS_ROI_Current");
        createElement(doc, id, "UsrID", "5324654654");
        createElement(doc, id, "UnqID", staffNumber != null ? staffNumber : "88140");

        // Add request fields
        createElement(doc, request, "regionCode", regionCode != null ? regionCode : "ROI");
        createElement(doc, request, "sourceNSC", sourceNSC != null ? sourceNSC : "931012");
        createElement(doc, request, "staffNumber", staffNumber != null ? staffNumber : "88140");
        createElement(doc, request, "deviceId", "");
        createElement(doc, request, "Transaction", "SecuritiesService001");
        createElement(doc, request, "TransactionVersion", "1");

        // Add SecuritiesService001 section
        Element securitiesService001 = doc.createElement("SecuritiesService001");
        request.appendChild(securitiesService001);

        createElement(doc, securitiesService001, "servType500", "RS");
        createElement(doc, securitiesService001, "source500", "NAPS");

        // Add ITEM_NUMBER with index attribute
        Element itemNumberElem = doc.createElement("ITEM_NUMBER");
        itemNumberElem.setAttribute("index", "1");
        itemNumberElem.setTextContent(itemNumber);
        securitiesService001.appendChild(itemNumberElem);

        // Convert Document to String
        return documentToString(doc);
    }

    /**
     * Extracts A0LAST_UPDATED_TIMESTAMP from the SecuritiesService001 response XML
     */
    private String extractLastUpdatedTimestamp(String xmlResponse) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();

        // Parse the XML response
        Document doc = db.parse(new org.xml.sax.InputSource(new StringReader(xmlResponse)));

        // Find the Field element with name="A0LAST_UPDATED_TIMESTAMP"
        NodeList fields = doc.getElementsByTagName("Field");
        for (int i = 0; i < fields.getLength(); i++) {
            Element field = (Element) fields.item(i);
            String fieldName = field.getAttribute("name");

            if ("A0LAST_UPDATED_TIMESTAMP".equals(fieldName)) {
                // Get the Value child element
                NodeList values = field.getElementsByTagName("Value");
                if (values.getLength() > 0) {
                    Element value = (Element) values.item(0);
                    String timestamp = value.getTextContent();
                    log.debug("Found A0LAST_UPDATED_TIMESTAMP: {}", timestamp);
                    return timestamp;
                }
            }
        }

        log.warn("A0LAST_UPDATED_TIMESTAMP not found in response");
        return null;
    }

    /**
     * Helper method to create a simple element with text content
     */
    private void createElement(Document doc, Element parent, String tagName, String textContent) {
        Element element = doc.createElement(tagName);
        element.setTextContent(textContent);
        parent.appendChild(element);
    }

    /**
     * Converts a Document to XML String
     */
    private String documentToString(Document doc) throws Exception {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer t = tf.newTransformer();
        t.setOutputProperty(OutputKeys.INDENT, "yes");
        t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
        t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        StringWriter sw = new StringWriter();
        t.transform(new DOMSource(doc), new StreamResult(sw));
        return sw.toString();
    }
}
