package ie.aib.credit.application.api.model;

import lombok.Data;

@Data
public class SecurityResponse {

    private String collateInternalId;
}


