package ie.aib.credit.application.service.engine;

import java.util.List;
import java.util.Map;

public class MappingSpec {

    public String service;         // e.g., SecuritiesService004
    public String operation;       // create | update
    public String transaction;     // Transaction node value
    public String transactionVersion = "1";
    public String rootXPath;       // /Request/SecuritiesService004
    public String servType500;     // C or U
    public List<FieldMap> fields;  // scalar and object mappings
    public List<ArrayMap> arrays;  // array/group mappings
    public Map<String, String> defaults; // default constant values
    public Envelope envelope;      // envelope config

    public static class Envelope {

        public String regionJsonPath;   // path or header name
        public Map<String, String> constants; // e.g., sourceNSC, AppID
    }

    public static class FieldMap {

        public String json;     // dot path (e.g., assignmentOfLife.policyType)
        public String xpath;    // target XPath (supports @index, attributes)
        public String format;   // passthrough | date_ddMMyyyy | timestamp_yyyyMMddHHmmssSSSSSS | decimal
        public boolean required = false;
        public String constant; // if present, overrides json (fixed value)
    }

    public static class ArrayMap {

        public String json;            // dot path to array
        public String countXPath;      // node to write the count to (e.g., /Request/.../BENOWN_INV_GROUP)
        public String listItemXPath;   // base path for list items
        public int startIndex = 1;     // start index attribute
        public String indexAttribute = "index";
        public ArrayFilter filter;     // optional filter to select subset of array items
        public List<SubField> mappings; // fields inside each listitem

        public static class ArrayFilter {

            public String field;       // nested field path to check (e.g., "securityInvolvement[0].involvementRole")
            public List<String> values; // list of values to match (OR condition)
        }

        public static class SubField {

            public String json;       // relative field in array element, e.g., cifRef
            public String xpath;      // child xpath under listitem
            public String constant;   // fixed value
            public String format;     // optional formatter
            public String indexAttribute; // if present, child element should have index attribute matching parent listitem index
        }
    }
}


