package ie.aib.credit.application.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import ie.aib.credit.application.api.model.SecurityResponse;
import ie.aib.credit.application.service.SecurityService001Client;
import ie.aib.credit.application.service.engine.MappingEngine;
import ie.aib.credit.infrastructure.DSLService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("{region}/v1/transform")
@Slf4j
public class TransformController {
    private final MappingEngine engine;
    private final DSLService dslService;
    private final SecurityService001Client securityService001Client;
    private final ObjectMapper objectMapper;

    @PostMapping(value = "/{service}/{operation}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SecurityResponse> transform(
            @PathVariable("service") String service,
            @PathVariable("operation") String operation,
            @RequestHeader(value = "X-Region", required = false) String region,
            @RequestHeader(value = "X-UsrID", required = false) String usrId,
            @RequestBody String body) throws Exception {

        log.info("Received transformation request for service: {}, operation: {}, body: {}", service, operation, body);

        Map<String, String> ctx = new HashMap<>();
        if (region != null) {
            ctx.put("region", region);
        }
        if (usrId != null) {
            ctx.put("UsrID", usrId);
        }

        // For UPDATE operations, fetch the last updated timestamp from SecuritiesService001
        if ("update".equalsIgnoreCase(operation)) {
            log.info("UPDATE operation detected. Fetching last updated timestamp from SecuritiesService001");
            fetchAndInjectLastUpdatedTimestamp(body, region, ctx);
        }

        log.debug("Transforming JSON to XML for service: {}", service);

        String txml = engine.transform(service, operation, body, ctx);

        log.debug("Calling backend DSL service for: {}", service);
        //String respXml = dslService.executeDsl(service, operation, txml);

        log.debug("Transforming XML response to JSON for service: {}", service);
        //SecurityResponse securityResponse = engine.transformFromXml(service, operation, respXml);

        log.info("Successfully completed transformation for service: {}, operation: {}", service, operation);
        return ResponseEntity.status(HttpStatus.OK).body(null);

    }

    /**
     * Fetches the last updated timestamp from SecuritiesService001 and injects it into the context
     * for UPDATE operations. This timestamp will be used by the MappingEngine instead of reading from JSON.
     */
    private void fetchAndInjectLastUpdatedTimestamp(String jsonBody, String region, Map<String, String> ctx) throws Exception {
        try {
            // Parse the JSON body
            JsonNode rootNode = objectMapper.readTree(jsonBody);

            // Extract itemNumber from securityItem.itemNumber
            JsonNode securityItemNode = rootNode.path("securityItem");
            if (securityItemNode.isMissingNode()) {
                log.warn("securityItem not found in request body. Cannot fetch timestamp.");
                return;
            }

            JsonNode itemNumberNode = securityItemNode.path("itemNumber");
            if (itemNumberNode.isMissingNode() || itemNumberNode.isNull()) {
                log.warn("securityItem.itemNumber not found in request body. Cannot fetch timestamp.");
                return;
            }

            String itemNumber = itemNumberNode.asText();
            log.info("Extracted itemNumber: {} for timestamp lookup", itemNumber);

            // Extract region, sourceNSC, staffNumber from context or defaults
            String regionCode = ctx.getOrDefault("region", region != null ? region : "ROI");
            String sourceNSC = "931012"; // Default value
            String staffNumber = ctx.getOrDefault("staffNumber", "88140"); // Default value

            // Call SecuritiesService001 to get the timestamp
            String lastUpdatedTimestamp = securityService001Client.getLastUpdatedTimestamp(
                    itemNumber, regionCode, sourceNSC, staffNumber);

            if (lastUpdatedTimestamp == null || lastUpdatedTimestamp.isEmpty()) {
                log.warn("Could not retrieve last updated timestamp for itemNumber: {}. Proceeding without it.", itemNumber);
                return;
            }

            log.info("Retrieved last updated timestamp: {} for itemNumber: {}", lastUpdatedTimestamp, itemNumber);

            // Store the timestamp in the context so MappingEngine can use it
            ctx.put("LAST_UPDATED_TIMESTAMP", lastUpdatedTimestamp);

            log.info("Successfully stored last updated timestamp in context");

        } catch (Exception e) {
            log.error("Error while fetching last updated timestamp: {}", e.getMessage(), e);
            // Don't throw - log and continue without the timestamp
            log.warn("Proceeding with transformation without last updated timestamp");
        }
    }
}


