package ie.aib.credit.infrastructure;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class DSLService {

    private final RestTemplate restTemplate;

    @Autowired
    public DSLService(RestTemplate customRestTemplate) {
        this.restTemplate = customRestTemplate;
    }

    @Value("${dsl.service.url}")
    private String dslUri;

    @Value("${dsl.service.timeout}")
    private int timeout;

    public String executeDsl(String serviceName,String operation, String xmlRequest) throws Exception {
        log.info("Calling backend service: {} with request: {}", serviceName, xmlRequest);
        ResponseEntity<String> responseEntity = null;

        try {
            HttpHeaders httpHeader = new HttpHeaders();
            httpHeader.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            HttpEntity<String> httpEntity = new HttpEntity<>(httpHeader);
            String url = dslUri + "?XMLRequest=" + xmlRequest;

            responseEntity = restTemplate.postForEntity(url, httpEntity, String.class);
            log.info("Received response from backend: {}", responseEntity.getBody());

        } catch (HttpClientErrorException | HttpServerErrorException e) {
            log.error("Backend service error: {}", e.getMessage(), e);
            throw new Exception("Backend service call failed", e);
        } catch (ResourceAccessException e) {
            log.error("Backend service timeout: {}", e.getMessage(), e);
            throw new Exception("Backend service timeout", e);
        } catch (Exception e) {
            log.error("Unexpected error during backend service execution: {}", e.getMessage(), e);
            throw new Exception("Unexpected error during backend service execution", e);
        }

        if (responseEntity == null || responseEntity.getBody() == null) {
            throw new Exception("No response received from backend service");
        }

        return responseEntity.getBody();
    }
}


