package ie.aib.credit.application.service.engine;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class XMLParser {

    private final Document document;
    private final XPath xmlPath;

    public XMLParser(String xmlContent) throws Exception {
        try {
            document = DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder()
                    .parse(new ByteArrayInputStream(xmlContent.getBytes(StandardCharsets.UTF_8)));
            xmlPath = XPathFactory.newInstance().newXPath();
        } catch (Exception e) {
            throw new Exception("Error parsing XML response from backend service", e);
        }
    }

    public String getValue(String expression) throws Exception {
        try {
            return (String) xmlPath.evaluate(expression, document, XPathConstants.STRING);
        } catch (Exception e) {
            throw new Exception("Error parsing XML response from backend service", e);
        }
    }

    public List<String> getValues(String expression) throws Exception {
        List<String> values = new ArrayList<>();
        try {
            NodeList nodes = (NodeList) xmlPath.evaluate(expression, document, XPathConstants.NODESET);
            for (int i = 0; i < nodes.getLength(); i++) {
                values.add(nodes.item(i).getTextContent());
            }
        } catch (Exception e) {
            throw new Exception("Error parsing XML response from backend service", e);
        }
        return values;
    }
}


