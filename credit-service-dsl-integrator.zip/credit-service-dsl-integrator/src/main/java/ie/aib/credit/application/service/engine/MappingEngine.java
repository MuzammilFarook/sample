package ie.aib.credit.application.service.engine;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import ie.aib.credit.application.api.model.SecurityResponse;
import java.io.InputStream;
import java.io.StringWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;

@Component
public class MappingEngine {

    private final ObjectMapper mapper = new ObjectMapper();
    private final Map<String, MappingSpec> byKey = new HashMap<>();

    public MappingEngine() throws Exception {
        // Load all YAML mapping specs from /mappings
        Yaml yaml = new Yaml(new Constructor(MappingSpec.class, new LoaderOptions()));
        String[] files = new String[] {
                "mappings/SecuritiesService004_create.yaml",
                "mappings/SecuritiesService004_update.yaml",
                "mappings/SecuritiesService003_create.yaml",
                "mappings/SecuritiesService003_update.yaml",
                //"mappings/SecuritiesService005_create.yaml",
                //"mappings/SecuritiesService005_update.yaml",
                "mappings/SecuritiesService006_create.yaml",
                "mappings/SecuritiesService006_update.yaml",
                "mappings/SecuritiesService007_create.yaml",
                "mappings/SecuritiesService007_update.yaml",
                "mappings/SecuritiesService033_create.yaml",
                "mappings/SecuritiesService033_update.yaml",
                "mappings/SecuritiesService034_create.yaml",
                "mappings/SecuritiesService034_update.yaml",
                "mappings/SecuritiesService042_create.yaml",
                "mappings/SecuritiesService042_update.yaml",
                "mappings/SecuritiesService039_create.yaml",
                "mappings/SecuritiesService039_update.yaml"
        };
        for (String f : files) {
            try (InputStream is = getClass().getClassLoader().getResourceAsStream(f)) {
                if (is == null) {
                    continue;
                }
                MappingSpec spec = yaml.load(is);
                String key = spec.service + ":" + spec.operation;
                byKey.put(key, spec);
            } catch (Exception e) {
                throw new Exception("Failed to load mapping: " + f, e);
            }
        }
    }

    public String transform(String service, String operation, String json, Map<String, String> ctx) throws Exception {
        MappingSpec spec = byKey.get(service + ":" + operation);
        if (spec == null) {
            throw new Exception("No mapping found for service: " + service + ", operation: " + operation);
        }

        JsonNode root = mapper.readTree(json);
        Document doc = newDocument();
        Element request = doc.createElement("Request");
        doc.appendChild(request);

        // Scalar field mappings - these will create the envelope and service structure
        if (spec.fields != null) {
            for (MappingSpec.FieldMap fm : spec.fields) {
                String value;

                // Special handling for LAST_UPDATED_TIMESTAMP from context (for UPDATE operations)
                if (fm.xpath != null && fm.xpath.contains("LAST_UPDATED_TIMESTAMP") &&
                    !fm.xpath.contains("LIFEPOL_LAST_UPDATED_TIMESTAMP") &&
                    !fm.xpath.contains("PROP_LAST_UPDATED_TIMESTAMP") &&
                    !fm.xpath.contains("GUARANTEE_LAST_UPDATED_TIMESTAMP") &&
                    !fm.xpath.contains("INDEMNITY_LAST_UPDATED_TIMESTAMP") &&
                    !fm.xpath.contains("PLEDGE_LAST_UPDATED_TIMESTAMP") &&
                    ctx != null && ctx.containsKey("LAST_UPDATED_TIMESTAMP")) {
                    // Use the timestamp from context (retrieved from SecuritiesService001)
                    value = ctx.get("LAST_UPDATED_TIMESTAMP");
                    log.debug("Using LAST_UPDATED_TIMESTAMP from context: {}", value);
                } else {
                    // Normal mapping: constant or from JSON
                    value = fm.constant != null ? fm.constant : readDotPath(root, fm.json);
                }

                if (fm.required && (value == null || value.isBlank())) {
                    throw new Exception("Missing required field: " + fm.json);
                }
                if (value != null) {
                    value = applyFormat(value, fm.format);
                }
                writeXPathValue(doc, request, fm.xpath, value == null ? "" : value);
            }
        }

        // Arrays / groups
        if (spec.arrays != null) {
            for (MappingSpec.ArrayMap arr : spec.arrays) {
                JsonNode arrNode = readNode(root, arr.json);

                // Apply filter if specified
                List<JsonNode> filteredItems = new ArrayList<>();
                if (arrNode != null && arrNode.isArray()) {
                    for (int i = 0; i < arrNode.size(); i++) {
                        JsonNode item = arrNode.get(i);
                        if (matchesFilter(item, arr.filter)) {
                            filteredItems.add(item);
                        }
                    }
                }

                int count = filteredItems.size();
                writeXPathValue(doc, request, arr.countXPath, String.valueOf(count));

                // If count is 0, always create empty container element
                if (count == 0) {
                    pathEnsure(doc, request, arr.listItemXPath);
                }

                for (int i = 0; i < count; i++) {
                    JsonNode item = filteredItems.get(i);
                    int currentIndex = i + arr.startIndex;
                    // create listitem node at index
                    Element base = pathEnsure(doc, request, arr.listItemXPath); // ensure container path
                    Element listItem = doc.createElement("listitem");
                    listItem.setAttribute(arr.indexAttribute, String.valueOf(currentIndex));
                    base.appendChild(listItem);
                    // write subfields
                    for (MappingSpec.ArrayMap.SubField sf : arr.mappings) {
                        String v = sf.constant != null ? sf.constant : readDotPathWithFilter(item, sf.json, arr.filter);
                        if (v == null) {
                            v = "";
                        }
                        if (sf.format != null) {
                            v = applyFormat(v, sf.format);
                        }
                        // If subfield has indexAttribute, child elements should also have index attribute
                        writeXPathValueWithIndex(doc, listItem, sf.xpath, v, sf.indexAttribute, currentIndex);
                    }
                }
            }
        }

        // Serialize
        return toString(doc);
    }

    // ---- Helpers ----
    private Document newDocument() throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(false);
        DocumentBuilder db = dbf.newDocumentBuilder();
        return db.newDocument();
    }

    private Element el(Document doc, String name) {
        return doc.createElement(name);
    }

    private Element child(Document doc, Element parent, String name, String text) {
        Element c = doc.createElement(name);
        if (text != null) {
            c.setTextContent(text);
        }
        parent.appendChild(c);
        return c;
    }

    private Element childWithIndex(Document doc, Element parent, String name, String text, String index) {
        Element c = doc.createElement(name);
        if (index != null) {
            c.setAttribute("index", index);
        }
        if (text != null) {
            c.setTextContent(text);
        }
        parent.appendChild(c);
        return c;
    }

    private String toString(Document doc) throws Exception {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer t = tf.newTransformer();
        t.setOutputProperty(OutputKeys.INDENT, "yes");
        t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
        StringWriter sw = new StringWriter();
        t.transform(new DOMSource(doc), new StreamResult(sw));
        return sw.toString();
    }

    // Enhanced version that uses filter context to find matching array elements
    private String readDotPathWithFilter(JsonNode node, String path, MappingSpec.ArrayMap.ArrayFilter filter) {
        if (path == null || path.isBlank()) {
            return null;
        }

        // If there's a filter and the path references the filtered array field, find the matching element
        if (filter != null && filter.field != null && filter.values != null && !filter.values.isEmpty()) {
            // Extract array field name from filter (e.g., "securityInvolvement" from "securityInvolvement.involvementRole")
            String filterArrayField = filter.field.split("\\.")[0];

            // Check if the path starts with the same array field
            if (path.startsWith(filterArrayField + "[0].") || path.startsWith(filterArrayField + ".")) {
                // Find the matching element in the array based on filter criteria
                JsonNode arrayNode = node.get(filterArrayField);
                if (arrayNode != null && arrayNode.isArray()) {
                    // Find the array element that matches the filter
                    for (int i = 0; i < arrayNode.size(); i++) {
                        JsonNode arrayItem = arrayNode.get(i);
                        // Check if this array item matches the filter
                        String remainingFilterPath = filter.field.substring(filterArrayField.length() + 1);
                        String filterValue = readDotPath(arrayItem, remainingFilterPath);
                        if (filterValue != null && filter.values.contains(filterValue.trim())) {
                            // This is the matching element, now read the requested field from it
                            String remainingPath = path.startsWith(filterArrayField + "[0].")
                                ? path.substring((filterArrayField + "[0].").length())
                                : path.substring((filterArrayField + ".").length());
                            return readDotPath(arrayItem, remainingPath);
                        }
                    }
                }
            }
        }

        // Fall back to regular readDotPath
        return readDotPath(node, path);
    }

    private String readDotPath(JsonNode node, String path) {
        if (path == null || path.isBlank()) {
            return null;
        }
        String[] parts = path.split("\\.");
        JsonNode cur = node;
        for (String p : parts) {
            if (cur == null) {
                return null;
            }

            // Handle array index notation like "securityInvolvement[0]"
            if (p.contains("[") && p.contains("]")) {
                int bracketIndex = p.indexOf('[');
                String fieldName = p.substring(0, bracketIndex);
                String indexStr = p.substring(bracketIndex + 1, p.indexOf(']'));
                int index = Integer.parseInt(indexStr);

                cur = cur.get(fieldName);
                if (cur != null && cur.isArray() && index < cur.size()) {
                    cur = cur.get(index);
                } else {
                    return null;
                }
            } else {
                cur = cur.get(p);
            }
        }
        if (cur == null || cur.isNull()) {
            return null;
        }
        if (cur.isValueNode()) {
            return cur.asText();
        }
        return cur.toString();
    }

    private JsonNode readNode(JsonNode node, String path) {
        if (path == null || path.isBlank()) {
            return null;
        }
        String[] parts = path.split("\\.");
        JsonNode cur = node;
        for (String p : parts) {
            if (cur == null) {
                return null;
            }
            cur = cur.get(p);
        }
        return cur;
    }

    private String applyFormat(String v, String fmt) {
        if (fmt == null || fmt.isBlank()) {
            return v;
        }
        switch (fmt) {
            case "date_ddMMyyyy": {
                // input yyyy-MM-dd
                LocalDate d = LocalDate.parse(v);
                return d.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            }
            case "timestamp_yyyyMMddHHmmssSSSSSS": {
                // assume already formatted or ISO-like; keep passthrough for simplicity
                return v.replaceAll("[^0-9]", "");
            }
            case "decimal": {
                return v.replaceAll(",", "");
            }
            default:
                return v;
        }
    }

    // Create nodes along XPath under given parent
    private Element pathEnsure(Document doc, Element parent, String xpath) {
        // simplistic: split by '/', ignore empty, attributes handled at leaf by writeXPathValue
        String[] parts = xpath.split("/");
        Element cur = parent;
        for (String p : parts) {
            if (p == null || p.isBlank()) {
                continue;
            }
            // simple element name without predicates
            String name = p.replaceAll("\\[.*?\\]", "");
            NodeList lst = cur.getElementsByTagName(name);
            Element next = null;
            // ensure direct child only
            for (int i = 0; i < lst.getLength(); i++) {
                Node n = lst.item(i);
                if (n.getParentNode() == cur) {
                    next = (Element) n;
                    break;
                }
            }
            if (next == null) {
                next = doc.createElement(name);
                cur.appendChild(next);
            }
            cur = next;
        }
        return cur;
    }

    // Write value at XPath relative to the given base element
    private void writeXPathValue(Document doc, Element base, String xpath, String value) {
        if (xpath == null || xpath.isBlank()) {
            return;
        }
        // Handle @index='1' attribute hints by setting after element creation
        String cleaned = xpath.replaceAll("\\[@index='(\\d+)'\\]", "");
        Element targetParent = pathEnsure(doc, base, cleaned);
        // Find last tag name to set text
        String[] parts = cleaned.split("/");
        String lastTag = null;
        for (int i = parts.length - 1; i >= 0; i--) {
            if (!parts[i].isBlank()) {
                lastTag = parts[i].replaceAll("\\[.*?\\]", "");
                break;
            }
        }
        if (lastTag != null) {
            // set text on the lastTag node (the ensured element itself)
            targetParent.setTextContent(value);
        }
        // Apply index attribute if present
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\[@index='(\\d+)'\\]").matcher(xpath);
        if (m.find()) {
            targetParent.setAttribute("index", m.group(1));
        }
    }

    // Write value at XPath with optional index attribute (for array child elements)
    private void writeXPathValueWithIndex(Document doc, Element base, String xpath, String value, String indexAttr,
            int indexValue) {
        if (xpath == null || xpath.isBlank()) {
            return;
        }
        Element targetParent = pathEnsure(doc, base, xpath);
        targetParent.setTextContent(value);
        // If indexAttribute is specified, add it to the child element
        if (indexAttr != null && !indexAttr.isBlank()) {
            targetParent.setAttribute(indexAttr, String.valueOf(indexValue));
        }
    }

    // Check if a JSON node matches the filter criteria
    // Handles both simple fields and array fields (checks if ANY array item matches)
    private boolean matchesFilter(JsonNode item, MappingSpec.ArrayMap.ArrayFilter filter) {
        if (filter == null || filter.field == null || filter.values == null || filter.values.isEmpty()) {
            return true; // no filter means include all
        }

        // Parse the filter field to handle array notation
        // e.g., "securityInvolvement.involvementRole" should check ALL items in securityInvolvement array
        String[] parts = filter.field.split("\\.");
        JsonNode current = item;

        for (int i = 0; i < parts.length; i++) {
            String part = parts[i];
            if (current == null) {
                return false;
            }

            current = current.get(part);

            // If current is an array and we have more path parts, we need to check ALL array items
            if (current != null && current.isArray() && i < parts.length - 1) {
                // Build remaining path
                String remainingPath = String.join(".", java.util.Arrays.copyOfRange(parts, i + 1, parts.length));

                // Check if ANY item in the array matches
                for (int j = 0; j < current.size(); j++) {
                    JsonNode arrayItem = current.get(j);
                    String value = readDotPath(arrayItem, remainingPath);
                    if (value != null && matchesFilterValue(value, filter.values)) {
                        return true;
                    }
                }
                return false; // None of the array items matched
            }
        }

        // Simple field case (not in array)
        if (current == null || current.isNull()) {
            return false;
        }
        String fieldValue = current.isValueNode() ? current.asText() : null;
        if (fieldValue == null) {
            return false;
        }

        return matchesFilterValue(fieldValue, filter.values);
    }

    // Helper to check if a value matches any of the filter values
    private boolean matchesFilterValue(String value, List<String> filterValues) {
        for (String filterValue : filterValues) {
            if (value.trim().equals(filterValue.trim())) {
                return true;
            }
        }
        return false;
    }


    public SecurityResponse transformFromXml(String serviceName, String operation, String xmlResponse) throws Exception {
        // Parse error node first
        XMLParser parser = new XMLParser(xmlResponse);

        String errorCode = parser.getValue("//errorNode/errorCode");
        if (!"1".equals(errorCode)) {
            String errorMsg = parser.getValue("//errorNode/errorMsg");
            throw new Exception(errorCode + "-" + errorMsg,
                    new Exception("Error Code is not equal to 1."));
        }

        // Extract response fields
        SecurityResponse response = new SecurityResponse();

        String itemNumber = parser.getValue("//Field[@name='A0ITEM_NUMBER_RESP']/Value");
        response.setCollateInternalId(itemNumber);

        return response;
    }
}


