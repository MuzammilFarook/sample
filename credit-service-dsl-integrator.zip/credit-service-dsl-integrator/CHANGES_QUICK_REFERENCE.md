# Quick Reference: JSON Structure Change

---

## 🔄 What Changed?

The JSON field name changed from `securityInvolvementList` to `securityInvolvement`, and the structure changed from array of strings to array of objects.

---

## 📋 Old vs New

### ❌ OLD (Stop Using)
```json
{
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvementList": ["BENEFJOIN", "BORROWJOIN", "LIFEASSURE"]
    }
  ]
}
```

### ✅ NEW (Use This)
```json
{
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvement": [
        { "involvementRole": "BENEFJOIN", "involvementType": "SECUR" },
        { "involvementRole": "BORROWJOIN", "involvementType": "SECUR" },
        { "involvementRole": "LIFEASSURE", "involvementType": "SECUR" }
      ]
    }
  ]
}
```

---

## 📁 Files Changed

### YAML Mapping Files (8 files)
| File | Service | Status |
|------|---------|--------|
| `SecuritiesService003_create.yaml` | Letter of Guarantee | ✅ Updated |
| `SecuritiesService003_update.yaml` | Letter of Guarantee | ✅ Updated |
| `SecuritiesService004_create.yaml` | Assignment of Life | ✅ Updated |
| `SecuritiesService004_update.yaml` | Assignment of Life | ✅ Updated |
| `SecuritiesService006_create.yaml` | Counter Indemnity | ✅ Already Correct |
| `SecuritiesService006_update.yaml` | Counter Indemnity | ✅ Already Correct |
| `SecuritiesService042_create.yaml` | Letter of Pledge | ✅ Updated |
| `SecuritiesService042_update.yaml` | Letter of Pledge | ✅ Updated |

### Java Code
| Component | Changes |
|-----------|---------|
| `MappingEngine.java` | ✅ No Changes (already handles this) |
| All other Java files | ✅ No Changes |

---

## 🎯 Impact

### For Consuming Team
- **Action Required:** Update JSON payloads to new structure
- **Breaking Change:** Yes
- **Backward Compatible:** No

### For Transformer Service
- **Code Changes:** Configuration only (YAML files)
- **Logic Changes:** None
- **Deployment:** Simple config update

---

## 📊 Comparison Table

| Aspect | Old Structure | New Structure |
|--------|--------------|---------------|
| Field Name | `securityInvolvementList` | `securityInvolvement` |
| Data Type | Array of Strings | Array of Objects |
| Example Element | `"BENEFJOIN"` | `{"involvementRole": "BENEFJOIN", "involvementType": "SECUR"}` |
| Flexibility | Low | High |
| Extensibility | Limited | Supports additional metadata |

---

## 🧪 Test Cases

### Test 1: Single Role
```json
"securityInvolvement": [
  { "involvementRole": "BENEFJOIN", "involvementType": "SECUR" }
]
```
**Result:** CIF appears in BENOWN_INV_GROUP only

### Test 2: Multiple Roles
```json
"securityInvolvement": [
  { "involvementRole": "BENEFJOIN", "involvementType": "SECUR" },
  { "involvementRole": "BORROWJOIN", "involvementType": "SECUR" }
]
```
**Result:** CIF appears in both BENOWN_INV_GROUP and BORROWCUST_INV_GROUP

### Test 3: No Matching Roles
```json
"securityInvolvement": [
  { "involvementRole": "OTHERPERSON", "involvementType": "SECUR" }
]
```
**Result:** All groups have count=0, empty containers created

---

## 🚀 Rollback

If needed, run:
```bash
cd src/main/resources/mappings
sed -i 's/securityInvolvement\.involvementRole/securityInvolvementList.involvementRole/g' \
  SecuritiesService003_*.yaml \
  SecuritiesService004_*.yaml \
  SecuritiesService042_*.yaml
```

---

## ✅ Verification

Check updates applied:
```bash
grep -r "securityInvolvementList" src/main/resources/mappings/*.yaml
```
Should return: **No results**

Check new structure:
```bash
grep -r "securityInvolvement\.involvementRole" src/main/resources/mappings/*.yaml
```
Should return: **Multiple matches** (14+ lines)

---

## 📞 Questions?

- Check `CODE_CHANGES_SUMMARY.md` for detailed changes
- Check `FIELD_MAPPINGS.md` for complete field mappings
- Check `LLD_Securities_transformer.MD` for system design

---
