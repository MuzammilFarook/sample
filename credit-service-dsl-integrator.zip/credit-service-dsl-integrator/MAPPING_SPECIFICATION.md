# JSON to XML Mapping Specification
## Securities Transformer - Priority Security Types

---

## Document Information

| Field | Value |
|-------|-------|
| Project Name | Securities Transformer - Credit Service DSL Integrator |
| Version | 1.0 |
| Date | December 4, 2025 |
| Purpose | Detailed JSON to XML mapping for 5 priority security types |

---

## Table of Contents

1. [Overview](#overview)
2. [Common Mapping Patterns](#common-mapping-patterns)
3. [Assignment of Life Policy (SecuritiesService004)](#1-assignment-of-life-policy-securitiesservice004)
4. [Letter of Guarantee (SecuritiesService003)](#2-letter-of-guarantee-securitiesservice003)
5. [Miscellaneous (SecuritiesService039)](#3-miscellaneous-securitiesservice039)
6. [Counter Indemnity (SecuritiesService006)](#4-counter-indemnity-securitiesservice006)
7. [Letter of Pledge (SecuritiesService042)](#5-letter-of-pledge-securitiesservice042)
8. [Appendix: Common Enumerations](#appendix-common-enumerations)

---

## Overview

This document provides detailed field-level mappings from JSON input (REST API) to XML output (legacy COLLATE system) for 5 priority security types. Each mapping includes:

- JSON field path (dot notation)
- XML XPath (with index attributes)
- Format transformations
- Required field indicators
- Sample values

### Mapping Notation

```
JSON Path → XML XPath [Format] {Required} = Sample Value
```

- **JSON Path**: Dot notation (e.g., `assignmentOfLife.policyNumber`)
- **XML XPath**: Relative to service root with `[@index='1']` attribute
- **[Format]**: Transformation applied (date_ddMMyyyy, timestamp, decimal)
- **{Required}**: Indicates mandatory field
- **= Sample**: Example value

---

## Common Mapping Patterns

### Envelope Fields (All Services)

These 12 fields are **constant** across all security types:

| XML XPath | Constant Value | Description |
|-----------|----------------|-------------|
| `Log` | `N` | Logging flag |
| `ID/version` | `1.0` | API version |
| `ID/AppID` | `NBP` | Application ID |
| `ID/AppName` | `SysTest_CAS_ROI_Current` | Application name |
| `ID/UsrID` | `5324654654` | User ID |
| `ID/UnqID` | `88140` | Unique ID |
| `regionCode` | `ROI` | Region code |
| `sourceNSC` | `931012` | Source NSC |
| `staffNumber` | `88140` | Staff number |
| `deviceId` | `` | Device ID (empty) |
| `Transaction` | `SecuritiesService00X` | Service name |
| `TransactionVersion` | `1` | Transaction version |

### Common Security Item Fields (All Services)

These fields exist in all 5 security types with identical mappings:

#### Core Identification Fields

```
JSON: securityItem.itemNumber
XML:  SecuritiesServiceXXX/ITEM_NUMBER[@index='1']
Note: Empty for CREATE, Required for UPDATE
```

```
JSON: securityItem.currentStatus
XML:  SecuritiesServiceXXX/CURRENT_STATUS[@index='1']
Values: APFH, APPR, APRE, EXIO, EXNA, EXSR, HEEX, IDRU, NENF, OTAD, OTCU, OTLA, TKAP, RELE
```

```
Constant: "SECURITY_TYPE_VALUE"
XML: SecuritiesServiceXXX/SECURITY_TYPE[@index='1']
Note: Service-specific (LIFE POL, GUARANTEE, MISCELL, INDEMNITY, PLEDGE)
```

#### Stamping Fields (17 fields - All empty or "0" for CREATE)

```
XML: SecuritiesServiceXXX/STAMPED_TYPE[@index='1']
XML: SecuritiesServiceXXX/STAMPING_REQUIRED[@index='1']
XML: SecuritiesServiceXXX/STAMPING_REQUIRED_DATE[@index='1']
XML: SecuritiesServiceXXX/STAMPED_AMOUNT[@index='1']
XML: SecuritiesServiceXXX/STAMPING_CURRENCY[@index='1']
XML: SecuritiesServiceXXX/STAMPED_DATE[@index='1']
XML: SecuritiesServiceXXX/ADDITIONAL_STAMPING_REQUIRED[@index='1']
XML: SecuritiesServiceXXX/ADDITIONAL_STAMPING_DATE[@index='1']
XML: SecuritiesServiceXXX/ADDITIONAL_STAMPING_AMT[@index='1']
XML: SecuritiesServiceXXX/ADDITIONAL_STAMPING_CURRENCY[@index='1']
XML: SecuritiesServiceXXX/STAMP_UP_DATE[@index='1']
XML: SecuritiesServiceXXX/ADDITIONAL_STAMPING_TYPE[@index='1']
XML: SecuritiesServiceXXX/STAMPING_STATUS[@index='1']
```

#### SLA and Currency Fields

```
JSON: securityItem.slaCode
XML:  SecuritiesServiceXXX/SLA_CODE[@index='1']
Values: A0, H0, L0, N0, S0
```

```
Constant: "EUR"
XML: SecuritiesServiceXXX/CURRENCY_TYPE[@index='1']
```

#### Company Office Fields

```
XML: SecuritiesServiceXXX/CO_OFFICE_SENT_FOR_REG_DATE[@index='1']
XML: SecuritiesServiceXXX/CO_OFFICE_REGISTERED_DATE[@index='1']
XML: SecuritiesServiceXXX/RELEASE_DATE[@index='1']
Note: Empty for CREATE, "0" for UPDATE
```

#### Restrictions Fields (9 fields)

```
XML: SecuritiesServiceXXX/RESTRICTIONS_FACILITY_ACC_TYPE[@index='1']
XML: SecuritiesServiceXXX/RESTRICTIONS_FACILITY_AMOUNT[@index='1']
XML: SecuritiesServiceXXX/RESTRICTIONS_FACILITY_CURR[@index='1']
XML: SecuritiesServiceXXX/REST_INSURANCE_CO_CONTACT_NAME[@index='1']
XML: SecuritiesServiceXXX/RESTRICTIONS_INSURANCE_ID[@index='1']
XML: SecuritiesServiceXXX/RESTRICTIONS_POLICY_NUMBER[@index='1']
XML: SecuritiesServiceXXX/RESTRICTIONS_PROPERTY_ADDRESS[@index='1']
XML: SecuritiesServiceXXX/RESTRICTIONS_DETAILS[@index='1']
XML: SecuritiesServiceXXX/RESTRICTIONS_CEILING_ALLSUMS_AMT[@index='1']
XML: SecuritiesServiceXXX/RESTRICTIONS_CEILING_ALLSUM_CURR[@index='1']
```

#### Miscellaneous Fields

```
XML: SecuritiesServiceXXX/SOLR_FILE_REF_NO[@index='1']
Constant: "0"
XML: SecuritiesServiceXXX/POS_NOTES[@index='1']
XML: SecuritiesServiceXXX/SO_NOTES[@index='1']
XML: SecuritiesServiceXXX/COMPANY_INDICATOR[@index='1']
XML: SecuritiesServiceXXX/BARCODE_NUMBER[@index='1']
```

#### Audit Fields (CREATE - Empty, UPDATE - Populated)

```
JSON: audit.lastUpdatedTimestamp
XML:  SecuritiesServiceXXX/LAST_UPDATED_TIMESTAMP[@index='1']
Format: timestamp_yyyyMMddHHmmssSSSSSS
Example: 20250729102911104000
```

```
JSON: audit.lastUpdatedBy
XML:  SecuritiesServiceXXX/LAST_UPDATED_BY[@index='1']
```

```
JSON: audit.createdTimestamp
XML:  SecuritiesServiceXXX/CREATED_TIMESTAMP[@index='1']
Format: timestamp_yyyyMMddHHmmssSSSSSS
```

```
JSON: audit.createdBy
XML:  SecuritiesServiceXXX/CREATED_BY[@index='1']
```

```
JSON: securityItem.setDate
XML:  SecuritiesServiceXXX/SET_DATE[@index='1']
Format: date_ddMMyyyy
```

#### Valuation Fields

```
JSON: valuation.amount OR securityItem.valuation.amount
XML:  SecuritiesServiceXXX/VALUATION_AMOUNT[@index='1']
Format: decimal (removes commas)
Example: "1,234.56" → "1234.56"
```

```
JSON: valuation.valuationCurrency OR securityItem.valuation.currency
XML:  SecuritiesServiceXXX/VALUATION_CURRENCY[@index='1']
Example: "EUR"
```

```
JSON: valuation.valuationDate OR securityItem.valuation.date
XML:  SecuritiesServiceXXX/VALUATION_DATE[@index='1']
Format: date_ddMMyyyy
Example: "2025-07-29" → "29/07/2025"
```

```
JSON: valuation.valuationBasis OR securityItem.valuation.by
XML:  SecuritiesServiceXXX/VALUATION_BY[@index='1']
Values: IRDU, CUST, INSU, LEND
```

#### NAPS Application ID

```
JSON: securityItem.napsAppId
XML:  SecuritiesServiceXXX/NAPS_APP_ID[@index='1']
Example: "14024080"
```

### Common Involvement Groups (All Services)

#### BENOWN_INV_GROUP (Beneficial Owners)

**Filter:** `securityInvolvementList.involvementRole` IN (`BENEFJOIN`, `BENEFSOLE`)

```
JSON Source: custSecurities[]
XML Count:   SecuritiesServiceXXX/BENOWN_INV_GROUP
XML Container: SecuritiesServiceXXX/BenOwnInvGroup
```

**Mappings per listitem:**

| JSON Path | XML XPath | Value | Description |
|-----------|-----------|-------|-------------|
| (constant) | `BENOWN_INV_COMPANY_INDICATOR[@index]` | ` ` (space) | Company indicator |
| (constant) | `BENOWN_RELATIONSHIP_QUALITY_CODE[@index]` | ` ` (space) | Relationship quality |
| (constant) | `BENOWN_HELD_ON_CIF_INDICATOR[@index]` | `Y` | CIF indicator |
| (constant) | `BENOWN_INVOLVEMENT_TYPE[@index]` | `SECUR` | Involvement type |
| (constant) | `BENOWN_INVOLVEMENT_ROLE[@index]` | `BENEFJOIN ` | Role (with trailing space) |
| `cifKey` | `BENOWN_CIF_REF_NUMBER[@index]` | - | CIF reference |
| (constant) | `BENOWN_COMPANY_ID[@index]` | `000000000000000` | Company ID |

**Example:**
```xml
<BENOWN_INV_GROUP>2</BENOWN_INV_GROUP>
<BenOwnInvGroup>
    <listitem index="0">
        <BENOWN_INV_COMPANY_INDICATOR index="0"> </BENOWN_INV_COMPANY_INDICATOR>
        <BENOWN_HELD_ON_CIF_INDICATOR index="0">Y</BENOWN_HELD_ON_CIF_INDICATOR>
        <BENOWN_INVOLVEMENT_TYPE index="0">SECUR</BENOWN_INVOLVEMENT_TYPE>
        <BENOWN_INVOLVEMENT_ROLE index="0">BENEFJOIN </BENOWN_INVOLVEMENT_ROLE>
        <BENOWN_CIF_REF_NUMBER index="0">0100000938437104000</BENOWN_CIF_REF_NUMBER>
        <BENOWN_COMPANY_ID index="0">000000000000000</BENOWN_COMPANY_ID>
    </listitem>
</BenOwnInvGroup>
```

#### BORROWCUST_INV_GROUP (Borrowers)

**Filter:** `securityInvolvementList.involvementRole` IN (`BORROWJOIN`, `BORROWSOLE`)

```
JSON Source: custSecurities[]
XML Count:   SecuritiesServiceXXX/BORROWCUST_INV_GROUP
XML Container: SecuritiesServiceXXX/BorrowCustInvGroup
```

**Mappings per listitem:**

| JSON Path | XML XPath | Value | Description |
|-----------|-----------|-------|-------------|
| (constant) | `BORROWCUST_INV_COMPANY_INDICATOR[@index]` | ` ` (space) | Company indicator |
| (constant) | `BORROWCUST_RELATIONSHIP_QUALITY_CODE[@index]` | ` ` (space) | Relationship quality |
| (constant) | `BORROWCUST_HELD_ON_CIF_INDICATOR[@index]` | `Y` | CIF indicator |
| (constant) | `BORROWCUST_INVOLVEMENT_TYPE[@index]` | `SECUR` | Involvement type |
| (constant) | `BORROWCUST_INVOLVEMENT_ROLE[@index]` | `BORROWJOIN` | Role (no trailing space) |
| `cifKey` | `BORROWCUST_CIF_REF_NUMBER[@index]` | - | CIF reference |
| (constant) | `BORROWCUST_COMPANY_ID[@index]` | `000000000000000` | Company ID |

---

## 1. Assignment of Life Policy (SecuritiesService004)

### 1.1 Service Configuration

```yaml
Service ID:       SecuritiesService004
Operation:        create | update
Transaction:      SecuritiesService004
Security Type:    LIFE POL
servType500:      C (create) | U (update)
source500:        NAPS
```

### 1.2 Input JSON Structure

```json
{
  "assignmentOfLife": {
    "policyType": "KEY",
    "policyNumber": "45677",
    "sumAssured": "56678",
    "expiryDate": "2025-07-30",
    "assignmentDate": "2025-07-29",
    "eventWhenPayble": "DEAT",
    "insuranceId": "1022"
  },
  "securityItem": {
    "itemNumber": "61175051",
    "currentStatus": "OTLA",
    "assuranceCode": "1022",
    "solicitorCode": "SOL001",
    "napsAppId": "14024080",
    "slaCode": "N0"
  },
  "valuation": {
    "amount": "3000",
    "valuationCurrency": "EUR",
    "valuationDate": "2025-07-29",
    "valuationBasis": "IRDU"
  },
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvementList": [
        {"involvementRole": "BENEFJOIN"},
        {"involvementRole": "BORROWJOIN"},
        {"involvementRole": "LIFEASSURE"}
      ]
    }
  ],
  "audit": {
    "lastUpdatedTimestamp": "2025-07-28T16:55:36.083698",
    "lastUpdatedBy": "86070",
    "createdTimestamp": "2025-07-28T11:16:55.252939",
    "createdBy": "57611"
  }
}
```

### 1.3 Life Policy Specific Mappings

#### Service Header

```
Constant: "C"
XML: SecuritiesService004/servType500
Note: "U" for UPDATE
```

```
Constant: "NAPS"
XML: SecuritiesService004/source500
```

```
Constant: "LIFE POL"
XML: SecuritiesService004/SECURITY_TYPE[@index='1']
```

#### Life Policy Fields

```
JSON: assignmentOfLife.policyType
XML:  SecuritiesService004/POLICY_TYPE[@index='1']
Values: ENDW, INVT, KEY, MORT, PIP, PREM, SURP, TERM, TRAK, WHOL
Example: "KEY"
```

```
JSON: assignmentOfLife.policyNumber
XML:  SecuritiesService004/POLICY_NUMBER[@index='1']
Max Length: 20
Example: "45677"
```

```
JSON: assignmentOfLife.eventWhenPayble
XML:  SecuritiesService004/EVENT_WHEN_PAYABLE[@index='1']
Values: BEFR, DEAT, MATU
Example: "" (often empty)
```

```
JSON: assignmentOfLife.sumAssured
XML:  SecuritiesService004/SUM_ASSURED[@index='1']
Max Length: 15
Example: "56678"
```

```
JSON: assignmentOfLife.expiryDate
XML:  SecuritiesService004/LIFEPOL_EXPIRY_DATE[@index='1']
Format: date_ddMMyyyy
Example: "2025-07-30" → "30/07/2025"
```

```
Constant: "" (CREATE) | "00/00/0000" (UPDATE)
XML: SecuritiesService004/ASSIGNMENT_DATE[@index='1']
```

```
Constant: "" (CREATE) | timestamp (UPDATE)
JSON: assignmentOfLife.lastUpdatedTimestamp
XML:  SecuritiesService004/LIFEPOL_LAST_UPDATED_TIMESTAMP[@index='1']
Format: timestamp_yyyyMMddHHmmssSSSSSS
Example: "20250728165536085515"
```

```
Constant: ""
XML: SecuritiesService004/PARENT_GUARANTEE_ITEM[@index='1']
```

#### Insurance Company

```
JSON: securityItem.assuranceCode
XML:  SecuritiesService004/ASSURANCE_CO_CODE[@index='1']
Example: "1022", "1001"
```

```
JSON: securityItem.solicitorCode
XML:  SecuritiesService004/SOLICITOR_CODE[@index='1']
Example: "" (often empty)
```

### 1.4 Life Assured Involvement Group (UNIQUE TO SERVICE004)

**Filter:** `securityInvolvementList.involvementRole` = `LIFEASSURE`

```
JSON Source: custSecurities[]
XML Count:   SecuritiesService004/LIFEASSURE_INV_GROUP
XML Container: SecuritiesService004/LifeAssureInvGroup
```

**Mappings per listitem:**

| JSON Path | XML XPath | Value |
|-----------|-----------|-------|
| (constant) | `LIFEASSURE_INV_COMPANY_INDICATOR[@index]` | ` ` |
| (constant) | `LIFEASSURE_RELATIONSHIP_QUALITY_CODE[@index]` | ` ` |
| (constant) | `LIFEASSURE_HELD_ON_CIF_INDICATOR[@index]` | `Y` |
| (constant) | `LIFEASSURE_INVOLVEMENT_TYPE[@index]` | `SECUR` |
| (constant) | `LIFEASSURE_INVOLVEMENT_ROLE[@index]` | `LIFEASSURE` |
| `cifKey` | `LIFEASSURE_CIF_REF_NUMBER[@index]` | - |
| (constant) | `LIFEASSURE_COMPANY_ID[@index]` | `000000000000000` |

**Example:**
```xml
<LIFEASSURE_INV_GROUP>2</LIFEASSURE_INV_GROUP>
<LifeAssureInvGroup>
    <listitem index="0">
        <LIFEASSURE_INV_COMPANY_INDICATOR index="0"> </LIFEASSURE_INV_COMPANY_INDICATOR>
        <LIFEASSURE_HELD_ON_CIF_INDICATOR index="0">Y</LIFEASSURE_HELD_ON_CIF_INDICATOR>
        <LIFEASSURE_INVOLVEMENT_TYPE index="0">SECUR</LIFEASSURE_INVOLVEMENT_TYPE>
        <LIFEASSURE_INVOLVEMENT_ROLE index="0">LIFEASSURE</LIFEASSURE_INVOLVEMENT_ROLE>
        <LIFEASSURE_CIF_REF_NUMBER index="0">0100000938437104000</LIFEASSURE_CIF_REF_NUMBER>
        <LIFEASSURE_COMPANY_ID index="0">000000000000000</LIFEASSURE_COMPANY_ID>
    </listitem>
</LifeAssureInvGroup>
```

### 1.5 Empty Involvement Groups

```
JSON Source: signedByInvolvements (empty array)
XML Count:   SecuritiesService004/SIGNEDBY_INV_GROUP = "0"
XML Container: SecuritiesService004/SignedByInvGroup (empty element)
```

```
JSON Source: companyInvolvements (empty array)
XML Count:   SecuritiesService004/COMPANY_INV_GROUP = "0"
XML Container: SecuritiesService004/CompanyInvGroup (empty element)
```

```
JSON Source: trusteeInvolvements (empty array)
XML Count:   SecuritiesService004/TRUSTEE_INV_GROUP = "0"
XML Container: SecuritiesService004/TrusteeInvGroup (empty element)
```

### 1.6 NAPS Group

```
JSON Source: napsDetails[]
XML Count:   SecuritiesService004/NAPS_GROUP
XML Container: SecuritiesService004/ApplicationIDList001
Note: Usually empty, count = 0
```

### 1.7 Complete XML Output Example (CREATE)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<Request>
    <Log>N</Log>
    <ID>
        <version>1.0</version>
        <AppID>NBP</AppID>
        <AppName>SysTest_CAS_ROI_Current</AppName>
        <UsrID>5324654654</UsrID>
        <UnqID>88140</UnqID>
    </ID>
    <regionCode>ROI</regionCode>
    <sourceNSC>931012</sourceNSC>
    <staffNumber>88140</staffNumber>
    <deviceId></deviceId>
    <Transaction>SecuritiesService004</Transaction>
    <TransactionVersion>1</TransactionVersion>

    <SecuritiesService004>
        <servType500>C</servType500>
        <source500>NAPS</source500>

        <!-- Core Fields -->
        <ITEM_NUMBER index="1"></ITEM_NUMBER>
        <VL_REGISTERED_OWNER index="1"></VL_REGISTERED_OWNER>
        <CURRENT_STATUS index="1">OTLA</CURRENT_STATUS>
        <SECURITY_TYPE index="1">LIFE POL</SECURITY_TYPE>

        <!-- Life Policy Specific -->
        <POLICY_TYPE index="1">KEY</POLICY_TYPE>
        <POLICY_NUMBER index="1">45677</POLICY_NUMBER>
        <SUM_ASSURED index="1">56678</SUM_ASSURED>
        <LIFEPOL_EXPIRY_DATE index="1">30/07/2025</LIFEPOL_EXPIRY_DATE>
        <ASSURANCE_CO_CODE index="1">1022</ASSURANCE_CO_CODE>
        <NAPS_APP_ID index="1">14024080</NAPS_APP_ID>

        <!-- Valuation -->
        <VALUATION_AMOUNT index="1">3000</VALUATION_AMOUNT>
        <VALUATION_CURRENCY index="1">EUR</VALUATION_CURRENCY>
        <VALUATION_DATE index="1">29/07/2025</VALUATION_DATE>
        <VALUATION_BY index="1">IRDU</VALUATION_BY>

        <!-- Involvement Groups -->
        <BENOWN_INV_GROUP>2</BENOWN_INV_GROUP>
        <BenOwnInvGroup>
            <listitem index="0">
                <BENOWN_CIF_REF_NUMBER index="0">0100000932437490000</BENOWN_CIF_REF_NUMBER>
                <!-- ... other fields ... -->
            </listitem>
            <listitem index="1">
                <BENOWN_CIF_REF_NUMBER index="1">0100000938437104000</BENOWN_CIF_REF_NUMBER>
                <!-- ... other fields ... -->
            </listitem>
        </BenOwnInvGroup>

        <BORROWCUST_INV_GROUP>2</BORROWCUST_INV_GROUP>
        <BorrowCustInvGroup>
            <!-- Similar structure -->
        </BorrowCustInvGroup>

        <LIFEASSURE_INV_GROUP>2</LIFEASSURE_INV_GROUP>
        <LifeAssureInvGroup>
            <!-- Similar structure -->
        </LifeAssureInvGroup>

        <SIGNEDBY_INV_GROUP>0</SIGNEDBY_INV_GROUP>
        <SignedByInvGroup></SignedByInvGroup>

        <COMPANY_INV_GROUP>0</COMPANY_INV_GROUP>
        <CompanyInvGroup></CompanyInvGroup>

        <TRUSTEE_INV_GROUP>0</TRUSTEE_INV_GROUP>
        <TrusteeInvGroup></TrusteeInvGroup>

        <NAPS_GROUP>0</NAPS_GROUP>
        <ApplicationIDList001></ApplicationIDList001>
    </SecuritiesService004>
</Request>
```

---

## 2. Letter of Guarantee (SecuritiesService003)

### 2.1 Service Configuration

```yaml
Service ID:       SecuritiesService003
Operation:        create | update
Transaction:      SecuritiesService003
Security Type:    GUARANTEE
servType500:      C (create) | U (update)
source500:        NAPS
```

### 2.2 Input JSON Structure

```json
{
  "letterOfGuarantee": {
    "guaranteeDate": "2025-07-29",
    "guaranteeAmount": 6000,
    "supportedOrUnsupported": "S",
    "guaranteeType": "PSTD",
    "letterOfWaiverIndicator": "0",
    "relationshipType": "DIR"
  },
  "securityItem": {
    "itemNumber": "84774748",
    "currentStatus": "OTLA",
    "solicitorCode": "SOL001",
    "solicitorCompanyName": "ABC Solicitors",
    "assuranceCode": "",
    "napsAppId": "14024080",
    "slaCode": "N0",
    "companyIndicator": "2"
  },
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvementList": [
        {"involvementRole": "BENEFJOIN"},
        {"involvementRole": "BORROWJOIN"},
        {"involvementRole": "GUARANTOR"}
      ]
    }
  ],
  "supportingSecurity": [],
  "napsDetails": [],
  "accountDetails": []
}
```

### 2.3 Letter of Guarantee Specific Mappings

#### Service Header

```
Constant: "GUARANTEE"
XML: SecuritiesService003/SECURITY_TYPE[@index='1']
```

#### Guarantee Fields

```
JSON: letterOfGuarantee.guaranteeDate
XML:  SecuritiesService003/GUARANTEE_DATE[@index='1']
Format: date_ddMMyyyy
Example: "2025-07-29" → "29/07/2025" or "" for CREATE
```

```
JSON: letterOfGuarantee.guaranteeAmount
XML:  SecuritiesService003/GUARANTEE_AMOUNT[@index='1']
Format: decimal
Example: 6000 → "6000"
```

```
JSON: letterOfGuarantee.supportedOrUnsupported
XML:  SecuritiesService003/SUPPORTED_OR_UNSUPPORTED[@index='1']
Example: "S", "U"
```

```
JSON: letterOfGuarantee.guaranteeType
XML:  SecuritiesService003/GUARANTEE_TYPE[@index='1']
Values: PCCA, CSTD, CROI, CGLO, COMN, CSUM, MISC, PINT, MINT, PRES, PROI, PSTD, MRBK, PALL
Example: "PSTD"
```

```
JSON: letterOfGuarantee.letterOfWaiverIndicator
XML:  SecuritiesService003/LETTER_OF_WAIVER_INDICATOR[@index='1']
Values: "0", "1"
Example: ""
```

```
JSON: letterOfGuarantee.relationshipType
XML:  SecuritiesService003/RELATIONSHIP_TYPE[@index='1']
Values: DIR, FAMY, OTHR, PASU, SPSE
Example: "DIR"
```

```
Constant: "" (CREATE) | timestamp (UPDATE)
XML: SecuritiesService003/GUARANTEE_LAST_UPDATED_TIMESTAMP[@index='1']
Format: timestamp_yyyyMMddHHmmssSSSSSS
```

#### Solicitor Fields

```
JSON: securityItem.solicitorCode
XML:  SecuritiesService003/SOLICITOR_CODE[@index='1']
Example: ""
```

```
JSON: securityItem.solicitorCompanyName
XML:  SecuritiesService003/SOLICITOR_COMPANY_NAME[@index='1']
Example: ""
```

```
JSON: securityItem.assuranceCode
XML:  SecuritiesService003/ASSURANCE_CO_CODE[@index='1']
Example: ""
```

```
JSON: securityItem.companyIndicator
XML:  SecuritiesService003/COMPANY_INDICATOR[@index='1']
Values: "1", "2"
Example: "2"
```

### 2.4 Guarantor Involvement Group (UNIQUE TO SERVICE003)

**Filter:** `securityInvolvementList.involvementRole` = `GUARANTOR`

```
JSON Source: custSecurities[]
XML Count:   SecuritiesService003/GUARANTOR_INV_GROUP
XML Container: SecuritiesService003/GuarantorInvGroup
```

**Mappings per listitem:**

| JSON Path | XML XPath | Value |
|-----------|-----------|-------|
| (constant) | `GUARANTOR_INV_COMPANY_INDICATOR[@index]` | ` ` |
| (constant) | `GUARANTOR_RELATIONSHIP_QUALITY_CODE[@index]` | ` ` |
| (constant) | `GUARANTOR_HELD_ON_CIF_INDICATOR[@index]` | `Y` |
| (constant) | `GUARANTOR_INVOLVEMENT_TYPE[@index]` | `SECUR` |
| (constant) | `GUARANTOR_INVOLVEMENT_ROLE[@index]` | `GUARANTOR ` (with trailing space) |
| `cifKey` | `GUARANTOR_CIF_REF_NUMBER[@index]` | - |
| (constant) | `GUARANTOR_COMPANY_ID[@index]` | `000000000000000` |

**Example:**
```xml
<GUARANTOR_INV_GROUP>1</GUARANTOR_INV_GROUP>
<GuarantorInvGroup>
    <listitem index="0">
        <GUARANTOR_INV_COMPANY_INDICATOR index="0"> </GUARANTOR_INV_COMPANY_INDICATOR>
        <GUARANTOR_HELD_ON_CIF_INDICATOR index="0">Y</GUARANTOR_HELD_ON_CIF_INDICATOR>
        <GUARANTOR_INVOLVEMENT_TYPE index="0">SECUR</GUARANTOR_INVOLVEMENT_TYPE>
        <GUARANTOR_INVOLVEMENT_ROLE index="0">GUARANTOR </GUARANTOR_INVOLVEMENT_ROLE>
        <GUARANTOR_CIF_REF_NUMBER index="0">0100000931530161000</GUARANTOR_CIF_REF_NUMBER>
        <GUARANTOR_COMPANY_ID index="0">000000000000000</GUARANTOR_COMPANY_ID>
    </listitem>
</GuarantorInvGroup>
```

### 2.5 Supporting Securities Array

```
JSON Source: supportingSecurity[]
XML Count:   SecuritiesService003/SUPPORTING_SECURITIES
XML Container: SecuritiesService003/supportingSecurities
Note: Usually empty, count = 0
```

### 2.6 Empty Involvement Groups

```
JSON Source: signedByInvolvements
XML Count:   SecuritiesService003/SIGNEDBY_INV_GROUP = "0"
XML Container: SecuritiesService003/SignedByInvGroup (empty)
```

```
JSON Source: companyInvolvements
XML Count:   SecuritiesService003/COMPANY_INV_GROUP = "0"
XML Container: SecuritiesService003/CompanyInvGroup (empty)
```

### 2.7 Complete XML Output Example (CREATE)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<Request>
    <!-- Envelope (same as Service004) -->

    <SecuritiesService003>
        <servType500>C</servType500>
        <source500>NAPS</source500>

        <ITEM_NUMBER index="1"></ITEM_NUMBER>
        <CURRENT_STATUS index="1">OTLA</CURRENT_STATUS>
        <SECURITY_TYPE index="1">GUARANTEE</SECURITY_TYPE>

        <!-- Guarantee Specific -->
        <GUARANTEE_DATE index="1"></GUARANTEE_DATE>
        <GUARANTEE_AMOUNT index="1">6000</GUARANTEE_AMOUNT>
        <SUPPORTED_OR_UNSUPPORTED index="1"></SUPPORTED_OR_UNSUPPORTED>
        <GUARANTEE_TYPE index="1">PSTD</GUARANTEE_TYPE>
        <LETTER_OF_WAIVER_INDICATOR index="1"></LETTER_OF_WAIVER_INDICATOR>
        <RELATIONSHIP_TYPE index="1">DIR</RELATIONSHIP_TYPE>
        <COMPANY_INDICATOR index="1">2</COMPANY_INDICATOR>
        <NAPS_APP_ID index="1">14024080</NAPS_APP_ID>

        <!-- Involvement Groups -->
        <BENOWN_INV_GROUP>2</BENOWN_INV_GROUP>
        <BenOwnInvGroup><!-- ... --></BenOwnInvGroup>

        <BORROWCUST_INV_GROUP>2</BORROWCUST_INV_GROUP>
        <BorrowCustInvGroup><!-- ... --></BorrowCustInvGroup>

        <SIGNEDBY_INV_GROUP>0</SIGNEDBY_INV_GROUP>
        <SignedByInvGroup></SignedByInvGroup>

        <COMPANY_INV_GROUP>0</COMPANY_INV_GROUP>
        <CompanyInvGroup></CompanyInvGroup>

        <GUARANTOR_INV_GROUP>1</GUARANTOR_INV_GROUP>
        <GuarantorInvGroup>
            <listitem index="0">
                <GUARANTOR_CIF_REF_NUMBER index="0">0100000931530161000</GUARANTOR_CIF_REF_NUMBER>
                <!-- ... other fields ... -->
            </listitem>
        </GuarantorInvGroup>

        <NAPS_GROUP>0</NAPS_GROUP>
        <ApplicationIDList001></ApplicationIDList001>

        <SUPPORTING_SECURITIES>0</SUPPORTING_SECURITIES>
        <supportingSecurities></supportingSecurities>
    </SecuritiesService003>
</Request>
```

---

## 3. Miscellaneous (SecuritiesService039)

### 3.1 Service Configuration

```yaml
Service ID:       SecuritiesService039
Operation:        create | update
Transaction:      SecuritiesService039
Security Type:    MISCELL
servType500:      C (create) | U (update)
source500:        NAPS
```

### 3.2 Input JSON Structure

```json
{
  "miscellaneous": {
    "miscellaneousType": "CRED",
    "description": "xyz",
    "letterDate": "2025-07-29",
    "securityAmount": "5000",
    "expiryDate": "2025-08-30",
    "cancellationNoticePeriod": "30"
  },
  "securityItem": {
    "itemNumber": "",
    "currentStatus": "OTLA",
    "solicitorCode": "SOL001",
    "solicitorCompanyName": "ABC Solicitors",
    "napsAppId": "14024080",
    "slaCode": "",
    "companyIndicator": "2"
  },
  "valuation": {
    "amount": "7000",
    "valuationCurrency": "EUR",
    "valuationDate": "2025-07-29",
    "valuationBasis": "LEND"
  },
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvementList": [
        {"involvementRole": "BENEFJOIN"},
        {"involvementRole": "BORROWJOIN"},
        {"involvementRole": "SIGNEDSOLE"}
      ]
    }
  ],
  "audit": {
    "lastUpdatedTimestamp": "2003-12-03T10:51:00.482038"
  }
}
```

### 3.3 Miscellaneous Specific Mappings

#### Service Header

```
Constant: "MISCELL"
XML: SecuritiesService039/SECURITY_TYPE[@index='1']
```

#### Miscellaneous Fields

```
JSON: miscellaneous.letterDate
XML:  SecuritiesService039/MISC_LETTER_DATE[@index='1']
Format: date_ddMMyyyy
Example: ""
```

```
JSON: miscellaneous.securityAmount
XML:  SecuritiesService039/MISC_SECURITY_AMOUNT[@index='1']
Example: ""
```

```
JSON: miscellaneous.miscellaneousType
XML:  SecuritiesService039/MISCELLANEOUS_TYPE[@index='1']
Values: CRED, etc.
Example: "CRED"
```

```
JSON: miscellaneous.expiryDate
XML:  SecuritiesService039/MISCELL_EXPIRY_DATE[@index='1']
Format: date_ddMMyyyy
Example: ""
```

```
JSON: miscellaneous.description
XML:  SecuritiesService039/VL_MISC_DESCRIPTION[@index='1']
Example: "xyz"
```

```
JSON: miscellaneous.cancellationNoticePeriod
XML:  SecuritiesService039/MISC_CANCELLATION_NOTICE_PERIOD[@index='1']
Example: ""
```

```
Constant: "" (CREATE) | timestamp (UPDATE)
JSON: miscellaneous.lastUpdatedTimestamp
XML:  SecuritiesService039/MISC_LAST_UPDATED_TIMESTAMP[@index='1']
Format: timestamp_yyyyMMddHHmmssSSSSSS
```

```
Constant: ""
XML: SecuritiesService039/PARENT_GUARANTEE_ITEM[@index='1']
```

#### Solicitor Fields

```
JSON: securityItem.solicitorCode
XML:  SecuritiesService039/SOLR_CODE[@index='1']
Note: Different from SOLICITOR_CODE used in other services
Example: ""
```

```
JSON: securityItem.solicitorCompanyName
XML:  SecuritiesService039/SOLICITOR_COMPANY_NAME[@index='1']
Example: ""
```

```
JSON: securityItem.companyIndicator
XML:  SecuritiesService039/COMPANY_INDICATOR[@index='1']
Example: "2"
```

#### Audit Field (Unique Mapping)

```
JSON: audit.lastUpdatedTimestamp
XML:  SecuritiesService039/LAST_UPDATED_TIMESTAMP[@index='1']
Format: timestamp_yyyyMMddHHmmssSSSSSS
Example: "20031203105100482038"
Note: Sometimes shows historical dates
```

### 3.4 Signed By Involvement Group (POPULATED IN SERVICE039)

**Filter:** `securityInvolvementList.involvementRole` IN (`SIGNEDSOLE`, `SIGNEDJOIN`)

```
JSON Source: custSecurities[]
XML Count:   SecuritiesService039/SIGNEDBY_INV_GROUP
XML Container: SecuritiesService039/SignedByInvGroup
```

**Mappings per listitem:**

| JSON Path | XML XPath | Value |
|-----------|-----------|-------|
| (constant) | `SIGNEDBY_INV_COMPANY_INDICATOR[@index]` | ` ` |
| (constant) | `SIGNEDBY_RELATIONSHIP_QUALITY_CODE[@index]` | ` ` |
| (constant) | `SIGNEDBY_HELD_ON_CIF_INDICATOR[@index]` | `Y` |
| (constant) | `SIGNEDBY_INVOLVEMENT_TYPE[@index]` | `SECUR` |
| (constant) | `SIGNEDBY_INVOLVEMENT_ROLE[@index]` | `SIGNEDSOLE` or `SIGNEDJOIN` |
| `cifKey` | `SIGNEDBY_CIF_REF_NUMBER[@index]` | - |
| (constant) | `SIGNEDBY_COMPANY_ID[@index]` | `000000000000000` |

**Example:**
```xml
<SIGNEDBY_INV_GROUP>1</SIGNEDBY_INV_GROUP>
<SignedByInvGroup>
    <listitem index="0">
        <SIGNEDBY_INV_COMPANY_INDICATOR index="0"> </SIGNEDBY_INV_COMPANY_INDICATOR>
        <SIGNEDBY_HELD_ON_CIF_INDICATOR index="0">Y</SIGNEDBY_HELD_ON_CIF_INDICATOR>
        <SIGNEDBY_INVOLVEMENT_TYPE index="0">SECUR</SIGNEDBY_INVOLVEMENT_TYPE>
        <SIGNEDBY_INVOLVEMENT_ROLE index="0">SIGNEDSOLE</SIGNEDBY_INVOLVEMENT_ROLE>
        <SIGNEDBY_CIF_REF_NUMBER index="0">0100000931530161000</SIGNEDBY_CIF_REF_NUMBER>
        <SIGNEDBY_COMPANY_ID index="0">000000000000000</SIGNEDBY_COMPANY_ID>
    </listitem>
</SignedByInvGroup>
```

### 3.5 Empty Involvement Groups

```
JSON Source: companyInvolvements
XML Count:   SecuritiesService039/COMPANY_INV_GROUP = "0"
XML Container: SecuritiesService039/CompanyInvGroup (empty)
```

### 3.6 Complete XML Output Example (CREATE)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<Request>
    <!-- Envelope (same as other services) -->

    <SecuritiesService039>
        <servType500>C</servType500>
        <source500>NAPS</source500>

        <ITEM_NUMBER index="1"></ITEM_NUMBER>
        <CURRENT_STATUS index="1">OTLA</CURRENT_STATUS>
        <SECURITY_TYPE index="1">MISCELL</SECURITY_TYPE>

        <!-- Miscellaneous Specific -->
        <MISCELLANEOUS_TYPE index="1">CRED</MISCELLANEOUS_TYPE>
        <VL_MISC_DESCRIPTION index="1">xyz</VL_MISC_DESCRIPTION>
        <COMPANY_INDICATOR index="1">2</COMPANY_INDICATOR>
        <LAST_UPDATED_TIMESTAMP index="1">20031203105100482038</LAST_UPDATED_TIMESTAMP>
        <NAPS_APP_ID index="1">14024080</NAPS_APP_ID>

        <!-- Valuation -->
        <VALUATION_AMOUNT index="1">7000</VALUATION_AMOUNT>
        <VALUATION_CURRENCY index="1">EUR</VALUATION_CURRENCY>
        <VALUATION_DATE index="1">29/07/2025</VALUATION_DATE>
        <VALUATION_BY index="1">LEND</VALUATION_BY>

        <!-- Involvement Groups -->
        <BENOWN_INV_GROUP>2</BENOWN_INV_GROUP>
        <BenOwnInvGroup><!-- ... --></BenOwnInvGroup>

        <BORROWCUST_INV_GROUP>2</BORROWCUST_INV_GROUP>
        <BorrowCustInvGroup><!-- ... --></BorrowCustInvGroup>

        <SIGNEDBY_INV_GROUP>1</SIGNEDBY_INV_GROUP>
        <SignedByInvGroup>
            <listitem index="0">
                <SIGNEDBY_CIF_REF_NUMBER index="0">0100000931530161000</SIGNEDBY_CIF_REF_NUMBER>
                <!-- ... other fields ... -->
            </listitem>
        </SignedByInvGroup>

        <COMPANY_INV_GROUP>0</COMPANY_INV_GROUP>
        <CompanyInvGroup></CompanyInvGroup>

        <NAPS_GROUP>0</NAPS_GROUP>
        <ApplicationIDList001></ApplicationIDList001>
    </SecuritiesService039>
</Request>
```

---

## 4. Counter Indemnity (SecuritiesService006)

### 4.1 Service Configuration

```yaml
Service ID:       SecuritiesService006
Operation:        create | update
Transaction:      SecuritiesService006
Security Type:    INDEMNITY
servType500:      C (create) | U (update)
source500:        NAPS
```

### 4.2 Input JSON Structure

```json
{
  "counterIndemnity": {
    "indemnityType": "CUST",
    "indemnityDate": "2025-07-29",
    "indemnityExpiryDate": "2025-07-30",
    "amount": "5000",
    "amountCurrency": "EUR",
    "amountFrequency": "ANNUAL",
    "type": "BOND",
    "dateOfBond": "2025-07-29",
    "subjectOfGuaranteeBond": "XYZ",
    "ifoThirdPartyName": "Third Party Ltd",
    "thirdPartyCode": "1023",
    "cancellationNoticePeriod": "30",
    "maximumExposure": "10000",
    "details": "Bond details",
    "planDescription": "Plan A",
    "planPermNo": "PERM123",
    "planPermDate": "2025-07-01"
  },
  "securityItem": {
    "itemNumber": "",
    "currentStatus": "OTLA",
    "napsAppId": "14024080",
    "slaCode": ""
  },
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvementList": [
        {"involvementRole": "BENEFJOIN"},
        {"involvementRole": "BORROWJOIN"}
      ]
    }
  ]
}
```

### 4.3 Counter Indemnity Specific Mappings

#### Service Header

```
Constant: "INDEMNITY"
XML: SecuritiesService006/SECURITY_TYPE[@index='1']
```

#### Indemnity Fields

```
JSON: counterIndemnity.indemnityDate
XML:  SecuritiesService006/INDEMNITY_DATE[@index='1']
Format: date_ddMMyyyy
Example: ""
```

```
JSON: counterIndemnity.indemnityType
XML:  SecuritiesService006/INDEMNITY_TYPE[@index='1']
Values: CUST, etc.
Example: "CUST"
```

```
Constant: "" (CREATE) | timestamp (UPDATE)
XML: SecuritiesService006/INDEMNITY_LAST_UPDATED_TIMESTAMP[@index='1']
Format: timestamp_yyyyMMddHHmmssSSSSSS
```

```
JSON: counterIndemnity.amount
XML:  SecuritiesService006/AMOUNT[@index='1']
Format: decimal
Example: "5000"
```

```
JSON: counterIndemnity.ifoThirdPartyName
XML:  SecuritiesService006/IFO_THIRD_PARTY_NAME[@index='1']
Example: ""
```

```
JSON: counterIndemnity.amountFrequency
XML:  SecuritiesService006/AMOUNT_FREQUENCY[@index='1']
Example: ""
```

```
JSON: counterIndemnity.cancellationNoticePeriod
XML:  SecuritiesService006/CANCELLATION_NOTICE_PERIOD[@index='1']
Example: ""
```

```
JSON: counterIndemnity.amountCurrency
XML:  SecuritiesService006/AMOUNT_CURRENCY[@index='1']
Example: "EUR"
```

```
JSON: counterIndemnity.indemnityExpiryDate
XML:  SecuritiesService006/INDEMNITY_EXPIRY_DATE[@index='1']
Format: date_ddMMyyyy
Example: "30/07/2025"
```

```
JSON: counterIndemnity.type
XML:  SecuritiesService006/TYPE[@index='1']
Values: BOND, etc.
Example: "BOND"
```

```
JSON: counterIndemnity.details
XML:  SecuritiesService006/VL_DETAILS[@index='1']
Example: ""
```

```
JSON: counterIndemnity.dateOfBond
XML:  SecuritiesService006/DATE_OF_BOND[@index='1']
Format: date_ddMMyyyy
Example: "29/07/2025"
```

```
JSON: counterIndemnity.subjectOfGuaranteeBond
XML:  SecuritiesService006/VL_SUBJECT_OF_GUARANTEE_BOND[@index='1']
Example: "XYZ"
```

```
JSON: counterIndemnity.maximumExposure
XML:  SecuritiesService006/MAXIMUM_EXPOSURE[@index='1']
Example: ""
```

```
Constant: ""
XML: SecuritiesService006/ID_CREATED_TIMESTAMP[@index='1']
```

```
JSON: counterIndemnity.planDescription
XML:  SecuritiesService006/PLAN_DESCRIPTION[@index='1']
Example: ""
```

```
JSON: counterIndemnity.planPermNo
XML:  SecuritiesService006/PLAN_PERM_NO[@index='1']
Example: ""
```

```
JSON: counterIndemnity.planPermDate
XML:  SecuritiesService006/PLAN_PERM_DATE[@index='1']
Format: date_ddMMyyyy
Example: ""
```

```
JSON: counterIndemnity.thirdPartyCode
XML:  SecuritiesService006/THIRD_PARTY_CODE[@index='1']
Example: "1023"
```

```
Constant: ""
XML: SecuritiesService006/PARENT_GUARANTEE_ITEM[@index='1']
```

### 4.4 Empty Involvement Groups

```
JSON Source: signedByInvolvements
XML Count:   SecuritiesService006/SIGNEDBY_INV_GROUP = "0"
XML Container: SecuritiesService006/SignedByInvGroup (empty)
```

```
JSON Source: companyInvolvements
XML Count:   SecuritiesService006/COMPANY_INV_GROUP = "0"
XML Container: SecuritiesService006/CompanyInvGroup (empty)
```

### 4.5 Complete XML Output Example (CREATE)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<Request>
    <!-- Envelope (same as other services) -->

    <SecuritiesService006>
        <servType500>C</servType500>
        <source500>NAPS</source500>

        <ITEM_NUMBER index="1"></ITEM_NUMBER>
        <CURRENT_STATUS index="1">OTLA</CURRENT_STATUS>
        <SECURITY_TYPE index="1">INDEMNITY</SECURITY_TYPE>

        <!-- Indemnity Specific -->
        <INDEMNITY_TYPE index="1">CUST</INDEMNITY_TYPE>
        <AMOUNT index="1">5000</AMOUNT>
        <AMOUNT_CURRENCY index="1">EUR</AMOUNT_CURRENCY>
        <INDEMNITY_EXPIRY_DATE index="1">30/07/2025</INDEMNITY_EXPIRY_DATE>
        <TYPE index="1">BOND</TYPE>
        <DATE_OF_BOND index="1">29/07/2025</DATE_OF_BOND>
        <VL_SUBJECT_OF_GUARANTEE_BOND index="1">XYZ</VL_SUBJECT_OF_GUARANTEE_BOND>
        <THIRD_PARTY_CODE index="1">1023</THIRD_PARTY_CODE>
        <NAPS_APP_ID index="1">14024080</NAPS_APP_ID>

        <!-- Involvement Groups -->
        <BENOWN_INV_GROUP>2</BENOWN_INV_GROUP>
        <BenOwnInvGroup><!-- ... --></BenOwnInvGroup>

        <BORROWCUST_INV_GROUP>2</BORROWCUST_INV_GROUP>
        <BorrowCustInvGroup><!-- ... --></BorrowCustInvGroup>

        <SIGNEDBY_INV_GROUP>0</SIGNEDBY_INV_GROUP>
        <SignedByInvGroup></SignedByInvGroup>

        <COMPANY_INV_GROUP>0</COMPANY_INV_GROUP>
        <CompanyInvGroup></CompanyInvGroup>

        <NAPS_GROUP>0</NAPS_GROUP>
        <ApplicationIDList001></ApplicationIDList001>
    </SecuritiesService006>
</Request>
```

---

## 5. Letter of Pledge (SecuritiesService042)

### 5.1 Service Configuration

```yaml
Service ID:       SecuritiesService042
Operation:        create | update
Transaction:      SecuritiesService042
Security Type:    PLEDGE
servType500:      C (create) | U (update)
source500:        NAPS
```

### 5.2 Input JSON Structure

```json
{
  "letterOfPledge": {
    "pledgeType": "PLED",
    "dateOfPledge": "2025-07-29",
    "portfolioNumber": "PORT123",
    "brokerContactName": "John Broker",
    "brokerId": "BRK001",
    "shares": [
      {
        "shareId": "000000056596334",
        "issuer": "xyz",
        "numberOfShares": "3",
        "baseValue": "0",
        "shareCurrency": "",
        "stockTransferForm": "N",
        "registeredIn": "ALIB"
      }
    ]
  },
  "securityItem": {
    "itemNumber": "",
    "currentStatus": "OTLA",
    "napsAppId": "14024080",
    "slaCode": ""
  },
  "valuation": {
    "amount": "5000",
    "valuationCurrency": "EUR",
    "valuationDate": "2025-07-29",
    "valuationBasis": "INSU"
  },
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvementList": [
        {"involvementRole": "BENEFJOIN"},
        {"involvementRole": "BORROWJOIN"}
      ]
    }
  ],
  "audit": {
    "lastUpdatedTimestamp": "2003-12-03T10:52:12.692240"
  }
}
```

### 5.3 Letter of Pledge Specific Mappings

#### Service Header

```
Constant: "PLEDGE"
XML: SecuritiesService042/SECURITY_TYPE[@index='1']
```

#### Pledge Fields

```
JSON: letterOfPledge.pledgeType
XML:  SecuritiesService042/PLEDGE_TYPE[@index='1']
Values: PLED, etc.
Example: "PLED"
```

```
JSON: letterOfPledge.dateOfPledge
XML:  SecuritiesService042/DATE_OF_PLEDGE[@index='1']
Format: date_ddMMyyyy
Example: ""
```

```
JSON: letterOfPledge.portfolioNumber
XML:  SecuritiesService042/PORTFOLIO_NUMBER[@index='1']
Example: ""
```

```
JSON: letterOfPledge.brokerContactName
XML:  SecuritiesService042/BROKER_CONTACT_NAME[@index='1']
Example: ""
```

```
JSON: letterOfPledge.brokerId
XML:  SecuritiesService042/BROKER_ID[@index='1']
Example: ""
```

```
Constant: "" (CREATE) | timestamp (UPDATE)
XML: SecuritiesService042/PLEDGE_LAST_UPDATED_TIMESTAMP[@index='1']
Format: timestamp_yyyyMMddHHmmssSSSSSS
```

```
Constant: ""
XML: SecuritiesService042/PARENT_GUARANTEE_ITEM[@index='1']
```

#### Audit Field (Unique)

```
JSON: audit.lastUpdatedTimestamp
XML:  SecuritiesService042/LAST_UPDATED_TIMESTAMP[@index='1']
Format: timestamp_yyyyMMddHHmmssSSSSSS
Example: "20031203105212692240"
```

### 5.4 Share Group (UNIQUE TO SERVICE042)

**No Filter** - All shares included

```
JSON Source: letterOfPledge.shares[]
XML Count:   SecuritiesService042/SHARE_GROUP
XML Container: SecuritiesService042/ShareGroup
```

**Mappings per listitem:**

| JSON Path | XML XPath | Format | Description |
|-----------|-----------|--------|-------------|
| `shareId` | `SHARE_ID[@index]` | - | Share identifier (15 chars, zero-padded) |
| `issuer` | `ISSUER[@index]` | - | Issuing company (30 chars, right-padded) |
| `numberOfShares` | `NUMBER_OF_SHARES[@index]` | - | Quantity (15 chars, zero-padded) |
| `baseValue` | `BASE_VALUE[@index]` | - | Value per share (15 chars, zero-padded) |
| `shareCurrency` | `SHARE_CURRENCY[@index]` | - | Currency (3 chars, right-padded) |
| `stockTransferForm` | `STOCK_TRANSFER_FORM[@index]` | - | Y/N indicator |
| `registeredIn` | `REGISTERED_IN[@index]` | - | Registration location (5 chars, right-padded) |

**Field Formatting Rules:**
- Numeric fields are **zero-padded left** to fixed width
- Text fields are **space-padded right** to fixed width

**Example:**
```xml
<SHARE_GROUP>1</SHARE_GROUP>
<ShareGroup>
    <listitem index="0">
        <SHARE_ID index="0">000000056596334</SHARE_ID>
        <ISSUER index="0">xyz                           </ISSUER>
        <NUMBER_OF_SHARES index="0">000000000000003</NUMBER_OF_SHARES>
        <BASE_VALUE index="0">000000000000000</BASE_VALUE>
        <SHARE_CURRENCY index="0">   </SHARE_CURRENCY>
        <STOCK_TRANSFER_FORM index="0">N</STOCK_TRANSFER_FORM>
        <REGISTERED_IN index="0">ALIB </REGISTERED_IN>
    </listitem>
</ShareGroup>
```

### 5.5 Empty Involvement Groups

```
JSON Source: signedByInvolvements
XML Count:   SecuritiesService042/SIGNEDBY_INV_GROUP = "0"
XML Container: SecuritiesService042/SignedByInvGroup (empty)
```

```
JSON Source: companyInvolvements
XML Count:   SecuritiesService042/COMPANY_INV_GROUP = "0"
XML Container: SecuritiesService042/CompanyInvGroup (empty)
```

### 5.6 Complete XML Output Example (CREATE)

```xml
<?xml version="1.0" encoding="UTF-8"?>
<Request>
    <!-- Envelope (same as other services) -->

    <SecuritiesService042>
        <servType500>C</servType500>
        <source500>NAPS</source500>

        <ITEM_NUMBER index="1"></ITEM_NUMBER>
        <CURRENT_STATUS index="1">OTLA</CURRENT_STATUS>
        <SECURITY_TYPE index="1">PLEDGE</SECURITY_TYPE>

        <!-- Pledge Specific -->
        <PLEDGE_TYPE index="1">PLED</PLEDGE_TYPE>
        <LAST_UPDATED_TIMESTAMP index="1">20031203105212692240</LAST_UPDATED_TIMESTAMP>
        <NAPS_APP_ID index="1">14024080</NAPS_APP_ID>

        <!-- Valuation -->
        <VALUATION_AMOUNT index="1">5000</VALUATION_AMOUNT>
        <VALUATION_CURRENCY index="1">EUR</VALUATION_CURRENCY>
        <VALUATION_DATE index="1">29/07/2025</VALUATION_DATE>
        <VALUATION_BY index="1">INSU</VALUATION_BY>

        <!-- Share Group -->
        <SHARE_GROUP>1</SHARE_GROUP>
        <ShareGroup>
            <listitem index="0">
                <SHARE_ID index="0">000000056596334</SHARE_ID>
                <ISSUER index="0">xyz                           </ISSUER>
                <NUMBER_OF_SHARES index="0">000000000000003</NUMBER_OF_SHARES>
                <BASE_VALUE index="0">000000000000000</BASE_VALUE>
                <SHARE_CURRENCY index="0">   </SHARE_CURRENCY>
                <STOCK_TRANSFER_FORM index="0">N</STOCK_TRANSFER_FORM>
                <REGISTERED_IN index="0">ALIB </REGISTERED_IN>
            </listitem>
        </ShareGroup>

        <!-- Involvement Groups -->
        <BENOWN_INV_GROUP>2</BENOWN_INV_GROUP>
        <BenOwnInvGroup><!-- ... --></BenOwnInvGroup>

        <BORROWCUST_INV_GROUP>2</BORROWCUST_INV_GROUP>
        <BorrowCustInvGroup><!-- ... --></BorrowCustInvGroup>

        <SIGNEDBY_INV_GROUP>0</SIGNEDBY_INV_GROUP>
        <SignedByInvGroup></SignedByInvGroup>

        <COMPANY_INV_GROUP>0</COMPANY_INV_GROUP>
        <CompanyInvGroup></CompanyInvGroup>

        <NAPS_GROUP>0</NAPS_GROUP>
        <ApplicationIDList001></ApplicationIDList001>
    </SecuritiesService042>
</Request>
```

---

## Appendix: Common Enumerations

### A.1 Current Status Codes

| Code | Description |
|------|-------------|
| `APFH` | Approved - Family Home |
| `APPR` | Approved |
| `APRE` | Appr-Restrict Facility |
| `EXIO` | EX - held items awaited |
| `EXNA` | Executed/Held Not Appr |
| `EXSR` | EX with Solicitor Reg |
| `HEEX` | Held/Re-examine on review |
| `IDRU` | Sent to IDRU |
| `NENF` | Not Enforceable |
| `OTAD` | O/S waiting info to prep |
| `OTCU` | O/S with Cust/Solr |
| `OTLA` | O/S Lender to arrange |
| `TKAP` | Approved Prior System |
| `RELE` | Released |

### A.2 SLA Codes

| Code | Description |
|------|-------------|
| `A0` | Access Records |
| `H0` | Home Mortgages |
| `L0` | Ledger |
| `N0` | AMU/NAPS |
| `S0` | SAM & Collate |

### A.3 Policy Types (Service004)

| Code | Description |
|------|-------------|
| `ENDW` | Endowment |
| `INVT` | Investment Bond |
| `KEY` | Keyman |
| `MORT` | Mortgage Protection |
| `PIP` | Personal Investment Portfolio |
| `PREM` | Single Premium Bond |
| `SURP` | Surplus Builder |
| `TERM` | Term Assurance |
| `TRAK` | Tracker Bond |
| `WHOL` | Whole Life |

### A.4 Guarantee Types (Service003)

| Code | Description |
|------|-------------|
| `PCCA` | AIB: CCA Guarantee |
| `CSTD` | AIB: Company Guarantee |
| `CROI` | AIB: Foreign Company Guarantee |
| `CGLO` | AIB: Global Guarantee |
| `COMN` | AIB: Omnibus Guarantee |
| `CSUM` | AIB: All Sums Company Guarantee |
| `MISC` | AIB: Miscellaneous Guarantee |
| `PINT` | AIB: Interest Shortfall Guarantee |
| `MINT` | AIB: Mortgage Bank Interest Shortfall Guarantee |
| `PRES` | AIB: Restricted Guarantee |
| `PROI` | AIB: Foreign Resident Guarantee |
| `PSTD` | AIB: Personal Guarantee |
| `MRBK` | AIB: Mortgage Bank Personal Guarantee |
| `PALL` | AIB: All Sums Personal Guarantee |

### A.5 Relationship Types (Service003)

| Code | Description |
|------|-------------|
| `DIR` | Director(s) |
| `FAMY` | Parent(s) |
| `OTHR` | Other |
| `PASU` | Parent/Subsidiary |
| `SPSE` | Spouse/Partner |

### A.6 Valuation Basis

| Code | Description |
|------|-------------|
| `IRDU` | IRDU |
| `CUST` | Customer |
| `INSU` | Insurance |
| `LEND` | Lender |

### A.7 Involvement Roles

| Role | Used In Service | Description |
|------|-----------------|-------------|
| `BENEFJOIN` | 003, 004, 006, 039, 042 | Joint Beneficial Owner |
| `BENEFSOLE` | 003, 004, 006, 039, 042 | Sole Beneficial Owner |
| `BORROWJOIN` | 003, 004, 006, 039, 042 | Joint Borrower |
| `BORROWSOLE` | 003, 004, 006, 039, 042 | Sole Borrower |
| `LIFEASSURE` | 004 | Life Assured |
| `GUARANTOR` | 003 | Guarantor |
| `SIGNEDSOLE` | 039 | Sole Signatory |
| `SIGNEDJOIN` | 039 | Joint Signatory |

---

## Document Version History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2025-12-04 | AIB Dev Team | Initial mapping specification for 5 priority security types |

---

**End of Document**
