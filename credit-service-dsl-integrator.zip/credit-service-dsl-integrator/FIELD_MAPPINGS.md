# Field Mappings - JSON to XML
## 5 Priority Security Types

---

## 1. Assignment of Life Policy (SecuritiesService004)

### Scalar Field Mappings

| XML XPath | JSON Path | Format | Notes |
|-----------|-----------|--------|-------|
| `SecuritiesService004/CURRENT_STATUS[@index='1']` | `securityItem.currentStatus` | - | - |
| `SecuritiesService004/VALUATION_AMOUNT[@index='1']` | `valuation.amount` | - | - |
| `SecuritiesService004/VALUATION_CURRENCY[@index='1']` | `valuation.valuationCurrency` | - | - |
| `SecuritiesService004/VALUATION_DATE[@index='1']` | `valuation.valuationDate` | `date_ddMMyyyy` | - |
| `SecuritiesService004/VALUATION_BY[@index='1']` | `valuation.valuationBasis` | - | - |
| `SecuritiesService004/SOLICITOR_CODE[@index='1']` | `securityItem.solicitorCode` | - | - |
| `SecuritiesService004/ASSURANCE_CO_CODE[@index='1']` | `securityItem.assuranceCode` | - | - |
| `SecuritiesService004/NAPS_APP_ID[@index='1']` | `securityItem.napsAppId` | - | - |
| `SecuritiesService004/POLICY_TYPE[@index='1']` | `assignmentOfLife.policyType` | - | ENDW, INVT, KEY, MORT, PIP, PREM, SURP, TERM, TRAK, WHOL |
| `SecuritiesService004/POLICY_NUMBER[@index='1']` | `assignmentOfLife.policyNumber` | - | - |
| `SecuritiesService004/SUM_ASSURED[@index='1']` | `assignmentOfLife.sumAssured` | - | - |
| `SecuritiesService004/LIFEPOL_EXPIRY_DATE[@index='1']` | `assignmentOfLife.expiryDate` | `date_ddMMyyyy` | - |

### Array Mappings

#### BENOWN_INV_GROUP (Beneficial Owners)
**Source:** `custSecurities[]`
**Filter:** Include CIF if ANY `securityInvolvement[].involvementRole` IN (`BENEFJOIN`, `BENEFSOLE`)

| XML XPath | JSON Path | Value |
|-----------|-----------|-------|
| `BENOWN_CIF_REF_NUMBER[@index]` | `cifKey` | - |

**Example Input:**
```json
{
  "cifKey": "0100000938437104000",
  "securityInvolvement": [
    { "involvementRole": "BENEFJOIN", "involvementType": "SECUR" },
    { "involvementRole": "BORROWJOIN", "involvementType": "SECUR" }
  ]
}
```
Result: CIF included in BENOWN_INV_GROUP (has BENEFJOIN role)

#### BORROWCUST_INV_GROUP (Borrowers)
**Source:** `custSecurities[]`
**Filter:** Include CIF if ANY `securityInvolvement[].involvementRole` IN (`BORROWJOIN`, `BORROWSOLE`)

| XML XPath | JSON Path | Value |
|-----------|-----------|-------|
| `BORROWCUST_CIF_REF_NUMBER[@index]` | `cifKey` | - |

**Example Input:**
```json
{
  "cifKey": "0100000938437104000",
  "securityInvolvement": [
    { "involvementRole": "BENEFJOIN", "involvementType": "SECUR" },
    { "involvementRole": "BORROWJOIN", "involvementType": "SECUR" }
  ]
}
```
Result: CIF included in BORROWCUST_INV_GROUP (has BORROWJOIN role)

#### LIFEASSURE_INV_GROUP (Lives Assured)
**Source:** `custSecurities[]`
**Filter:** Include CIF if ANY `securityInvolvement[].involvementRole` = `LIFEASSURE`

| XML XPath | JSON Path | Value |
|-----------|-----------|-------|
| `LIFEASSURE_CIF_REF_NUMBER[@index]` | `cifKey` | - |

**Example Input:**
```json
{
  "cifKey": "0100000938437104000",
  "securityInvolvement": [
    { "involvementRole": "LIFEASSURE", "involvementType": "SECUR" }
  ]
}
```
Result: CIF included in LIFEASSURE_INV_GROUP (has LIFEASSURE role)

---

## 2. Letter of Guarantee (SecuritiesService003)

### Scalar Field Mappings

| XML XPath | JSON Path | Format | Notes |
|-----------|-----------|--------|-------|
| `SecuritiesService003/CURRENT_STATUS[@index='1']` | `securityItem.currentStatus` | - | - |
| `SecuritiesService003/VALUATION_AMOUNT[@index='1']` | `securityItem.valuation.amount` | - | - |
| `SecuritiesService003/VALUATION_CURRENCY[@index='1']` | `securityItem.valuation.currency` | - | - |
| `SecuritiesService003/VALUATION_DATE[@index='1']` | `securityItem.valuation.date` | `date_ddMMyyyy` | - |
| `SecuritiesService003/VALUATION_BY[@index='1']` | `securityItem.valuation.by` | - | - |
| `SecuritiesService003/SOLICITOR_CODE[@index='1']` | `securityItem.solicitorCode` | - | - |
| `SecuritiesService003/SOLICITOR_COMPANY_NAME[@index='1']` | `securityItem.solicitorCompanyName` | - | - |
| `SecuritiesService003/ASSURANCE_CO_CODE[@index='1']` | `securityItem.assuranceCode` | - | - |
| `SecuritiesService003/NAPS_APP_ID[@index='1']` | `securityItem.napsAppId` | - | - |
| `SecuritiesService003/GUARANTEE_DATE[@index='1']` | `letterOfGuarantee.guaranteeDate` | `date_ddMMyyyy` | - |
| `SecuritiesService003/GUARANTEE_AMOUNT[@index='1']` | `letterOfGuarantee.guaranteeAmount` | `decimal` | - |
| `SecuritiesService003/SUPPORTED_OR_UNSUPPORTED[@index='1']` | `letterOfGuarantee.supportedOrUnsupported` | - | - |
| `SecuritiesService003/GUARANTEE_TYPE[@index='1']` | `letterOfGuarantee.guaranteeType` | - | PCCA, CSTD, PROI, PRES, PSTD, etc. |
| `SecuritiesService003/LETTER_OF_WAIVER_INDICATOR[@index='1']` | `letterOfGuarantee.letterOfWaiver` | - | 0, 1 |
| `SecuritiesService003/RELATIONSHIP_TYPE[@index='1']` | `letterOfGuarantee.relationshipType` | - | DIR, FAMY, OTHR, PASU, SPSE |

### Array Mappings

#### BENOWN_INV_GROUP (Beneficial Owners)
**Source:** `custSecurities[]`
**Filter:** Include CIF if ANY `securityInvolvement[].involvementRole` IN (`BENEFJOIN`, `BENEFSOLE`)

| XML XPath | JSON Path | Value |
|-----------|-----------|-------|
| `BENOWN_CIF_REF_NUMBER[@index]` | `cifKey` | - |

**Example Input:**
```json
{
  "cifKey": "0100000938437104000",
  "securityInvolvement": [
    { "involvementRole": "BENEFJOIN", "involvementType": "SECUR" }
  ]
}
```

#### BORROWCUST_INV_GROUP (Borrowers)
**Source:** `custSecurities[]`
**Filter:** Include CIF if ANY `securityInvolvement[].involvementRole` IN (`BORROWJOIN`, `BORROWSOLE`)

| XML XPath | JSON Path | Value |
|-----------|-----------|-------|
| `BORROWCUST_CIF_REF_NUMBER[@index]` | `cifKey` | - |

**Example Input:**
```json
{
  "cifKey": "0100000938437104000",
  "securityInvolvement": [
    { "involvementRole": "BORROWJOIN", "involvementType": "SECUR" }
  ]
}
```

#### GUARANTOR_INV_GROUP (Guarantors)
**Source:** `custSecurities[]`
**Filter:** Include CIF if ANY `securityInvolvement[].involvementRole` = `GUARANTOR`

| XML XPath | JSON Path | Value |
|-----------|-----------|-------|
| `GUARANTOR_CIF_REF_NUMBER[@index]` | `cifKey` | - |

**Example Input:**
```json
{
  "cifKey": "0100000931530161000",
  "securityInvolvement": [
    { "involvementRole": "GUARANTOR", "involvementType": "SECUR" }
  ]
}
```

#### SUPPORTING_SECURITIES
**Source:** `supportingSecurity[]`
**No Filter**

---

## 3. Miscellaneous (SecuritiesService039)

### Scalar Field Mappings

| XML XPath | JSON Path | Format | Notes |
|-----------|-----------|--------|-------|
| `SecuritiesService039/MISCELLANEOUS_TYPE[@index='1']` | `miscellaneous.miscType` | - | Required |
| `SecuritiesService039/MISC_LETTER_DATE[@index='1']` | `miscellaneous.letterDate` | `date_ddMMyyyy` | - |
| `SecuritiesService039/MISC_SECURITY_AMOUNT[@index='1']` | `miscellaneous.miscSecurityAmount` | `decimal` | - |
| `SecuritiesService039/MISCELL_EXPIRY_DATE[@index='1']` | `miscellaneous.expiryDate` | `date_ddMMyyyy` | - |
| `SecuritiesService039/VL_MISC_DESCRIPTION[@index='1']` | `miscellaneous.miscDescription` | - | - |
| `SecuritiesService039/MISC_CANCELLATION_NOTICE_PERIOD[@index='1']` | `miscellaneous.cancellationNoticePeriod` | - | - |
| `SecuritiesService039/PARENT_GUARANTEE_ITEM[@index='1']` | `miscellaneous.parentGuaranteeItem` | - | - |
| `SecuritiesService039/RESTRICTIONS_FACILITY_ACC_TYPE[@index='1']` | `restriction.facilityAccountType` | - | - |
| `SecuritiesService039/RESTRICTIONS_FACILITY_AMOUNT[@index='1']` | `restriction.facilityAmount` | `decimal` | - |
| `SecuritiesService039/RESTRICTIONS_FACILITY_CURR[@index='1']` | `restriction.facilityCurrency` | - | - |
| `SecuritiesService039/RESTRICTIONS_DETAILS[@index='1']` | `restriction.details` | - | - |
| `SecuritiesService039/RESTRICTIONS_PROPERTY_ADDRESS[@index='1']` | `restriction.propertyAddress` | - | - |
| `SecuritiesService039/RESTRICTIONS_POLICY_NUMBER[@index='1']` | `restriction.policyNumber` | - | - |
| `SecuritiesService039/RESTRICTIONS_INSURANCE_ID[@index='1']` | `restriction.insuranceId` | - | - |
| `SecuritiesService039/VALUATION_AMOUNT[@index='1']` | `securityItem.valuation.amount` | `decimal` | - |
| `SecuritiesService039/VALUATION_CURRENCY[@index='1']` | `securityItem.valuation.currency` | - | - |
| `SecuritiesService039/VALUATION_DATE[@index='1']` | `securityItem.valuation.date` | `date_ddMMyyyy` | - |
| `SecuritiesService039/VALUATION_BY[@index='1']` | `securityItem.valuation.by` | - | - |
| `SecuritiesService039/SLA_CODE[@index='1']` | `admin.slaCode` | - | - |
| `SecuritiesService039/CURRENCY_TYPE[@index='1']` | `admin.currencyType` | - | - |
| `SecuritiesService039/POS_NOTES[@index='1']` | `admin.posNotes` | - | - |
| `SecuritiesService039/SO_NOTES[@index='1']` | `admin.soNotes` | - | - |

### Array Mappings

#### BENOWN_INV_GROUP (Beneficial Owners)
**Source:** `parties.beneficiaries[]`
**No Filter**

| XML XPath | JSON Path | Value |
|-----------|-----------|-------|
| `BENOWN_CIF_REF_NUMBER[@index]` | `cifRef` | - |
| `BENOWN_COMPANY_ID[@index]` | `companyId` | - |

#### BORROWCUST_INV_GROUP (Borrowers)
**Source:** `parties.borrowers[]`
**No Filter**

| XML XPath | JSON Path | Value |
|-----------|-----------|-------|
| `BORROWCUST_CIF_REF_NUMBER[@index]` | `cifRef` | - |
| `BORROWCUST_COMPANY_ID[@index]` | `companyId` | - |

#### SIGNEDBY_INV_GROUP (Signatories)
**Source:** `parties.signatories[]`
**No Filter**

| XML XPath | JSON Path | Value |
|-----------|-----------|-------|
| `SIGNEDBY_CIF_REF_NUMBER[@index]` | `cifRef` | - |
| `SIGNEDBY_COMPANY_ID[@index]` | `companyId` | - |

---

## 4. Counter Indemnity (SecuritiesService006)

### Scalar Field Mappings

| XML XPath | JSON Path | Format | Notes |
|-----------|-----------|--------|-------|
| `SecuritiesService006/CURRENT_STATUS[@index='1']` | `securityItem.currentStatus` | - | - |
| `SecuritiesService006/VALUATION_AMOUNT[@index='1']` | `securityItem.valuation.amount` | - | - |
| `SecuritiesService006/VALUATION_CURRENCY[@index='1']` | `securityItem.valuation.currency` | - | - |
| `SecuritiesService006/VALUATION_DATE[@index='1']` | `securityItem.valuation.date` | `date_ddMMyyyy` | - |
| `SecuritiesService006/VALUATION_BY[@index='1']` | `securityItem.valuation.by` | - | - |
| `SecuritiesService006/NAPS_APP_ID[@index='1']` | `securityItem.napsAppId` | - | - |
| `SecuritiesService006/INDEMNITY_DATE[@index='1']` | `counterIndemnity.indemnityDate` | `date_ddMMyyyy` | - |
| `SecuritiesService006/INDEMNITY_TYPE[@index='1']` | `counterIndemnity.indemnityType` | - | CUST, etc. |
| `SecuritiesService006/AMOUNT[@index='1']` | `counterIndemnity.amount` | `decimal` | - |
| `SecuritiesService006/IFO_THIRD_PARTY_NAME[@index='1']` | `counterIndemnity.thirdPartyName` | - | - |
| `SecuritiesService006/AMOUNT_FREQUENCY[@index='1']` | `counterIndemnity.amountFrequency` | - | - |
| `SecuritiesService006/CANCELLATION_NOTICE_PERIOD[@index='1']` | `counterIndemnity.cancellationNoticePeriod` | - | - |
| `SecuritiesService006/AMOUNT_CURRENCY[@index='1']` | `counterIndemnity.currency` | - | - |
| `SecuritiesService006/INDEMNITY_EXPIRY_DATE[@index='1']` | `counterIndemnity.expiryDate` | `date_ddMMyyyy` | - |
| `SecuritiesService006/TYPE[@index='1']` | `counterIndemnity.type` | - | BOND, etc. |
| `SecuritiesService006/VL_DETAILS[@index='1']` | `counterIndemnity.vlDetails` | - | - |
| `SecuritiesService006/DATE_OF_BOND[@index='1']` | `counterIndemnity.dateOfBond` | `date_ddMMyyyy` | - |
| `SecuritiesService006/VL_SUBJECT_OF_GUARANTEE_BOND[@index='1']` | `counterIndemnity.subjectOfGuaranteeBond` | - | - |
| `SecuritiesService006/MAXIMUM_EXPOSURE[@index='1']` | `counterIndemnity.maximumExposure` | - | - |
| `SecuritiesService006/PLAN_DESCRIPTION[@index='1']` | `counterIndemnity.planDescription` | - | - |
| `SecuritiesService006/PLAN_PERM_NO[@index='1']` | `counterIndemnity.planPermNo` | - | - |
| `SecuritiesService006/PLAN_PERM_DATE[@index='1']` | `counterIndemnity.planPermDate` | `date_ddMMyyyy` | - |
| `SecuritiesService006/THIRD_PARTY_CODE[@index='1']` | `counterIndemnity.thirdPartyCode` | - | - |

### Array Mappings

#### BENOWN_INV_GROUP (Beneficial Owners)
**Source:** `custSecurities[]`
**Filter:** Include CIF if ANY `securityInvolvement[].involvementRole` IN (`BENEFJOIN`, `BENEFSOLE`)

| XML XPath | JSON Path | Value |
|-----------|-----------|-------|
| `BENOWN_CIF_REF_NUMBER[@index]` | `cifKey` | - |

**Example Input:**
```json
{
  "cifKey": "0100000938437104000",
  "securityInvolvement": [
    { "involvementRole": "BENEFJOIN", "involvementType": "SECUR" }
  ]
}
```

#### BORROWCUST_INV_GROUP (Borrowers)
**Source:** `custSecurities[]`
**Filter:** Include CIF if ANY `securityInvolvement[].involvementRole` IN (`BORROWJOIN`, `BORROWSOLE`)

| XML XPath | JSON Path | Value |
|-----------|-----------|-------|
| `BORROWCUST_CIF_REF_NUMBER[@index]` | `cifKey` | - |

**Example Input:**
```json
{
  "cifKey": "0100000938437104000",
  "securityInvolvement": [
    { "involvementRole": "BORROWJOIN", "involvementType": "SECUR" }
  ]
}
```

---

## 5. Letter of Pledge (SecuritiesService042)

### Scalar Field Mappings

| XML XPath | JSON Path | Format | Notes |
|-----------|-----------|--------|-------|
| `SecuritiesService042/CURRENT_STATUS[@index='1']` | `securityItem.currentStatus` | - | - |
| `SecuritiesService042/VALUATION_AMOUNT[@index='1']` | `valuation.amount` | - | - |
| `SecuritiesService042/VALUATION_CURRENCY[@index='1']` | `valuation.valuationCurrency` | - | - |
| `SecuritiesService042/VALUATION_DATE[@index='1']` | `valuation.valuationDate` | `date_ddMMyyyy` | - |
| `SecuritiesService042/VALUATION_BY[@index='1']` | `valuation.valuationBasis` | - | - |
| `SecuritiesService042/NAPS_APP_ID[@index='1']` | `securityItem.napsAppId` | - | - |
| `SecuritiesService042/PLEDGE_TYPE[@index='1']` | `letterOfPledge.pledgeType` | - | PLED, etc. |
| `SecuritiesService042/DATE_OF_PLEDGE[@index='1']` | `letterOfPledge.dateOfPledge` | `date_ddMMyyyy` | - |
| `SecuritiesService042/PORTFOLIO_NUMBER[@index='1']` | `letterOfPledge.portfolioNumber` | - | - |
| `SecuritiesService042/BROKER_CONTACT_NAME[@index='1']` | `letterOfPledge.brokerContactName` | - | - |
| `SecuritiesService042/BROKER_ID[@index='1']` | `letterOfPledge.brokerId` | - | - |
| `SecuritiesService042/PARENT_GUARANTEE_ITEM[@index='1']` | `pledge.parentGuaranteeItem` | - | - |

### Array Mappings

#### SHARE_GROUP (Share Details)
**Source:** `shareDetails[]`
**No Filter**

| XML XPath | JSON Path | Notes |
|-----------|-----------|-------|
| `SHARE_ID[@index]` | `shareId` | 15 chars, zero-padded |
| `ISSUER[@index]` | `issuer` | 30 chars, space-padded |
| `NUMBER_OF_SHARES[@index]` | `numberOfShares` | 15 chars, zero-padded |
| `BASE_VALUE[@index]` | `baseValue` | 15 chars, zero-padded |
| `SHARE_CURRENCY[@index]` | `currencyType` | 3 chars, space-padded |
| `STOCK_TRANSFER_FORM[@index]` | `stockTransferForm` | Y/N |
| `REGISTERED_IN[@index]` | `registeredIn` | 5 chars, space-padded |

#### BENOWN_INV_GROUP (Beneficial Owners)
**Source:** `custSecurities[]`
**Filter:** Include CIF if ANY `securityInvolvement[].involvementRole` IN (`BENEFJOIN`, `BENEFSOLE`)

| XML XPath | JSON Path | Value |
|-----------|-----------|-------|
| `BENOWN_CIF_REF_NUMBER[@index]` | `cifKey` | - |

**Example Input:**
```json
{
  "cifKey": "0100000938437104000",
  "securityInvolvement": [
    { "involvementRole": "BENEFJOIN", "involvementType": "SECUR" }
  ]
}
```

#### BORROWCUST_INV_GROUP (Borrowers)
**Source:** `custSecurities[]`
**Filter:** Include CIF if ANY `securityInvolvement[].involvementRole` IN (`BORROWJOIN`, `BORROWSOLE`)

| XML XPath | JSON Path | Value |
|-----------|-----------|-------|
| `BORROWCUST_CIF_REF_NUMBER[@index]` | `cifKey` | - |

**Example Input:**
```json
{
  "cifKey": "0100000938437104000",
  "securityInvolvement": [
    { "involvementRole": "BORROWJOIN", "involvementType": "SECUR" }
  ]
}
```

---

## Format Transformations

| Format Code | Description | Example Input | Example Output |
|-------------|-------------|---------------|----------------|
| `date_ddMMyyyy` | Date transformation | `2025-07-29` | `29/07/2025` |
| `timestamp_yyyyMMddHHmmssSSSSSS` | Timestamp transformation | `2025-07-29T10:29:11.104` | `20250729102911104000` |
| `decimal` | Decimal formatting | `1,234.56` | `1234.56` |

---

## Common Constants (All Services)

### Envelope Constants

| XML XPath | Constant Value |
|-----------|----------------|
| `Log` | `N` |
| `ID/version` | `1.0` |
| `ID/AppID` | `NBP` |
| `ID/AppName` | `SysTest_CAS_ROI_Current` |
| `ID/UsrID` | `5324654654` |
| `ID/UnqID` | `88140` |
| `regionCode` | `ROI` |
| `sourceNSC` | `931012` |
| `staffNumber` | `88140` |
| `deviceId` | `` (empty) |
| `TransactionVersion` | `1` |

### Service-Specific Constants

| Service | XPath | Constant Value |
|---------|-------|----------------|
| All | `servType500` | `C` (CREATE) / `U` (UPDATE) |
| All | `source500` | `NAPS` |
| Service004 | `SECURITY_TYPE[@index='1']` | `LIFE POL` |
| Service003 | `SECURITY_TYPE[@index='1']` | `GUARANTEE` |
| Service039 | `SECURITY_TYPE[@index='1']` | `MISCELL` |
| Service006 | `SECURITY_TYPE[@index='1']` | `INDEMNITY` |
| Service042 | `SECURITY_TYPE[@index='1']` | `PLEDGE` |
| Service004 | `CURRENCY_TYPE[@index='1']` | `EUR` |
| Service003 | `CURRENCY_TYPE[@index='1']` | `EUR` |
| Service039 | `CURRENCY_TYPE[@index='1']` | `EUR` |
| All | `POS_NOTES[@index='1']` | `0` |

### Common Array Constants (All Services)

For all involvement groups, these constants are always applied:

| Field Suffix | Constant Value |
|--------------|----------------|
| `_INV_COMPANY_INDICATOR` | ` ` (space) |
| `_RELATIONSHIP_QUALITY_CODE` | ` ` (space) |
| `_HELD_ON_CIF_INDICATOR` | `Y` |
| `_INVOLVEMENT_TYPE` | `SECUR` |
| `_COMPANY_ID` | `000000000000000` |

---

## Notes

1. **[@index='1']** notation indicates fields are indexed in XML (all service-specific fields use this)
2. **Empty arrays** still create container elements with count=0
3. **Filters** are OR logic - if ANY involvement role matches, the record is included
4. **Multiple roles** - Same CIF can appear in multiple groups if it has multiple roles
5. **CREATE vs UPDATE** - Main difference is ITEM_NUMBER (empty for CREATE, required for UPDATE)

---

## Complete Example: Multiple Roles for Same CIF

### Input JSON
```json
{
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvement": [
        { "involvementRole": "BENEFJOIN", "involvementType": "SECUR" },
        { "involvementRole": "BORROWJOIN", "involvementType": "SECUR" },
        { "involvementRole": "LIFEASSURE", "involvementType": "SECUR" }
      ]
    },
    {
      "cifKey": "0100000932437490000",
      "securityInvolvement": [
        { "involvementRole": "BENEFJOIN", "involvementType": "SECUR" },
        { "involvementRole": "BORROWJOIN", "involvementType": "SECUR" }
      ]
    }
  ]
}
```

### Output XML (SecuritiesService004 - Assignment of Life)
```xml
<!-- First CIF appears in BENOWN because it has BENEFJOIN role -->
<BENOWN_INV_GROUP>2</BENOWN_INV_GROUP>
<BenOwnInvGroup>
    <listitem index="0">
        <BENOWN_CIF_REF_NUMBER index="0">0100000938437104000</BENOWN_CIF_REF_NUMBER>
        <!-- other fields -->
    </listitem>
    <listitem index="1">
        <BENOWN_CIF_REF_NUMBER index="1">0100000932437490000</BENOWN_CIF_REF_NUMBER>
        <!-- other fields -->
    </listitem>
</BenOwnInvGroup>

<!-- Same CIFs appear in BORROWCUST because they have BORROWJOIN role -->
<BORROWCUST_INV_GROUP>2</BORROWCUST_INV_GROUP>
<BorrowCustInvGroup>
    <listitem index="0">
        <BORROWCUST_CIF_REF_NUMBER index="0">0100000938437104000</BORROWCUST_CIF_REF_NUMBER>
        <!-- other fields -->
    </listitem>
    <listitem index="1">
        <BORROWCUST_CIF_REF_NUMBER index="1">0100000932437490000</BORROWCUST_CIF_REF_NUMBER>
        <!-- other fields -->
    </listitem>
</BorrowCustInvGroup>

<!-- Only first CIF appears in LIFEASSURE because only it has LIFEASSURE role -->
<LIFEASSURE_INV_GROUP>1</LIFEASSURE_INV_GROUP>
<LifeAssureInvGroup>
    <listitem index="0">
        <LIFEASSURE_CIF_REF_NUMBER index="0">0100000938437104000</LIFEASSURE_CIF_REF_NUMBER>
        <!-- other fields -->
    </listitem>
</LifeAssureInvGroup>
```

### Key Points:
- **CIF 0100000938437104000** appears in all 3 groups because it has 3 different roles
- **CIF 0100000932437490000** appears in 2 groups because it has 2 different roles
- Each involvement group filters based on the roles present in the `securityInvolvement` array
- The consuming team controls which groups a CIF appears in by providing the appropriate roles
