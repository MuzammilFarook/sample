INSERT INTO issue (issue_date, title, team, description, resolution, tags, time_spent)
VALUES ('2025-06-23', 'Feign client error', 'Payments Team', 'Issue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with missing beanIssue with ', 'Added missing FeignContext bean', 'spring,feign', '1h');

INSERT INTO issue (issue_date, title, team, description, resolution, tags, time_spent)
VALUES ('2025-06-22', 'JWT validation fail', 'Security Team', 'Token missing audience claim', 'Updated token generator to include aud', 'jwt,keycloak', '45m');

INSERT INTO issue (issue_date, title, team, description, resolution, tags, time_spent)
VALUES ('2025-06-23', 'Feign client error', 'Payments Team', 'Issue with missing bean', 'Added missing FeignContext bean', 'spring,feign', '1h');

INSERT INTO issue (issue_date, title, team, description, resolution, tags, time_spent)
VALUES ('2025-06-22', 'JWT validation fail', 'Security Team', 'Token missing audience claim', 'Updated token generator to include aud', 'jwt,keycloak', '45m');


