
package com.muzammil.issuetracker.model;

import jakarta.persistence.*;

@Entity
public class Issue {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "issue_date")
    private String date;
    private String title;
    private String team;
    @Column(length = 2000)
    private String description;
    @Column(length = 2000)
    private String resolution;
    private String tags;
    private String timeSpent;

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getTeam() { return team; }
    public void setTeam(String team) { this.team = team; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getResolution() { return resolution; }
    public void setResolution(String resolution) { this.resolution = resolution; }

    public String getTags() { return tags; }
    public void setTags(String tags) { this.tags = tags; }

    public String getTimeSpent() { return timeSpent; }
    public void setTimeSpent(String timeSpent) { this.timeSpent = timeSpent; }
}
