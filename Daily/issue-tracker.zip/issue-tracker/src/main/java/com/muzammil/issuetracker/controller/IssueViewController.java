package com.muzammil.issuetracker.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IssueViewController {

    @GetMapping("/log")
    public String showLogPage() {
        return "addIssue";
    }

    @GetMapping("/dashboard")
    public String showDashboard() {
        return "index";
    }
}
