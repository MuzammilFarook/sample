
package com.muzammil.issuetracker.controller;

import com.muzammil.issuetracker.model.Issue;
import com.muzammil.issuetracker.repository.IssueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/issues")
public class IssueController {

    @Autowired
    private IssueRepository issueRepository;

    @PostMapping("/add")
    public ResponseEntity<String> addIssue(@RequestBody Issue issue) {
        issueRepository.save(issue);
        return ResponseEntity.ok("Issue logged successfully");
    }

    @GetMapping("/all")
    public List<Issue> getAllIssues() {
        return issueRepository.findAll();
    }

    @GetMapping("/search")
    public List<Issue> searchIssues(@RequestParam(required = false) String team,
                                    @RequestParam(required = false) String tags) {
        return issueRepository.findByTeamContainingIgnoreCaseAndTagsContainingIgnoreCase(
                team != null ? team : "", tags != null ? tags : "");
    }
}
