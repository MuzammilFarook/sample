# Low Level Design Document
## Securities Transformer - Config-Driven XML Transformation Engine

---

## Document Information

| Field | Value |
|-------|-------|
| Project Name | Securities Transformer |
| Version | 1.0 |
| Date | October 10, 2025 |
| Author | AIB Development Team |
| Technology Stack | Spring Boot 3.3.4, Java 17, Jackson, SnakeYAML |

---

## Table of Contents

1. [System Overview](#1-system-overview)
2. [Architecture Design](#2-architecture-design)
3. [Component Details](#3-component-details)
4. [Data Models](#4-data-models)
5. [Processing Flow](#5-processing-flow)
6. [YAML Mapping Specification](#6-yaml-mapping-specification)
7. [Transformation Rules](#7-transformation-rules)
8. [API Contracts](#8-api-contracts)
9. [Error Handling](#9-error-handling)
10. [Configuration Management](#10-configuration-management)
11. [Performance Considerations](#11-performance-considerations)
12. [Testing Strategy](#12-testing-strategy)

---

## 1. System Overview

### 1.1 Purpose
The Securities Transformer is a configuration-driven transformation engine that converts modern JSON-based REST API requests into legacy XML format required by the AIB Bank's Securities System (COLLATE).

### 1.2 Scope
- Transform 7 different security types (CREATE and UPDATE operations = 14 mappings)
- Support complex nested data structures with multi-role party involvement
- Provide declarative YAML-based mapping configuration
- Generate XML with precise formatting and attribute requirements

### 1.3 Key Features
- **Config-Driven**: No code changes required for mapping modifications
- **Multi-Role Filtering**: Single party can have multiple roles in different XML groups
- **Format Support**: Date, timestamp, decimal formatting
- **Validation**: Required field validation
- **Extensibility**: Easy to add new security types

---

## 2. Architecture Design

### 2.1 High-Level Architecture

```
┌─────────────────┐
│   REST API      │
│  (Swagger)      │
└────────┬────────┘
         │ JSON Request
         ▼
┌─────────────────────────────────┐
│    Spring Boot Application      │
│  ┌───────────────────────────┐  │
│  │  Controller Layer         │  │
│  └───────────┬───────────────┘  │
│              │                   │
│  ┌───────────▼───────────────┐  │
│  │  Service Layer            │  │
│  │  - Orchestration          │  │
│  └───────────┬───────────────┘  │
│              │                   │
│  ┌───────────▼───────────────┐  │
│  │  MappingEngine            │  │
│  │  - YAML Parser            │  │
│  │  - JSON Reader            │  │
│  │  - XML Generator          │  │
│  │  - Filter Engine          │  │
│  └───────────┬───────────────┘  │
│              │                   │
└──────────────┼───────────────────┘
               │
               ▼
      ┌────────────────┐
      │  Legacy XML    │
      │  (COLLATE)     │
      └────────────────┘

┌─────────────────────────────────┐
│   Configuration Layer           │
│  ┌──────────────────────────┐   │
│  │  YAML Mappings           │   │
│  │  - Service004_create     │   │
│  │  - Service004_update     │   │
│  │  - Service003_create     │   │
│  │  - ...                   │   │
│  └──────────────────────────┘   │
└─────────────────────────────────┘
```

### 2.2 Component Diagram

```
┌────────────────────────────────────────────────────────────┐
│                   MappingEngine.java                       │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │ YAML Loader  │  │ JSON Parser  │  │ XML Builder  │   │
│  │ (SnakeYAML)  │  │  (Jackson)   │  │    (DOM)     │   │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘   │
│         │                 │                  │            │
│         └─────────┬───────┴──────────────────┘            │
│                   ▼                                       │
│         ┌──────────────────┐                             │
│         │  Transform Core  │                             │
│         │  - Field Mapping │                             │
│         │  - Array Mapping │                             │
│         │  - Filter Logic  │                             │
│         │  - Format Apply  │                             │
│         └──────────────────┘                             │
│                                                            │
└────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│                   MappingSpec.java                         │
├────────────────────────────────────────────────────────────┤
│  Data Classes:                                             │
│  - MappingSpec                                             │
│  - FieldMap                                                │
│  - ArrayMap                                                │
│  - ArrayFilter                                             │
│  - SubField                                                │
└────────────────────────────────────────────────────────────┘
```

---

## 3. Component Details

### 3.1 MappingEngine Component

#### 3.1.1 Class: `MappingEngine.java`

**Location**: `com.aib.securities.engine.MappingEngine`

**Responsibilities**:
- Load and parse YAML mapping specifications
- Transform JSON to XML based on mapping rules
- Apply filters for multi-role party separation
- Format date, timestamp, and decimal values
- Generate well-formed XML with proper structure and attributes

**Key Methods**:

```java
public class MappingEngine {
    // Instance Variables
    private final ObjectMapper mapper = new ObjectMapper();
    private final Map<String, MappingSpec> byKey = new HashMap<>();

    // Constructor - Loads all YAML mappings
    public MappingEngine()

    // Main transformation method
    public String transform(String service, String operation,
                          String json, Map<String, String> ctx) throws Exception

    // Helper Methods
    private Document newDocument() throws Exception
    private String readDotPath(JsonNode node, String path)
    private JsonNode readNode(JsonNode node, String path)
    private String applyFormat(String value, String format)
    private Element pathEnsure(Document doc, Element parent, String xpath)
    private void writeXPathValue(Document doc, Element base, String xpath, String value)
    private void writeXPathValueWithIndex(Document doc, Element base, String xpath,
                                         String value, String indexAttr, int indexValue)
    private boolean matchesFilter(JsonNode item, MappingSpec.ArrayMap.ArrayFilter filter)
    private boolean matchesFilterValue(String value, List<String> filterValues)
    private String toString(Document doc) throws Exception
}
```

#### 3.1.2 Mapping Loading Logic

```java
// Loads all YAML files at initialization
String[] files = new String[] {
    "mappings/SecuritiesService004_create.yaml",
    "mappings/SecuritiesService004_update.yaml",
    "mappings/SecuritiesService003_create.yaml",
    "mappings/SecuritiesService003_update.yaml",
    "mappings/SecuritiesService006_create.yaml",
    "mappings/SecuritiesService006_update.yaml",
    "mappings/SecuritiesService007_create.yaml",
    "mappings/SecuritiesService007_update.yaml",
    "mappings/SecuritiesService033_create.yaml",
    "mappings/SecuritiesService033_update.yaml",
    "mappings/SecuritiesService034_create.yaml",
    "mappings/SecuritiesService034_update.yaml",
    "mappings/SecuritiesService042_create.yaml",
    "mappings/SecuritiesService042_update.yaml"
};

// Store by composite key: "ServiceName:operation"
String key = spec.service + ":" + spec.operation;
byKey.put(key, spec);
```

---

### 3.2 MappingSpec Component

#### 3.2.1 Class: `MappingSpec.java`

**Location**: `com.aib.securities.mapping.MappingSpec`

**Purpose**: Data models for YAML mapping configuration

**Class Structure**:

```java
public class MappingSpec {
    public String service;              // e.g., "SecuritiesService004"
    public String operation;            // "create" | "update"
    public String transaction;          // Transaction node value
    public String transactionVersion;   // Default "1"
    public String rootXPath;            // Relative path (no /Request/ prefix)
    public String servType500;          // "C" | "U"
    public List<FieldMap> fields;       // Scalar mappings
    public List<ArrayMap> arrays;       // Array/group mappings
    public Map<String, String> defaults;
    public Envelope envelope;

    // Inner Classes
    public static class Envelope { ... }
    public static class FieldMap { ... }
    public static class ArrayMap { ... }
}
```

#### 3.2.2 FieldMap Class

```java
public static class FieldMap {
    public String json;         // Dot-notation path (e.g., "assignmentOfLife.policyType")
    public String xpath;        // Target XPath with attributes
    public String format;       // Format type: date_ddMMyyyy | timestamp_yyyyMMddHHmmssSSSSSS | decimal
    public boolean required;    // Validation flag
    public String constant;     // Fixed value (overrides json)
}
```

#### 3.2.3 ArrayMap Class

```java
public static class ArrayMap {
    public String json;                 // Source array path
    public String countXPath;           // XPath for count element
    public String listItemXPath;        // XPath for container
    public int startIndex;              // Usually 0
    public String indexAttribute;       // Usually "index"
    public ArrayFilter filter;          // Optional role-based filter
    public List<SubField> mappings;     // Child field mappings

    public static class ArrayFilter {
        public String field;            // Nested path to check
        public List<String> values;     // Acceptable values (OR logic)
    }

    public static class SubField {
        public String json;             // Relative field path
        public String xpath;            // Child element XPath
        public String constant;         // Fixed value
        public String format;           // Optional formatter
        public String indexAttribute;   // For indexed children
    }
}
```

---

## 4. Data Models

### 4.1 Input JSON Structure

```json
{
  "assignmentOfLife": {
    "policyType": "ENDW",
    "policyNumber": "string",
    "sumAssured": "string",
    "expiryDate": "2025-10-10"
  },
  "securityItem": {
    "itemNumber": "111111111111111111111111",  // Required for UPDATE
    "currentStatus": "APFH",
    "napsAppId": "string",
    "slaCode": "A0"
  },
  "custSecurities": [
    {
      "cifKey": "0100000938437104000",
      "securityInvolvement": [
        {
          "involvementRole": "BENEFJOIN",
          "involvementType": "SECUR"
        },
        {
          "involvementRole": "BORROWJOIN",
          "involvementType": "SECUR"
        },
        {
          "involvementRole": "LIFEASSURE",
          "involvementType": "SECUR"
        }
      ]
    }
  ],
  "napsDetails": [
    {
      "napsAppId": "string"
    }
  ]
}
```

**Key Points**:
- `custSecurities` used for BOTH CREATE and UPDATE operations
- Single CIF can have multiple roles via `securityInvolvement` array
- Same CIF appears in multiple XML groups based on roles

### 4.2 Output XML Structure

```xml
<?xml version="1.0" encoding="UTF-8"?>
<Request>
    <!-- Envelope Fields -->
    <Log>N</Log>
    <ID>
        <version>1.0</version>
        <AppID>NBP</AppID>
        <AppName>SysTest_CAS_ROI_Current</AppName>
        <UsrID>5324654654</UsrID>
        <UnqID>88140</UnqID>
    </ID>
    <regionCode>ROI</regionCode>
    <sourceNSC>931012</sourceNSC>
    <staffNumber>88140</staffNumber>
    <deviceId/>
    <Transaction>SecuritiesService004</Transaction>
    <TransactionVersion>1</TransactionVersion>

    <!-- Service-Specific Data -->
    <SecuritiesService004>
        <servType500>C</servType500>
        <source500>NAPS</source500>

        <!-- Indexed Fields -->
        <ITEM_NUMBER index="1"/>
        <CURRENT_STATUS index="1">APFH</CURRENT_STATUS>
        <SECURITY_TYPE index="1">LIFE POL</SECURITY_TYPE>
        <!-- ... 60-80 more indexed fields ... -->

        <!-- Involvement Groups -->
        <BENOWN_INV_GROUP>2</BENOWN_INV_GROUP>
        <BenOwnInvGroup>
            <listitem index="0">
                <BENOWN_INV_COMPANY_INDICATOR index="0"> </BENOWN_INV_COMPANY_INDICATOR>
                <BENOWN_HELD_ON_CIF_INDICATOR index="0">Y</BENOWN_HELD_ON_CIF_INDICATOR>
                <BENOWN_INVOLVEMENT_TYPE index="0">SECUR</BENOWN_INVOLVEMENT_TYPE>
                <BENOWN_INVOLVEMENT_ROLE index="0">BENEFJOIN </BENOWN_INVOLVEMENT_ROLE>
                <BENOWN_CIF_REF_NUMBER index="0">0100000938437104000</BENOWN_CIF_REF_NUMBER>
                <BENOWN_COMPANY_ID index="0">000000000000000</BENOWN_COMPANY_ID>
            </listitem>
            <listitem index="1">
                <!-- Second beneficiary -->
            </listitem>
        </BenOwnInvGroup>

        <BORROWCUST_INV_GROUP>2</BORROWCUST_INV_GROUP>
        <BorrowCustInvGroup>
            <!-- Similar structure -->
        </BorrowCustInvGroup>

        <!-- Empty groups still have containers -->
        <SIGNEDBY_INV_GROUP>0</SIGNEDBY_INV_GROUP>
        <SignedByInvGroup/>

    </SecuritiesService004>
</Request>
```

---

## 5. Processing Flow

### 5.1 Overall Transformation Flow

```
┌─────────────────────────────────────────────────────────────┐
│ 1. Request Reception                                        │
│    - Receive JSON from REST API                             │
│    - Extract service type and operation                     │
└────────────────┬────────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. Mapping Lookup                                           │
│    - Construct key: "ServiceName:operation"                 │
│    - Retrieve MappingSpec from cache                        │
│    - Throw error if mapping not found                       │
└────────────────┬────────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. JSON Parsing                                             │
│    - Parse JSON string to JsonNode tree                     │
│    - Validate structure                                     │
└────────────────┬────────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. XML Document Creation                                    │
│    - Create new DOM Document                                │
│    - Create root <Request> element                          │
└────────────────┬────────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────────┐
│ 5. Field Mapping (Scalar Fields)                            │
│    FOR EACH field in spec.fields:                           │
│      a. Read value from JSON (or use constant)              │
│      b. Apply format transformation if specified            │
│      c. Validate if required field                          │
│      d. Write to XML at specified XPath                     │
│      e. Set index attribute if present                      │
└────────────────┬────────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────────┐
│ 6. Array Mapping (Complex Fields)                           │
│    FOR EACH array in spec.arrays:                           │
│      a. Read source array from JSON                         │
│      b. Apply filter if specified                           │
│      c. Write count to countXPath                           │
│      d. Create container element if count=0                 │
│      e. FOR EACH filtered item:                             │
│         - Create listitem element with index                │
│         - Map all subfields                                 │
│         - Apply formatting                                  │
│         - Set index attributes                              │
└────────────────┬────────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────────┐
│ 7. XML Serialization                                        │
│    - Convert DOM to string                                  │
│    - Apply formatting (indentation)                         │
│    - Return XML string                                      │
└─────────────────────────────────────────────────────────────┘
```

### 5.2 Filter Processing Algorithm

```java
// Pseudo-code for filter matching
boolean matchesFilter(JsonNode custSecurity, ArrayFilter filter) {
    if (filter == null) return true;  // No filter = include all

    // Parse filter path: "securityInvolvement.involvementRole"
    String[] pathParts = filter.field.split("\\.");

    // Navigate to nested array
    JsonNode current = custSecurity;
    for (int i = 0; i < pathParts.length; i++) {
        current = current.get(pathParts[i]);

        // If current is an array, check ALL items
        if (current.isArray() && hasRemainingPath) {
            String remainingPath = joinPathParts(i+1, pathParts.length);

            for (JsonNode arrayItem : current) {
                String value = readDotPath(arrayItem, remainingPath);
                if (matchesFilterValue(value, filter.values)) {
                    return true;  // ANY match = include
                }
            }
            return false;  // NONE matched = exclude
        }
    }

    // Simple field case
    String value = current.asText();
    return matchesFilterValue(value, filter.values);
}
```

**Example**:
```json
{
  "cifKey": "12345",
  "securityInvolvement": [
    {"involvementRole": "BENEFJOIN"},
    {"involvementRole": "BORROWJOIN"},
    {"involvementRole": "LIFEASSURE"}
  ]
}
```

Filter for `BENEFJOIN` → Checks ALL 3 roles → Finds match → **Include**
Filter for `GUARANTOR` → Checks ALL 3 roles → No match → **Exclude**

### 5.3 Multi-Role Separation Example

**Input**: Single CIF with 3 roles
```json
{
  "cifKey": "0100000938437104000",
  "securityInvolvement": [
    {"involvementRole": "BENEFJOIN"},
    {"involvementRole": "BORROWJOIN"},
    {"involvementRole": "LIFEASSURE"}
  ]
}
```

**Output**: Same CIF appears in 3 different XML groups
```xml
<BENOWN_INV_GROUP>1</BENOWN_INV_GROUP>
<BenOwnInvGroup>
    <listitem index="0">
        <BENOWN_CIF_REF_NUMBER index="0">0100000938437104000</BENOWN_CIF_REF_NUMBER>
    </listitem>
</BenOwnInvGroup>

<BORROWCUST_INV_GROUP>1</BORROWCUST_INV_GROUP>
<BorrowCustInvGroup>
    <listitem index="0">
        <BORROWCUST_CIF_REF_NUMBER index="0">0100000938437104000</BORROWCUST_CIF_REF_NUMBER>
    </listitem>
</BorrowCustInvGroup>

<LIFEASSURE_INV_GROUP>1</LIFEASSURE_INV_GROUP>
<LifeAssureInvGroup>
    <listitem index="0">
        <LIFEASSURE_CIF_REF_NUMBER index="0">0100000938437104000</LIFEASSURE_CIF_REF_NUMBER>
    </listitem>
</LifeAssureInvGroup>
```

---

## 6. YAML Mapping Specification

### 6.1 Complete YAML Structure

```yaml
# Header Section
service: SecuritiesService004
operation: create
transaction: SecuritiesService004
transactionVersion: "1"
rootXPath: SecuritiesService004  # RELATIVE PATH - NO /Request/ PREFIX!
servType500: "C"

# Field Mappings Section
fields:
  # ========================
  # Envelope Fields (12 fields - always first)
  # ========================
  - constant: "N"
    xpath: Log

  - constant: "1.0"
    xpath: ID/version
  - constant: "NBP"
    xpath: ID/AppID
  - constant: "SysTest_CAS_ROI_Current"
    xpath: ID/AppName
  - constant: "5324654654"
    xpath: ID/UsrID
  - constant: "88140"
    xpath: ID/UnqID

  - constant: "ROI"
    xpath: regionCode
  - constant: "931012"
    xpath: sourceNSC
  - constant: "88140"
    xpath: staffNumber
  - constant: ""
    xpath: deviceId
  - constant: "SecuritiesService004"
    xpath: Transaction
  - constant: "1"
    xpath: TransactionVersion

  # ========================
  # Service Fields (60-80 fields with [@index='1'])
  # ========================
  - constant: "C"
    xpath: SecuritiesService004/servType500
  - constant: "NAPS"
    xpath: SecuritiesService004/source500

  # For UPDATE only - required field
  - json: securityItem.itemNumber
    xpath: SecuritiesService004/ITEM_NUMBER[@index='1']
    required: true

  # Standard indexed fields
  - json: securityItem.currentStatus
    xpath: SecuritiesService004/CURRENT_STATUS[@index='1']

  - constant: "LIFE POL"
    xpath: SecuritiesService004/SECURITY_TYPE[@index='1']

  # Fields with formatting
  - json: assignmentOfLife.expiryDate
    xpath: SecuritiesService004/LIFEPOL_EXPIRY_DATE[@index='1']
    format: date_ddMMyyyy

  - json: audit.lastUpdatedTimestamp
    xpath: SecuritiesService004/LAST_UPDATED_TIMESTAMP[@index='1']
    format: timestamp_yyyyMMddHHmmssSSSSSS

  - json: securityItem.valuation.amount
    xpath: SecuritiesService004/VALUATION_AMOUNT[@index='1']
    format: decimal

# Array Mappings Section
arrays:
  # ========================
  # Filtered Array (with role-based filtering)
  # ========================
  - json: custSecurities
    countXPath: SecuritiesService004/BENOWN_INV_GROUP
    listItemXPath: SecuritiesService004/BenOwnInvGroup
    startIndex: 0
    indexAttribute: index
    filter:
      field: securityInvolvement.involvementRole
      values:
        - BENEFJOIN
        - BENEFSOLE
    mappings:
      - constant: " "
        xpath: BENOWN_INV_COMPANY_INDICATOR
        indexAttribute: index
      - constant: "Y"
        xpath: BENOWN_HELD_ON_CIF_INDICATOR
        indexAttribute: index
      - constant: "SECUR"
        xpath: BENOWN_INVOLVEMENT_TYPE
        indexAttribute: index
      - constant: "BENEFJOIN "
        xpath: BENOWN_INVOLVEMENT_ROLE
        indexAttribute: index
      - json: cifKey
        xpath: BENOWN_CIF_REF_NUMBER
        indexAttribute: index
      - constant: "000000000000000"
        xpath: BENOWN_COMPANY_ID
        indexAttribute: index

  # ========================
  # Empty Array (no mappings)
  # ========================
  - json: signedByInvolvements
    countXPath: SecuritiesService004/SIGNEDBY_INV_GROUP
    listItemXPath: SecuritiesService004/SignedByInvGroup
    startIndex: 0
    indexAttribute: index
    mappings: []
```

### 6.2 Field Mapping Rules

| Rule | Description | Example |
|------|-------------|---------|
| **Constant Value** | Use `constant` to specify fixed value | `constant: "LIFE POL"` |
| **JSON Path** | Use dot notation for nested fields | `json: assignmentOfLife.policyType` |
| **XPath Relative** | All XPaths are relative to root | `xpath: SecuritiesService004/POLICY_TYPE[@index='1']` |
| **Index Attribute** | Use [@index='1'] for indexed fields | `ITEM_NUMBER[@index='1']` |
| **Required Fields** | Set `required: true` for validation | Used for itemNumber in UPDATE |
| **Format Date** | Use `date_ddMMyyyy` for date conversion | Input: 2025-10-10 → Output: 10/10/2025 |
| **Format Timestamp** | Use `timestamp_yyyyMMddHHmmssSSSSSS` | Strips non-numeric characters |
| **Format Decimal** | Use `decimal` to remove commas | Input: 1,234.56 → Output: 1234.56 |

### 6.3 Array Mapping Rules

| Rule | Description | Example |
|------|-------------|---------|
| **Source Path** | Point to JSON array | `json: custSecurities` |
| **Count XPath** | Where to write array count | `countXPath: .../BENOWN_INV_GROUP` |
| **Container XPath** | Parent element for listitems | `listItemXPath: .../BenOwnInvGroup` |
| **Start Index** | Usually 0 | `startIndex: 0` |
| **Index Attribute** | Attribute name for indices | `indexAttribute: index` |
| **Filter Field** | Nested field to check | `field: securityInvolvement.involvementRole` |
| **Filter Values** | Acceptable values (OR logic) | `values: [BENEFJOIN, BENEFSOLE]` |
| **SubField JSON** | Relative to array item | `json: cifKey` |
| **SubField XPath** | Relative to listitem | `xpath: BENOWN_CIF_REF_NUMBER` |
| **SubField Index** | Add index attribute | `indexAttribute: index` |

---

## 7. Transformation Rules

### 7.1 Date Formatting

**Format**: `date_ddMMyyyy`

**Transformation**:
- Input Format: `yyyy-MM-dd` (ISO-8601)
- Output Format: `dd/MM/yyyy`
- Implementation: `LocalDate.parse(value).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))`

**Examples**:
```
2025-10-10 → 10/10/2025
2025-01-15 → 15/01/2025
2024-12-31 → 31/12/2024
```

### 7.2 Timestamp Formatting

**Format**: `timestamp_yyyyMMddHHmmssSSSSSS`

**Transformation**:
- Input: Any format with date/time components
- Output: Numeric only, format `yyyyMMddHHmmssSSSSSS`
- Implementation: `value.replaceAll("[^0-9]", "")`

**Examples**:
```
2025-07-29T10:29:11.104 → 20250729102911104
20250729102911104000   → 20250729102911104000
2025/07/29 10:29:11    → 20250729102911
```

### 7.3 Decimal Formatting

**Format**: `decimal`

**Transformation**:
- Removes thousand separators (commas)
- Keeps decimal point
- Implementation: `value.replaceAll(",", "")`

**Examples**:
```
1,234.56   → 1234.56
10,000     → 10000
999.99     → 999.99
```

### 7.4 XPath Resolution

**Algorithm**:
1. Split XPath by `/`
2. For each part:
   - Extract element name (remove `[@index='...']`)
   - Find or create child element
   - If index attribute exists, apply it
3. Set text content on final element

**Example**:
```yaml
xpath: SecuritiesService004/POLICY_TYPE[@index='1']
```

**Generates**:
```xml
<SecuritiesService004>
    <POLICY_TYPE index="1">ENDW</POLICY_TYPE>
</SecuritiesService004>
```

### 7.5 Empty Container Creation

**Rule**: When array count = 0, still create empty container element

**Before Fix** (Bug):
```xml
<BENOWN_INV_GROUP>0</BENOWN_INV_GROUP>
<!-- No container element! -->
```

**After Fix**:
```xml
<BENOWN_INV_GROUP>0</BENOWN_INV_GROUP>
<BenOwnInvGroup/>
```

**Implementation** (MappingEngine.java line 107-109):
```java
// If count is 0, always create empty container element
if (count == 0) {
    pathEnsure(doc, request, arr.listItemXPath);
}
```

---

## 8. API Contracts

### 8.1 Swagger API Definition

**Base Path**: `/{region}/v1/securities-mortgage`

**Endpoints**:

| Security Type | POST (Create) | PUT (Update) |
|---------------|---------------|--------------|
| Life Policy | `/life-policy` | `/life-policy` |
| Debenture | `/debenture` | `/debenture` |
| Letter of Guarantee | `/letter-of-guarantee` | `/letter-of-guarantee` |
| Mortgage Over Property | `/mortgage-over-property` | `/mortgage-over-property` |

### 8.2 Request Body Schema

**Common Structure** (Both POST and PUT):

```json
{
  "assignmentOfLife": { /* Security-specific fields */ },
  "securityItem": {
    "itemNumber": "string",        // REQUIRED for UPDATE
    "currentStatus": "APFH|APPR|OTLA|...",
    "napsAppId": "string",
    "slaCode": "A0|H0|L0|N0|S0"
  },
  "custSecurities": [              // SAME for CREATE and UPDATE
    {
      "cifKey": "string",
      "securityInvolvement": [
        {
          "involvementRole": "BENEFJOIN|BENEFSOLE|BORROWJOIN|BORROWSOLE|LIFEASSURE|GUARANTOR",
          "involvementType": "SECUR"
        }
      ]
    }
  ],
  "napsDetails": [],
  "supportingSecurity": [],
  "accountDetails": []
}
```

### 8.3 Response Schema

**Success Response (201 for POST, 204 for PUT)**:

```json
{
  "ledCollateInternaId": "string",
  "assetCollateInternaId": ["string"]
}
```

**Error Response (400/401/403/404/503)**:

```json
{
  "timestamp": "2025-10-10T11:31:06.611+01:00",
  "status": 400,
  "error": "Bad Request",
  "message": "Missing required field: itemNumber",
  "path": "/roi/v1/securities-mortgage/life-policy"
}
```

---

## 9. Error Handling

### 9.1 Error Categories

| Error Type | HTTP Status | Handling Strategy |
|------------|-------------|-------------------|
| Mapping Not Found | 500 | `IllegalArgumentException` - No mapping for service:operation |
| Required Field Missing | 400 | `IllegalArgumentException` - Missing required field: {field} |
| Invalid Format | 400 | `Exception` - Date/timestamp parsing error |
| JSON Parse Error | 400 | `JsonProcessingException` - Invalid JSON structure |
| XML Generation Error | 500 | `TransformerException` - XML serialization failed |

### 9.2 Validation Rules

**Required Fields Validation**:
```java
if (fm.required && (value == null || value.isBlank())) {
    throw new IllegalArgumentException("Missing required field: " + fm.json);
}
```

**Applied to**:
- UPDATE operations: `itemNumber` is required
- CREATE operations: Service-specific required fields (e.g., `guaranteeType`)

### 9.3 Exception Propagation

```
Controller Layer
    ↓ try-catch
Service Layer
    ↓ propagate
MappingEngine.transform()
    ↓ throws Exception
    ├─ IllegalArgumentException (validation)
    ├─ JsonProcessingException (JSON parsing)
    └─ TransformerException (XML generation)
```

---

## 10. Configuration Management

### 10.1 YAML File Organization

```
src/main/resources/mappings/
├── SecuritiesService003_create.yaml  (Letter of Guarantee)
├── SecuritiesService003_update.yaml
├── SecuritiesService004_create.yaml  (Assignment of Life Policy)
├── SecuritiesService004_update.yaml
├── SecuritiesService006_create.yaml  (Counter Indemnity)
├── SecuritiesService006_update.yaml
├── SecuritiesService007_create.yaml  (Letter of Lien)
├── SecuritiesService007_update.yaml
├── SecuritiesService033_create.yaml  (Mortgage Debenture)
├── SecuritiesService033_update.yaml
├── SecuritiesService034_create.yaml  (Mortgage Over Property)
├── SecuritiesService034_update.yaml
├── SecuritiesService042_create.yaml  (Letter of Pledge)
└── SecuritiesService042_update.yaml
```

### 10.2 Sample XML Organization

```
src/main/resources/sample_xmls/
├── SecuritiesService003_LetterOfGuarantee.xml
├── SecuritiesService003_UpdateLetterOfGuarantee.xml
├── SecuritiesService004_AssignmentOfLifePolicy.xml
├── SecuritiesService004_UpdateAssignmentOfLifePolicy.xml
├── SecuritiesService006_CounterIndemnity.xml
├── SecuritiesService006_UpdateCounterIndemnity.xml
├── SecuritiesService007_LetterOfLien.xml
├── SecuritiesService007_UpdateLetterOfLien.xml
├── SecuritiesService033_MortgageDebenture.xml
├── SecuritiesService033_UpdateMortgageDebenture.xml
├── SecuritiesService034_MortgageOverProperty.xml
├── SecuritiesService034_UpdateMortgageOverProperty.xml
├── SecuritiesService042_LetterOfPledge.xml
└── SecuritiesService042_UpdateLetterOfPledge.xml
```

**Purpose**: Sample XMLs serve as **Source of Truth** for validation

### 10.3 Swagger Organization

```
src/main/resources/swaggers/
└── swagger1.yml  (Main API specification)
```

---

## 11. Performance Considerations

### 11.1 Optimization Strategies

| Area | Strategy | Benefit |
|------|----------|---------|
| YAML Loading | Load once at startup, cache in Map | Avoid repeated file I/O |
| JSON Parsing | Jackson streaming API | Memory efficient for large payloads |
| XML Generation | DOM API with pre-sized elements | Controlled memory usage |
| XPath Resolution | Iterative navigation vs XPath API | Faster element lookup |
| Filter Evaluation | Early termination on first match | Reduce iteration |

### 11.2 Memory Profile

**Estimated Memory per Request**:
- Input JSON: ~5-10 KB
- Parsed JsonNode tree: ~20-40 KB
- DOM Document: ~50-100 KB
- Output XML String: ~15-30 KB

**Total**: ~100-200 KB per transformation

**Concurrent Requests**:
- Spring Boot thread pool (default 200 threads)
- Estimated heap requirement: 200 threads × 200 KB = 40 MB

### 11.3 Throughput Estimates

**Single Thread Performance**:
- YAML cache lookup: <1 ms
- JSON parsing: 2-5 ms
- Transformation: 10-20 ms
- XML serialization: 5-10 ms
- **Total**: ~20-35 ms per request

**Estimated Throughput**:
- Single thread: ~30-50 requests/second
- 200 threads: ~6,000-10,000 requests/second (CPU bound)

---

## 12. Testing Strategy

### 12.1 Unit Testing

**Test Cases per Security Type**:

```java
@Test
public void testSecuritiesService004_Create_ValidInput() {
    // Given
    String json = loadTestJson("Assignment_of_Life_Policy_create.json");
    String expectedXml = loadSampleXml("SecuritiesService004_AssignmentOfLifePolicy.xml");

    // When
    String actualXml = mappingEngine.transform("SecuritiesService004", "create", json, null);

    // Then
    assertXmlEquals(expectedXml, actualXml);
}

@Test
public void testSecuritiesService004_Update_ValidInput() {
    // Test UPDATE operation
}

@Test
public void testSecuritiesService004_Update_MissingItemNumber() {
    // Should throw IllegalArgumentException
}

@Test
public void testMultiRoleInvolvement() {
    // Verify single CIF appears in multiple groups
}

@Test
public void testEmptyArrays() {
    // Verify empty containers are created
}

@Test
public void testDateFormatting() {
    // Verify date conversion
}

@Test
public void testTimestampFormatting() {
    // Verify timestamp conversion
}

@Test
public void testDecimalFormatting() {
    // Verify decimal conversion
}
```

### 12.2 Integration Testing

**Test Scenarios**:
1. End-to-end POST request → XML generation → Legacy system
2. End-to-end PUT request → XML generation → Legacy system
3. Error handling for invalid JSON
4. Error handling for missing mappings
5. Performance testing under load

### 12.3 Validation Testing

**XML Validation**:
- Compare against sample XMLs (source of truth)
- Verify all indexed fields have index attribute
- Verify empty containers are present
- Verify multi-role separation logic
- Verify date/timestamp/decimal formatting

### 12.4 Test Data

**Coverage Matrix**:

| Security Type | Create Test | Update Test | Multi-Role Test | Empty Arrays Test |
|---------------|-------------|-------------|-----------------|-------------------|
| Service003 (Letter of Guarantee) | ✓ | ✓ | ✓ | ✓ |
| Service004 (Life Policy) | ✓ | ✓ | ✓ | ✓ |
| Service006 (Counter Indemnity) | ✓ | ✓ | ✓ | ✓ |
| Service007 (Letter of Lien) | ✓ | ✓ | ✓ | ✓ |
| Service033 (Mortgage Debenture) | ✓ | ✓ | ✓ | ✓ |
| Service034 (Mortgage Over Property) | ✓ | ✓ | ✓ | ✓ |
| Service042 (Letter of Pledge) | ✓ | ✓ | ✓ | ✓ |

---

## Appendices

### Appendix A: Security Type Reference

| Service ID | Security Type | Description |
|------------|---------------|-------------|
| SecuritiesService003 | Letter of Guarantee | Personal/Company guarantees |
| SecuritiesService004 | Assignment of Life Policy | Life insurance policies |
| SecuritiesService005 | Solicitor's Undertaking | Legal undertakings (not implemented) |
| SecuritiesService006 | Counter Indemnity | Indemnity agreements |
| SecuritiesService007 | Letter of Lien | Lien on assets |
| SecuritiesService033 | Mortgage Debenture | Debenture mortgages |
| SecuritiesService034 | Mortgage Over Property | Property mortgages |
| SecuritiesService039 | Miscellaneous | Other securities (not implemented) |
| SecuritiesService040 | Marine Mortgage | Ship/vessel mortgages (not implemented) |
| SecuritiesService042 | Letter of Pledge | Pledged assets |

### Appendix B: Involvement Role Reference

| Role Code | Group | Description |
|-----------|-------|-------------|
| BENEFJOIN | BENOWN_INV_GROUP | Joint beneficial owner |
| BENEFSOLE | BENOWN_INV_GROUP | Sole beneficial owner |
| BORROWJOIN | BORROWCUST_INV_GROUP | Joint borrower |
| BORROWSOLE | BORROWCUST_INV_GROUP | Sole borrower |
| LIFEASSURE | LIFEASSURE_INV_GROUP | Life assured party |
| GUARANTOR | GUARANTOR_INV_GROUP | Guarantor |
| SIGNEDBY | SIGNEDBY_INV_GROUP | Signatory (not used) |
| COMPANY | COMPANY_INV_GROUP | Company involvement (not used) |
| TRUSTEE | TRUSTEE_INV_GROUP | Trustee (not used) |

### Appendix C: Status Code Reference

**Security Status Codes** (`currentStatus`):

| Code | Description |
|------|-------------|
| APFH | Approved - Family Home |
| APPR | Approved |
| APRE | Approved - Restricted Facility |
| EXIO | EX - held items awaited |
| EXNA | Executed/Held Not Approved |
| EXSR | EX with Solicitor Registration |
| HEEX | Held/Re-examine on review |
| IDRU | Sent to IDRU |
| NENF | Not Enforceable |
| OTAD | O/S waiting info to prep |
| OTCU | O/S with Customer/Solicitor |
| OTLA | O/S Lender to arrange |
| TKAP | Approved Prior System |
| RELE | Released |

**SLA Codes** (`slaCode`):

| Code | Description |
|------|-------------|
| A0 | Access Records |
| H0 | Home Mortgages |
| L0 | Ledger |
| N0 | AMU/NAPS |
| S0 | SAM & Collate |

### Appendix D: Change Log

| Date | Version | Author | Changes |
|------|---------|--------|---------|
| 2025-10-10 | 1.0 | AIB Dev Team | Initial LLD creation |

---

## Document Approval

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Technical Lead | | | |
| Architect | | | |
| QA Lead | | | |

---

**End of Document**
