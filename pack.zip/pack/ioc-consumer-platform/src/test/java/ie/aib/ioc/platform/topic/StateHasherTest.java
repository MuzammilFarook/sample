package ie.aib.ioc.platform.topic;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

import ie.aib.ioc.platform.core.ChangeKind;

class StateHasherTest {

    record Money(BigDecimal amount, String currency, String note) {
    }

    record Ccv(List<String> customers) {
    }

    private static boolean same(byte[] a, byte[] b) {
        return Arrays.equals(a, b);
    }

    @Test
    void amountsIgnoreScale() {
        StateHasher h = new StateHasher(Money.class, List.of());
        assertThat(same(h.hash(ChangeKind.UPSERT, new Money(new BigDecimal("100.0"), "EUR", null)),
                h.hash(ChangeKind.UPSERT, new Money(new BigDecimal("100.00"), "EUR", null)))).isTrue();
    }

    @Test
    void onlyTheConfiguredFieldsCount() {
        StateHasher h = new StateHasher(Money.class, List.of("amount", "currency"));
        assertThat(same(h.hash(ChangeKind.UPSERT, new Money(BigDecimal.TEN, "EUR", "a")),
                h.hash(ChangeKind.UPSERT, new Money(BigDecimal.TEN, "EUR", "b")))).isTrue();
        assertThat(same(h.hash(ChangeKind.UPSERT, new Money(BigDecimal.TEN, "EUR", "a")),
                h.hash(ChangeKind.UPSERT, new Money(BigDecimal.ONE, "EUR", "a")))).isFalse();
    }

    @Test
    void nullIsNotAnEmptyStringAndKindCounts() {
        StateHasher h = new StateHasher(Money.class, List.of());
        assertThat(same(h.hash(ChangeKind.UPSERT, new Money(null, "", null)),
                h.hash(ChangeKind.UPSERT, new Money(null, null, null)))).isFalse();
        assertThat(same(h.hash(ChangeKind.UPSERT, new Money(null, null, null)),
                h.hash(ChangeKind.DELETE, new Money(null, null, null)))).isFalse();
    }

    @Test
    void listsAreWalked() {
        StateHasher h = new StateHasher(Ccv.class, List.of());
        assertThat(same(h.hash(ChangeKind.UPSERT, new Ccv(List.of("1", "2"))), h.hash(ChangeKind.UPSERT, new Ccv(List.of("1", "2"))))).isTrue();
        assertThat(same(h.hash(ChangeKind.UPSERT, new Ccv(List.of("1", "2"))), h.hash(ChangeKind.UPSERT, new Ccv(List.of("12"))))).isFalse();
    }

    @Test
    void unknownFieldFailsAtStartUp() {
        assertThatThrownBy(() -> new StateHasher(Money.class, List.of("amount", "typo")))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("typo");
    }
}
