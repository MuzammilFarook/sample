package ie.aib.ioc.platform.topic;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Instant;
import java.util.List;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.junit.jupiter.api.Test;

import ie.aib.ioc.platform.core.ChangeKind;
import ie.aib.ioc.platform.topic.TopicsProperties.EnvelopeFields;

/** Envelope items read from configured field paths: a header-style topic (CIF_CCV) and a flat one (account balance). */
class EnvelopeReaderTest {

    private static final Schema CCV = new Schema.Parser().parse("""
            {"type":"record","name":"CifCcvEntity","fields":[
              {"name":"header","type":{"type":"record","name":"H","fields":[
                {"name":"eventId","type":"string"},
                {"name":"actionType","type":{"type":"enum","name":"A","symbols":["INSERT","UPDATE","DELETE","UNKNOWN"]}},
                {"name":"aggregateVersion","type":"long"},
                {"name":"sourceChangedAt","type":{"type":"long","logicalType":"timestamp-micros"}},
                {"name":"correlationId","type":["null","string"],"default":null}]}},
              {"name":"ccvId","type":"string"}]}""");

    private static final Schema FLAT = new Schema.Parser().parse("""
            {"type":"record","name":"Flat","fields":[
              {"name":"accountId","type":"string"},
              {"name":"updatedDateTime","type":["null",{"type":"long","logicalType":"timestamp-micros"}],"default":null},
              {"name":"stamp","type":["null","string"],"default":null},
              {"name":"millis","type":["null",{"type":"long","logicalType":"timestamp-millis"}],"default":null}]}""");

    private static final Instant T = Instant.parse("2026-11-17T09:00:01.234567Z");
    private static final long T_MICROS = 1_794_906_001_234_567L;

    private static GenericRecord ccv(String action) {
        GenericRecord h = new GenericData.Record(CCV.getField("header").schema());
        h.put("eventId", "CCV:10000005:42");
        h.put("actionType", new GenericData.EnumSymbol(CCV.getField("header").schema().getField("actionType").schema(), action));
        h.put("aggregateVersion", 42L);
        h.put("sourceChangedAt", T_MICROS);
        h.put("correlationId", "abc123");
        GenericRecord r = new GenericData.Record(CCV);
        r.put("header", h);
        r.put("ccvId", "10000005");
        return r;
    }

    private static EnvelopeFields ccvFields() {
        EnvelopeFields f = new EnvelopeFields();
        f.setEntityKey("ccvId");
        f.setVersion("header.aggregateVersion");
        f.setEventId("header.eventId");
        f.getChangeKind().setField("header.actionType");
        f.getChangeKind().setDeleteValues(List.of("DELETE"));
        f.setBusinessTime("header.sourceChangedAt");
        f.setTraceId("header.correlationId");
        return f;
    }

    @Test
    void readsEveryItemFromHeaderFields() {
        Envelope e = new EnvelopeReader("cif.ccv", ccvFields()).read(ccv("UPDATE"));
        assertThat(e.valid()).isTrue();
        assertThat(e.entityKey()).isEqualTo("10000005");
        assertThat(e.version()).isEqualTo(42L);
        assertThat(e.eventId()).isEqualTo("CCV:10000005:42");
        assertThat(e.kind()).isEqualTo(ChangeKind.UPSERT);
        assertThat(e.businessTime()).isEqualTo(T);
        assertThat(e.traceId()).isEqualTo("abc123");
    }

    @Test
    void deleteActionIsADelete() {
        assertThat(new EnvelopeReader("cif.ccv", ccvFields()).read(ccv("DELETE")).kind()).isEqualTo(ChangeKind.DELETE);
    }

    @Test
    void noChangeKindFieldMeansEveryEventIsAnUpsert() {
        EnvelopeFields f = ccvFields();
        f.getChangeKind().setField(null);
        assertThat(new EnvelopeReader("cif.ccv", f).read(ccv("DELETE")).kind()).isEqualTo(ChangeKind.UPSERT);
    }

    private static EnvelopeFields flatFields(String version) {
        EnvelopeFields f = new EnvelopeFields();
        f.setEntityKey("accountId");
        f.setVersion(version);
        f.setBusinessTime(version);
        return f;   // event-id: derive (default)
    }

    private static GenericRecord flat(String id, Long micros, String stamp, Long millis) {
        GenericRecord r = new GenericData.Record(FLAT);
        r.put("accountId", id);
        r.put("updatedDateTime", micros);
        r.put("stamp", stamp);
        r.put("millis", millis);
        return r;
    }

    @Test
    void timestampVersionsAreMicros() {
        assertThat(new EnvelopeReader("t", flatFields("updatedDateTime")).read(flat("A", T_MICROS, null, null)).version()).isEqualTo(T_MICROS);
        assertThat(new EnvelopeReader("t", flatFields("millis")).read(flat("A", null, null, 1_794_906_001_234L)).version())
                .isEqualTo(1_794_906_001_234_000L);
        Envelope iso = new EnvelopeReader("t", flatFields("stamp")).read(flat("A", null, "2026-11-17T09:00:01.234567Z", null));
        assertThat(iso.version()).isEqualTo(T_MICROS);
        assertThat(iso.businessTime()).isEqualTo(T);
    }

    @Test
    void derivedEventIdIsStableAndNeedsNoField() {
        EnvelopeReader r = new EnvelopeReader("t", flatFields("updatedDateTime"));
        assertThat(r.derivesEventId()).isTrue();
        String a = EnvelopeReader.derivedEventId("t", "A", T_MICROS, new byte[] {1});
        assertThat(a).hasSize(64).isEqualTo(EnvelopeReader.derivedEventId("t", "A", T_MICROS, new byte[] {1}));
        assertThat(a).isNotEqualTo(EnvelopeReader.derivedEventId("t", "A", T_MICROS, new byte[] {2}));
    }

    @Test
    void blankKeyAndNullVersionAreReportedTogether() {
        Envelope e = new EnvelopeReader("t", flatFields("updatedDateTime")).read(flat(" ", null, null, null));
        assertThat(e.valid()).isFalse();
        assertThat(e.problems()).containsExactly("accountId (entity key) is blank", "updatedDateTime (version) is null");
    }

    @Test
    void aMissingFieldReadsAsMissingNotAsAnError() {
        EnvelopeFields f = flatFields("updatedDateTime");
        f.setTraceId("header.correlationId");     // FLAT has no header
        Envelope e = new EnvelopeReader("t", f).read(flat("A", T_MICROS, null, null));
        assertThat(e.valid()).isTrue();
        assertThat(e.traceId()).isNull();
    }
}
