package ie.aib.ioc.platform.topic;

import java.lang.reflect.RecordComponent;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import ie.aib.ioc.platform.core.ChangeKind;
import ie.aib.ioc.platform.core.InboundRecord;

/**
 * Fingerprint of an entity's business values: SHA-256 over the change kind and the chosen fields of the mapped
 * record ({@code ioc.topics.<consumer>.state-hash}; empty = every field). Two events with the same hash say the
 * same thing, so the library can tell DUPLICATE from CONFLICT and skip writes when nothing changed.
 *
 * <p>Canonical form, so equal values always hash the same: amounts ignore scale ({@code 100.0} = {@code 100.00}),
 * nested records and lists are walked, map entries are sorted by key, null is distinct from an empty string.
 * Field order is the configured order (or the record's declared order).
 */
public final class StateHasher {

    private final List<String> fields;

    /**
     * @param stateType the mapped record type, used to check the configured field names at start-up
     * @param fields    configured fields; empty = all
     */
    public StateHasher(Class<?> stateType, List<String> fields) {
        this.fields = List.copyOf(fields);
        if (!this.fields.isEmpty()) {
            if (stateType == null || !stateType.isRecord()) {
                throw new IllegalStateException("state-hash fields are configured but " + stateType + " is not a Java record");
            }
            List<String> known = new ArrayList<>();
            for (RecordComponent c : stateType.getRecordComponents()) {
                known.add(c.getName());
            }
            for (String f : this.fields) {
                if (!known.contains(f)) {
                    throw new IllegalStateException("state-hash field '" + f + "' is not a field of " + stateType.getSimpleName()
                            + " " + known);
                }
            }
        }
    }

    public byte[] hash(ChangeKind kind, Object state) {
        StringBuilder sb = new StringBuilder(kind.name()).append('|');
        if (state != null && state.getClass().isRecord()) {
            Map<String, Object> values = components(state);
            List<String> names = fields.isEmpty() ? new ArrayList<>(values.keySet()) : fields;
            for (String n : names) {
                sb.append(n).append('=');
                append(sb, values.get(n));
                sb.append(';');
            }
        } else {
            append(sb, state);
        }
        return InboundRecord.sha256(sb.toString().getBytes(StandardCharsets.UTF_8));
    }

    private static Map<String, Object> components(Object rec) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (RecordComponent c : rec.getClass().getRecordComponents()) {
            try {
                var accessor = c.getAccessor();
                accessor.setAccessible(true);
                out.put(c.getName(), accessor.invoke(rec));
            } catch (ReflectiveOperationException e) {
                throw new IllegalStateException("Can't read " + c.getName() + " of " + rec.getClass().getSimpleName(), e);
            }
        }
        return out;
    }

    /** Length-prefixed so no value can imitate a separator. */
    private static void append(StringBuilder sb, Object v) {
        if (v == null) {
            sb.append("~");
            return;
        }
        if (v instanceof BigDecimal d) {
            text(sb, d.signum() == 0 ? "0" : d.stripTrailingZeros().toPlainString());
        } else if (v instanceof byte[] b) {
            text(sb, HexFormat.of().formatHex(b));
        } else if (v instanceof Enum<?> e) {
            text(sb, e.name());
        } else if (v.getClass().isRecord()) {
            sb.append('{');
            components(v).forEach((k, x) -> {
                sb.append(k).append('=');
                append(sb, x);
                sb.append(';');
            });
            sb.append('}');
        } else if (v instanceof Collection<?> c) {
            sb.append('[');
            for (Object x : c) {
                append(sb, x);
                sb.append(',');
            }
            sb.append(']');
        } else if (v instanceof Map<?, ?> m) {
            sb.append('<');
            new TreeMap<>(stringKeys(m)).forEach((k, x) -> {
                text(sb, k);
                sb.append('=');
                append(sb, x);
                sb.append(';');
            });
            sb.append('>');
        } else {
            text(sb, v.toString());
        }
    }

    private static Map<String, Object> stringKeys(Map<?, ?> m) {
        Map<String, Object> out = new LinkedHashMap<>();
        m.forEach((k, v) -> out.put(String.valueOf(k), v));
        return out;
    }

    private static void text(StringBuilder sb, String s) {
        sb.append(s.length()).append(':').append(s);
    }
}
