package ie.aib.ioc.platform.kafka;

import java.util.HashMap;
import java.util.Map;

import org.apache.avro.specific.SpecificRecord;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;

/**
 * Turns raw bytes into an Avro record, inside the pipeline.
 *
 * <p>Why not let Kafka deserialise? Because then a corrupt record throws before our code runs,
 * the offset never commits, and the partition is stuck forever ("poison pill"). Consuming bytes
 * and decoding here makes a bad record an ordinary DESERIALISATION failure, and lets replay use
 * exactly the same code on the bytes saved in the failure tray.
 *
 * <p>Two readers:
 * <ul>
 *   <li><b>specific</b> - for handlers whose {@code avroType()} is a generated {@link SpecificRecord}
 *       class. Confluent finds the class named in the writer's schema; if it is not on the classpath it throws.</li>
 *   <li><b>generic</b> - for handlers whose {@code avroType()} is {@code GenericRecord}. No generated classes,
 *       so a topic owned by another team can be read without copying their .avsc into our build, and a new enum
 *       symbol the producer adds is just a string to us instead of a decode failure.</li>
 * </ul>
 *
 * <p>Each underlying deserializer caches schemas by id, so this costs one registry call per schema, not per record.
 */
public class AvroPayloadDecoder {

    private final KafkaAvroDeserializer specific = new KafkaAvroDeserializer();
    private final KafkaAvroDeserializer generic = new KafkaAvroDeserializer();

    public AvroPayloadDecoder(Map<String, ?> kafkaProperties) {
        Map<String, Object> specificConfig = new HashMap<>(kafkaProperties);
        specificConfig.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, true);
        specific.configure(specificConfig, false);

        Map<String, Object> genericConfig = new HashMap<>(kafkaProperties);
        genericConfig.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, false);
        generic.configure(genericConfig, false);
    }

    /** Decodes with the specific reader (generated classes). Kept for existing callers. */
    public Object decode(String topic, byte[] value) {
        return specific.deserialize(topic, value);
    }

    /**
     * Decodes for a handler that expects {@code expected}. A generated {@link SpecificRecord} class uses the
     * specific reader; anything else (normally {@code GenericRecord}) uses the generic reader.
     */
    public Object decode(String topic, byte[] value, Class<?> expected) {
        if (expected != null && SpecificRecord.class.isAssignableFrom(expected)) {
            return specific.deserialize(topic, value);
        }
        return generic.deserialize(topic, value);
    }

    /** For people looking at a failed payload: works for any schema, whether or not we have its class. */
    public Object decodeForDisplay(String topic, byte[] value) {
        return generic.deserialize(topic, value);
    }
}
