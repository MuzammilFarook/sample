package ie.aib.ioc.platform.topic;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.avro.LogicalType;
import org.apache.avro.LogicalTypes;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;

import ie.aib.ioc.platform.core.ChangeKind;
import ie.aib.ioc.platform.core.InboundRecord;
import ie.aib.ioc.platform.topic.TopicsProperties.EnvelopeFields;

/**
 * Reads the envelope items (entity key, version, event id, change kind, business time, trace id) from an Avro
 * record using the field paths in {@code ioc.topics.<consumer>.envelope}. Works for generic records and for
 * generated classes (both are {@link GenericRecord}).
 *
 * <p>Version is always a {@code long}: a plain long/int is used as it is; a timestamp (Avro logical type,
 * {@code Instant}, or an ISO-8601 string) becomes microseconds since the epoch, so versions taken from times
 * keep their full precision. Business time is an {@code Instant}; a plain long is read as epoch milliseconds.
 */
public final class EnvelopeReader {

    public static final int MAX_KEY = 255;
    public static final int MAX_EVENT_ID = 100;
    public static final int MAX_TRACE_ID = 64;

    private final String topic;
    private final EnvelopeFields cfg;
    private final Set<String> deleteValues;

    public EnvelopeReader(String topic, EnvelopeFields cfg) {
        this.topic = topic;
        this.cfg = cfg;
        this.deleteValues = cfg.getChangeKind().getDeleteValues().stream()
                .map(v -> v.trim().toUpperCase(Locale.ROOT)).collect(Collectors.toUnmodifiableSet());
    }

    public Envelope read(Object avro) {
        List<String> problems = new ArrayList<>();
        GenericRecord rec = (GenericRecord) avro;

        String key = blankToNull(str(value(rec, cfg.getEntityKey())));
        if (key == null) {
            problems.add(cfg.getEntityKey() + " (entity key) is blank");
        } else if (key.length() > MAX_KEY) {
            problems.add(cfg.getEntityKey() + " (entity key) is longer than " + MAX_KEY);
        }

        Long version = null;
        Field v = field(rec, cfg.getVersion());
        if (v.value() == null) {
            problems.add(cfg.getVersion() + " (version) is null");
        } else {
            try {
                version = toVersion(v);
                if (version < 0) {
                    problems.add(cfg.getVersion() + " (version) is negative");
                }
            } catch (RuntimeException e) {
                problems.add(cfg.getVersion() + " (version) can't be read: " + e.getMessage());
            }
        }

        String eventId;
        if (derivesEventId()) {
            eventId = derivedEventId(topic, key, version, null);   // final id is set once the state hash is known
        } else {
            eventId = blankToNull(str(value(rec, cfg.getEventId())));
            if (eventId == null) {
                problems.add(cfg.getEventId() + " (event id) is blank");
            } else if (eventId.length() > MAX_EVENT_ID) {
                problems.add(cfg.getEventId() + " (event id) is longer than " + MAX_EVENT_ID);
            }
        }

        ChangeKind kind = ChangeKind.UPSERT;
        String kindField = cfg.getChangeKind().getField();
        if (kindField != null && !kindField.isBlank()) {
            String k = blankToNull(str(value(rec, kindField)));
            if (k != null && deleteValues.contains(k.toUpperCase(Locale.ROOT))) {
                kind = ChangeKind.DELETE;
            }
        }

        Instant businessTime = null;
        if (cfg.getBusinessTime() != null && !cfg.getBusinessTime().isBlank()) {
            Field t = field(rec, cfg.getBusinessTime());
            if (t.value() != null) {
                try {
                    businessTime = toInstant(t);
                } catch (RuntimeException e) {
                    problems.add(cfg.getBusinessTime() + " (business time) can't be read: " + e.getMessage());
                }
            }
        }

        String traceId = null;
        if (cfg.getTraceId() != null && !cfg.getTraceId().isBlank()) {
            traceId = blankToNull(str(value(rec, cfg.getTraceId())));
            if (traceId != null && traceId.length() > MAX_TRACE_ID) {
                traceId = traceId.substring(0, MAX_TRACE_ID);
            }
        }
        return new Envelope(key, version, eventId, kind, businessTime, traceId, List.copyOf(problems));
    }

    /** {@code event-id: derive}: the topic has no event id of its own. */
    public boolean derivesEventId() {
        return EnvelopeFields.DERIVE.equalsIgnoreCase(cfg.getEventId());
    }

    /**
     * SHA-256(topic | key | version | state hash), hex. The same event redelivered or republished gets the same id
     * (DUPLICATE). The state hash is part of it so that the same version with <b>different</b> values gets a
     * different id and reaches the version check as a CONFLICT, instead of being taken for a redelivery.
     */
    public static String derivedEventId(String topic, String key, Long version, byte[] stateHash) {
        String seed = topic + "|" + (key == null ? "" : key) + "|" + (version == null ? "" : version) + "|"
                + (stateHash == null ? "" : HexFormat.of().formatHex(stateHash));
        return HexFormat.of().formatHex(InboundRecord.sha256(seed.getBytes(StandardCharsets.UTF_8)));
    }

    // ------------------------------------------------------------------ field access

    /** A value and the (non-null branch of the) writer's schema it came from. */
    public record Field(Object value, Schema schema) {
    }

    /** Value at a dotted path, or null when any step is missing or null (a field the producer dropped reads as missing). */
    public static Object value(GenericRecord rec, String path) {
        return field(rec, path).value();
    }

    public static Field field(GenericRecord rec, String path) {
        if (rec == null || path == null || path.isBlank()) {
            return new Field(null, null);
        }
        Object current = rec;
        Schema schema = rec.getSchema();
        for (String step : path.split("\\.")) {
            if (!(current instanceof GenericRecord r)) {
                return new Field(null, null);
            }
            Schema.Field f = r.getSchema().getField(step);
            if (f == null) {
                return new Field(null, null);
            }
            current = r.get(f.pos());
            schema = branch(f.schema(), current);
            if (current == null) {
                return new Field(null, schema);
            }
        }
        return new Field(current, schema);
    }

    private static Schema branch(Schema s, Object value) {
        if (s.getType() != Schema.Type.UNION) {
            return s;
        }
        for (Schema t : s.getTypes()) {
            if (t.getType() != Schema.Type.NULL) {
                return t;     // envelope fields are [null, X]
            }
        }
        return s;
    }

    // ------------------------------------------------------------------ conversions

    static long toVersion(Field f) {
        Object v = f.value();
        if (v instanceof Instant i) {
            return micros(i);
        }
        if (v instanceof LocalDateTime t) {
            return micros(t.toInstant(ZoneOffset.UTC));
        }
        if (v instanceof Number n) {
            LogicalType lt = f.schema() == null ? null : f.schema().getLogicalType();
            if (lt instanceof LogicalTypes.TimestampMillis || lt instanceof LogicalTypes.LocalTimestampMillis) {
                return Math.multiplyExact(n.longValue(), 1_000L);
            }
            return n.longValue();   // plain long, or already micros
        }
        if (v instanceof CharSequence cs) {
            String s = cs.toString().trim();
            try {
                return Long.parseLong(s);
            } catch (NumberFormatException notANumber) {
                return micros(parseTime(s));
            }
        }
        throw new IllegalArgumentException("unsupported type " + v.getClass().getSimpleName());
    }

    static Instant toInstant(Field f) {
        Object v = f.value();
        if (v instanceof Instant i) {
            return i;
        }
        if (v instanceof LocalDateTime t) {
            return t.toInstant(ZoneOffset.UTC);
        }
        if (v instanceof Number n) {
            LogicalType lt = f.schema() == null ? null : f.schema().getLogicalType();
            if (lt instanceof LogicalTypes.TimestampMicros || lt instanceof LogicalTypes.LocalTimestampMicros) {
                return Instant.EPOCH.plus(n.longValue(), ChronoUnit.MICROS);
            }
            return Instant.ofEpochMilli(n.longValue());
        }
        if (v instanceof CharSequence cs) {
            return parseTime(cs.toString().trim());
        }
        throw new IllegalArgumentException("unsupported type " + v.getClass().getSimpleName());
    }

    private static Instant parseTime(String s) {
        try {
            return Instant.parse(s);
        } catch (DateTimeParseException e) {
            try {
                return OffsetDateTime.parse(s).toInstant();
            } catch (DateTimeParseException e2) {
                return LocalDateTime.parse(s).toInstant(ZoneOffset.UTC);
            }
        }
    }

    public static long micros(Instant i) {
        return Math.addExact(Math.multiplyExact(i.getEpochSecond(), 1_000_000L), i.getNano() / 1_000L);
    }

    private static String str(Object o) {
        return o == null ? null : o.toString();
    }

    private static String blankToNull(String s) {
        return s == null || s.isBlank() ? null : s.trim();
    }
}
