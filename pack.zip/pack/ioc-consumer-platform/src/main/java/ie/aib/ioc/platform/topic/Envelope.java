package ie.aib.ioc.platform.topic;

import java.time.Instant;
import java.util.List;

import ie.aib.ioc.platform.core.ChangeKind;

/**
 * The items the library needs from every event, read by {@link EnvelopeReader} from the configured fields.
 * {@code problems} lists what could not be read (blank key, missing version ...); the pipeline rejects the event
 * as VALIDATION when it is not empty.
 */
public record Envelope(
        String entityKey,
        Long version,
        String eventId,
        ChangeKind kind,
        Instant businessTime,
        String traceId,
        List<String> problems) {

    public boolean valid() {
        return problems.isEmpty();
    }
}
