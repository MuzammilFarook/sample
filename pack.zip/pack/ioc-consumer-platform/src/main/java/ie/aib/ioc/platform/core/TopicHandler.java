package ie.aib.ioc.platform.core;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import ie.aib.ioc.platform.topic.Envelope;
import ie.aib.ioc.platform.topic.EnvelopeReader;

/**
 * Everything a topic team writes: <b>business code only</b>. The library does the rest (envelope, dedup,
 * version guard, batching, bisect, failure tray, pause-on-outage, outbox, replay, ledger, logging, metrics,
 * ops console).
 *
 * <p>The envelope (entity key, version, event id, change kind, business time, trace id), the topic name, entity
 * type, evidence level and the state-hash fields are <b>configuration</b>: {@code ioc.topics.<consumerName()>}
 * (see {@code TopicsProperties}). The version and state hash are kept by the library in {@code entity_version},
 * so the topic's own tables hold business columns only.
 *
 * <p>What the topic writes:
 * <ol>
 *   <li>{@link #map}: Avro to the topic's own record (business fields only).</li>
 *   <li>{@link #validate}: business contract checks (key and version are already checked by the library).</li>
 *   <li>{@link #load}: current values, for the materiality comparison.</li>
 *   <li>{@link #apply}: write values. Called only when the values differ from what is stored.</li>
 *   <li>{@link #assessMateriality}: does this change matter enough to announce?</li>
 * </ol>
 *
 * @param <A> the Avro type on the topic: {@code GenericRecord}, or a generated class
 * @param <S> the topic's own record (a Java record is recommended: the state hash reads its fields)
 */
public interface TopicHandler<A, S> {

    /** Stable name: the key of {@code ioc.topics.*}, the Kafka listener id, and the scope of every library table. */
    String consumerName();

    /** The Avro type this topic carries; {@code GenericRecord} reads it with the writer's schema (no generated classes). */
    Class<A> avroType();

    /** The topic's own record type (checked against {@code state-hash} at start-up). */
    Class<S> stateType();

    /** Mapper: Avro to the topic's own record. Pure, no I/O, business fields only. */
    S map(A avro);

    /** Business contract checks. Throw {@link ValidationException} (listing every problem) to reject. */
    default void validate(DecodedEvent<S> event) {
    }

    /** Valid but not needed by IOC: FILTERED. Default: everything is in scope. */
    default Optional<String> filterReason(DecodedEvent<S> event) {
        return Optional.empty();
    }

    /**
     * Current values for these keys, for the materiality rule. Runs inside the library's transaction, after the
     * library has locked the entities' version rows, so no lock hints are needed. Absent key = no row.
     */
    Map<String, S> load(Collection<String> entityKeys);

    /**
     * Write these changes (batched), inside the library's transaction. Called only for changes whose values differ
     * from the stored ones (new entity, changed values, or a delete). {@code isNew} = the library has never applied
     * an event for this entity; write as an upsert anyway, so it stays correct if a row exists without a version.
     */
    void apply(List<AppliedChange<S>> changes);

    /** Materiality rule: does this change matter enough to announce on the Credit Change topic? */
    Materiality assessMateriality(CurrentState<S> before, DecodedEvent<S> after);

    /** Stamped on every Credit Change note, so "why was this announced?" can be answered later. */
    String materialityRuleVersion();

    /**
     * Override only when an envelope item is not a single field (e.g. a key built from two fields). Default: read
     * every item from the configured field paths.
     */
    default Envelope envelope(A avro, EnvelopeReader reader) {
        return reader.read(avro);
    }

    /** Override only when the state hash can't be built from fields of {@code S}. Empty = the library builds it. */
    default Optional<byte[]> stateHash(DecodedEvent<S> event) {
        return Optional.empty();
    }

    /** What is stored for one entity: the library's version row, plus the topic's values ({@code state} may be null). */
    record CurrentState<S>(long sourceVersion, byte[] stateHash, boolean deleted, S state) {
    }

    /** One change to write, with the lineage of the Kafka record that caused it. */
    record AppliedChange<S>(DecodedEvent<S> event, InboundRecord record, String traceId, boolean isNew) {
    }
}
