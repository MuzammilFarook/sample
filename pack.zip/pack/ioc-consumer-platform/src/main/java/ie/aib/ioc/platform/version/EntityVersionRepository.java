package ie.aib.ioc.platform.version;

import java.time.Instant;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import ie.aib.ioc.platform.core.Db;

/**
 * {@code entity_version}: the version guard, one row per (consumer, entity). It holds the last applied version and
 * state hash, and a deleted flag, so "only apply if newer" works for every topic without any column in the topic's
 * own tables, and keeps working after the ledger is purged.
 *
 * <p>The row is also the lock: the pipeline locks it ({@code UPDLOCK, HOLDLOCK, ROWLOCK}) before it reads or writes
 * the topic's tables, so the live consumer and a replay can never write the same entity at the same time.
 * {@code HOLDLOCK} also locks the key range of entities that don't exist yet, so two writers can't both create one.
 */
@Repository
public class EntityVersionRepository {

    private final NamedParameterJdbcTemplate jdbc;

    public EntityVersionRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** Last applied version per entity key, locked until the transaction ends. Absent key = never seen. */
    public Map<String, EntityVersion> lockAndLoad(String consumer, Collection<String> keys) {
        Map<String, EntityVersion> out = new HashMap<>();
        for (List<String> chunk : Db.chunks(keys, Db.MAX_IN_LIST)) {
            jdbc.query("""
                    SELECT entity_key, source_version, state_hash, is_deleted
                    FROM entity_version WITH (UPDLOCK, HOLDLOCK, ROWLOCK)
                    WHERE consumer_name = :consumer AND entity_key IN (:keys)
                    """, new MapSqlParameterSource("consumer", consumer).addValue("keys", chunk),
                    rs -> {
                        out.put(rs.getString("entity_key"), new EntityVersion(rs.getLong("source_version"),
                                rs.getBytes("state_hash"), rs.getBoolean("is_deleted")));
                    });
        }
        return out;
    }

    /** Moves the guard forward (never backwards: version check in the WHERE), creating rows for new entities. */
    public void save(String consumer, List<NewVersion> versions, Instant now) {
        if (versions.isEmpty()) {
            return;
        }
        SqlParameterSource[] params = versions.stream().map(v -> new MapSqlParameterSource()
                .addValue("consumer", consumer).addValue("key", v.entityKey()).addValue("version", v.sourceVersion())
                .addValue("hash", v.stateHash()).addValue("deleted", v.deleted()).addValue("now", Db.utc(now))
        ).toArray(SqlParameterSource[]::new);
        jdbc.batchUpdate("""
                UPDATE entity_version SET source_version = :version, state_hash = :hash, is_deleted = :deleted, updated_at = :now
                WHERE consumer_name = :consumer AND entity_key = :key AND source_version <= :version
                """, params);
        jdbc.batchUpdate("""
                INSERT INTO entity_version (consumer_name, entity_key, source_version, state_hash, is_deleted, updated_at)
                SELECT :consumer, :key, :version, :hash, :deleted, :now
                WHERE NOT EXISTS (SELECT 1 FROM entity_version WHERE consumer_name = :consumer AND entity_key = :key)
                """, params);
    }

    /** What the guard holds for one entity. */
    public record EntityVersion(long sourceVersion, byte[] stateHash, boolean deleted) {
    }

    /** The guard row to write after an event passed the version check. */
    public record NewVersion(String entityKey, long sourceVersion, byte[] stateHash, boolean deleted) {
    }
}
