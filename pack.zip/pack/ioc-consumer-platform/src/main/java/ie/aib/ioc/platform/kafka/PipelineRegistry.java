package ie.aib.ioc.platform.kafka;

import java.time.Clock;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import ie.aib.ioc.platform.core.EventPipeline;
import ie.aib.ioc.platform.core.PlatformHealth;
import ie.aib.ioc.platform.core.TopicHandler;
import ie.aib.ioc.platform.topic.TopicsProperties;
import ie.aib.ioc.platform.topic.TopicsProperties.TopicConfig;
import ie.aib.ioc.platform.observability.ConsumerStats;
import ie.aib.ioc.platform.observability.EventLog;
import org.springframework.stereotype.Component;

/**
 * One pipeline + runtime per {@link TopicHandler} bean. Usually one per deployable
 * ("one clerk per type of letter"), but the platform does not assume it.
 */
@Component
public class PipelineRegistry {

    private final Map<String, EventPipeline<?, ?>> pipelines = new LinkedHashMap<>();
    private final Map<String, ConsumerRuntime> runtimes = new LinkedHashMap<>();

    public PipelineRegistry(List<TopicHandler<?, ?>> handlers, TopicsProperties topics, EventPipeline.Dependencies deps,
                            PlatformHealth health, ConsumerStats stats, EventLog eventLog, Clock clock) {
        for (TopicHandler<?, ?> handler : handlers) {
            EventPipeline<?, ?> pipeline = create(handler, topicConfig(handler.consumerName(), topics), deps);
            String name = pipeline.consumerName();
            if (pipelines.put(name, pipeline) != null) {
                throw new IllegalStateException("Two topic handlers share the consumer name " + name);
            }
            runtimes.put(name, new ConsumerRuntime(pipeline, health, stats, eventLog, clock));
            stats.register(name, pipeline.settings().topic());
        }
    }

    private static <A, S> EventPipeline<A, S> create(TopicHandler<A, S> handler, TopicConfig topic, EventPipeline.Dependencies deps) {
        return new EventPipeline<>(handler, topic, deps);
    }

    /** Fails start-up with a clear message when a topic's {@code ioc.topics.<name>} block is missing or incomplete. */
    static TopicConfig topicConfig(String consumer, TopicsProperties topics) {
        TopicConfig t = topics.getTopics().get(consumer);
        if (t == null) {
            throw new IllegalStateException("No configuration for consumer '" + consumer + "': add ioc.topics." + consumer
                    + " (topic, entity-type, envelope.entity-key, envelope.version). Configured: " + topics.getTopics().keySet());
        }
        List<String> missing = new ArrayList<>();
        if (blank(t.getTopic())) missing.add("topic");
        if (blank(t.getEntityType())) missing.add("entity-type");
        if (blank(t.getEnvelope().getEntityKey())) missing.add("envelope.entity-key");
        if (blank(t.getEnvelope().getVersion())) missing.add("envelope.version");
        if (blank(t.getEnvelope().getEventId())) missing.add("envelope.event-id (a field path, or 'derive')");
        if (!missing.isEmpty()) {
            throw new IllegalStateException("ioc.topics." + consumer + " is missing: " + String.join(", ", missing));
        }
        return t;
    }

    private static boolean blank(String s) {
        return s == null || s.isBlank();
    }

    public EventPipeline<?, ?> pipeline(String consumer) {
        EventPipeline<?, ?> p = pipelines.get(consumer);
        if (p == null) {
            throw new NoSuchElementException("Unknown consumer: " + consumer);
        }
        return p;
    }

    public ConsumerRuntime runtime(String consumer) {
        ConsumerRuntime r = runtimes.get(consumer);
        if (r == null) {
            throw new NoSuchElementException("Unknown consumer: " + consumer);
        }
        return r;
    }

    public Collection<EventPipeline<?, ?>> all() {
        return pipelines.values();
    }
}
