package ie.aib.ioc.platform.topic;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

import ie.aib.ioc.platform.core.EvidenceLevel;

/**
 * {@code ioc.topics.<consumer-name>.*}: everything the library needs to know about a topic, as configuration.
 * A new topic team writes this block and its business code; it never writes envelope or version-guard code.
 *
 * <pre>
 * ioc:
 *   topics:
 *     account-balance-current:                    # = TopicHandler.consumerName()
 *       topic: accounts.entity.balance.current
 *       entity-type: ACCOUNT
 *       source-system: ACCOUNTS                   # optional; stored on the ledger and outbox
 *       evidence-level: FULL                      # FULL keeps the payload in the ledger, METADATA a fingerprint
 *       envelope:
 *         entity-key: accountId                   # field path in the Avro record
 *         version: updatedDateTime                # long, timestamp (made micros) or ISO string
 *         event-id: derive                        # a field path, or 'derive' = SHA-256(topic|key|version|state hash)
 *         change-kind:                            # omit: every event is an upsert
 *           field: header.actionType
 *           delete-values: [DELETE]
 *         business-time: updatedDateTime          # optional
 *         trace-id: header.correlationId          # optional; else traceparent header, else derived
 *       state-hash: [balance, limit]              # fields of the mapped record; empty = all of them
 * </pre>
 */
@ConfigurationProperties(prefix = "ioc")
public class TopicsProperties {

    private Map<String, TopicConfig> topics = new LinkedHashMap<>();

    public Map<String, TopicConfig> getTopics() { return topics; }
    public void setTopics(Map<String, TopicConfig> topics) { this.topics = topics; }

    public static class TopicConfig {
        private String topic;
        private String entityType;
        private String sourceSystem;
        private EvidenceLevel evidenceLevel = EvidenceLevel.METADATA;
        private EnvelopeFields envelope = new EnvelopeFields();
        private List<String> stateHash = new ArrayList<>();

        public String getTopic() { return topic; }
        public void setTopic(String topic) { this.topic = topic; }
        public String getEntityType() { return entityType; }
        public void setEntityType(String entityType) { this.entityType = entityType; }
        public String getSourceSystem() { return sourceSystem; }
        public void setSourceSystem(String sourceSystem) { this.sourceSystem = sourceSystem; }
        public EvidenceLevel getEvidenceLevel() { return evidenceLevel; }
        public void setEvidenceLevel(EvidenceLevel evidenceLevel) { this.evidenceLevel = evidenceLevel; }
        public EnvelopeFields getEnvelope() { return envelope; }
        public void setEnvelope(EnvelopeFields envelope) { this.envelope = envelope; }
        public List<String> getStateHash() { return stateHash; }
        public void setStateHash(List<String> stateHash) { this.stateHash = stateHash; }
    }

    /** Where the library finds each envelope item in the Avro record. Paths use dots: {@code header.eventId}. */
    public static class EnvelopeFields {
        public static final String DERIVE = "derive";

        private String entityKey;
        private String version;
        private String eventId = DERIVE;
        private ChangeKindRule changeKind = new ChangeKindRule();
        private String businessTime;
        private String traceId;

        public String getEntityKey() { return entityKey; }
        public void setEntityKey(String entityKey) { this.entityKey = entityKey; }
        public String getVersion() { return version; }
        public void setVersion(String version) { this.version = version; }
        public String getEventId() { return eventId; }
        public void setEventId(String eventId) { this.eventId = eventId; }
        public ChangeKindRule getChangeKind() { return changeKind; }
        public void setChangeKind(ChangeKindRule changeKind) { this.changeKind = changeKind; }
        public String getBusinessTime() { return businessTime; }
        public void setBusinessTime(String businessTime) { this.businessTime = businessTime; }
        public String getTraceId() { return traceId; }
        public void setTraceId(String traceId) { this.traceId = traceId; }
    }

    /** No field: every event is an upsert. Otherwise the event is a delete when the field's value is in the list. */
    public static class ChangeKindRule {
        private String field;
        private List<String> deleteValues = new ArrayList<>(List.of("DELETE"));

        public String getField() { return field; }
        public void setField(String field) { this.field = field; }
        public List<String> getDeleteValues() { return deleteValues; }
        public void setDeleteValues(List<String> deleteValues) { this.deleteValues = deleteValues; }
    }
}
