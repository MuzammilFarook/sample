package ie.aib.ioc.platform.core;

import java.time.Instant;

/**
 * One event as the library sees it: the envelope (read from configuration) plus the topic's mapped state.
 * The internal state {@code S} is stable; when the source schema changes, only the mapper (or the config) changes.
 *
 * @param eventId         unique per business change (dedup)
 * @param entityKey       the record the event is about (version guard, coalescing, outbox ordering)
 * @param kind            upsert or delete
 * @param sourceVersion   monotonic per entity — "only apply if newer"
 * @param occurredAt      business time: when the change happened at source (envelope business-time; may be null)
 * @param sourceSystem    from config ({@code source-system}); may be null
 * @param producerTraceId trace id carried in the payload, if any
 * @param state           the full current state (a snapshot, never a delta)
 */
public record DecodedEvent<S>(
        String eventId,
        String entityKey,
        ChangeKind kind,
        long sourceVersion,
        Instant occurredAt,
        String sourceSystem,
        String producerTraceId,
        S state) {
}
