-- =====================================================================================
-- IOC consumer platform, v2: the version guard moves into the library.
--
-- Before: every topic table carried event_id, source_version, state_hash, source_topic,
-- source_partition, source_offset, trace_id ... next to its business columns.
-- Now:    the library keeps one row per (consumer, entity) here, and the per-event details
--         stay on the ledger line. Topic tables hold business columns only.
-- =====================================================================================

-- -------------------------------------------------------------------------------------
-- ENTITY VERSION: the last applied version of every entity, per consumer.
--   * "only apply if newer" reads this row (and locks it: UPDLOCK, HOLDLOCK)
--   * same version + same state_hash = DUPLICATE; same version + different hash = CONFLICT
--   * newer version + same state_hash = nothing changed, so the topic table is not written
--   * is_deleted = the last applied event was a delete (a late upsert is then STALE)
-- Not purged: it is one small row per entity and must outlive the ledger's hot window.
-- -------------------------------------------------------------------------------------
CREATE TABLE entity_version (
    consumer_name        VARCHAR(100)   NOT NULL,
    entity_key           VARCHAR(255)   NOT NULL,
    source_version       BIGINT         NOT NULL,
    state_hash           BINARY(32)     NOT NULL,
    is_deleted           BIT            NOT NULL CONSTRAINT df_entity_version_deleted DEFAULT 0,
    updated_at           DATETIME2(3)   NOT NULL,
    CONSTRAINT pk_entity_version PRIMARY KEY (consumer_name, entity_key)
);

-- -------------------------------------------------------------------------------------
-- LEDGER: three more envelope items per line, so each line says everything about its event.
-- -------------------------------------------------------------------------------------
ALTER TABLE event_ledger ADD
    change_kind          VARCHAR(6)     NULL,      -- UPSERT | DELETE (null if the record could not be decoded)
    source_event_time    DATETIME2(6)   NULL,      -- business time from the event (envelope business-time)
    state_hash           BINARY(32)     NULL;      -- fingerprint of the business values (explains CONFLICT)
