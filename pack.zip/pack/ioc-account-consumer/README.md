# IOC Account Consumer: real-time account balances

A Spring Boot service on the **IOC consumer platform library** (`ioc-consumer-platform`). It consumes the
Accounts Domain real-time balance topic and keeps one row per account in `account.account`.
Design: `LLD_IOC_Account_Balance_Consumer.md` (v0.5).

| | |
|---|---|
| Source topic | `accounts.entity.balance.current` (environments add a suffix, e.g. `.ppd`), set with `ACCOUNT_BALANCE_TOPIC` |
| Schema | `ie.aib.accounts.balance.model.avro.AccountsBalanceEntity` (PPD subject `accounts.entity.balance.current.ppd-value`, v1, id 2621) |
| Target | Azure SQL: `account.account` (business columns, current values only). Version guard and event details are the library's (`entity_version`, `event_ledger`) |
| Read view | `account.v_account` (Secured Exposure derived on read) |
| Out of scope | `accounts.entity.balance.closing` (end-of-day closing balances) |

```
 Kafka (raw bytes) ──► decode (generic Avro) ─► envelope (config) + map + validate ─► seen this offset / eventId? ─► newest in batch? ─► newer than entity_version?
                                                                                                         │
                              ┌──────────────────────────── ONE Azure SQL transaction ───────────────────┘
                              │  entity_version (always) + account.account (only if values changed)
                              │  + one ledger line per record + outbox note (if material)
                              └────────────────────────────────────┬────────────────────────────────────
                                                                   ▼
                                                      commit, THEN commit the offsets
   bad record      → failure tray (raw bytes kept), carry on         outbox publisher → Credit Change topic
   temporary blip  → retry 1s/2s/4s, then tray                       auto-replay → 1m, 5m, 15m, 1h, 4h, then a person
   DB / SR down    → pause, Kafka holds the backlog, resume          ops console / API → replay, four-eyes, audit
```

---

## 1. What the service stores

Only the attributes in the Account Balance consumption agreement:

| Column | Event field | Rule |
|---|---|---|
| `account_id` | `accountId` | Envelope entity key: trimmed, not blank (library); at most 40 characters (M1) |
| `account_balance`, `account_currency` | `balances[type=Expected].amount` | At most one `Expected` entry (M3); currency upper-cased, 3 letters (M4) |
| `account_limit`, `account_limit_currency` | `creditLine[type=PreAgreed].amount` | At most one `PreAgreed` entry; null type ignored; no line = `NULL` (M5, M6) |
| `source_updated_datetime` | `updatedDateTime` | Envelope business time of the last **change** |
| `is_deleted`, `modified_datetime` | — | Standard; the topic has no deletes |
| Secured Exposure | — | `MAX(balance, limit)` in `account.v_account`, never stored |

Everything else (other balance types, `Credit` lines, `included`, top-level `amount`) stays in the
ledger payload (evidence level `FULL`). The selected types are config: `ioc.account.balance-type`,
`ioc.account.limit-type`.

**No technical columns in `account.account`.** The library needs these items from every event, and
reads them from configuration (`ioc.topics.account-balance-current.envelope`):

| Item | Account topic | Kept by the library in |
|---|---|---|
| Entity key | `accountId` | `entity_version`, `event_ledger` |
| Version | `updatedDateTime` in micros | `entity_version` (last applied), `event_ledger` |
| Event id | derived: SHA-256(topic \| accountId \| version \| state hash) | `event_ledger` |
| State hash | balance, currency, limit, limit currency (`state-hash`) | `entity_version`, `event_ledger` |
| Change kind | always upsert | `entity_version` (deleted flag), `event_ledger` |
| Business time | `updatedDateTime` | `event_ledger` (`source_event_time`); also `account.account.source_updated_datetime` |
| Trace id | none: `traceparent` header, else derived | `event_ledger` |
| Topic, partition, offset | from the Kafka record | `event_ledger` |

The state hash is part of the derived event id so that the same version with different values is a
`CONFLICT`, not a redelivery.

To find the event behind the current row:
`event_ledger.entity_key = account_id AND source_event_time = source_updated_datetime`.

**Only real changes are written.** The library locks the account's `entity_version` row, checks the
version, and calls the repository only when the values changed. A newer event with the same values
moves `entity_version` on and writes nothing to `account.account`, and a late older event is still
`STALE`:

```
v10 balance 100 applied   → account.account written, entity_version v10
v12 balance 100 arrives   → same values: account.account untouched, entity_version v12
v11 balance 90 arrives    → STALE (older than v12)
```

**Reading Avro without generated classes.** The handler's `avroType()` is `GenericRecord`, so the
library decodes this topic with Confluent's generic reader and the writer's schema. A new enum
symbol from the producer (e.g. a new `BalanceType`) is just a string here instead of a decode
failure (LLD R5). `src/main/resources/avro/AccountsBalanceEntity.avsc` is a copy used only by the
local simulator and the tests.

---

## 2. Classes

```
src/main/java/ie/aib/ioc/account/
├── AccountBalanceListener        @KafkaListener, raw bytes in batches → platform runtime
├── AccountBalanceTopicHandler    TopicHandler<GenericRecord, AccountBalanceState>: wires the business pieces
├── AccountBalanceMapper          GenericRecord → AccountBalanceState (business fields only)
├── AccountBalanceValidator       account rules (M1 length, M3–M7), warning metrics; key/version checked by the library
├── AccountBalanceMetrics         ioc_account_* data-quality counters
├── AccountRepository             account.account: load values, batched upsert (no version or lock logic)
├── AccountMaterialityRule        NEW_ACCOUNT, LIMIT_CHANGED, BALANCE_CHANGED (≥5%), CURRENCY_CHANGED (DRAFT)
├── AccountProperties             ioc.account.* (balance type, limit type, materiality)
├── domain/AccountBalanceState    balance, balanceCurrency, limit, limitCurrency (+ decode-time selection counts)
└── dev/                          local profile only: LocalEventSimulator, LocalTopics, AccountsBalanceEvents (builder)

src/main/resources/db/migration/account/
├── V100__account.sql             schema, account.account, checks, grants
└── R__account_v_account.sql      account.v_account (owned by the IOC API in shared environments)
```

Configuration (`application.yml`): `ioc.topics.account-balance-current` (library: topic, entity type,
evidence level, envelope fields, state-hash fields) and `ioc.account` (business: balance and limit
types, materiality).

The library does the rest: envelope, decoding, dedup, version guard (`entity_version`), batching,
failure tray, retries, auto-replay, pausing, outbox, ledger, gap checks, logging, metrics and the ops console.

---

## 3. Build and run locally

The library must be installed first, and it must be the version with **per-topic configuration**
(`ioc.topics.*`, `entity_version`, migration `V2__entity_version.sql`):

```bash
cd ../ioc-consumer-platform && mvn clean install
cd ../ioc-account-consumer  && mvn clean package
docker compose up -d                                   # Kafka, Schema Registry, SQL Server (unchanged)
mvn spring-boot:run -Dspring-boot.run.profiles=local
```

The local profile creates the topic `accounts.entity.balance.current` on start-up (`LocalTopics`),
so `docker-compose.yml` needs no change.

**Existing local database.** The old `V100__t1_account.sql` was applied to your local `ioc`
database, and Flyway will refuse to start because version 100 changed. Either recreate the database
(`docker compose down -v` then `up -d`), or run this once in the `ioc` database (the library's
`V2__entity_version.sql` and the new `V100__account.sql` then run on start-up):

```sql
DELETE FROM flyway_schema_history WHERE version = '100';
DROP TABLE IF EXISTS dbo.t1_account;
IF OBJECT_ID('account.account', 'U') IS NOT NULL
BEGIN
    IF EXISTS (SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID('account.account') AND temporal_type = 2)
        ALTER TABLE account.account SET (SYSTEM_VERSIONING = OFF);
    DROP TABLE account.account;
END
DROP TABLE IF EXISTS account.account_history;
DROP TABLE IF EXISTS account.account_version;
```

Open **http://localhost:8080/ops/** and sign in:

| User | Roles | Try |
|---|---|---|
| `viewer` / `viewer` | read | everything read-only, no payloads |
| `alice` / `alice` | read, replay | replay one event, request a bulk replay |
| `bob` / `bob` | read, replay, approve | approve alice's request (he can't approve his own) |
| `admin` / `admin` | all | pause/resume, mark gaps explained, submit control totals |

Then go to **Simulator** and publish 2,000 events. The console's fields mean:

| Field | What the simulator sends | Expected outcome |
|---|---|---|
| Duplicate % | the same record again | `DUPLICATE` |
| Republish % | newer `updatedDateTime`, identical values | `PROCESSED`, row not written |
| Stale % | older `updatedDateTime`, different balance | `STALE` |
| Conflict % | same `updatedDateTime`, different balance | `CONFLICT` (tray) |
| Invalid % | two `Expected` entries, null `updatedDateTime`, or currency `EURO` | `VALIDATION` (tray) |
| Poison % | bytes that are not Avro | `DESERIALISATION` (tray) |
| Over-limit % | a 10–30% balance move | `PROCESSED`, announced `BALANCE_CHANGED` |

About 10% of simulated accounts have no credit line, 2% a GBP limit (Secured Exposure `NULL`) and
2% no `Expected` balance.

Useful queries:

```sql
SELECT TOP 20 * FROM account.v_account ORDER BY source_updated_datetime DESC;
SELECT outcome, COUNT(*) FROM event_ledger WHERE consumer_name = 'account-balance-current' GROUP BY outcome;
-- the event behind the current values of one account
SELECT l.* FROM account.account a
JOIN event_ledger l ON l.entity_key = a.account_id AND l.source_event_time = a.source_updated_datetime
WHERE a.account_id = 'IE29AIBK93110000000042';
```

---

## 4. Tests

| Test | Proves |
|---|---|
| `AccountBalanceContractTest` | Rules M1–M8, the envelope read from config, derived eventId and state hash (DUPLICATE vs CONFLICT), a new enum symbol is ignored (R5) |
| `AccountMaterialityRuleTest` | New account, limit change (incl. to/from NULL), ≥5% balance change, currency change; small moves and same-value versions are not announced |
| `AccountConsumerIT` (Docker) | LLD 11 scenarios end to end: one row per account, duplicates, STALE, same values not written, late event after a same-value version, CONFLICT, currency mismatch in the view, contract breaches, DB outage pause, no offset holes, corrupt bytes, replay can't overwrite newer data, announcement with the same trace id, four-eyes |

```bash
mvn test       # unit tests
mvn verify     # + integration tests (needs Docker)
```

---

## 5. Ops console and auditor questions

Everything in the console is also an API under `/ops/api/**`:

```
GET  /ops/api/consumers/account-balance-current/overview?hours=24
GET  /ops/api/consumers/account-balance-current/trace?q={eventId|traceId|accountId|topic/partition@offset}
GET  /ops/api/consumers/account-balance-current/ledger?outcome=&entityKey=&partition=&offsetFrom=&offsetTo=
GET  /ops/api/consumers/account-balance-current/failures?category=&status=&entityKey=
POST /ops/api/consumers/account-balance-current/failures/{id}/replay
```

> *"On 3 September the Accounts Domain sent a balance for IE29AIBK93115212345678. Did IOC receive it? What did it do with it?"*

1. **Trace** → search the account id. The timeline shows the Kafka record (partition/offset, SHA-256 of
   the bytes), the ledger outcome, any failure and retries, and the outbox note if material.
2. For the values IOC held that day, see **Values on an earlier date** below.
3. Splunk: `index=ioc traceId=<the trace id>`.

### Values on an earlier date

`account.account` holds current values only: there is no requirement for account history, so there is
no history table. Earlier values come from the ledger, which keeps every event's payload as received
(evidence level `FULL`) and is not purged.

*"What balance and limit did IOC hold for this account on 3 September?"* is the last event IOC had
**applied** by then. The version check only ever applies newer versions, so that is the applied event
with the highest version:

```sql
SELECT TOP 1 l.ledger_id, l.source_version, l.source_event_time,
       CASE WHEN l.outcome = 'PROCESSED' THEN l.processed_at ELSE l.last_changed_at END AS applied_at,
       l.topic, l.kafka_partition, l.kafka_offset, l.payload
FROM event_ledger l
WHERE l.consumer_name = 'account-balance-current'
  AND l.entity_key = 'IE29AIBK93115212345678'
  AND (l.outcome = 'PROCESSED'                                                 -- applied live
       OR (l.outcome = 'REPLAYED' AND l.outcome_detail LIKE 'replay result PROCESSED%'))   -- applied by a replay
  AND CASE WHEN l.outcome = 'PROCESSED' THEN l.processed_at ELSE l.last_changed_at END < '2026-09-04T00:00:00'
ORDER BY l.source_version DESC;
```

- `DUPLICATE`, `STALE`, `SUPERSEDED`, `FILTERED` and `FAILED` lines changed nothing, so they are left out.
  A `PROCESSED` line with "same values" is fine: its values equal what was held.
- That finds **what IOC held** (by when IOC applied it). For **what the source said** at a moment, filter on
  `source_event_time` instead; the two differ only when events arrive late.
- `payload` is the Avro bytes (Confluent format: magic byte + schema id + body). SQL can't read the balance
  out of it; it has to be decoded with the schema from Schema Registry. This needs to stay `FULL`: at
  `METADATA` the ledger keeps a fingerprint, and earlier values could not be answered.

---

## 6. Production checklist

- **Topic:** `ACCOUNT_BALANCE_TOPIC` per environment (Q1); Confluent service account with READ on the topic and Schema Registry.
- **Schemas:** never registered by the app (`auto.register.schemas=false` outside local).
- **Database:** Managed Identity, `socketTimeout` set, Flyway from the pipeline (`IOC_FLYWAY_ON_START=false`).
  `R__account_v_account.sql` belongs to the IOC API in shared environments.
- **Sizing:** `pods × concurrency ≤ partitions`; `pods × IOC_DB_POOL <` Azure SQL connection limit; 10× load test in SIT.
- **Ledger:** evidence level must stay `FULL` (it is the only record of earlier account values). At ~20M events/day that is
  ~20 GB/day, ~7 TB/year, kept (no purge planned): size storage for it and plan partitioning by `business_date` (Q8).
- **Alerts:** `ioc.alert` lines, consumer lag, open MANUAL failures, `ioc_account_missing_updated_datetime_total`,
  `ioc_account_currency_mismatch_total`.

---

## 7. Open items (LLD section 12)

| Item | Current value | Who decides |
|---|---|---|
| Topic names per environment | `accounts.entity.balance.current` (+ suffix) | Accounts Domain, Platform |
| Can `updatedDateTime` be null? Strictly increasing? | Null is rejected (VALIDATION) | Accounts Domain |
| Sign convention for lending balances | `MAX(balance, limit)` as received | Accounts Domain, Credit Risk |
| Meaning of `creditLine[].included` and top-level `amount` | Ignored | Accounts Domain |
| Kafka key is `accountId`? | Assumed | Accounts Domain |
| Materiality rule | `ACC-MAT-0.2-DRAFT`, 5% balance change | Business + Architecture |
| Credit Change topic name | `ioc.credit.change.v1` | Architecture |
