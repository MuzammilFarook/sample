package ie.aib.ioc.account;

import java.time.Clock;
import java.time.Instant;
import java.util.List;

import org.apache.avro.generic.GenericRecord;

import ie.aib.ioc.account.dev.AccountsBalanceEvents;
import ie.aib.ioc.account.domain.AccountBalanceState;
import ie.aib.ioc.platform.core.DecodedEvent;
import ie.aib.ioc.platform.core.EvidenceLevel;
import ie.aib.ioc.platform.core.TopicHandler.CurrentState;
import ie.aib.ioc.platform.topic.Envelope;
import ie.aib.ioc.platform.topic.EnvelopeReader;
import ie.aib.ioc.platform.topic.StateHasher;
import ie.aib.ioc.platform.topic.TopicsProperties.TopicConfig;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

/**
 * The handler's pieces wired without Spring, plus the library's envelope reader and state hasher with the same
 * settings as {@code ioc.topics.account-balance-current} in application.yml.
 */
final class AccountBalanceFixtures {

    static final String TOPIC = "accounts.entity.balance.current";
    static final String ACCOUNT = "IE29AIBK93115212345678";
    static final Instant T = Instant.parse("2026-11-17T09:00:01.234567Z");

    final AccountProperties props = new AccountProperties();
    final SimpleMeterRegistry meters = new SimpleMeterRegistry();
    final AccountBalanceMapper mapper = new AccountBalanceMapper(props);
    final AccountBalanceValidator validator = new AccountBalanceValidator(Clock.systemUTC(), props, new AccountBalanceMetrics(meters));
    final AccountMaterialityRule rule = new AccountMaterialityRule(props);
    final TopicConfig topic = topicConfig();
    final EnvelopeReader envelope = new EnvelopeReader(TOPIC, topic.getEnvelope());
    final StateHasher hasher = new StateHasher(AccountBalanceState.class, topic.getStateHash());

    /** Same values as application.yml. */
    static TopicConfig topicConfig() {
        TopicConfig t = new TopicConfig();
        t.setTopic(TOPIC);
        t.setEntityType("ACCOUNT");
        t.setSourceSystem("ACCOUNTS");
        t.setEvidenceLevel(EvidenceLevel.FULL);
        t.getEnvelope().setEntityKey("accountId");
        t.getEnvelope().setVersion("updatedDateTime");
        t.getEnvelope().setEventId("derive");
        t.getEnvelope().setBusinessTime("updatedDateTime");
        t.setStateHash(List.of("balance", "balanceCurrency", "limit", "limitCurrency"));
        return t;
    }

    /** What the library builds: envelope from config + the topic's mapped state. */
    DecodedEvent<AccountBalanceState> decode(GenericRecord r) {
        Envelope env = envelope.read(r);
        AccountBalanceState state = mapper.map(r);
        long version = env.version() == null ? 0L : env.version();
        DecodedEvent<AccountBalanceState> e = new DecodedEvent<>(null, env.entityKey(), env.kind(), version,
                env.businessTime(), topic.getSourceSystem(), env.traceId(), state);
        String id = EnvelopeReader.derivedEventId(TOPIC, env.entityKey(), env.version(), hash(e));
        return new DecodedEvent<>(id, e.entityKey(), e.kind(), e.sourceVersion(), e.occurredAt(), e.sourceSystem(),
                e.producerTraceId(), e.state());
    }

    byte[] hash(DecodedEvent<AccountBalanceState> e) {
        return hasher.hash(e.kind(), e.state());
    }

    /** Expected balance and PreAgreed limit in EUR, plus an Available balance and a Credit line (ignored). */
    static GenericRecord event(Instant updated, String balance, String limit) {
        AccountsBalanceEvents.Builder b = AccountsBalanceEvents.event(ACCOUNT).updated(updated)
                .balance("Expected", balance, "EUR").balance("Available", "1.00", "EUR");
        if (limit != null) {
            b.creditLine("PreAgreed", limit, "EUR");
        }
        return b.creditLine("Credit", "50000.00", "EUR").build();
    }

    DecodedEvent<AccountBalanceState> decoded(Instant updated, String balance, String limit) {
        return decode(event(updated, balance, limit));
    }

    CurrentState<AccountBalanceState> stored(String balance, String limit) {
        DecodedEvent<AccountBalanceState> e = decoded(T, balance, limit);
        AccountBalanceState s = e.state();
        return new CurrentState<>(e.sourceVersion(), hash(e), false,
                new AccountBalanceState(s.balance(), s.balanceCurrency(), s.limit(), s.limitCurrency(), null));
    }
}
