package ie.aib.ioc.account;

import static ie.aib.ioc.account.AccountBalanceFixtures.T;
import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import ie.aib.ioc.account.dev.AccountsBalanceEvents;
import ie.aib.ioc.platform.core.Materiality;

/** LLD 5.6, ACC-MAT-0.2-DRAFT. */
class AccountMaterialityRuleTest {

    private final AccountBalanceFixtures f = new AccountBalanceFixtures();

    @Test
    void newAccountIsAnnounced() {
        Materiality m = f.rule.assess(null, f.decoded(T, "100.00", "1000.00"));
        assertThat(m.reasons()).containsExactly("NEW_ACCOUNT");
        assertThat(m.changeType()).isEqualTo("ACCOUNT_CREATED");
    }

    @Test
    void smallBalanceMoveIsNotAnnounced() {
        Materiality m = f.rule.assess(f.stored("100000.00", "200000.00"), f.decoded(T.plusSeconds(1), "104999.99", "200000.00"));
        assertThat(m.material()).isFalse();
        assertThat(m.changeType()).isEqualTo("ACCOUNT_UPDATED");
    }

    @Test
    void fivePercentBalanceMoveIsAnnounced() {
        assertThat(f.rule.assess(f.stored("100000.00", "200000.00"), f.decoded(T.plusSeconds(1), "105000.00", "200000.00")).reasons())
                .containsExactly("BALANCE_CHANGED");
        assertThat(f.rule.assess(f.stored("100000.00", "200000.00"), f.decoded(T.plusSeconds(1), "95000.00", "200000.00")).reasons())
                .containsExactly("BALANCE_CHANGED");
    }

    @Test
    void smallBalancesUseOneAsTheBase() {
        // |0.04 - 0.00| / max(0, 1) = 4%: not material
        assertThat(f.rule.assess(f.stored("0.00", null), f.decoded(T.plusSeconds(1), "0.04", null)).material()).isFalse();
    }

    @Test
    void limitChangeIncludingToOrFromNullIsAnnounced() {
        assertThat(f.rule.assess(f.stored("100.00", "1000.00"), f.decoded(T.plusSeconds(1), "100.00", "1500.00")).reasons())
                .containsExactly("LIMIT_CHANGED");
        assertThat(f.rule.assess(f.stored("100.00", "1000.00"), f.decoded(T.plusSeconds(1), "100.00", null)).reasons())
                .containsExactly("LIMIT_CHANGED");
    }

    @Test
    void sameLimitWithADifferentScaleIsNotAChange() {
        assertThat(f.rule.assess(f.stored("100.00", "1000.00"), f.decoded(T.plusSeconds(1), "100.00", "1000.0")).material()).isFalse();
    }

    @Test
    void currencyChangeIsAnnounced() {
        Materiality m = f.rule.assess(f.stored("100.00", null), f.decode(AccountsBalanceEvents.event(AccountBalanceFixtures.ACCOUNT)
                .updated(T.plusSeconds(1)).balance("Expected", "100.00", "GBP").build()));
        assertThat(m.reasons()).containsExactly("CURRENCY_CHANGED");
    }

    @Test
    void newerVersionWithTheSameValuesIsNotAnnounced() {
        assertThat(f.rule.assess(f.stored("100.00", "1000.00"), f.decoded(T.plusSeconds(60), "100.00", "1000.00")).material()).isFalse();
    }
}
