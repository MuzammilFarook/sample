package ie.aib.ioc.account;

import static ie.aib.ioc.account.AccountBalanceFixtures.ACCOUNT;
import static ie.aib.ioc.account.AccountBalanceFixtures.T;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.util.Arrays;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.junit.jupiter.api.Test;

import ie.aib.ioc.account.dev.AccountsBalanceEvents;
import ie.aib.ioc.account.domain.AccountBalanceState;
import ie.aib.ioc.platform.core.DecodedEvent;
import ie.aib.ioc.platform.core.ValidationException;
import ie.aib.ioc.platform.topic.Envelope;

/**
 * Mapper rules M1-M8 (LLD 5.3), validator, and the envelope / state hash the library builds from
 * {@code ioc.topics.account-balance-current} (LLD 5.2).
 */
class AccountBalanceContractTest {

    private final AccountBalanceFixtures f = new AccountBalanceFixtures();

    @Test
    void mapsExpectedBalanceAndPreAgreedLimit() {
        DecodedEvent<AccountBalanceState> e = f.decode(AccountsBalanceEvents.event(" " + ACCOUNT + " ").updated(T)
                .balance("Expected", "125000.50", "eur").balance("Available", "74999.50", "EUR")
                .creditLine("PreAgreed", "200000.00", "EUR").creditLine("Credit", "50000.00", "EUR").build());
        f.validator.validate(e);
        AccountBalanceState s = e.state();
        assertThat(s.balance()).isEqualByComparingTo("125000.50");
        assertThat(s.balanceCurrency()).isEqualTo("EUR");
        assertThat(s.limit()).isEqualByComparingTo("200000.00");
        assertThat(s.limitCurrency()).isEqualTo("EUR");
    }

    @Test
    void envelopeComesFromTheConfiguredFields() {
        DecodedEvent<AccountBalanceState> e = f.decoded(T, "10.00", "20.00");
        assertThat(e.entityKey()).isEqualTo(ACCOUNT);
        assertThat(e.sourceVersion()).isEqualTo(1_794_906_001_234_567L);   // updatedDateTime in micros
        assertThat(e.occurredAt()).isEqualTo(T);                         // -> source_updated_datetime
        assertThat(e.sourceSystem()).isEqualTo("ACCOUNTS");
        assertThat(e.eventId()).hasSize(64);
    }

    @Test
    void blankAccountIdAndNullUpdatedDateTimeAreEnvelopeProblems() {
        Envelope env = f.envelope.read(AccountsBalanceEvents.event(" ").updated((Long) null).balance("Expected", "1.00", "EUR").build());
        assertThat(env.valid()).isFalse();
        assertThat(String.join("; ", env.problems()))
                .contains("accountId (entity key) is blank")
                .contains("updatedDateTime (version) is null");
    }

    @Test
    void creditLineNullGivesNoLimit() {
        AccountBalanceState s = f.mapper.map(AccountsBalanceEvents.event(ACCOUNT).updated(T).balance("Expected", "10.00", "EUR").build());
        assertThat(s.limit()).isNull();
        assertThat(s.limitCurrency()).isNull();
    }

    @Test
    void noExpectedEntryStoresNullBalanceAndCountsIt() {
        DecodedEvent<AccountBalanceState> e = f.decode(AccountsBalanceEvents.event(ACCOUNT).updated(T)
                .balance("Available", "10.00", "EUR").balance("Unknown", "3.00", "EUR").creditLine("Credit", "5.00", "EUR").build());
        f.validator.validate(e);
        assertThat(e.state().balance()).isNull();
        assertThat(e.state().limit()).isNull();
        assertThat(f.meters.counter("ioc.account.no.expected.balance").count()).isEqualTo(1.0);
    }

    @Test
    void expectedEntryWithNullValueStoresNullBalance() {
        DecodedEvent<AccountBalanceState> e = f.decode(AccountsBalanceEvents.event(ACCOUNT).updated(T).balance("Expected", null, "EUR").build());
        f.validator.validate(e);
        assertThat(e.state().balance()).isNull();
        assertThat(e.state().selection().balanceValueNull()).isTrue();
    }

    @Test
    void creditLineWithNullTypeIsIgnored() {
        AccountBalanceState s = f.mapper.map(AccountsBalanceEvents.event(ACCOUNT).updated(T).balance("Expected", "10.00", "EUR")
                .creditLine(null, "99.00", "EUR").creditLine("PreAgreed", "50.00", "GBP").build());
        assertThat(s.limit()).isEqualByComparingTo("50.00");
        assertThat(s.limitCurrency()).isEqualTo("GBP");
    }

    @Test
    void contractBreachListsEveryProblem() {
        GenericRecord bad = AccountsBalanceEvents.event(ACCOUNT).updated(T)
                .balance("Expected", "1.00", "EURO").balance("Expected", "2.00", "EUR")
                .creditLine("PreAgreed", "1.00", "EUR").creditLine("PreAgreed", "2.00", "EUR").build();
        assertThatThrownBy(() -> f.validator.validate(f.decode(bad)))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("2 balances[] entries with type Expected")
                .hasMessageContaining("2 creditLine[] entries with type PreAgreed")
                .hasMessageContaining("'EURO'");
    }

    @Test
    void sameStateRedeliveredHasTheSameEventIdAndHash() {
        DecodedEvent<AccountBalanceState> a = f.decoded(T, "125000.50", "200000.00");
        DecodedEvent<AccountBalanceState> b = f.decoded(T, "125000.50", "200000.00");
        assertThat(a.eventId()).isEqualTo(b.eventId());
        assertThat(Arrays.equals(f.hash(a), f.hash(b))).isTrue();
    }

    @Test
    void differentBalanceAtTheSameVersionHasADifferentHashAndEventId() {
        DecodedEvent<AccountBalanceState> a = f.decoded(T, "125000.50", "200000.00");
        DecodedEvent<AccountBalanceState> b = f.decoded(T, "125000.51", "200000.00");
        assertThat(Arrays.equals(f.hash(a), f.hash(b))).as("same version, different content -> CONFLICT").isFalse();
        assertThat(a.eventId()).as("so it is not taken for a redelivery").isNotEqualTo(b.eventId());
    }

    @Test
    void hashIgnoresTheVersionAndTheTypesWeDoNotStore() {
        byte[] a = f.hash(f.decoded(T, "125000.50", "200000.00"));
        byte[] b = f.hash(f.decode(AccountsBalanceEvents.event(ACCOUNT).updated(T.plusSeconds(60))
                .balance("Expected", "125000.50", "EUR").creditLine("PreAgreed", "200000.00", "EUR").build()));
        assertThat(Arrays.equals(a, b)).as("newer version, same values -> account row not touched").isTrue();
    }

    @Test
    void aNewBalanceTypeFromTheProducerDecodesAndIsIgnored() {
        // R5: the producer adds a symbol to BalanceType. Read generically, it is just a string.
        Schema v2 = new Schema.Parser().parse(AccountsBalanceEvents.SCHEMA.toString().replace("\"Unknown\"]", "\"Unknown\",\"Pending\"]"));
        DecodedEvent<AccountBalanceState> e = f.decode(AccountsBalanceEvents.event(v2, ACCOUNT).updated(T)
                .balance("Pending", "1.00", "EUR").balance("Expected", "7.00", "EUR").build());
        f.validator.validate(e);
        assertThat(e.state().balance()).isEqualTo(new BigDecimal("7.00"));
    }
}
