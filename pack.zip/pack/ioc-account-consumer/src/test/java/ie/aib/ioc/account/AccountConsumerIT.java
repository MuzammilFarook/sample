package ie.aib.ioc.account;

import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import com.github.dockerjava.api.DockerClient;
import ie.aib.ioc.account.dev.AccountsBalanceEvents;
import ie.aib.ioc.account.domain.AccountBalanceState;
import ie.aib.ioc.events.v1.CreditChangeEvent;
import ie.aib.ioc.platform.core.DecodedEvent;
import ie.aib.ioc.platform.core.DependencyMissingException;
import ie.aib.ioc.platform.ops.OpsException;
import ie.aib.ioc.platform.replay.ReplayModels.ReplayRequestView;
import ie.aib.ioc.platform.replay.ReplayModels.SingleReplayResult;
import ie.aib.ioc.platform.replay.ReplayService;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.DockerClientFactory;
import org.testcontainers.containers.KafkaContainer;
import org.testcontainers.containers.MSSQLServerContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.awaitility.Awaitility.await;

/**
 * End to end, one test per rule (LLD 11). Real Kafka and real SQL Server (Testcontainers); Schema Registry is
 * Confluent's in-JVM mock. Events are the registered {@code AccountsBalanceEntity} schema, sent as GenericRecords.
 *
 * <pre>
 *   Rule / LLD scenario                                Test
 *   1  Expected + PreAgreed -> one row                 mapsTheAgreedAttributesIntoOneRow
 *   8  Same event 3 times -> one change                duplicatesAreHarmless
 *   9  v12 then v11 -> STALE                           olderVersionIsStale
 *   10 Newer version, identical values -> no write     newerVersionWithTheSameValuesIsNotWritten
 *      ... and a late event after it is still STALE    lateEventAfterAnUnchangedNewerVersionIsStale
 *   11 Same version, different balance -> CONFLICT     sameVersionDifferentBalanceIsAConflict
 *   12 EUR balance, GBP limit -> exposure NULL         currencyMismatchGivesNoSecuredExposure
 *   5,6 Contract breach -> tray, waits for a person    contractBreachWaitsForAPerson
 *   13 Database stopped -> pause, tray stays empty     databaseOutagePausesTheConsumerAndNothingGoesToTheTray
 *      Every record has one ledger line, no holes      everyRecordHasExactlyOneLedgerLineAndOffsetsHaveNoHoles
 *      Corrupt bytes -> tray, next record processed    corruptBytesGoToTheTrayAndTheNextRecordIsProcessed
 *      Replay can never overwrite newer data           replayCanNeverOverwriteNewerData
 *      Material change announced with the trace id     materialChangeIsAnnouncedWithEvidenceAndTheSameTraceId
 *      Bulk replay needs a second person               bulkReplayNeedsASecondPerson
 * </pre>
 * Scenario 14 (kill between DB commit and offset commit) is covered by design (commit after the transaction,
 * redelivery gives DUPLICATE) and by duplicatesAreHarmless; scenario 15 (new enum symbol) by
 * AccountBalanceContractTest; load is a separate SIT run.
 */
@SpringBootTest(properties = {
        "ioc.topics.account-balance-current.topic=it.accounts.entity.balance.current",
        "ioc.platform.outbox.topic=it.credit.change.v1",
        "spring.kafka.properties.schema.registry.url=mock://ioc-it",
        "spring.kafka.properties.auto.register.schemas=true",
        "spring.kafka.consumer.properties.group.instance.id=it-account",
        "spring.kafka.listener.concurrency=1",
        "ioc.platform.auto-replay.enabled=false",
        "ioc.platform.transient-retry.backoff=10ms,10ms,10ms",
        "ioc.platform.pause.max-backoff=2s",
        "ioc.platform.outbox.poll-interval-ms=200",
        "ioc.platform.outbox.lease-renew-ms=500",
        "ioc.platform.manual-replay.approval-threshold=0",
        "ioc.platform.gap-check.enabled=false",
        "ioc.ops.security.mode=local"
})
@Testcontainers
class AccountConsumerIT {

    static final String TOPIC = "it.accounts.entity.balance.current";
    static final String CC_TOPIC = "it.credit.change.v1";
    static final String CONSUMER = "account-balance-current";
    static final String SR = "mock://ioc-it";

    @Container
    static final KafkaContainer KAFKA = new KafkaContainer(DockerImageName.parse("confluentinc/cp-kafka:7.6.1"));

    @Container
    static final MSSQLServerContainer<?> SQL = new MSSQLServerContainer<>(
            DockerImageName.parse("mcr.microsoft.com/mssql/server:2022-latest")).acceptLicense();

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) {
        r.add("spring.kafka.bootstrap-servers", KAFKA::getBootstrapServers);
        // socketTimeout: a frozen DB must surface as an error, not hang a thread forever (recommended in prod too)
        r.add("spring.datasource.url", () -> SQL.getJdbcUrl() + ";socketTimeout=8000");
        r.add("spring.datasource.username", SQL::getUsername);
        r.add("spring.datasource.password", SQL::getPassword);
    }

    static KafkaProducer<String, Object> avro;
    static KafkaProducer<String, byte[]> raw;

    @Autowired
    JdbcTemplate jdbc;
    @Autowired
    ReplayService replay;
    @Autowired
    ToggleValidator toggle;

    @BeforeAll
    static void producers() {
        Map<String, Object> cfg = new HashMap<>();
        cfg.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, KAFKA.getBootstrapServers());
        cfg.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        cfg.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class);
        cfg.put("schema.registry.url", SR);
        avro = new KafkaProducer<>(cfg);
        Map<String, Object> rawCfg = new HashMap<>(cfg);
        rawCfg.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ByteArraySerializer.class);
        raw = new KafkaProducer<>(rawCfg);
    }

    @AfterAll
    static void close() {
        avro.close();
        raw.close();
    }

    // ===================================================================== rules

    @Test
    void mapsTheAgreedAttributesIntoOneRow() throws Exception {
        String acc = account();
        send(AccountsBalanceEvents.event(acc).updated(at(1))
                .balance("Expected", "125000.50", "EUR").balance("Available", "74999.50", "EUR")
                .creditLine("PreAgreed", "200000.00", "EUR").creditLine("Credit", "50000.00", "EUR").build());
        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(acc).contains("PROCESSED"));

        Map<String, Object> row = jdbc.queryForMap("""
                SELECT account_balance, account_currency, account_limit, account_limit_currency, source_updated_datetime
                FROM account.account WHERE account_id = ?""", acc);
        assertThat(row.get("account_balance").toString()).isEqualTo("125000.50");
        assertThat(row.get("account_currency")).isEqualTo("EUR");
        assertThat(row.get("account_limit").toString()).isEqualTo("200000.00");
        assertThat(row.get("account_limit_currency")).isEqualTo("EUR");
        assertThat(updatedOf(acc)).isEqualTo(at(1));
        assertThat(versionOf(acc)).as("library version row").isEqualTo(AccountsBalanceEvents.micros(at(1)));
        Map<String, Object> line = jdbc.queryForMap(
                "SELECT change_kind, source_event_time, state_hash FROM event_ledger WHERE entity_key = ?", acc);
        assertThat(line.get("change_kind")).isEqualTo("UPSERT");
        assertThat(line.get("state_hash")).isNotNull();
        assertThat(jdbc.queryForObject("SELECT secured_exposure FROM account.v_account WHERE account_id = ?", String.class, acc))
                .isEqualTo("200000.00");
    }

    @Test
    void duplicatesAreHarmless() throws Exception {
        String acc = account();
        GenericRecord v1 = event(acc, 1, "50000.00", "100000.00");
        send(v1);
        send(v1);
        send(v1);

        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(acc).size() == 3);
        assertThat(ledgerOutcomes(acc)).containsExactly("PROCESSED", "DUPLICATE", "DUPLICATE");
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM account.account WHERE account_id = ?", Integer.class, acc)).isEqualTo(1);
    }

    @Test
    void olderVersionIsStale() throws Exception {
        String acc = account();
        send(event(acc, 12, "120.00", "1000.00"));
        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(acc).size() == 1);
        send(event(acc, 11, "110.00", "1000.00"));
        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(acc).size() == 2);

        assertThat(ledgerOutcomes(acc)).containsExactly("PROCESSED", "STALE");
        assertThat(balanceOf(acc)).isEqualTo("120.00");
    }

    @Test
    void newerVersionWithTheSameValuesIsNotWritten() throws Exception {
        String acc = account();
        send(event(acc, 1, "100.00", "1000.00"));
        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(acc).size() == 1);
        Object modified = modifiedOf(acc);
        send(event(acc, 2, "100.00", "1000.00"));     // same values
        send(event(acc, 3, "100.00", "1000.00"));     // same values
        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(acc).size() == 3);

        assertThat(ledgerOutcomes(acc)).containsOnly("PROCESSED", "SUPERSEDED");
        assertThat(modifiedOf(acc)).as("no value changed, so the row was not written").isEqualTo(modified);
        assertThat(updatedOf(acc)).as("account row still shows the last CHANGE").isEqualTo(at(1));
        assertThat(versionOf(acc)).as("library version row shows the newest version applied").isEqualTo(AccountsBalanceEvents.micros(at(3)));

        send(event(acc, 4, "150.00", "1000.00"));     // real change
        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(acc).size() == 4);
        assertThat(modifiedOf(acc)).isNotEqualTo(modified);
        assertThat(balanceOf(acc)).isEqualTo("150.00");
        assertThat(updatedOf(acc)).isEqualTo(at(4));
    }

    @Test
    void lateEventAfterAnUnchangedNewerVersionIsStale() throws Exception {
        String acc = account();
        send(event(acc, 10, "100.00", "1000.00"));
        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(acc).size() == 1);
        send(event(acc, 12, "100.00", "1000.00"));    // same values: account row untouched, version row moves to v12
        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(acc).size() == 2);
        send(event(acc, 11, "90.00", "1000.00"));     // late, older than v12
        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(acc).size() == 3);

        assertThat(ledgerOutcomes(acc)).containsExactly("PROCESSED", "PROCESSED", "STALE");
        assertThat(balanceOf(acc)).isEqualTo("100.00");
    }

    @Test
    void sameVersionDifferentBalanceIsAConflict() throws Exception {
        String acc = account();
        send(event(acc, 5, "100.00", "1000.00"));
        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(acc).size() == 1);
        send(event(acc, 5, "999.00", "1000.00"));
        await().atMost(Duration.ofSeconds(60)).until(() -> failureCount(acc) == 1);

        assertThat(jdbc.queryForObject("SELECT error_category FROM event_failure WHERE entity_key = ?", String.class, acc))
                .isEqualTo("CONFLICT");
        assertThat(balanceOf(acc)).isEqualTo("100.00");
    }

    @Test
    void currencyMismatchGivesNoSecuredExposure() throws Exception {
        String acc = account();
        send(AccountsBalanceEvents.event(acc).updated(at(1)).balance("Expected", "100.00", "EUR")
                .creditLine("PreAgreed", "1000.00", "GBP").build());
        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(acc).contains("PROCESSED"));

        Map<String, Object> v = jdbc.queryForMap(
                "SELECT secured_exposure, exposure_currency_mismatch FROM account.v_account WHERE account_id = ?", acc);
        assertThat(v.get("secured_exposure")).isNull();
        assertThat(v.get("exposure_currency_mismatch")).isEqualTo(true);
    }

    @Test
    void everyRecordHasExactlyOneLedgerLineAndOffsetsHaveNoHoles() throws Exception {
        String prefix = "IT" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        int accounts = 20, versions = 10;
        for (int v = 1; v <= versions; v++) {
            for (int a = 0; a < accounts; a++) {
                send(event(prefix + a, v, (40000 + v * 100) + ".00", "100000.00"));
            }
        }
        await().atMost(Duration.ofSeconds(90)).until(() -> jdbc.queryForObject(
                "SELECT COUNT(*) FROM event_ledger WHERE entity_key LIKE ?", Integer.class, prefix + "%") == accounts * versions);

        // Every offset that reached the consumer has exactly one line: per partition, count == max - min + 1
        List<Map<String, Object>> parts = jdbc.queryForList("""
                SELECT kafka_partition, COUNT(*) AS n, MIN(kafka_offset) AS lo, MAX(kafka_offset) AS hi
                FROM event_ledger WHERE topic = ? GROUP BY kafka_partition""", TOPIC);
        for (Map<String, Object> p : parts) {
            long n = ((Number) p.get("n")).longValue();
            long span = ((Number) p.get("hi")).longValue() - ((Number) p.get("lo")).longValue() + 1;
            assertThat(n).as("partition %s has no holes", p.get("kafka_partition")).isEqualTo(span);
        }
        assertThat(jdbc.queryForObject("SELECT MAX(source_version) FROM entity_version WHERE consumer_name = ? AND entity_key LIKE ?",
                Long.class, CONSUMER, prefix + "%")).isEqualTo(AccountsBalanceEvents.micros(at(versions)));
    }

    @Test
    void corruptBytesGoToTheTrayAndTheNextRecordIsProcessed() throws Exception {
        String acc = account();
        RecordMetadata bad = raw.send(new ProducerRecord<>(TOPIC, acc, "not avro at all".getBytes(StandardCharsets.UTF_8))).get();
        send(event(acc, 1, "50000.00", "100000.00"));

        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(acc).contains("PROCESSED"));
        Map<String, Object> f = jdbc.queryForMap("SELECT error_category, status, DATALENGTH(payload) AS bytes FROM event_failure"
                + " WHERE topic = ? AND kafka_partition = ? AND kafka_offset = ?", TOPIC, bad.partition(), bad.offset());
        assertThat(f.get("error_category")).isEqualTo("DESERIALISATION");
        assertThat(f.get("status")).isEqualTo("MANUAL");
        assertThat(((Number) f.get("bytes")).intValue()).as("raw bytes kept for replay").isEqualTo(15);
    }

    @Test
    void contractBreachWaitsForAPerson() throws Exception {
        String acc = account();
        send(AccountsBalanceEvents.event(acc).updated((Long) null).balance("Expected", "1.00", "EUR").build());   // M2
        send(AccountsBalanceEvents.event(acc).updated(at(2))
                .balance("Expected", "1.00", "EUR").balance("Expected", "2.00", "EUR").build());                // M3
        send(event(acc, 3, "50.00", "100.00"));                                                               // fine

        await().atMost(Duration.ofSeconds(60)).until(() -> failureCount(acc) == 2 && ledgerOutcomes(acc).contains("PROCESSED"));
        assertThat(jdbc.queryForList("SELECT DISTINCT error_category FROM event_failure WHERE entity_key = ?", String.class, acc))
                .containsExactly("VALIDATION");
        assertThat(jdbc.queryForList("SELECT DISTINCT status FROM event_failure WHERE entity_key = ?", String.class, acc))
                .containsExactly("MANUAL");
    }

    @Test
    void databaseOutagePausesTheConsumerAndNothingGoesToTheTray() throws Exception {
        String acc = account();
        DockerClient docker = DockerClientFactory.instance().client();
        docker.pauseContainerCmd(SQL.getContainerId()).exec();
        try {
            for (int v = 1; v <= 20; v++) {
                send(event(acc, v, (50000 + v) + ".00", "100000.00"));
            }
            Thread.sleep(15_000); // consumer hits the frozen DB, classifies it as PLATFORM, pauses and probes
        } finally {
            docker.unpauseContainerCmd(SQL.getContainerId()).exec();
        }
        await().atMost(Duration.ofSeconds(120)).until(() -> ledgerOutcomes(acc).size() == 20);
        assertThat(failureCount(acc)).as("a broken system must not fill the failure tray").isZero();
        assertThat(versionOf(acc)).isEqualTo(AccountsBalanceEvents.micros(at(20)));
    }

    @Test
    void replayCanNeverOverwriteNewerData() throws Exception {
        String acc = account();
        GenericRecord v5 = event(acc, 5, "55555.00", "100000.00");
        toggle.failAccounts.add(acc);
        send(v5);
        await().atMost(Duration.ofSeconds(60)).until(() -> failureCount(acc) == 1);
        assertThat(jdbc.queryForObject("SELECT status FROM event_failure WHERE entity_key = ?", String.class, acc)).isEqualTo("AUTO_RETRY");

        toggle.failAccounts.clear();
        send(event(acc, 6, "66666.00", "100000.00"));
        await().atMost(Duration.ofSeconds(60)).until(() -> versionOf(acc) == AccountsBalanceEvents.micros(at(6)));

        // "the bug is fixed": replay v5
        long failureId = jdbc.queryForObject("SELECT failure_id FROM event_failure WHERE entity_key = ?", Long.class, acc);
        SingleReplayResult r = replay.replayFailure(failureId, "it-operator", "127.0.0.1");

        assertThat(r.result()).isEqualTo("SUCCEEDED");
        assertThat(r.outcome()).as("v5 is older than stored v6").isEqualTo("STALE");
        assertThat(balanceOf(acc)).isEqualTo("66666.00");
        assertThat(jdbc.queryForObject("SELECT status FROM event_failure WHERE failure_id = ?", String.class, failureId)).isEqualTo("REPLAYED");
    }

    @Test
    void materialChangeIsAnnouncedWithEvidenceAndTheSameTraceId() throws Exception {
        String acc = account();
        send(event(acc, 1, "90000.00", "100000.00"));   // NEW_ACCOUNT
        send(event(acc, 2, "90500.00", "100000.00"));   // +0.6%: saved, not announced
        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(acc).size() == 2);
        send(event(acc, 3, "99000.00", "100000.00"));   // +9.4%: BALANCE_CHANGED

        await().atMost(Duration.ofSeconds(60)).until(() -> jdbc.queryForObject(
                "SELECT COUNT(*) FROM outbox WHERE aggregate_key = ? AND status = 'SENT' AND sent_offset IS NOT NULL", Integer.class, acc) == 2);
        assertThat(jdbc.queryForList("SELECT reasons FROM outbox WHERE aggregate_key = ? ORDER BY outbox_id", String.class, acc))
                .containsExactly("NEW_ACCOUNT", "BALANCE_CHANGED");
        long v3 = AccountsBalanceEvents.micros(at(3));
        String trace = jdbc.queryForObject("SELECT trace_id FROM event_ledger WHERE entity_key = ? AND source_version = ?", String.class, acc, v3);

        try (KafkaConsumer<String, Object> c = ccConsumer()) {
            c.subscribe(List.of(CC_TOPIC));
            ConsumerRecord<String, Object> found = null;
            long deadline = System.currentTimeMillis() + 30_000;
            while (found == null && System.currentTimeMillis() < deadline) {
                for (ConsumerRecord<String, Object> rec : c.poll(Duration.ofMillis(500))) {
                    CreditChangeEvent e = (CreditChangeEvent) rec.value();
                    if (e.getEntityKey().equals(acc) && e.getReasons().contains("BALANCE_CHANGED")) {
                        found = rec;
                    }
                }
            }
            assertThat(found).isNotNull();
            assertThat(new String(found.headers().lastHeader("ioc-trace-id").value(), StandardCharsets.UTF_8)).isEqualTo(trace);
            assertThat(((CreditChangeEvent) found.value()).getEntityVersion()).isEqualTo(v3);
        }
    }

    @Test
    void bulkReplayNeedsASecondPerson() throws Exception {
        String acc = account();
        send(AccountsBalanceEvents.event(acc).updated(at(1)).balance("Expected", "1.00", "XX").build());
        await().atMost(Duration.ofSeconds(60)).until(() -> failureCount(acc) == 1);

        ReplayRequestView req = replay.createRequest(CONSUMER, "FAILURES", Map.of("entityKey", acc),
                "currency mapping fixed", "alice", "127.0.0.1");
        assertThat(req.status()).isEqualTo("PENDING_APPROVAL");
        assertThatThrownBy(() -> replay.decide(req.requestId(), true, "alice", "self", "127.0.0.1"))
                .isInstanceOf(OpsException.class)
                .satisfies(e -> assertThat(((OpsException) e).status()).isEqualTo(HttpStatus.FORBIDDEN));
        assertThat(replay.decide(req.requestId(), true, "bob", "checked", "127.0.0.1").status()).isEqualTo("APPROVED");
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM ops_audit WHERE target = ?", Integer.class,
                "replay-request:" + req.requestId())).isGreaterThanOrEqualTo(3);
    }

    // ===================================================================== helpers

    /** updatedDateTime for "version n" of an account: a fixed base plus n seconds. */
    private static Instant at(int n) {
        return Instant.parse("2026-11-17T09:00:00Z").plusSeconds(n);
    }

    private static GenericRecord event(String acc, int n, String balance, String limit) {
        return AccountsBalanceEvents.event(acc).updated(at(n))
                .balance("Expected", balance, "EUR").balance("Available", "1.00", "EUR")
                .creditLine("PreAgreed", limit, "EUR").build();
    }

    private static String account() {
        return "IEIT" + UUID.randomUUID().toString().replace("-", "").substring(0, 18).toUpperCase();
    }

    private static void send(GenericRecord e) throws Exception {
        avro.send(new ProducerRecord<>(TOPIC, e.get("accountId").toString(), e)).get();
    }

    private List<String> ledgerOutcomes(String acc) {
        return jdbc.queryForList("SELECT outcome FROM event_ledger WHERE entity_key = ? ORDER BY kafka_offset", String.class, acc);
    }

    private int failureCount(String acc) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM event_failure WHERE entity_key = ?", Integer.class, acc);
        return n == null ? 0 : n;
    }

    /** The library's version row for this account. */
    private Long versionOf(String acc) {
        List<Long> v = jdbc.queryForList("SELECT source_version FROM entity_version WHERE consumer_name = ? AND entity_key = ?",
                Long.class, CONSUMER, acc);
        return v.isEmpty() ? -1L : v.get(0);
    }

    private Instant updatedOf(String acc) {
        return jdbc.queryForObject("SELECT source_updated_datetime FROM account.account WHERE account_id = ?",
                java.time.LocalDateTime.class, acc).toInstant(java.time.ZoneOffset.UTC);
    }

    private String balanceOf(String acc) {
        return jdbc.queryForObject("SELECT CONVERT(varchar(20), account_balance) FROM account.account WHERE account_id = ?", String.class, acc);
    }

    private Object modifiedOf(String acc) {
        return jdbc.queryForObject("SELECT modified_datetime FROM account.account WHERE account_id = ?", Object.class, acc);
    }

    private static KafkaConsumer<String, Object> ccConsumer() {
        Map<String, Object> cfg = new HashMap<>();
        cfg.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, KAFKA.getBootstrapServers());
        cfg.put(ConsumerConfig.GROUP_ID_CONFIG, "it-verify-" + UUID.randomUUID());
        cfg.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        cfg.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        cfg.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KafkaAvroDeserializer.class);
        cfg.put("schema.registry.url", SR);
        cfg.put("specific.avro.reader", true);
        return new KafkaConsumer<>(cfg);
    }

    /** Lets a test make one account's events fail with a retryable error, then "fix the bug". */
    static class ToggleValidator extends AccountBalanceValidator {
        final Set<String> failAccounts = ConcurrentHashMap.newKeySet();

        ToggleValidator(Clock clock, AccountProperties props, AccountBalanceMetrics metrics) {
            super(clock, props, metrics);
        }

        @Override
        public void validate(DecodedEvent<AccountBalanceState> e) {
            if (failAccounts.contains(e.entityKey())) {
                throw new DependencyMissingException("Simulated: something this event needs has not arrived yet");
            }
            super.validate(e);
        }
    }

    @TestConfiguration
    static class Config {
        @Bean
        @Primary
        ToggleValidator toggleValidator(Clock clock, AccountProperties props, AccountBalanceMetrics metrics) {
            return new ToggleValidator(clock, props, metrics);
        }
    }
}
