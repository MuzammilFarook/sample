package ie.aib.ioc.account;

import java.util.List;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import ie.aib.ioc.platform.config.PlatformConfiguration;
import ie.aib.ioc.platform.kafka.ConsumerRuntime;
import ie.aib.ioc.platform.kafka.PipelineRegistry;

/**
 * Listener on the real-time balance topic. Raw bytes in, a batch at a time; the library decodes them and decides
 * when offsets are committed (after the database transaction).
 */
@Component
public class AccountBalanceListener {

    private final ConsumerRuntime runtime;

    public AccountBalanceListener(PipelineRegistry registry) {
        this.runtime = registry.runtime(AccountBalanceTopicHandler.CONSUMER);
    }

    @KafkaListener(
            id = AccountBalanceTopicHandler.CONSUMER,
            topics = "${ioc.topics.account-balance-current.topic}",
            containerFactory = PlatformConfiguration.BATCH_FACTORY,
            autoStartup = "${ioc.account.auto-startup:true}")
    public void onBatch(List<ConsumerRecord<byte[], byte[]>> records, Acknowledgment ack) {
        runtime.onBatch(records, ack);
    }
}
