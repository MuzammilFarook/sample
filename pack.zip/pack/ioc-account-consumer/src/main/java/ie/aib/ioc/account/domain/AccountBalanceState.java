package ie.aib.ioc.account.domain;

import java.math.BigDecimal;

/**
 * IOC's own model of one account's agreed values (LLD 5.1). Business fields only: the account id, version and
 * updated time are envelope items the library reads from configuration.
 *
 * <ul>
 *   <li>{@code balance}, {@code balanceCurrency}: {@code balances[type=Expected].amount}</li>
 *   <li>{@code limit}, {@code limitCurrency}: {@code creditLine[type=PreAgreed].amount}</li>
 * </ul>
 *
 * <p>{@code selection} says how the values were picked out of the event. It is set only on a freshly mapped event
 * (the validator reads it) and is {@code null} on values loaded from the database. It is not business state and is
 * left out of the state hash ({@code ioc.topics.account-balance-current.state-hash}).
 */
public record AccountBalanceState(
        BigDecimal balance,
        String balanceCurrency,
        BigDecimal limit,
        String limitCurrency,
        Selection selection) {

    /**
     * How many entries matched the configured balance and limit types (rules M3 and M5).
     *
     * @param balanceEntries   entries in {@code balances[]} with the configured balance type (e.g. Expected)
     * @param limitEntries     entries in {@code creditLine[]} with the configured limit type (e.g. PreAgreed)
     * @param balanceValueNull the single matching balance entry has {@code amount.value = null}
     */
    public record Selection(int balanceEntries, int limitEntries, boolean balanceValueNull) {
    }
}
