package ie.aib.ioc.account;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Locale;

import org.apache.avro.Conversions;
import org.apache.avro.LogicalType;
import org.apache.avro.LogicalTypes;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericFixed;
import org.apache.avro.generic.GenericRecord;
import org.springframework.stereotype.Component;

import ie.aib.ioc.account.domain.AccountBalanceState;
import ie.aib.ioc.account.domain.AccountBalanceState.Selection;

/**
 * Avro ({@code AccountsBalanceEntity}) to {@link AccountBalanceState}. The only class that knows the shape of the
 * business fields. The envelope (accountId, updatedDateTime) is read by the library from
 * {@code ioc.topics.account-balance-current.envelope}.
 *
 * <p>The topic is read as a {@link GenericRecord} with the writer's schema (no generated classes), so a new
 * enum symbol from the producer is just a string here, not a decode failure (LLD R5).
 *
 * <p>Selection rules (LLD 5.3): balance = the {@code balances[]} entry whose type is the configured balance type
 * (Expected); limit = the {@code creditLine[]} entry whose type is the configured limit type (PreAgreed).
 * Everything else in the event is ignored here and stays in the ledger payload (M8).
 *
 * <p>The mapper never rejects: it reports what it found in {@link Selection}, and the validator decides.
 */
@Component
public class AccountBalanceMapper {

    private static final Conversions.DecimalConversion DECIMAL = new Conversions.DecimalConversion();

    private final AccountProperties props;

    public AccountBalanceMapper(AccountProperties props) {
        this.props = props;
    }

    public AccountBalanceState map(GenericRecord event) {
        // M3, M4: the configured balance type
        int balanceEntries = 0;
        GenericRecord balanceAmount = null;
        for (Object o : list(field(event, "balances"))) {
            GenericRecord b = (GenericRecord) o;
            if (b != null && props.getBalanceType().equals(str(field(b, "type")))) {
                balanceEntries++;
                if (balanceEntries == 1) {
                    balanceAmount = (GenericRecord) field(b, "amount");
                }
            }
        }
        BigDecimal balance = balanceAmount == null ? null : decimal(balanceAmount, "value");
        String balanceCurrency = balanceAmount == null ? null : currency(str(field(balanceAmount, "currency")));

        // M5, M6: the configured credit line type; entries with a null type are ignored
        int limitEntries = 0;
        GenericRecord limitAmount = null;
        for (Object o : list(field(event, "creditLine"))) {
            GenericRecord c = (GenericRecord) o;
            if (c != null && props.getLimitType().equals(str(field(c, "type")))) {
                limitEntries++;
                if (limitEntries == 1) {
                    limitAmount = (GenericRecord) field(c, "amount");
                }
            }
        }
        BigDecimal limit = limitAmount == null ? null : decimal(limitAmount, "value");
        String limitCurrency = limitAmount == null ? null : currency(str(field(limitAmount, "currency")));

        return new AccountBalanceState(balance, balanceCurrency, limit, limitCurrency,
                new Selection(balanceEntries, limitEntries, balanceEntries == 1 && balance == null));
    }

    // ------------------------------------------------------------------ generic record helpers

    /** Null when the writer's schema has no such field, so a field the producer drops reads as missing. */
    private static Object field(GenericRecord r, String name) {
        return r == null || r.getSchema().getField(name) == null ? null : r.get(name);
    }

    private static List<?> list(Object o) {
        return o instanceof List<?> l ? l : List.of();
    }

    /** Strings arrive as String or Utf8, enum symbols as EnumSymbol: all read through toString(). */
    private static String str(Object o) {
        return o == null ? null : o.toString();
    }

    private static String currency(String s) {
        if (s == null || s.isBlank()) {
            return null;
        }
        return s.trim().toUpperCase(Locale.ROOT);
    }

    /**
     * Decimal logical type. Arrives as BigDecimal when {@code avro.use.logical.type.converters=true},
     * otherwise as the raw bytes (or fixed), which are converted with the scale from the writer's schema.
     */
    static BigDecimal decimal(GenericRecord amount, String name) {
        Object v = field(amount, name);
        if (v == null || v instanceof BigDecimal) {
            return (BigDecimal) v;
        }
        Schema s = nonNull(amount.getSchema().getField(name).schema());
        LogicalType lt = s.getLogicalType();
        if (!(lt instanceof LogicalTypes.Decimal)) {
            throw new IllegalStateException("Field " + name + " is not a decimal in the writer's schema");
        }
        if (v instanceof ByteBuffer buf) {
            return DECIMAL.fromBytes(buf.duplicate(), s, lt);
        }
        if (v instanceof GenericFixed fixed) {
            return DECIMAL.fromFixed(fixed, s, lt);
        }
        throw new IllegalStateException("Unexpected decimal representation " + v.getClass().getName());
    }

    private static Schema nonNull(Schema s) {
        if (s.getType() != Schema.Type.UNION) {
            return s;
        }
        return s.getTypes().stream().filter(t -> t.getType() != Schema.Type.NULL).findFirst().orElse(s);
    }
}
