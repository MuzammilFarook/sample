package ie.aib.ioc.account.dev;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.ByteBuffer;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.apache.avro.Conversions;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;

/**
 * Builds {@code AccountsBalanceEntity} records as {@link GenericRecord}s from the copy of the registered schema
 * ({@code avro/AccountsBalanceEntity.avsc}). Used by the local simulator and by the tests; the consumer itself
 * never uses this schema copy (it reads with the writer's schema from Schema Registry).
 *
 * <p>Values are written in their raw Avro form (decimal as bytes, timestamp as micros), which serialises
 * whether or not logical type converters are switched on.
 */
public final class AccountsBalanceEvents {

    public static final Schema SCHEMA = load("/avro/AccountsBalanceEntity.avsc");

    private static final Conversions.DecimalConversion DECIMAL = new Conversions.DecimalConversion();

    private AccountsBalanceEvents() {
    }

    public static Builder event(String accountId) {
        return new Builder(SCHEMA, accountId);
    }

    /** Same, but against another writer schema (e.g. one with a new enum symbol). */
    public static Builder event(Schema schema, String accountId) {
        return new Builder(schema, accountId);
    }

    public static long micros(Instant i) {
        return Math.addExact(Math.multiplyExact(i.getEpochSecond(), 1_000_000L), i.getNano() / 1_000L);
    }

    public static Schema load(String classpathResource) {
        try (InputStream in = AccountsBalanceEvents.class.getResourceAsStream(classpathResource)) {
            if (in == null) {
                throw new IllegalStateException("Missing schema resource " + classpathResource);
            }
            return new Schema.Parser().parse(in);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public static final class Builder {
        private final Schema schema;
        private final Schema amountSchema;
        private final Schema balanceSchema;
        private final Schema creditLineSchema;
        private final String accountId;
        private final List<GenericRecord> balances = new ArrayList<>();
        private List<GenericRecord> creditLines;          // null = field is null
        private Long updatedMicros = micros(Instant.now());
        private GenericRecord topAmount;

        private Builder(Schema schema, String accountId) {
            this.schema = schema;
            this.accountId = accountId;
            this.balanceSchema = schema.getField("balances").schema().getElementType();
            this.amountSchema = balanceSchema.getField("amount").schema();
            this.creditLineSchema = nonNull(schema.getField("creditLine").schema()).getElementType();
        }

        public Builder updated(Long micros) {
            this.updatedMicros = micros;
            return this;
        }

        public Builder updated(Instant at) {
            return updated(at == null ? null : micros(at));
        }

        public Builder balance(String type, String value, String currency) {
            GenericRecord b = new GenericData.Record(balanceSchema);
            b.put("dateTime", updatedMicros);
            b.put("type", new GenericData.EnumSymbol(balanceSchema.getField("type").schema(), type));
            b.put("amount", amount(value, currency));
            balances.add(b);
            return this;
        }

        public Builder creditLine(String type, String value, String currency) {
            if (creditLines == null) {
                creditLines = new ArrayList<>();
            }
            GenericRecord c = new GenericData.Record(creditLineSchema);
            Schema typeSchema = nonNull(creditLineSchema.getField("type").schema());
            c.put("type", type == null ? null : new GenericData.EnumSymbol(typeSchema, type));
            c.put("amount", value == null && currency == null ? null : amount(value, currency));
            c.put("included", Boolean.TRUE);
            creditLines.add(c);
            return this;
        }

        /** {@code creditLine: []} rather than {@code null}. */
        public Builder noCreditLines() {
            creditLines = new ArrayList<>();
            return this;
        }

        public Builder topLevelAmount(String value, String currency) {
            topAmount = amount(value, currency);
            return this;
        }

        public GenericRecord build() {
            GenericRecord r = new GenericData.Record(schema);
            r.put("amount", topAmount);
            r.put("accountId", accountId);
            r.put("balances", new ArrayList<>(balances));
            r.put("creditLine", creditLines == null ? null : new ArrayList<>(creditLines));
            r.put("updatedDateTime", updatedMicros);
            return r;
        }

        private GenericRecord amount(String value, String currency) {
            GenericRecord a = new GenericData.Record(amountSchema);
            Schema valueSchema = nonNull(amountSchema.getField("value").schema());
            a.put("value", value == null ? null : decimalBytes(new BigDecimal(value), valueSchema));
            a.put("currency", currency);
            return a;
        }
    }

    private static ByteBuffer decimalBytes(BigDecimal v, Schema valueSchema) {
        int scale = ((org.apache.avro.LogicalTypes.Decimal) valueSchema.getLogicalType()).getScale();
        return DECIMAL.toBytes(v.setScale(scale, RoundingMode.UNNECESSARY), valueSchema, valueSchema.getLogicalType());
    }

    private static Schema nonNull(Schema s) {
        if (s.getType() != Schema.Type.UNION) {
            return s;
        }
        return s.getTypes().stream().filter(t -> t.getType() != Schema.Type.NULL).findFirst().orElse(s);
    }
}
