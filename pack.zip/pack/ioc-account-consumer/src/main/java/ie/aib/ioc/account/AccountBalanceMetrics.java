package ie.aib.ioc.account;

import org.springframework.stereotype.Component;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * Data-quality counters for the balance topic (LLD 8, Observability). These are warnings, not failures:
 * the event is still applied. Prometheus names: {@code ioc_account_*_total}.
 */
@Component
public class AccountBalanceMetrics {

    private final Counter noExpectedBalance;
    private final Counter balanceNoCurrency;
    private final Counter missingUpdatedDateTime;
    private final Counter currencyMismatch;

    public AccountBalanceMetrics(MeterRegistry registry) {
        this.noExpectedBalance = Counter.builder("ioc.account.no.expected.balance")
                .description("Events with no Expected balance entry, or one with a null value (balance stored as NULL)")
                .register(registry);
        this.balanceNoCurrency = Counter.builder("ioc.account.balance.no.currency")
                .description("Events with a balance but no currency (currency stored as NULL)")
                .register(registry);
        this.missingUpdatedDateTime = Counter.builder("ioc.account.missing.updated.datetime")
                .description("Events rejected because updatedDateTime is null (no version)")
                .register(registry);
        this.currencyMismatch = Counter.builder("ioc.account.currency.mismatch")
                .description("Events whose balance and limit currencies differ (Secured Exposure will be NULL)")
                .register(registry);
    }

    void noExpectedBalance() { noExpectedBalance.increment(); }
    void balanceNoCurrency() { balanceNoCurrency.increment(); }
    void missingUpdatedDateTime() { missingUpdatedDateTime.increment(); }
    void currencyMismatch() { currencyMismatch.increment(); }
}
