package ie.aib.ioc.account.dev;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.config.TopicBuilder;

import ie.aib.ioc.account.AccountBalanceTopicHandler;
import ie.aib.ioc.platform.topic.TopicsProperties;

/**
 * LOCAL PROFILE ONLY. Creates the balance topic on the local broker at start-up (before the listener starts),
 * so the docker-compose stack needs no change. Spring's KafkaAdmin skips it if the topic already exists.
 */
@Configuration
@Profile("local")
public class LocalTopics {

    @Bean
    NewTopic accountBalanceTopic(TopicsProperties topics) {
        return TopicBuilder.name(topics.getTopics().get(AccountBalanceTopicHandler.CONSUMER).getTopic())
                .partitions(6).replicas(1).build();
    }
}
