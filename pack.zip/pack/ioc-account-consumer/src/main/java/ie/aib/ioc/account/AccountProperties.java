package ie.aib.ioc.account;

import java.math.BigDecimal;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * {@code ioc.account.*}: the account topic's business settings (LLD 5.7). Topic name, envelope fields, evidence
 * level and state-hash fields are library settings under {@code ioc.topics.account-balance-current}.
 */
@ConfigurationProperties(prefix = "ioc.account")
public class AccountProperties {

    /** Rule M3: the {@code balances[].type} taken as Account Balance (consumption agreement). */
    private String balanceType = "Expected";
    /** Rule M5: the {@code creditLine[].type} taken as Account Limit (consumption agreement). */
    private String limitType = "PreAgreed";
    private final MaterialityRule materiality = new MaterialityRule();

    /**
     * "Does this change matter?" (LLD 5.6). DRAFT until the business signs it off. Every switch is configuration,
     * and the version is stamped on every Credit Change note.
     */
    public static class MaterialityRule {
        private String version = "ACC-MAT-0.2-DRAFT";
        private boolean newAccount = true;
        private boolean limitChange = true;
        /** Balance change is material when |new - old| / max(|old|, 1) is at least this. Null turns the rule off. */
        private BigDecimal balanceChangeRatio = new BigDecimal("0.05");
        private boolean currencyChange = true;

        public String getVersion() { return version; }
        public void setVersion(String version) { this.version = version; }
        public boolean isNewAccount() { return newAccount; }
        public void setNewAccount(boolean newAccount) { this.newAccount = newAccount; }
        public boolean isLimitChange() { return limitChange; }
        public void setLimitChange(boolean limitChange) { this.limitChange = limitChange; }
        public BigDecimal getBalanceChangeRatio() { return balanceChangeRatio; }
        public void setBalanceChangeRatio(BigDecimal balanceChangeRatio) { this.balanceChangeRatio = balanceChangeRatio; }
        public boolean isCurrencyChange() { return currencyChange; }
        public void setCurrencyChange(boolean currencyChange) { this.currencyChange = currencyChange; }
    }

    public String getBalanceType() { return balanceType; }
    public void setBalanceType(String balanceType) { this.balanceType = balanceType; }
    public String getLimitType() { return limitType; }
    public void setLimitType(String limitType) { this.limitType = limitType; }
    public MaterialityRule getMateriality() { return materiality; }
}
