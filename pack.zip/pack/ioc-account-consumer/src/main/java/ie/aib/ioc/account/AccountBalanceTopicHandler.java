package ie.aib.ioc.account;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.avro.generic.GenericRecord;
import org.springframework.stereotype.Component;

import ie.aib.ioc.account.domain.AccountBalanceState;
import ie.aib.ioc.platform.core.DecodedEvent;
import ie.aib.ioc.platform.core.Materiality;
import ie.aib.ioc.platform.core.TopicHandler;

/**
 * The balance topic's business code, plugged into the platform library: mapper, validator, repository, materiality.
 *
 * <p>Everything else is configuration, in {@code ioc.topics.account-balance-current}: the topic, entity type,
 * evidence level, the envelope (accountId = key, updatedDateTime = version and business time, derived event id)
 * and the state-hash fields. The library keeps the version and state hash in {@code entity_version}, so
 * {@code account.account} holds business columns only.
 *
 * <p>{@code avroType()} is {@link GenericRecord}: no generated classes for a schema the Accounts Domain owns (LLD R5).
 */
@Component
public class AccountBalanceTopicHandler implements TopicHandler<GenericRecord, AccountBalanceState> {

    /** Key of {@code ioc.topics.*} and the Kafka listener id. */
    public static final String CONSUMER = "account-balance-current";

    private final AccountBalanceMapper mapper;
    private final AccountBalanceValidator validator;
    private final AccountRepository repository;
    private final AccountMaterialityRule materiality;

    public AccountBalanceTopicHandler(AccountBalanceMapper mapper, AccountBalanceValidator validator,
                                      AccountRepository repository, AccountMaterialityRule materiality) {
        this.mapper = mapper;
        this.validator = validator;
        this.repository = repository;
        this.materiality = materiality;
    }

    @Override
    public String consumerName() {
        return CONSUMER;
    }

    @Override
    public Class<GenericRecord> avroType() {
        return GenericRecord.class;
    }

    @Override
    public Class<AccountBalanceState> stateType() {
        return AccountBalanceState.class;
    }

    @Override
    public AccountBalanceState map(GenericRecord avro) {
        return mapper.map(avro);
    }

    @Override
    public void validate(DecodedEvent<AccountBalanceState> event) {
        validator.validate(event);
    }

    @Override
    public Map<String, AccountBalanceState> load(Collection<String> accountIds) {
        return repository.load(accountIds);
    }

    @Override
    public void apply(List<AppliedChange<AccountBalanceState>> changes) {
        repository.apply(changes);
    }

    @Override
    public Materiality assessMateriality(CurrentState<AccountBalanceState> before, DecodedEvent<AccountBalanceState> after) {
        return materiality.assess(before, after);
    }

    @Override
    public String materialityRuleVersion() {
        return materiality.version();
    }
}
