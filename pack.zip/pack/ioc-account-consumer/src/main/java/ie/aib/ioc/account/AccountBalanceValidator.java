package ie.aib.ioc.account;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import ie.aib.ioc.account.domain.AccountBalanceState;
import ie.aib.ioc.account.domain.AccountBalanceState.Selection;
import ie.aib.ioc.platform.core.DecodedEvent;
import ie.aib.ioc.platform.core.ValidationException;

/**
 * The topic contract (LLD 5.3, 7), checked on every event, no database access. A breach goes to the failure
 * tray as VALIDATION and waits for a person (retrying would fail the same way). All problems are reported at
 * once, so whoever fixes it sees the full list.
 *
 * <p>The library already rejects a blank accountId (M1) and a null updatedDateTime (M2): they are the configured
 * entity key and version. This class adds the account rules: accountId longer than the column (M1), updatedDateTime
 * more than 24h in the future, more than one Expected balance (M3) or PreAgreed line (M5), a currency that is not
 * 3 letters (M4), an amount that does not fit DECIMAL(15,2) (M7).
 * <br>Allowed with a warning metric: no Expected balance, balance without currency, balance and limit in
 * different currencies.
 */
@Component
public class AccountBalanceValidator {

    private static final Logger log = LoggerFactory.getLogger(AccountBalanceValidator.class);
    private static final Duration MAX_CLOCK_SKEW = Duration.ofHours(24);
    private static final BigDecimal MAX_AMOUNT = new BigDecimal("9999999999999.99"); // DECIMAL(15,2)
    private static final int MAX_ACCOUNT_ID = 40;

    private final Clock clock;
    private final AccountProperties props;
    private final AccountBalanceMetrics metrics;

    public AccountBalanceValidator(Clock clock, AccountProperties props, AccountBalanceMetrics metrics) {
        this.clock = clock;
        this.props = props;
        this.metrics = metrics;
    }

    public void validate(DecodedEvent<AccountBalanceState> e) {
        List<String> problems = new ArrayList<>();
        AccountBalanceState s = e.state();
        Selection sel = s.selection() == null ? new Selection(0, 0, false) : s.selection();

        // M1: the library checks blank; the column is 40 wide
        require(problems, e.entityKey() == null || e.entityKey().length() <= MAX_ACCOUNT_ID,
                "accountId longer than " + MAX_ACCOUNT_ID);
        // M2: the library rejects a null version; count it here for the data-quality metric
        if (e.occurredAt() == null) {
            metrics.missingUpdatedDateTime();
        } else {
            require(problems, !e.occurredAt().isAfter(clock.instant().plus(MAX_CLOCK_SKEW)),
                    "updatedDateTime is more than 24h in the future");
        }
        // M3, M5
        require(problems, sel.balanceEntries() <= 1,
                sel.balanceEntries() + " balances[] entries with type " + props.getBalanceType() + " (at most 1)");
        require(problems, sel.limitEntries() <= 1,
                sel.limitEntries() + " creditLine[] entries with type " + props.getLimitType() + " (at most 1)");
        // M4, M6
        require(problems, s.balanceCurrency() == null || s.balanceCurrency().matches("[A-Z]{3}"),
                "balance currency '" + s.balanceCurrency() + "' is not a 3-letter code");
        require(problems, s.limitCurrency() == null || s.limitCurrency().matches("[A-Z]{3}"),
                "limit currency '" + s.limitCurrency() + "' is not a 3-letter code");
        // M7
        require(problems, fits(s.balance()), "balance " + plain(s.balance()) + " does not fit DECIMAL(15,2)");
        require(problems, fits(s.limit()), "limit " + plain(s.limit()) + " does not fit DECIMAL(15,2)");

        if (!problems.isEmpty()) {
            throw new ValidationException(String.join("; ", problems));
        }

        // Warnings: the row is still written
        if (s.balance() == null) {
            metrics.noExpectedBalance();
            log.info("ACC_NO_EXPECTED_BALANCE accountId={} version={} reason={}", e.entityKey(), e.sourceVersion(),
                    sel.balanceEntries() == 0 ? "no " + props.getBalanceType() + " entry" : "amount.value is null");
        } else if (s.balanceCurrency() == null) {
            metrics.balanceNoCurrency();
        }
        if (s.balanceCurrency() != null && s.limitCurrency() != null && !s.balanceCurrency().equals(s.limitCurrency())) {
            metrics.currencyMismatch();
        }
    }

    private static boolean fits(BigDecimal v) {
        return v == null || (v.scale() <= 2 && v.abs().compareTo(MAX_AMOUNT) <= 0);
    }

    private static String plain(BigDecimal v) {
        return v == null ? "null" : v.toPlainString();
    }

    private static void require(List<String> problems, boolean ok, String problem) {
        if (!ok) {
            problems.add(problem);
        }
    }
}
