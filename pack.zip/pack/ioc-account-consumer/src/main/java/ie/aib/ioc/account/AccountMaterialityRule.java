package ie.aib.ioc.account;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.stereotype.Component;

import ie.aib.ioc.account.domain.AccountBalanceState;
import ie.aib.ioc.platform.core.DecodedEvent;
import ie.aib.ioc.platform.core.Materiality;
import ie.aib.ioc.platform.core.TopicHandler.CurrentState;

/**
 * Decides whether an applied change gets a Credit Change note (LLD 5.6). DRAFT rule, version in
 * {@code ioc.account.materiality.version}; the business must sign it off.
 *
 * <ul>
 *   <li>NEW_ACCOUNT: first row for the account</li>
 *   <li>LIMIT_CHANGED: the limit or its currency changes, including to or from NULL</li>
 *   <li>BALANCE_CHANGED: |new - old| / max(|old|, 1) at or above {@code balance-change-ratio} (5%),
 *       or the balance appears or disappears</li>
 *   <li>CURRENCY_CHANGED: the balance currency changes</li>
 * </ul>
 * Not material: small balance movements and a newer version with the same values. They are still in the ledger.
 */
@Component
public class AccountMaterialityRule {

    private static final String CREATED = "ACCOUNT_CREATED";
    private static final String UPDATED = "ACCOUNT_UPDATED";

    private final AccountProperties.MaterialityRule cfg;

    public AccountMaterialityRule(AccountProperties props) {
        this.cfg = props.getMateriality();
    }

    public Materiality assess(CurrentState<AccountBalanceState> before, DecodedEvent<AccountBalanceState> after) {
        List<String> reasons = new ArrayList<>();
        AccountBalanceState a = after.state();

        if (before == null || before.deleted() || before.state() == null) {
            if (cfg.isNewAccount()) {
                reasons.add("NEW_ACCOUNT");
            }
            return new Materiality(!reasons.isEmpty(), CREATED, reasons);
        }

        AccountBalanceState b = before.state();
        if (cfg.isLimitChange() && (!sameAmount(b.limit(), a.limit()) || !Objects.equals(b.limitCurrency(), a.limitCurrency()))) {
            reasons.add("LIMIT_CHANGED");
        }
        if (balanceChanged(b.balance(), a.balance())) {
            reasons.add("BALANCE_CHANGED");
        }
        if (cfg.isCurrencyChange() && !Objects.equals(b.balanceCurrency(), a.balanceCurrency())) {
            reasons.add("CURRENCY_CHANGED");
        }
        return new Materiality(!reasons.isEmpty(), UPDATED, reasons);
    }

    public String version() {
        return cfg.getVersion();
    }

    private boolean balanceChanged(BigDecimal old, BigDecimal now) {
        BigDecimal ratio = cfg.getBalanceChangeRatio();
        if (ratio == null) {
            return false;
        }
        if (old == null || now == null) {
            return old != now;          // appeared or disappeared
        }
        if (old.compareTo(now) == 0) {
            return false;
        }
        BigDecimal base = old.abs().max(BigDecimal.ONE);
        return now.subtract(old).abs().divide(base, MathContext.DECIMAL64).compareTo(ratio) >= 0;
    }

    private static boolean sameAmount(BigDecimal x, BigDecimal y) {
        return x == null ? y == null : y != null && x.compareTo(y) == 0;
    }
}
