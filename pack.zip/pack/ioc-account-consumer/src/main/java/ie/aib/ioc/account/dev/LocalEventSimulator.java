package ie.aib.ioc.account.dev;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.boot.ssl.SslBundles;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ie.aib.ioc.account.AccountBalanceTopicHandler;
import ie.aib.ioc.platform.topic.TopicsProperties;
import io.confluent.kafka.serializers.KafkaAvroSerializer;

/**
 * LOCAL PROFILE ONLY. Plays the Accounts Domain: publishes {@code AccountsBalanceEntity} events (the registered
 * schema, as GenericRecords) with a deliberately messy mix so every path in the console lights up.
 *
 * <pre>
 *   kind (console field)                  what is sent                                    expected outcome
 *   normal                                small balance move, newer updatedDateTime       PROCESSED (rarely material)
 *   big move  ("Over-limit %" field)      balance moves 10-30%                            PROCESSED, BALANCE_CHANGED
 *   duplicate ("Duplicate %")             the same record again                           DUPLICATE
 *   same values ("Republish %")           newer updatedDateTime, identical values         PROCESSED, row not updated
 *   stale ("Stale %")                     older updatedDateTime, different balance        STALE
 *   conflict ("Conflict %")               same updatedDateTime, different balance        CONFLICT (tray)
 *   contract breach ("Invalid %")         two Expected entries / null updatedDateTime / bad currency   VALIDATION (tray)
 *   corrupt bytes ("Poison %")            not Avro                                        DESERIALISATION (tray)
 * </pre>
 * Account mix: most have an Expected balance and a PreAgreed limit in EUR; some have no credit line, some no
 * Expected balance, some a GBP limit (currency mismatch: Secured Exposure NULL in the view).
 *
 * <p>Use it from the console's <b>Simulator</b> tab (shown only when the {@code local} profile is active).
 */
@RestController
@Profile("local")
public class LocalEventSimulator {

    private final KafkaTemplate<String, Object> avro;
    private final KafkaTemplate<String, byte[]> raw;
    private final String topic;
    private final Map<String, Acc> book = new HashMap<>();

    public LocalEventSimulator(KafkaProperties kafka, ObjectProvider<SslBundles> ssl, TopicsProperties topics) {
        Map<String, Object> cfg = new HashMap<>(kafka.buildProducerProperties(ssl.getIfAvailable()));
        cfg.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        cfg.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class);
        cfg.put("auto.register.schemas", true);
        cfg.put(ProducerConfig.CLIENT_ID_CONFIG, "dev-simulator");
        this.avro = new KafkaTemplate<>(new DefaultKafkaProducerFactory<>(cfg));
        Map<String, Object> rawCfg = new HashMap<>(cfg);
        rawCfg.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ByteArraySerializer.class);
        rawCfg.put(ProducerConfig.CLIENT_ID_CONFIG, "dev-simulator-raw");
        this.raw = new KafkaTemplate<>(new DefaultKafkaProducerFactory<>(rawCfg));
        this.topic = topics.getTopics().get(AccountBalanceTopicHandler.CONSUMER).getTopic();
    }

    @PostMapping("/dev/simulate")
    public synchronized Map<String, Object> simulate(@RequestBody Simulation s) {
        Random rnd = new Random(s.seed() == null ? System.nanoTime() : s.seed());
        int accounts = s.accounts() == null ? 200 : s.accounts();
        int events = s.events() == null ? 2000 : s.events();
        Map<String, Integer> sent = new LinkedHashMap<>();

        for (int i = 0; i < events; i++) {
            String accountId = String.format("IE29AIBK9311%010d", rnd.nextInt(accounts));
            Acc acc = book.computeIfAbsent(accountId, id -> Acc.open(id, rnd));
            acc.tick();
            String kind = acc.move(rnd, pct(s.overLimitPct(), 2)) ? "big move" : "normal";
            String trace = rnd.nextInt(3) == 0 ? hex(rnd, 32) : null;
            GenericRecord ev = acc.event(acc.updated, acc.balance);
            send(acc.id, ev, trace, sent, kind);

            double roll = rnd.nextDouble() * 100;
            if (roll < pct(s.duplicatePct(), 2)) {
                send(acc.id, ev, trace, sent, "duplicate (same record)");
            } else if ((roll -= pct(s.duplicatePct(), 2)) < pct(s.republishPct(), 1)) {
                acc.tick();
                send(acc.id, acc.event(acc.updated, acc.balance), null, sent, "newer version, same values");
            } else if ((roll -= pct(s.republishPct(), 1)) < pct(s.stalePct(), 1)) {
                send(acc.id, acc.event(acc.updated - 1_000_000, acc.balance.add(BigDecimal.ONE)), null, sent, "stale (older updatedDateTime)");
            } else if ((roll -= pct(s.stalePct(), 1)) < pct(s.conflictPct(), 0.2)) {
                send(acc.id, acc.event(acc.updated, acc.balance.add(new BigDecimal("999.00"))), null, sent,
                        "conflict (same updatedDateTime, different balance)");
            } else if ((roll -= pct(s.conflictPct(), 0.2)) < pct(s.invalidPct(), 0.3)) {
                send(acc.id, acc.broken(rnd), null, sent, "contract breach (validation)");
            } else if ((roll -= pct(s.invalidPct(), 0.3)) < pct(s.poisonPct(), 0.2)) {
                raw.send(new ProducerRecord<>(topic, acc.id, ("not avro " + UUID.randomUUID()).getBytes(StandardCharsets.UTF_8)));
                sent.merge("corrupt bytes (deserialisation)", 1, Integer::sum);
            }
        }
        avro.flush();
        raw.flush();
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("topic", topic);
        out.put("recordsSent", sent.values().stream().mapToInt(Integer::intValue).sum());
        out.put("byKind", sent);
        out.put("accountsKnown", book.size());
        return out;
    }

    private void send(String key, GenericRecord ev, String trace, Map<String, Integer> sent, String kind) {
        ProducerRecord<String, Object> rec = new ProducerRecord<>(topic, key, ev);
        if (trace != null) {
            rec.headers().add("traceparent", ("00-" + trace + "-00f067aa0ba902b7-01").getBytes(StandardCharsets.US_ASCII));
        }
        avro.send(rec);
        sent.merge(kind, 1, Integer::sum);
    }

    private static double pct(Double v, double dflt) {
        return v == null ? dflt : v;
    }

    private static String hex(Random r, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            sb.append(Character.forDigit(r.nextInt(16), 16));
        }
        return sb.toString();
    }

    /** Field names match the console form (shared with the library's ops UI). */
    public record Simulation(Integer accounts, Integer events, Long seed, Double duplicatePct, Double republishPct,
                             Double stalePct, Double conflictPct, Double invalidPct, Double poisonPct, Double overLimitPct) {
    }

    /** The simulator's own idea of each account. */
    private static final class Acc {
        String id;
        BigDecimal balance;          // null = no Expected entry
        BigDecimal limit;            // null = no PreAgreed line
        String limitCurrency = "EUR";
        boolean creditLineNull;
        long updated;

        static Acc open(String id, Random rnd) {
            Acc a = new Acc();
            a.id = id;
            a.limit = BigDecimal.valueOf(10_000 + rnd.nextInt(2_000_000)).setScale(2, RoundingMode.HALF_UP);
            a.balance = a.limit.multiply(BigDecimal.valueOf(0.4 + rnd.nextDouble() * 0.7)).setScale(2, RoundingMode.HALF_UP);
            int profile = rnd.nextInt(50);
            if (profile < 5) {            // 10%: no credit line at all
                a.limit = null;
                a.creditLineNull = true;
            } else if (profile == 5) {    // 2%: limit in another currency
                a.limitCurrency = "GBP";
            } else if (profile == 6) {    // 2%: no Expected balance
                a.balance = null;
            }
            return a;
        }

        /** Next updatedDateTime: now, and always later than the last one. */
        void tick() {
            updated = Math.max(AccountsBalanceEvents.micros(Instant.now()), updated + 1);
        }

        /** @return true for a big move (material) */
        boolean move(Random rnd, double bigMovePct) {
            if (balance == null) {
                return false;
            }
            BigDecimal base = limit == null ? balance.abs().max(BigDecimal.valueOf(1000)) : limit;
            if (rnd.nextDouble() * 100 < bigMovePct) {
                double f = 1 + (rnd.nextBoolean() ? 1 : -1) * (0.10 + rnd.nextDouble() * 0.2);
                balance = balance.multiply(BigDecimal.valueOf(f)).setScale(2, RoundingMode.HALF_UP);
                return true;
            }
            if (limit != null && rnd.nextInt(100) == 0) {
                limit = limit.multiply(BigDecimal.valueOf(1.1)).setScale(2, RoundingMode.HALF_UP);
                return true;
            }
            BigDecimal delta = base.multiply(BigDecimal.valueOf((rnd.nextDouble() - 0.5) * 0.02));
            balance = balance.add(delta).setScale(2, RoundingMode.HALF_UP);
            return false;
        }

        GenericRecord event(long updatedMicros, BigDecimal bal) {
            AccountsBalanceEvents.Builder b = AccountsBalanceEvents.event(id).updated(updatedMicros);
            if (bal != null) {
                b.balance("Expected", bal.toPlainString(), "EUR");
                b.balance("Available", limit == null ? "0.00" : limit.subtract(bal).max(BigDecimal.ZERO).toPlainString(), "EUR");
            } else {
                b.balance("Available", "0.00", "EUR");
            }
            if (!creditLineNull) {
                if (limit != null) {
                    b.creditLine("PreAgreed", limit.toPlainString(), limitCurrency);
                }
                b.creditLine("Credit", "0.00", "EUR");
            }
            return b.build();
        }

        GenericRecord broken(Random rnd) {
            String bal = balance == null ? "100.00" : balance.toPlainString();
            return switch (rnd.nextInt(3)) {
                case 0 -> AccountsBalanceEvents.event(id).updated(updated + 7)
                        .balance("Expected", bal, "EUR").balance("Expected", "1.00", "EUR").build();
                case 1 -> AccountsBalanceEvents.event(id).updated((Long) null).balance("Expected", bal, "EUR").build();
                default -> AccountsBalanceEvents.event(id).updated(updated + 7).balance("Expected", bal, "EURO").build();
            };
        }
    }
}
