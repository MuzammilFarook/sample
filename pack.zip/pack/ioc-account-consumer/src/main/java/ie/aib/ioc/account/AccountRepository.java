package ie.aib.ioc.account;

import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import ie.aib.ioc.account.domain.AccountBalanceState;
import ie.aib.ioc.platform.core.ChangeKind;
import ie.aib.ioc.platform.core.Db;
import ie.aib.ioc.platform.core.DecodedEvent;
import ie.aib.ioc.platform.core.TopicHandler.AppliedChange;

/**
 * {@code account.account}: business columns only. Batched: one round trip per statement per batch.
 *
 * <p>No version or lock logic here. The library locks the account's row in {@code entity_version}, checks the
 * version, and calls {@link #apply} only when the values changed, so every UPDATE here is a real change.
 * The table holds current values only; earlier values are in the library ledger (payload kept, evidence level FULL).
 */
@Repository
public class AccountRepository {

    private final NamedParameterJdbcTemplate jdbc;
    private final Clock clock;

    public AccountRepository(NamedParameterJdbcTemplate jdbc, Clock clock) {
        this.jdbc = jdbc;
        this.clock = clock;
    }

    /** Current values, for the materiality comparison. */
    public Map<String, AccountBalanceState> load(Collection<String> accountIds) {
        Map<String, AccountBalanceState> out = new HashMap<>();
        for (List<String> chunk : Db.chunks(accountIds, Db.MAX_IN_LIST)) {
            jdbc.query("""
                    SELECT account_id, account_balance, account_currency, account_limit, account_limit_currency
                    FROM account.account
                    WHERE account_id IN (:ids)
                    """, new MapSqlParameterSource("ids", chunk), rs -> {
                out.put(rs.getString("account_id"), new AccountBalanceState(
                        rs.getBigDecimal("account_balance"),
                        trimmed(rs.getString("account_currency")),
                        rs.getBigDecimal("account_limit"),
                        trimmed(rs.getString("account_limit_currency")),
                        null));
            });
        }
        return out;
    }

    /** Upsert: update the rows that exist, insert the ones that don't. */
    public void apply(List<AppliedChange<AccountBalanceState>> changes) {
        Instant now = clock.instant();
        List<SqlParameterSource> rows = new ArrayList<>(changes.size());
        for (AppliedChange<AccountBalanceState> c : changes) {
            rows.add(params(c.event(), now));
        }
        SqlParameterSource[] p = rows.toArray(SqlParameterSource[]::new);
        jdbc.batchUpdate("""
                UPDATE account.account SET account_balance = :balance, account_currency = :currency,
                    account_limit = :limit, account_limit_currency = :limitCurrency,
                    source_updated_datetime = :updatedAt, is_deleted = :deleted, modified_datetime = :now
                WHERE account_id = :id
                """, p);
        jdbc.batchUpdate("""
                INSERT INTO account.account (account_id, account_balance, account_currency, account_limit,
                    account_limit_currency, source_updated_datetime, is_deleted, modified_datetime)
                SELECT :id, :balance, :currency, :limit, :limitCurrency, :updatedAt, :deleted, :now
                WHERE NOT EXISTS (SELECT 1 FROM account.account WHERE account_id = :id)
                """, p);
    }

    private static SqlParameterSource params(DecodedEvent<AccountBalanceState> e, Instant now) {
        AccountBalanceState s = e.state();
        return new MapSqlParameterSource()
                .addValue("id", e.entityKey())
                .addValue("balance", s.balance())
                .addValue("currency", s.balanceCurrency())
                .addValue("limit", s.limit())
                .addValue("limitCurrency", s.limitCurrency())
                .addValue("updatedAt", Db.utc(e.occurredAt()))     // business time = updatedDateTime
                .addValue("deleted", e.kind() == ChangeKind.DELETE)
                .addValue("now", Db.utc(now));
    }

    private static String trimmed(String s) {
        return s == null ? null : s.trim();
    }
}
