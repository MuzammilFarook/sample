------------------------------------------------------------
-- IOC: Account (real-time balances), schema [account]: data from the account topic
-- Source topic : accounts.entity.balance.current (AccountsBalanceEntity)
-- Design       : LLD_IOC_Account_Balance_Consumer.md v0.6, section 5.5
-- Owner        : ioc-account-consumer (Flyway range V100)
--
-- One row per account. Only the agreed attributes are stored:
--   Account Balance  = balances[type = Expected].amount
--   Account Limit    = creditLine[type = PreAgreed].amount
-- Every other balance / credit line type stays in the library ledger (payload as received).
-- Current values only: no history table (no requirement for account history). Earlier values are answered
-- from the library ledger (dbo.event_ledger, evidence level FULL keeps every payload as received).
-- Business columns only. The version guard (version, state hash) is the library's dbo.entity_version, and the
-- per-event details (event id, topic, partition, offset, trace id) are on the library's ledger line.
-- To find the event behind the row: entity_key = account_id and source_event_time = source_updated_datetime.
-- The library calls the consumer only when values change, so every UPDATE is a real change.
-- Secured Exposure is derived on read (see R__account_v_account.sql), never stored.
------------------------------------------------------------


------------------------------------------------------------
-- FILE: 10_schema\schema_account.sql
------------------------------------------------------------

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE [name] = N'account')
    EXEC('CREATE SCHEMA [account]');
GO


------------------------------------------------------------
-- FILE: 20_table\account.sql
------------------------------------------------------------

IF OBJECT_ID(N'[account].[account]', N'U') IS NULL
    CREATE TABLE [account].[account]
    (
        -- business attributes (agreed consumption view)
        [account_id] varchar(40) not null,                     -- accountId (Source Account Number)
        [account_balance] decimal(15,2) null,                  -- balances[type=Expected].amount.value
        [account_currency] char(3) null,                       -- balances[type=Expected].amount.currency
        [account_limit] decimal(15,2) null,                    -- creditLine[type=PreAgreed].amount.value
        [account_limit_currency] char(3) null,                 -- creditLine[type=PreAgreed].amount.currency
        [source_updated_datetime] datetime2(6) not null,       -- updatedDateTime (UTC) of the last change applied

        [is_deleted] bit not null constraint [df_account_is_deleted] default (0),
        [modified_datetime] datetime2(3) not null constraint [df_account_modified_datetime] default sysutcdatetime()
    );
GO


------------------------------------------------------------
-- FILE: 21_constraint_primary_key\pk_account.sql
------------------------------------------------------------

IF NOT EXISTS (
    SELECT 1 FROM sys.key_constraints
    WHERE [name] = N'pk_account'
      AND [parent_object_id] = OBJECT_ID(N'[account].[account]')
)
    ALTER TABLE [account].[account]
        ADD CONSTRAINT [pk_account] PRIMARY KEY CLUSTERED ([account_id]);
GO


------------------------------------------------------------
-- FILE: 22_constraint_check\ck_account_currency.sql
------------------------------------------------------------

IF NOT EXISTS (
    SELECT 1 FROM sys.check_constraints
    WHERE [name] = N'ck_account_currency'
      AND [parent_object_id] = OBJECT_ID(N'[account].[account]')
)
    ALTER TABLE [account].[account]
        ADD CONSTRAINT [ck_account_currency] CHECK (
            ([account_currency] IS NULL OR [account_currency] LIKE '[A-Z][A-Z][A-Z]')
        AND ([account_limit_currency] IS NULL OR [account_limit_currency] LIKE '[A-Z][A-Z][A-Z]')
        );
GO


------------------------------------------------------------
-- FILE: 40_grant\grant_account.sql
-- Only if the platform roles exist (created by the platform migration).
------------------------------------------------------------

IF DATABASE_PRINCIPAL_ID(N'ioc_consumer') IS NOT NULL
    GRANT SELECT, INSERT, UPDATE ON [account].[account] TO [ioc_consumer];
GO

IF DATABASE_PRINCIPAL_ID(N'ioc_api') IS NOT NULL
    GRANT SELECT ON [account].[account] TO [ioc_api];
GO
