------------------------------------------------------------
-- IOC: account read view, [account].[v_account] (Secured Exposure derived on read)
-- The per-borrower version is [borrower].[v_account] (ioc_schema_v0_5.sql).
-- Owner  : IOC API (Flyway repeatable migration, runs after the consumer's V100__account.sql)
-- Design : LLD_IOC_Account_Balance_Consumer.md v0.6, section 5.5
-- Shipped with ioc-account-consumer for local runs; the IOC API owns it in shared environments.
--
-- Secured Exposure = MAX(Account Balance, Account Limit), per the Account Balance consumption mapping.
--   * both NULL                  -> NULL
--   * only one present           -> that one
--   * currencies differ          -> NULL, and exposure_currency_mismatch = 1
-- Current values only. Earlier values: the library ledger (see the README, "Values on an earlier date").
------------------------------------------------------------


------------------------------------------------------------
-- FILE: 30_view\account_v_account.sql
------------------------------------------------------------

CREATE OR ALTER VIEW [account].[v_account]
AS
SELECT
    a.[account_id],
    a.[account_balance],
    a.[account_currency],
    a.[account_limit],
    a.[account_limit_currency],
    CASE
        WHEN a.[account_balance] IS NULL AND a.[account_limit] IS NULL THEN NULL
        WHEN a.[account_balance] IS NOT NULL AND a.[account_limit] IS NOT NULL
             AND a.[account_currency] <> a.[account_limit_currency] THEN NULL
        WHEN a.[account_limit] IS NULL THEN a.[account_balance]
        WHEN a.[account_balance] IS NULL THEN a.[account_limit]
        WHEN a.[account_balance] >= a.[account_limit] THEN a.[account_balance]
        ELSE a.[account_limit]
    END AS [secured_exposure],
    COALESCE(a.[account_currency], a.[account_limit_currency]) AS [secured_exposure_currency],
    CAST(CASE
        WHEN a.[account_balance] IS NOT NULL AND a.[account_limit] IS NOT NULL
             AND a.[account_currency] <> a.[account_limit_currency] THEN 1
        ELSE 0
    END AS bit) AS [exposure_currency_mismatch],
    a.[source_updated_datetime]
FROM [account].[account] a
WHERE a.[is_deleted] = 0;
GO


------------------------------------------------------------
-- FILE: 40_grant\grant_v_account.sql
------------------------------------------------------------

IF DATABASE_PRINCIPAL_ID(N'ioc_api') IS NOT NULL
    GRANT SELECT ON [account].[v_account] TO [ioc_api];
GO
