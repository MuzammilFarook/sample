package com.example.demo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class YourService {

    private final ApiRequestBuilder builder;

    @Autowired
    public YourService(ApiMappingProperties properties, TranslatorRegistry registry, EnrichmentService enrichment) {
        this.builder = new ApiRequestBuilder(properties.getMappings(), registry, enrichment);
    }

    public Map<String, Object> processData(Map<String, Object> rowData, String actionCode, String actionSubCode) {
        return builder.build(rowData, actionCode, actionSubCode);
    }
}
