
package com.example.demo.config;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class TranslatorRegistry {
    private final Map<String, DataTranslator> translators = new HashMap<>();

    public TranslatorRegistry() {
        translators.put("none", input -> input);
        translators.put("dateToString", new DateToStringTranslator());
        translators.put("uppercase", new UppercaseTranslator());
        translators.put("commaToList", new CommaToListTranslator());

        // Add more translators as needed
    }

    public DataTranslator get(String key) {
        return translators.getOrDefault(key, input -> input);
    }
}
