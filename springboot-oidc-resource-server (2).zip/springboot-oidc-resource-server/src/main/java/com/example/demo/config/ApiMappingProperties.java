package com.example.demo.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@ConfigurationProperties(prefix = "api-mappings")
public class ApiMappingProperties {
    private Map<String, Map<String, MappingConfig>> mappings;

    public Map<String, Map<String, MappingConfig>> getMappings() {
        return mappings;
    }

    public void setMappings(Map<String, Map<String, MappingConfig>> mappings) {
        this.mappings = mappings;
    }
}
