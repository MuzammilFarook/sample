
package com.example.demo.config;

public class UppercaseTranslator implements DataTranslator {
    @Override
    public Object translate(Object input) {
        return input != null ? input.toString().toUpperCase() : null;
    }
}
