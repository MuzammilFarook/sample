package com.example.demo.config;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class DefaultEnrichmentService implements EnrichmentService {

    private final RestTemplate restTemplate = new RestTemplate();

    @Override
    public Map<String, Object> enrich(String inputValue, List<ApiCall> apiCalls) {
        Map<String, Object> enrichmentMap = new HashMap<>();

        for (ApiCall apiCall : apiCalls) {
            String url = apiCall.getUrl().replace("{input}", inputValue);
            System.out.println("inputValue::" + inputValue);
            try {
                ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
                Object value = extractJsonPath(response.getBody(), apiCall.getResponsePath());
                enrichmentMap.put(apiCall.getFieldAs(), value);
            } catch (Exception e) {
                // log and continue
                System.err.println("Enrichment API call failed for: " + url);
            }
        }

        return enrichmentMap;
    }

    private Object extractJsonPath(Map<String, Object> json, String path) {
        String[] parts = path.split("\\.");
        Object current = json;
        for (String part : parts) {
            if (current instanceof Map<?, ?> map) {
                current = map.get(part);
            } else {
                return null;
            }
        }
        return current;
    }
}
