package com.example.demo.config;

import java.util.List;
import java.util.Map;

public class Enrichment {

    private List<ApiCall> apis;
    private Map<String, Object> objectTemplate;

    public List<ApiCall> getApis() {
        return apis;
    }

    public void setApis(List<ApiCall> apis) {
        this.apis = apis;
    }

    public Map<String, Object> getObjectTemplate() {
        return objectTemplate;
    }

    public void setObjectTemplate(Map<String, Object> objectTemplate) {
        this.objectTemplate = objectTemplate;
    }
}
