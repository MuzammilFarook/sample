
package com.example.demo.config;

import java.util.Map;

public class MappingConfig {
    private String apiPath;
    private String translation;
    private String key;
    private boolean asKeyValuePair;
    private Map<String, Object> objectTemplate;

    private Map<String, MappingConfig> actionMappings;

    private Map<String, MappingConfig> subActions;

    private Enrichment enrichment;

    public String getApiPath() {
        return apiPath;
    }

    public void setApiPath(String apiPath) {
        this.apiPath = apiPath;
    }

    public String getTranslation() {
        return translation;
    }

    public void setTranslation(String translation) {
        this.translation = translation;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public boolean isAsKeyValuePair() {
        return asKeyValuePair;
    }

    public void setAsKeyValuePair(boolean asKeyValuePair) {
        this.asKeyValuePair = asKeyValuePair;
    }

    public Map<String, Object> getObjectTemplate() {
        return objectTemplate;
    }

    public void setObjectTemplate(Map<String, Object> objectTemplate) {
        this.objectTemplate = objectTemplate;
    }

    public Map<String, MappingConfig> getActionMappings() {
        return actionMappings;
    }

    public void setActionMappings(Map<String, MappingConfig> actionMappings) {
        this.actionMappings = actionMappings;
    }

    public Map<String, MappingConfig> getSubActions() {
        return subActions;
    }

    public void setSubActions(Map<String, MappingConfig> subActions) {
        this.subActions = subActions;
    }

    public Enrichment getEnrichment() {
        return enrichment;
    }

    public void setEnrichment(Enrichment enrichment) {
        this.enrichment = enrichment;
    }
}
