
package com.example.demo.config;


import java.util.*;
import java.util.stream.Collectors;

public class ApiRequestBuilder {
    private final Map<String, Map<String, MappingConfig>> config;
    private final TranslatorRegistry translatorRegistry;
    private final EnrichmentService enrichmentService;

    public ApiRequestBuilder(Map<String, Map<String, MappingConfig>> config, TranslatorRegistry translatorRegistry, EnrichmentService enrichmentService) {
        this.config = config;
        this.translatorRegistry = translatorRegistry;
        this.enrichmentService = enrichmentService;
    }

    public static Object getValueFromNestedMap(Map<String, Object> map, String fullKey) {
        String[] parts = fullKey.split("\\.");
        Object current = map;
        for (String part : parts) {
            if (!(current instanceof Map<?, ?> currentMap)) return null;
            current = currentMap.get(part);
            if (current == null) return null;
        }
        return current;
    }

    public Map<String, Object> build(Map<String, Object> dbRowMap, String actionCode, String actionSubCode) {
        Map<String, Object> requestBody = new HashMap<>();

        config.forEach((tableName, columnMappings) ->
                columnMappings.forEach((columnName, baseMapping) -> {
                    MappingConfig mapping = resolveMapping(baseMapping, actionCode, actionSubCode);
                    if (mapping == null || mapping.getApiPath() == null) return;

                    String fullKey = tableName + "." + columnName;
                    Object rawValue = getValueFromNestedMap(dbRowMap, fullKey);
                    if (rawValue == null) return;

                    // ✅ Enrichment Handling
                    if (mapping.getEnrichment() != null) {
                        Map<String, Object> enriched = enrichmentService.enrich(rawValue.toString(), mapping.getEnrichment().getApis());
                        if (enriched == null) enriched = Collections.emptyMap();
                        Map<String, Object> finalEnriched = enriched;
                        Map<String, Object> enrichedObject = mapping.getEnrichment().getObjectTemplate().entrySet().stream()
                                .collect(Collectors.toMap(
                                        Map.Entry::getKey,
                                        entry -> {
                                            Object v = entry.getValue();
                                            if (v instanceof String s && s.startsWith("$")) {
                                                return finalEnriched.getOrDefault(s.substring(1), null);
                                            }
                                            return v;
                                        }
                                ));

                        injectIntoRequest(requestBody, mapping.getApiPath(), enrichedObject);
                        return;
                    }

                    Object translated = translatorRegistry.get(mapping.getTranslation()).translate(rawValue);
                    if (translated == null) return;

                    if (mapping.getObjectTemplate() != null) {
                        handleObjectTemplateInjection(requestBody, mapping, translated);
                    } else if (mapping.isAsKeyValuePair()) {
                        injectKeyValueIntoPath(requestBody, mapping.getApiPath(), mapping.getKey(), translated, true);
                    } else {
                        injectIntoRequest(requestBody, mapping.getApiPath(), translated);
                    }
                })
        );

        return requestBody;
    }

    private MappingConfig resolveMapping(MappingConfig baseMapping, String actionCode, String actionSubCode) {
        if (baseMapping.getActionMappings() == null) return baseMapping;

        MappingConfig mapping = baseMapping.getActionMappings().getOrDefault(actionCode,
                baseMapping.getActionMappings().get("DEFAULT"));

        if (mapping != null && mapping.getSubActions() != null &&
                actionSubCode != null && mapping.getSubActions().containsKey(actionSubCode)) {
            return mapping.getSubActions().get(actionSubCode);
        }

        return mapping;
    }

    private void handleObjectTemplateInjection(Map<String, Object> requestBody, MappingConfig mapping, Object translated) {
        if (translated instanceof List<?> list) {
            for (int i = 0; i < list.size(); i++) {
                Object item = list.get(i);
                boolean isFirst = (i == 0);

                Map<String, Object> obj = mapping.getObjectTemplate().entrySet().stream()
                        .collect(Collectors.toMap(
                                Map.Entry::getKey,
                                tpl -> switch (tpl.getValue().toString()) {
                                    case "$input" -> item;
                                    case "$isFirst" -> isFirst;
                                    default -> tpl.getValue();
                                }));
                injectIntoRequest(requestBody, mapping.getApiPath(), obj);
            }

        } else {
            Map<String, Object> obj = mapping.getObjectTemplate().entrySet().stream()
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            tpl -> "$input".equals(tpl.getValue()) ? translated : tpl.getValue()));
            injectIntoRequest(requestBody, mapping.getApiPath(), obj);
        }
    }

    public void injectIntoRequest(Map<String, Object> root, String path, Object value) {
        navigateAndInsert(root, path, value, null, false);
    }

    public void injectKeyValueIntoPath(Map<String, Object> root, String path, String key, Object value, boolean asKeyValuePair) {
        navigateAndInsert(root, path, value, key, asKeyValuePair);
    }

    @SuppressWarnings("unchecked")
    private void navigateAndInsert(Map<String, Object> root, String path, Object value, String key, boolean asKeyValuePair) {
        if (path == null || path.isBlank()) return;

        String[] parts = path.split("\\.");
        Object current = root;

        for (int i = 0; i < parts.length; i++) {
            String part = parts[i];
            boolean isList = part.endsWith("[]");
            String cleanKey = isList ? part.substring(0, part.length() - 2) : part;

            boolean isLast = (i == parts.length - 1);

            if (current instanceof Map<?, ?> map) {
                if (isList) {
                    List<Object> list = (List<Object>) ((Map<String, Object>) map).computeIfAbsent(cleanKey, k -> new ArrayList<>());

                    if (isLast) {
                        Object insertValue = (key != null)
                                ? (asKeyValuePair ? Map.of("key", key, "value", value) : Map.of(key, value))
                                : value;
                        list.add(insertValue);
                        return;
                    } else {
                        if (list.isEmpty()) list.add(new HashMap<>());
                        current = list.get(0);
                    }

                } else {
                    if (isLast) {
                        ((Map<String, Object>) map).put(cleanKey, key != null ? Map.of(key, value) : value);
                        return;
                    } else {
                        current = ((Map<String, Object>) map).computeIfAbsent(cleanKey, k -> new HashMap<>());
                    }
                }

            } else if (current instanceof List<?> rawList) {
                List<Object> list = (List<Object>) rawList;
                if (list.isEmpty()) list.add(new HashMap<String, Object>());
                current = list.get(0);
            }
        }
    }


}
