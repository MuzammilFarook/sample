package com.example.demo.config;

import java.util.List;
import java.util.Map;

public interface EnrichmentService {
    Map<String, Object> enrich(String inputValue, List<ApiCall> apiCalls);
}
