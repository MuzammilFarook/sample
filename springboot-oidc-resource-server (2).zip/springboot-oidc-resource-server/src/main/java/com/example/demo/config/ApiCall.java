package com.example.demo.config;

public class ApiCall {
    private String url;
    private String responsePath;
    private String fieldAs;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getResponsePath() {
        return responsePath;
    }

    public void setResponsePath(String responsePath) {
        this.responsePath = responsePath;
    }

    public String getFieldAs() {
        return fieldAs;
    }

    public void setFieldAs(String fieldAs) {
        this.fieldAs = fieldAs;
    }
}
