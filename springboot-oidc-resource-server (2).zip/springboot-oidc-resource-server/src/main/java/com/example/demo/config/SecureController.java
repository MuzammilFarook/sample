package com.example.demo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class SecureController {

  private final YourService yourService;

  @Autowired
  public SecureController(YourService yourService) {
    this.yourService = yourService;
  }

  @PostMapping({"/submit/{actionCode}", "/submit/{actionCode}/{actionSubCode}"})
  public ResponseEntity<?> handleActionItem(
          @PathVariable String actionCode,
          @PathVariable(required = false)  String actionSubCode,
          @RequestBody Map<String, Object> dbRowData
  ) {
    Map<String, Object> apiBody = yourService.processData(dbRowData, actionCode, actionSubCode);
    return ResponseEntity.ok(apiBody);
  }
}
