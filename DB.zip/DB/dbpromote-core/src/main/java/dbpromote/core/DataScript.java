package dbpromote.core;

import dbpromote.core.DataPlan.Delete;
import dbpromote.core.DataPlan.Insert;
import dbpromote.core.DataPlan.Update;
import dbpromote.core.Model.Column;
import dbpromote.core.Model.Constraint;
import dbpromote.core.Model.Table;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static dbpromote.core.DdlScript.banner;
import static dbpromote.core.DdlScript.oneLine;
import static dbpromote.core.DdlScript.section;
import static dbpromote.core.DdlScript.wrap;
import static dbpromote.core.Sql.q;

/**
 * Writes one table's data script and its rollback. Runs in manual-commit
 * mode: nothing is permanent until COMMIT, which is left commented out.
 *
 * Every UPDATE and DELETE is guarded on the values the target held when it
 * was read, and checked to touch exactly one row -- so a change made in the
 * target since then stops the script instead of being silently overwritten.
 */
public final class DataScript {

    private static final int BLOCK = 200;   // statements per PL/SQL block

    private final DataPlan p;
    private final Decisions decisions;
    private final DdlScript.Header header;
    private final String owner;
    private final Table def;
    private final List<Table> referencing;   // tables with foreign keys pointing at this one
    private final String table;
    private final String where;              // the read filter, applied to every count

    public final List<Insert> inserts = new ArrayList<>();
    public final List<Update> updates = new ArrayList<>();
    public final List<Delete> deletes = new ArrayList<>();
    public final List<String> skipped = new ArrayList<>();

    public DataScript(DataPlan plan, Decisions decisions, DdlScript.Header header, List<Table> referencing, String filter) {
        this.p = plan;
        this.decisions = decisions;
        this.header = header;
        this.owner = header.owner();
        this.def = plan.definition;
        this.table = Sql.qt(owner, plan.table);
        this.referencing = referencing;
        this.where = filter == null || filter.isBlank() ? "" : " WHERE (" + filter + ")";
        for (Insert i : plan.inserts) {
            if (decisions.applies(i.id(), i.conflict() == null)) inserts.add(i);
            else skipped.add("insert " + i.keyText() + reason(i.id(), i.conflict()));
        }
        for (Update u : plan.updates) {
            if (decisions.applies(u.id(), true)) updates.add(u);
            else skipped.add("update " + u.keyText() + " " + u.column() + ": " + show(u.oldValue()) + " -> "
                + show(u.newValue()) + reason(u.id(), null));
        }
        for (Delete d : plan.deletes) {
            if (decisions.applies(d.id(), plan.scriptDeletes)) deletes.add(d);
            else skipped.add("keep target-only row " + d.keyText() + reason(d.id(), null));
        }
    }

    private String reason(String id, String fallback) {
        Decisions.Decision d = decisions.get(id);
        String r = d != null && d.reason() != null && !d.reason().isBlank() ? d.reason() : fallback;
        return r == null ? "" : "  (" + oneLine(r) + ")";
    }

    public boolean isEmpty() { return inserts.isEmpty() && updates.isEmpty() && deletes.isEmpty(); }

    // ============================================================== forward
    public String forward(int order) {
        StringBuilder sb = new StringBuilder();
        banner(sb, "DATA " + order + ": " + p.table + " -- bring the rows in line with " + header.source());
        sb.append("-- Target   : ").append(header.target()).append(" (schema ").append(owner).append(")\n");
        sb.append("-- Matched on: ").append(String.join(", ", p.key)).append('\n');
        if (!where.isEmpty()) sb.append("-- Rows      : only those where").append(where.substring(6)).append('\n');
        sb.append("--\n");
        sb.append("--   ").append(inserts.size()).append(" INSERTs\n");
        sb.append("--   ").append(updates.size()).append(" UPDATEs (column values) on ").append(plural(updatedRows().size(), "row")).append('\n');
        sb.append("--   ").append(deletes.size()).append(" DELETEs\n");
        if (!skipped.isEmpty()) sb.append("--   ").append(skipped.size()).append(" differences left out -- listed at the end\n");
        for (String n : p.notes) wrap(sb, n, "-- ");
        if (!p.ignored.isEmpty()) sb.append("-- Never compared or updated: ").append(String.join(", ", p.ignored)).append('\n');
        sb.append("--\n");
        sb.append("-- HOW TO RUN\n");
        sb.append("-- * DBeaver: Database > Transaction Mode > Manual Commit. Execute Script\n");
        sb.append("--   (Alt+X) with error handling set to STOP.\n");
        sb.append("-- * Run section 0 and read every result. Then 1-3, then section 4.\n");
        sb.append("-- * COMMIT only if every check in section 4 gives its expected answer.\n");
        sb.append("--   Anything else: ROLLBACK, and nothing has changed.\n");
        sb.append("-- * Each block of UPDATEs/DELETEs stops with an error if a row has changed\n");
        sb.append("--   in the target since it was compared. Then ROLLBACK and compare again.\n");
        DdlScript.line(sb);

        // ---- pre-flight
        sb.append("\n\n");
        section(sb, "0. PRE-FLIGHT -- read-only");
        int n = 0;
        sb.append("-- 0.").append(++n).append(". Rows now. Expect ").append(p.targetRows).append(".\n");
        sb.append("SELECT COUNT(*) AS rows_before FROM ").append(table).append(where).append(";\n\n");
        if (!p.newColumns.isEmpty() || p.targetDefinition == null) {
            List<String> needed = new ArrayList<>(p.targetDefinition == null ? columnsOf(def) : List.copyOf(p.newColumns));
            sb.append("-- 0.").append(++n).append(". The DDL script has run: columns this script needs exist. Expect ")
              .append(needed.size()).append(".\n");
            sb.append("SELECT COUNT(*) AS columns_present FROM all_tab_columns\n WHERE owner = ").append(Sql.str(owner))
              .append(" AND table_name = ").append(Sql.str(p.table)).append("\n   AND column_name IN (")
              .append(names(needed)).append(");\n\n");
        }
        if (!inserts.isEmpty()) {
            sb.append("-- 0.").append(++n).append(". None of the ").append(inserts.size()).append(" new rows exist yet. Expect 0.\n");
            sb.append("SELECT COUNT(*) AS already_present FROM ").append(table).append("\n WHERE ")
              .append(keyIn(inserts.stream().map(Insert::row).toList(), " ")).append(";\n\n");
            for (String sc : p.surrogate) {
                List<Map<String, Object>> withVal = new ArrayList<>();
                for (Insert i : inserts) if (i.row().get(sc) != null) withVal.add(i.row());
                if (withVal.isEmpty()) continue;
                sb.append("-- 0.").append(++n).append(". The ").append(sc).append(" values being inserted are unused. Expect 0.\n");
                sb.append("SELECT COUNT(*) AS id_in_use FROM ").append(table).append("\n WHERE ")
                  .append(Sql.inList(List.of(sc), withVal, r -> List.of(Sql.lit(def.column(sc), r.get(sc))), " "))
                  .append(";\n\n");
            }
            for (Constraint fk : def.constraints) {
                if (!fk.type.equals("R") || !fk.enabled) continue;
                Set<List<Object>> tuples = new LinkedHashSet<>();
                for (Insert i : inserts) {
                    List<Object> t = new ArrayList<>();
                    boolean anyNull = false;
                    for (String c : fk.columns) { Object v = i.row().get(c); if (v == null) anyNull = true; t.add(norm(v)); }
                    if (!anyNull) tuples.add(t);
                }
                if (tuples.isEmpty()) continue;
                sb.append("-- 0.").append(++n).append(". Every parent the new rows point at exists in ").append(fk.refTable)
                  .append(" (").append(fk.name).append("). Expect 0.\n");
                sb.append(missingParents(fk, tuples)).append(";\n\n");
            }
        }
        if (needsCharset()) {
            sb.append("-- 0.").append(++n).append(". Database character set. Expect AL32UTF8. Some values hold characters\n")
              .append("--      outside ASCII (written with UNISTR); a single-byte character set may not store them.\n");
            sb.append("SELECT value AS db_charset FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET';\n\n");
        }

        // ---- changes
        int step = 0;
        if (!deletes.isEmpty()) {
            sb.append("\n\n");
            section(sb, (++step) + ". DELETES -- " + deletes.size() + " rows that exist only in the target (approved)");
            List<String> stmts = new ArrayList<>();
            for (Delete d : deletes) stmts.add(guarded("DELETE FROM " + table + "\n     WHERE " + keyEq(d.row())
                + guards(d.row(), p.compared), d.keyText()));
            blocks(sb, stmts);
        }
        if (!updates.isEmpty()) {
            sb.append("\n\n");
            section(sb, (++step) + ". UPDATES -- " + plural(updates.size(), "value") + " on "
                + plural(updatedRows().size(), "row") + ". Each must touch exactly one row.");
            List<String> stmts = new ArrayList<>();
            for (Map.Entry<String, List<Update>> e : updatedRows().entrySet()) {
                List<Update> us = e.getValue();
                List<String> sets = new ArrayList<>(), guards = new ArrayList<>();
                for (Update u : us) {
                    Column c = def.column(u.column());
                    sets.add(q(u.column()) + " = " + Sql.lit(c, u.newValue()));
                    if (!p.newColumns.contains(u.column())) guards.add(Sql.eq(c, q(u.column()), u.oldValue()));
                }
                stmts.add(guarded("UPDATE " + table + "\n       SET " + String.join(",\n           ", sets)
                    + "\n     WHERE " + keyEq(us.get(0).key())
                    + (guards.isEmpty() ? "" : "\n       AND " + String.join("\n       AND ", guards)), e.getKey()));
            }
            blocks(sb, stmts);
        }
        if (!inserts.isEmpty()) {
            sb.append("\n\n");
            section(sb, (++step) + ". INSERTS -- " + inserts.size() + " rows");
            List<String> cols = insertColumns();
            for (Insert i : inserts) {
                List<String> vals = new ArrayList<>();
                for (String c : cols) vals.add(Sql.lit(def.column(c), i.row().get(c)));
                sb.append("INSERT INTO ").append(table).append(" (").append(Sql.cols(cols)).append(")\n  VALUES (")
                  .append(String.join(", ", vals)).append(");\n");
            }
        }
        if (isEmpty()) sb.append("\n-- Nothing to change: the rows already match.\n");

        // ---- verify
        sb.append("\n\n");
        section(sb, (++step) + ". VERIFY -- then COMMIT");
        n = 0;
        Expected exp = expectedEndState();
        sb.append("-- ").append(step).append('.').append(++n).append(". Rows now. Expect ").append(exp.rows.size()).append(".\n");
        sb.append("SELECT COUNT(*) AS rows_after FROM ").append(table).append(where).append(";\n\n");
        if (!inserts.isEmpty()) {
            sb.append("-- ").append(step).append('.').append(++n).append(". All ").append(inserts.size())
              .append(" new rows are there. Expect ").append(inserts.size()).append(".\n");
            sb.append("SELECT COUNT(*) AS inserted FROM ").append(table).append("\n WHERE ")
              .append(keyIn(inserts.stream().map(Insert::row).toList(), " ")).append(";\n\n");
        }
        sb.append("-- ").append(step).append('.').append(++n).append(". THE KEY CHECK: every column's fingerprint (row count, values\n")
          .append("--      present, total length or sum) against what the table must hold now.\n")
          .append("--      Expect NO ROWS. Any row returned names a column that differs: ROLLBACK.\n");
        sb.append(fingerprint(exp)).append(";\n\n");
        sb.append("-- COMMIT;\n-- ROLLBACK;\n");

        if (!skipped.isEmpty()) {
            sb.append("\n\n");
            section(sb, "LEFT OUT -- " + skipped.size() + " differences not applied");
            for (String s : skipped) sb.append("--   ").append(oneLine(s)).append('\n');
        }
        return sb.toString();
    }

    // ============================================================= rollback
    public String rollback(int order) {
        StringBuilder sb = new StringBuilder();
        banner(sb, "ROLLBACK of DATA " + order + ": " + p.table);
        sb.append("-- Removes the inserted rows, restores the updated values and puts back any\n");
        sb.append("-- deleted rows. Manual-commit mode; run R0 first.\n");
        sb.append("-- Rolling back several tables: newest data script first, then the DDL rollback.\n");
        DdlScript.line(sb);
        if (isEmpty()) { sb.append("\n-- Nothing to roll back.\n"); return sb.toString(); }

        sb.append("\n");
        boolean r0 = false;
        if (!inserts.isEmpty()) {
            for (Table child : referencing) {
                for (Constraint fk : child.constraints) {
                    if (!fk.type.equals("R") || !fk.refTable.equals(p.table)) continue;
                    if (!r0) {
                        sb.append("-- R0. Rows elsewhere that already use the new rows. Expect 0 on every line.\n")
                          .append("--     Anything above 0 means live data depends on this release: the DELETE\n")
                          .append("--     below would fail (ORA-02292) and rollback is no longer a clean option.\n");
                        r0 = true;
                    }
                    Set<List<Object>> tuples = new LinkedHashSet<>();
                    for (Insert i : inserts) {
                        List<Object> t = new ArrayList<>();
                        for (String c : fk.refColumns) t.add(i.row().get(c));
                        if (!t.contains(null)) tuples.add(t);
                    }
                    if (tuples.isEmpty()) continue;
                    List<List<Object>> list = new ArrayList<>(tuples);
                    sb.append("SELECT ").append(Sql.str(child.name + "." + fk.name)).append(" AS reference, COUNT(*) AS rows_using FROM ")
                      .append(Sql.qt(owner, child.name)).append("\n WHERE ")
                      .append(Sql.inList(fk.columns, list, t -> {
                          List<String> l = new ArrayList<>();
                          for (int k = 0; k < fk.refColumns.size(); k++) l.add(Sql.lit(def.column(fk.refColumns.get(k)), t.get(k)));
                          return l;
                      }, " ")).append(";\n\n");
                }
            }
        }
        int step = 0;
        if (!inserts.isEmpty()) {
            sb.append("-- R").append(++step).append(". Remove the ").append(inserts.size()).append(" inserted rows.\n");
            sb.append(checkedBlock("DELETE FROM " + table + "\n     WHERE " + keyIn(inserts.stream().map(Insert::row).toList(), "     "),
                inserts.size(), "inserted rows")).append("\n\n");
        }
        if (!updates.isEmpty()) {
            sb.append("-- R").append(++step).append(". Restore the updated values. Each must touch exactly one row.\n");
            List<String> stmts = new ArrayList<>();
            for (Map.Entry<String, List<Update>> e : updatedRows().entrySet()) {
                List<String> sets = new ArrayList<>(), guards = new ArrayList<>();
                for (Update u : e.getValue()) {
                    Column c = def.column(u.column());
                    sets.add(q(u.column()) + " = " + Sql.lit(c, u.oldValue()));
                    guards.add(Sql.eq(c, q(u.column()), u.newValue()));
                }
                stmts.add(guarded("UPDATE " + table + "\n       SET " + String.join(",\n           ", sets)
                    + "\n     WHERE " + keyEq(e.getValue().get(0).key()) + "\n       AND " + String.join("\n       AND ", guards),
                    e.getKey()));
            }
            blocks(sb, stmts);
            sb.append('\n');
        }
        if (!deletes.isEmpty()) {
            sb.append("-- R").append(++step).append(". Put back the ").append(deletes.size()).append(" deleted rows.\n");
            List<String> cols = new ArrayList<>();
            for (Column c : (p.targetDefinition != null ? p.targetDefinition : def).columns)
                if (!c.isUnsupportedForData() && !(c.identity && "ALWAYS".equals(c.identityGeneration))) cols.add(c.name);
            Table td = p.targetDefinition != null ? p.targetDefinition : def;
            for (Delete d : deletes) {
                List<String> vals = new ArrayList<>();
                for (String c : cols) vals.add(Sql.lit(td.column(c), d.row().get(c)));
                sb.append("INSERT INTO ").append(table).append(" (").append(Sql.cols(cols)).append(")\n  VALUES (")
                  .append(String.join(", ", vals)).append(");\n");
            }
            sb.append('\n');
        }
        sb.append("-- R").append(++step).append(". Rows now. Expect ").append(p.targetRows).append(" (as before the release).\n");
        sb.append("SELECT COUNT(*) AS rows_after_rollback FROM ").append(table).append(where).append(";\n\n");
        sb.append("-- COMMIT;\n-- ROLLBACK;\n");
        return sb.toString();
    }

    // ============================================================ helpers
    private Map<String, List<Update>> updatedRows() {
        Map<String, List<Update>> m = new LinkedHashMap<>();
        for (Update u : updates) m.computeIfAbsent(u.keyText(), k -> new ArrayList<>()).add(u);
        return m;
    }

    private List<String> insertColumns() {
        List<String> cols = new ArrayList<>();
        for (Column c : def.columns) {
            if (p.generated.contains(c.name) || p.unsupported.contains(c.name)) continue;
            cols.add(c.name);
        }
        return cols;
    }

    private static List<String> columnsOf(Table t) {
        List<String> l = new ArrayList<>();
        for (Column c : t.columns) l.add(c.name);
        return l;
    }

    private String keyEq(Map<String, Object> row) {
        List<String> parts = new ArrayList<>();
        for (String k : p.key) parts.add(Sql.eq(def.column(k), q(k), row.get(k)));
        return String.join(" AND ", parts);
    }

    private String guards(Map<String, Object> row, Set<String> columns) {
        StringBuilder sb = new StringBuilder();
        for (String c : columns) {
            if (p.newColumns.contains(c)) continue;
            sb.append("\n       AND ").append(Sql.eq(def.column(c), q(c), row.get(c)));
        }
        return sb.toString();
    }

    private String keyIn(List<Map<String, Object>> rows, String indent) {
        return Sql.inList(p.key, rows, r -> {
            List<String> l = new ArrayList<>();
            for (String k : p.key) l.add(Sql.lit(def.column(k), r.get(k)));
            return l;
        }, indent);
    }

    private static String guarded(String stmt, String keyText) {
        return "    " + stmt + ";\n    IF SQL%ROWCOUNT <> 1 THEN\n      RAISE_APPLICATION_ERROR(-20001, "
            + Sql.str(shorten(keyText) + ": expected 1 row, changed ") + " || SQL%ROWCOUNT"
            + " || ' -- the target has changed since it was compared. ROLLBACK and compare again.');\n    END IF;";
    }

    private static String checkedBlock(String stmt, int expected, String what) {
        return "BEGIN\n    " + stmt + ";\n    IF SQL%ROWCOUNT <> " + expected + " THEN\n      RAISE_APPLICATION_ERROR(-20001, "
            + Sql.str("Expected " + expected + " " + what + ", changed ") + " || SQL%ROWCOUNT || '. ROLLBACK.');\n"
            + "    END IF;\nEND;\n/";
    }

    private static String plural(int n, String word) { return n + " " + word + (n == 1 ? "" : "s"); }

    private static String shorten(String s) { return s.length() > 120 ? s.substring(0, 117) + "..." : s; }

    /** PL/SQL blocks of guarded statements; in DBeaver each block runs as one statement. */
    private static void blocks(StringBuilder sb, List<String> stmts) {
        for (int i = 0; i < stmts.size(); i += BLOCK) {
            sb.append("BEGIN\n");
            for (String s : stmts.subList(i, Math.min(stmts.size(), i + BLOCK))) sb.append(s).append('\n');
            sb.append("END;\n/\n\n");
        }
    }

    private String missingParents(Constraint fk, Set<List<Object>> tuples) {
        List<String> rows = new ArrayList<>();
        int i = 0;
        for (List<Object> t : tuples) {
            List<String> cols = new ArrayList<>();
            for (int k = 0; k < fk.columns.size(); k++)
                cols.add(Sql.lit(def.column(fk.columns.get(k)), t.get(k)) + (i == 0 ? " AS c" + (k + 1) : ""));
            rows.add("SELECT " + String.join(", ", cols) + " FROM dual");
            i++;
        }
        List<String> join = new ArrayList<>();
        for (int k = 0; k < fk.refColumns.size(); k++) join.add("pt." + q(fk.refColumns.get(k)) + " = n.c" + (k + 1));
        return "SELECT COUNT(*) AS missing_parents FROM (\n    " + String.join("\n    UNION ALL ", rows)
            + "\n) n\n WHERE NOT EXISTS (SELECT 1 FROM " + Sql.qt(owner, fk.refTable) + " pt WHERE " + String.join(" AND ", join) + ")";
    }

    private boolean needsCharset() {
        for (Insert i : inserts) for (Object v : i.row().values()) if (v instanceof String s && !Sql.isAscii(s)) return true;
        for (Update u : updates) if (u.newValue() instanceof String s && !Sql.isAscii(s)) return true;
        return false;
    }

    private static Object norm(Object v) { return v instanceof BigDecimal b ? b.stripTrailingZeros() : v; }

    private static String names(List<String> n) {
        List<String> out = new ArrayList<>();
        for (String s : n) out.add(Sql.str(s));
        return String.join(", ", out);
    }

    private static String show(Object v) {
        if (v == null) return "NULL";
        String s = v.toString();
        return "'" + (s.length() > 60 ? s.substring(0, 57) + "..." : s) + "'";
    }

    // ===================================================== expected end state
    /** The rows the table must hold after this script: the target, changed as approved. */
    record Expected(List<Map<String, Object>> rows, List<String> columns) {}

    Expected expectedEndState() {
        Map<String, Map<String, Object>> rows = new LinkedHashMap<>();
        for (Map<String, Object> r : p.targetRowsList) {
            Map<String, Object> copy = new LinkedHashMap<>(r);
            for (String c : p.newColumns) copy.put(c, DataPlan.defaultValue(def.column(c)));
            rows.put(DataPlan.keyText(p.key, r), copy);
        }
        for (Delete d : deletes) rows.remove(d.keyText());
        for (Update u : updates) rows.get(u.keyText()).put(u.column(), u.newValue());
        for (Insert i : inserts) rows.put(i.keyText(), new LinkedHashMap<>(i.row()));
        List<String> cols = new ArrayList<>();
        for (Column c : def.columns) {
            if (p.generated.contains(c.name) || p.unsupported.contains(c.name)) continue;
            if (c.isDate() || c.isTimestamp()) continue;   // counted below, not summed
            cols.add(c.name);
        }
        for (Column c : def.columns) if ((c.isDate() || c.isTimestamp()) && !p.generated.contains(c.name)) cols.add(c.name);
        return new Expected(new ArrayList<>(rows.values()), cols);
    }

    private String fingerprint(Expected e) {
        List<String> lines = new ArrayList<>();
        lines.add(check("rows", BigDecimal.valueOf(e.rows.size()), "COUNT(*)"));
        for (String cn : e.columns) {
            Column c = def.column(cn);
            long present = 0;
            BigDecimal total = BigDecimal.ZERO;
            for (Map<String, Object> r : e.rows) {
                Object v = r.get(cn);
                if (v instanceof String s && s.isEmpty()) v = null;
                if (v == null) continue;
                present++;
                if (c.isNumber()) total = total.add(Sql.num(v));
                else if (c.dataType.equals("CHAR") || c.dataType.equals("NCHAR")) total = total.add(BigDecimal.valueOf(Math.max(c.length, v.toString().length())));
                else if (c.isChar() || c.isClob()) total = total.add(BigDecimal.valueOf(v.toString().length()));
            }
            lines.add(check(cn + " present", BigDecimal.valueOf(present), "COUNT(" + q(cn) + ")"));
            if (c.isNumber()) lines.add(check(cn + " sum", total, "NVL(SUM(" + q(cn) + "), 0)"));
            else if (c.isClob()) lines.add(check(cn + " length", total, "NVL(SUM(DBMS_LOB.GETLENGTH(" + q(cn) + ")), 0)"));
            else if (c.isChar()) lines.add(check(cn + " length", total, "NVL(SUM(LENGTH(" + q(cn) + ")), 0)"));
        }
        return "SELECT chk, expected_value, actual_value FROM (\n    " + String.join("\n    UNION ALL ", lines)
            + "\n)\n WHERE actual_value IS NULL OR actual_value <> expected_value";
    }

    private String check(String name, BigDecimal expected, String aggregate) {
        return "SELECT " + Sql.str(name) + " AS chk, " + expected.toPlainString() + " AS expected_value, (SELECT "
            + aggregate + " FROM " + table + where + ") AS actual_value FROM dual";
    }
}
