package dbpromote.core;

import dbpromote.core.Change.Category;
import dbpromote.core.Change.Check;
import dbpromote.core.Change.Phase;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Writes the DDL script and its rollback from the structural changes and the
 * decisions taken on them. Applied changes become statements; everything else
 * is listed, commented out, so the script also documents what was left alone.
 */
public final class DdlScript {

    private final List<Change> changes;
    private final Decisions decisions;
    private final Header header;
    private final String owner;

    /** Facts printed at the top of every script. */
    public record Header(String source, String target, String owner, String generatedAt, String generatedBy) {}

    public DdlScript(List<Change> changes, Decisions decisions, Header header) {
        this.changes = changes;
        this.decisions = decisions;
        this.header = header;
        this.owner = header.owner();
    }

    public boolean applied(Change c) {
        return c.scriptable() && decisions.applies(c.id, c.appliedByDefault());
    }

    public List<Change> appliedChanges() {
        List<Change> out = new ArrayList<>();
        for (Phase p : Phase.values()) for (Change c : changes) if (c.phase == p && applied(c)) out.add(c);
        return out;
    }

    // ================================================================ forward
    public String forward() {
        List<Change> apply = appliedChanges();
        List<Change> skipped = new ArrayList<>();
        for (Change c : changes) if (c.scriptable() && !applied(c)) skipped.add(c);
        StringBuilder sb = new StringBuilder();
        banner(sb, "DDL: bring " + owner + " in line with " + header.source());
        sb.append("-- Source of truth : ").append(header.source()).append('\n');
        sb.append("-- Target          : ").append(header.target()).append(" (schema ").append(owner).append(")\n");
        sb.append("-- Generated       : ").append(header.generatedAt()).append(" by dbpromote")
          .append(header.generatedBy() == null ? "" : " for " + header.generatedBy()).append('\n');
        sb.append("--\n");
        sb.append("-- Changes applied : ").append(apply.size()).append('\n');
        sb.append("-- Left out        : ").append(skipped.size()).append(" (listed, commented out, at the end)\n");
        sb.append("--\n");
        sb.append("-- HOW TO RUN\n");
        sb.append("-- * Every DDL statement commits on its own: this is NOT one transaction and\n");
        sb.append("--   ROLLBACK cannot undo it. Run section 0 first and read every result.\n");
        sb.append("-- * In DBeaver: Execute Script (Alt+X) with error handling set to STOP.\n");
        sb.append("--   If a statement fails, stop there and do not re-run from the top: what\n");
        sb.append("--   ran before it is already permanent. The rollback script reverses it.\n");
        sb.append("-- * Run the data scripts only after this one has completed.\n");
        line(sb);
        if (apply.isEmpty()) {
            sb.append("\n-- Nothing to apply: the selected structure already matches.\n");
        }

        // ---- pre-flight
        sb.append("\n\n");
        section(sb, "0. PRE-FLIGHT -- read-only. Every check must give its expected answer.");
        Set<String> creates = new LinkedHashSet<>();
        for (Change c : apply) creates.addAll(c.creates);
        int n = 0;
        if (!creates.isEmpty()) {
            sb.append("-- 0.").append(++n).append(". Nothing this script creates may exist yet. Expect NO ROWS.\n");
            sb.append(existenceQuery(creates)).append(";\n\n");
        }
        for (Change c : apply) {
            for (Check k : c.preflight) {
                sb.append("-- 0.").append(++n).append(". ").append(k.description()).append(". Expect ")
                  .append(expect(k.expect())).append(".\n");
                sb.append("--      (").append(c.title).append(")\n");
                sb.append(k.sql()).append(";\n\n");
            }
        }
        if (n == 0) sb.append("-- No pre-flight checks needed.\n");

        // ---- changes by phase
        int step = 0;
        for (Phase p : Phase.values()) {
            List<Change> inPhase = new ArrayList<>();
            for (Change c : apply) if (c.phase == p) inPhase.add(c);
            if (inPhase.isEmpty()) continue;
            sb.append("\n\n");
            section(sb, (++step) + ". " + p.title.toUpperCase());
            if (p == Phase.TRIGGER)
                sb.append("-- Each trigger ends with a line holding only \"/\". In DBeaver run each one\n"
                    + "-- on its own: select from CREATE to the \"/\" line and press Ctrl+Enter.\n\n");
            for (Change c : inPhase) {
                sb.append("-- ").append(c.title);
                if (c.category == Category.REVIEW) sb.append("   [reviewed and approved]");
                sb.append('\n');
                Decisions.Decision d = decisions.get(c.id);
                if (d != null && d.reason() != null && !d.reason().isBlank())
                    sb.append("-- Decision: ").append(oneLine(d.reason())).append('\n');
                if (c.reason != null) wrap(sb, c.reason, "-- ");
                for (String s : c.sql) sb.append(statement(s, p)).append('\n');
                sb.append('\n');
            }
        }

        // ---- verification
        sb.append("\n\n");
        section(sb, (++step) + ". VERIFY");
        n = 0;
        if (!creates.isEmpty()) {
            sb.append("-- ").append(step).append('.').append(++n)
              .append(". Everything this script created exists. Expect ").append(creates.size()).append(" rows.\n");
            sb.append(existenceQuery(creates)).append(";\n\n");
        }
        Set<String> touched = new LinkedHashSet<>();
        for (Change c : apply) if (c.table != null) touched.add(c.table);
        if (!touched.isEmpty()) {
            sb.append("-- ").append(step).append('.').append(++n)
              .append(". Every constraint on the changed tables is enabled and validated. Expect NO ROWS.\n");
            sb.append("SELECT table_name, constraint_name, status, validated\n  FROM all_constraints\n WHERE owner = ")
              .append(Sql.str(owner)).append("\n   AND table_name IN (").append(list(touched))
              .append(")\n   AND (status <> 'ENABLED' OR validated <> 'VALIDATED');\n\n");
        }
        sb.append("-- ").append(step).append('.').append(++n)
          .append(". Nothing in the schema was left invalid. Expect NO ROWS.\n");
        sb.append("SELECT object_type, object_name FROM all_objects\n WHERE owner = ").append(Sql.str(owner))
          .append(" AND status = 'INVALID';\n\n");
        sb.append("-- ").append(step).append('.').append(++n)
          .append(". The real proof: run the comparison again. The only differences left\n")
          .append("--      should be the ones listed below as left out.\n");

        // ---- left out
        if (!skipped.isEmpty()) {
            sb.append("\n\n");
            section(sb, "LEFT OUT -- not applied. Kept here, commented out, for the record.");
            for (Change c : skipped) {
                Decisions.Decision d = decisions.get(c.id);
                sb.append("-- ").append(c.title).append("   [").append(c.category == Category.AUTO ? "skipped" : "needs review")
                  .append("]\n");
                if (d != null && d.reason() != null && !d.reason().isBlank())
                    sb.append("--   Decision: ").append(oneLine(d.reason())).append('\n');
                else if (c.reason != null) wrap(sb, c.reason, "--   ");
                for (String s : c.sql) for (String l : statement(s, c.phase).split("\n")) sb.append("--   ").append(l).append('\n');
                sb.append('\n');
            }
        }
        return sb.toString();
    }

    // =============================================================== rollback
    public String rollback() {
        List<Change> apply = appliedChanges();
        StringBuilder sb = new StringBuilder();
        banner(sb, "ROLLBACK of the DDL script for " + owner);
        sb.append("-- Reverses the DDL script, last change first. Use only if the release has to\n");
        sb.append("-- come back out.\n--\n");
        sb.append("-- * Run the data rollbacks FIRST, newest data script first.\n");
        sb.append("-- * Data written since the release into new tables or new columns is lost.\n");
        sb.append("--   Take an export first if any of it matters.\n");
        sb.append("-- * Added columns are SET UNUSED: instant even on large tables. Reclaim the\n");
        sb.append("--   space later with ALTER TABLE ... DROP UNUSED COLUMNS.\n");
        sb.append("-- * Dropped tables go to the recycle bin (no PURGE).\n");
        sb.append("-- * If the release stopped part-way, statements for steps that never ran fail\n");
        sb.append("--   with \"does not exist\" errors. Those are expected: in DBeaver set error\n");
        sb.append("--   handling to IGNORE, then check the verification at the end.\n");
        line(sb);
        if (apply.isEmpty()) sb.append("\n-- Nothing to roll back.\n");
        List<Change> rev = new ArrayList<>(apply);
        java.util.Collections.reverse(rev);
        int step = 0;
        for (Change c : rev) {
            if (c.rollback.isEmpty()) continue;
            sb.append("\n-- R").append(++step).append(". Undo: ").append(c.title).append('\n');
            if (c.id.startsWith("COL_TYPE:"))
                sb.append("--     Fails if longer or larger values were written since the release.\n");
            if (c.id.startsWith("COL_NULL:") && c.sql.get(0).endsWith(" NULL)"))
                sb.append("--     Fails if NULLs were written since the release.\n");
            for (String s : c.rollback) sb.append(statement(s, c.phase)).append('\n');
        }
        Set<String> creates = new LinkedHashSet<>();
        for (Change c : apply) creates.addAll(c.creates);
        if (!creates.isEmpty()) {
            sb.append("\n\n");
            section(sb, "VERIFY -- nothing the release created is left. Expect NO ROWS.");
            sb.append(existenceQuery(creates)).append(";\n");
        }
        return sb.toString();
    }

    // ================================================================ helpers
    private String existenceQuery(Set<String> objects) {
        List<String> tables = new ArrayList<>(), others = new ArrayList<>(), cons = new ArrayList<>();
        for (String o : objects) {
            String type = o.substring(0, o.indexOf(' ')), name = o.substring(o.indexOf(' ') + 1);
            if (type.equals("CONSTRAINT")) cons.add(name);
            else if (type.equals("TABLE")) tables.add(name);
            else others.add(name);
        }
        List<String> parts = new ArrayList<>();
        if (!tables.isEmpty() || !others.isEmpty()) {
            List<String> all = new ArrayList<>(tables);
            all.addAll(others);
            parts.add("SELECT object_type AS kind, object_name AS name FROM all_objects\n WHERE owner = "
                + Sql.str(owner) + "\n   AND object_type IN ('TABLE', 'INDEX', 'SEQUENCE', 'TRIGGER')\n   AND object_name IN ("
                + list(all) + ")");
        }
        if (!cons.isEmpty()) {
            parts.add("SELECT 'CONSTRAINT', constraint_name FROM all_constraints\n WHERE owner = " + Sql.str(owner)
                + "\n   AND constraint_name IN (" + list(cons) + ")");
        }
        return String.join("\nUNION ALL\n", parts);
    }

    private static String list(Iterable<String> names) {
        List<String> out = new ArrayList<>();
        int i = 0;
        for (String n : names) out.add((i++ > 0 && i % 4 == 1 ? "\n       " : "") + Sql.str(n));
        return String.join(", ", out);
    }

    static String statement(String s, Phase p) {
        if (p == Phase.TRIGGER && s.startsWith("CREATE OR REPLACE TRIGGER")) return s + "\n/";
        return s + ";";
    }

    private static String expect(String e) {
        return switch (e) { case "no rows" -> "NO ROWS"; default -> e; };
    }

    static void banner(StringBuilder sb, String title) {
        line(sb);
        sb.append("-- ").append(title).append('\n');
        line(sb);
    }

    static void section(StringBuilder sb, String title) {
        line(sb);
        sb.append("-- ").append(title).append('\n');
        line(sb);
    }

    static void line(StringBuilder sb) { sb.append("-".repeat(80)).append('\n'); }

    static String oneLine(String s) { return s.replaceAll("\\s+", " ").trim(); }

    static void wrap(StringBuilder sb, String text, String prefix) {
        String[] words = oneLine(text).split(" ");
        StringBuilder cur = new StringBuilder();
        for (String w : words) {
            if (cur.length() + w.length() + 1 > 78 - prefix.length()) {
                sb.append(prefix).append(cur.toString().trim()).append('\n');
                cur.setLength(0);
            }
            cur.append(w).append(' ');
        }
        if (cur.length() > 0) sb.append(prefix).append(cur.toString().trim()).append('\n');
    }
}
