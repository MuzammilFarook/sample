package dbpromote.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** What to compare: the tables chosen, and how each table's data is matched. */
public final class CompareRequest {

    /** Per-table choice: compare its structure, its data, or both. */
    public static final class TableChoice {
        public String table;
        public boolean structure = true;
        public boolean data;
        public TableChoice() {}
        public TableChoice(String table, boolean structure, boolean data) {
            this.table = table; this.structure = structure; this.data = data;
        }
    }

    /** How one table's rows are matched and which columns are left alone. */
    public static final class DataSettings {
        /** Business key; empty means the primary key (or the only unique key). */
        public List<String> key = new ArrayList<>();
        /** Never compared or updated, e.g. DESCRIPTION. Inserts still carry them. */
        public Set<String> ignore = new LinkedHashSet<>();
        /** SQL condition applied when reading both sides, e.g. REFERENCE_CODE <> 'AAA'. */
        public String filter;
        /** Script deletes for target-only rows (otherwise they are only listed). */
        public boolean scriptDeletes;
    }

    public String sourceSchema;
    public String targetSchema;
    public final List<TableChoice> tables = new ArrayList<>();
    public final Map<String, DataSettings> dataSettings = new LinkedHashMap<>();
    /** Also compare sequences (all of them, or those matching this LIKE pattern). */
    public boolean sequences = true;
    public String sequencePattern = "%";

    public TableChoice choice(String table) {
        for (TableChoice c : tables) if (c.table.equals(table)) return c;
        return null;
    }

    public DataSettings settings(String table) {
        return dataSettings.computeIfAbsent(table, t -> new DataSettings());
    }

    public Set<String> structureTables() {
        Set<String> s = new LinkedHashSet<>();
        for (TableChoice c : tables) if (c.structure) s.add(c.table);
        return s;
    }

    public Set<String> dataTables() {
        Set<String> s = new LinkedHashSet<>();
        for (TableChoice c : tables) if (c.data) s.add(c.table);
        return s;
    }

    public Set<String> allTables() {
        Set<String> s = new LinkedHashSet<>();
        for (TableChoice c : tables) s.add(c.table);
        return s;
    }

    // ------------------------------------------------------------- profiles
    public Map<String, Object> toJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("sourceSchema", sourceSchema);
        m.put("targetSchema", targetSchema);
        m.put("sequences", sequences);
        m.put("sequencePattern", sequencePattern);
        List<Object> t = new ArrayList<>();
        for (TableChoice c : tables) {
            Map<String, Object> x = new LinkedHashMap<>();
            x.put("table", c.table); x.put("structure", c.structure); x.put("data", c.data);
            t.add(x);
        }
        m.put("tables", t);
        Map<String, Object> d = new LinkedHashMap<>();
        dataSettings.forEach((k, s) -> {
            Map<String, Object> x = new LinkedHashMap<>();
            x.put("key", new ArrayList<Object>(s.key));
            x.put("ignore", new ArrayList<Object>(s.ignore));
            x.put("filter", s.filter);
            x.put("scriptDeletes", s.scriptDeletes);
            d.put(k, x);
        });
        m.put("dataSettings", d);
        return m;
    }

    public static CompareRequest fromJson(Map<String, Object> m) {
        CompareRequest r = new CompareRequest();
        r.sourceSchema = Json.str(m.get("sourceSchema"));
        r.targetSchema = Json.str(m.get("targetSchema"));
        if (m.get("sequences") != null) r.sequences = Json.bool(m.get("sequences"));
        if (m.get("sequencePattern") != null) r.sequencePattern = Json.str(m.get("sequencePattern"));
        for (Object o : Json.arr(m.get("tables"))) {
            Map<String, Object> x = Json.obj(o);
            r.tables.add(new TableChoice(Json.str(x.get("table")), Json.bool(x.get("structure")), Json.bool(x.get("data"))));
        }
        Json.obj(m.get("dataSettings")).forEach((k, v) -> {
            Map<String, Object> x = Json.obj(v);
            DataSettings s = new DataSettings();
            for (Object o : Json.arr(x.get("key"))) s.key.add(Json.str(o));
            for (Object o : Json.arr(x.get("ignore"))) s.ignore.add(Json.str(o));
            s.filter = Json.str(x.get("filter"));
            s.scriptDeletes = Json.bool(x.get("scriptDeletes"));
            r.dataSettings.put(k, s);
        });
        return r;
    }
}
