package dbpromote.core;

import dbpromote.core.CompareRequest.DataSettings;
import dbpromote.core.Model.Column;
import dbpromote.core.Model.Constraint;
import dbpromote.core.Model.Table;
import dbpromote.core.Model.TableData;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Row-level differences for one table: which rows to insert, which column
 * values to update and which target-only rows could be deleted. Rows are
 * matched on a business key; sequence/identity columns are never compared or
 * inserted, because the target allocates its own values.
 */
public final class DataPlan {

    public record Insert(String id, String keyText, Map<String, Object> row, String conflict) {}
    public record Update(String id, String keyText, Map<String, Object> key, String column,
                         Object oldValue, Object newValue, boolean whitespaceOnly) {}
    public record Delete(String id, String keyText, Map<String, Object> row) {}

    public final String table;
    public Table definition;                      // source table (the shape the target will have)
    public Table targetDefinition;                // current target table, or null if it is new
    public final List<String> key = new ArrayList<>();
    public final Set<String> compared = new LinkedHashSet<>();
    public final Set<String> ignored = new LinkedHashSet<>();
    public final Set<String> generated = new LinkedHashSet<>();
    public final Set<String> surrogate = new LinkedHashSet<>();  // PK columns outside the business key
    public final Set<String> unsupported = new LinkedHashSet<>();
    public final Set<String> newColumns = new LinkedHashSet<>(); // in the source, not yet in the target
    public final Set<String> targetOnlyColumns = new LinkedHashSet<>();
    public final List<Insert> inserts = new ArrayList<>();
    public final List<Update> updates = new ArrayList<>();
    public final List<Delete> deletes = new ArrayList<>();
    public final List<String> notes = new ArrayList<>();
    public String blocked;                        // why the table could not be compared
    public boolean scriptDeletes;
    public int matchedRows, sourceRows, targetRows;
    public List<Map<String, Object>> targetRowsList = List.of();

    private DataPlan(String table) { this.table = table; }

    public boolean hasDifferences() { return !inserts.isEmpty() || !updates.isEmpty() || !deletes.isEmpty(); }

    public static String insertId(String table, String key) { return "DATA:" + table + ":INS:" + key; }
    public static String updateId(String table, String key, String col) { return "DATA:" + table + ":UPD:" + key + ":" + col; }
    public static String deleteId(String table, String key) { return "DATA:" + table + ":DEL:" + key; }

    // ================================================================ compare
    public static DataPlan compare(String table, Table src, Table tgt, TableData sd, TableData td, DataSettings settings) {
        DataPlan p = new DataPlan(table);
        p.definition = src;
        p.targetDefinition = tgt;
        p.scriptDeletes = settings.scriptDeletes;
        if (src == null) { p.blocked = "The table does not exist in the source."; return p; }
        if (sd == null) { p.blocked = "The source rows were not read."; return p; }
        if (td == null && tgt != null) { p.blocked = "The target rows were not read."; return p; }
        if (td != null && sd.filter != null && !sd.filter.equals(td.filter)) {
            p.blocked = "The two sides were read with different filters."; return p;
        }

        // ---- column roles
        for (Column c : src.columns) {
            if (c.isGenerated()) p.generated.add(c.name);
            else if (c.isUnsupportedForData()) p.unsupported.add(c.name);
        }
        for (String i : settings.ignore) if (src.column(i) != null) p.ignored.add(i);
        if (!settings.key.isEmpty()) {
            for (String k : settings.key) {
                if (src.column(k) == null) { p.blocked = "Key column " + k + " does not exist."; return p; }
                p.key.add(k);
            }
        } else {
            Constraint pk = src.primaryKey();
            Constraint uk = null;
            int uks = 0;
            for (Constraint c : src.constraints) if (c.type.equals("U")) { uk = c; uks++; }
            if (pk != null && pk.columns.stream().noneMatch(p.generated::contains)) p.key.addAll(pk.columns);
            else if (uks == 1) p.key.addAll(uk.columns);
            else {
                p.blocked = pk != null
                    ? "The primary key is sequence-generated, so it differs between environments. Choose a business key."
                    : "No primary key or single unique key. Choose the columns that identify a row.";
                return p;
            }
        }
        for (String k : p.key) {
            if (p.generated.contains(k)) { p.blocked = "Key column " + k + " is sequence-generated; choose a business key."; return p; }
            if (p.ignored.contains(k)) { p.blocked = "Key column " + k + " is also marked as ignored."; return p; }
            if (p.unsupported.contains(k)) { p.blocked = "Key column " + k + " has an unsupported type."; return p; }
        }
        Constraint pk = src.primaryKey();
        if (pk != null) for (String c : pk.columns) if (!p.key.contains(c) && !p.generated.contains(c)) p.surrogate.add(c);

        Set<String> targetCols = new HashSet<>(td == null ? List.of() : td.columns);
        for (Column c : src.columns) {
            if (!sd.columns.contains(c.name)) continue;
            if (td != null && !targetCols.contains(c.name)) p.newColumns.add(c.name);
            if (p.key.contains(c.name) || p.generated.contains(c.name) || p.ignored.contains(c.name)
                || p.unsupported.contains(c.name) || p.surrogate.contains(c.name)) continue;
            p.compared.add(c.name);
        }
        if (td != null) for (String c : td.columns) if (src.column(c) == null) p.targetOnlyColumns.add(c);
        if (!p.generated.isEmpty()) p.notes.add("Not compared or inserted, the target allocates its own values: "
            + String.join(", ", p.generated) + ".");
        if (!p.unsupported.isEmpty()) p.notes.add("Not compared (binary or unsupported type): " + String.join(", ", p.unsupported) + ".");
        if (!p.targetOnlyColumns.isEmpty()) p.notes.add("Only in the target, left as they are: " + String.join(", ", p.targetOnlyColumns) + ".");

        // ---- index both sides; duplicate and null keys stop the comparison
        Map<String, Map<String, Object>> s = index(p, sd.rows, "source");
        if (p.blocked != null) return p;
        List<Map<String, Object>> tRows = td == null ? List.of() : td.rows;
        Map<String, Map<String, Object>> t = index(p, tRows, "target");
        if (p.blocked != null) return p;
        p.sourceRows = s.size();
        p.targetRows = t.size();
        p.targetRowsList = tRows;

        // values the target will hold in columns the DDL adds
        Map<String, Object> assumed = new HashMap<>();
        for (String c : p.newColumns) {
            Object d = defaultValue(src.column(c));
            assumed.put(c, d);
            p.notes.add("Column " + c + " is new in the target: compared as its default after the DDL ("
                + (d == null ? "NULL" : d) + ").");
        }

        Set<Object> usedSurrogates = new HashSet<>();
        if (p.surrogate.size() == 1) {
            String sc = p.surrogate.iterator().next();
            for (Map<String, Object> r : tRows) if (r.get(sc) != null) usedSurrogates.add(norm(r.get(sc)));
        }
        int surrogateDiffs = 0;

        for (Map.Entry<String, Map<String, Object>> e : s.entrySet()) {
            String k = e.getKey();
            Map<String, Object> sr = e.getValue();
            Map<String, Object> tr = t.get(k);
            if (tr == null) {
                String conflict = null;
                if (p.surrogate.size() == 1) {
                    String sc = p.surrogate.iterator().next();
                    if (sr.get(sc) != null && usedSurrogates.contains(norm(sr.get(sc))))
                        conflict = sc + " " + sr.get(sc) + " is already used by another row in the target.";
                }
                p.inserts.add(new Insert(insertId(table, k), k, sr, conflict));
                continue;
            }
            p.matchedRows++;
            for (String c : p.compared) {
                Object nv = sr.get(c);
                Object ov = p.newColumns.contains(c) ? assumed.get(c) : tr.get(c);
                if (!Sql.same(nv, ov)) {
                    Map<String, Object> keyVals = new LinkedHashMap<>();
                    for (String kc : p.key) keyVals.put(kc, sr.get(kc));
                    p.updates.add(new Update(updateId(table, k, c), k, keyVals, c, ov, nv, Sql.whitespaceOnly(nv, ov)));
                }
            }
            for (String c : p.surrogate) if (!Sql.same(sr.get(c), tr.get(c))) surrogateDiffs++;
        }
        for (Map.Entry<String, Map<String, Object>> e : t.entrySet())
            if (!s.containsKey(e.getKey())) p.deletes.add(new Delete(deleteId(table, e.getKey()), e.getKey(), e.getValue()));

        if (surrogateDiffs > 0)
            p.notes.add(surrogateDiffs + " matched rows have a different " + String.join(", ", p.surrogate)
                + " in the target. Key columns are never updated; rows are matched on " + String.join(", ", p.key) + ".");
        if (!p.deletes.isEmpty() && !p.scriptDeletes)
            p.notes.add(p.deletes.size() + " rows exist only in the target. They are listed, not deleted, "
                + "unless you approve them individually or switch on deletes for this table.");
        return p;
    }

    private static Map<String, Map<String, Object>> index(DataPlan p, List<Map<String, Object>> rows, String side) {
        Map<String, Map<String, Object>> m = new LinkedHashMap<>();
        List<String> dups = new ArrayList<>();
        int nulls = 0;
        for (Map<String, Object> r : rows) {
            boolean hasNull = false;
            for (String k : p.key) if (r.get(k) == null || (r.get(k) instanceof String x && x.isEmpty())) hasNull = true;
            if (hasNull) { nulls++; continue; }
            String k = keyText(p.key, r);
            if (m.putIfAbsent(k, r) != null && dups.size() < 5) dups.add(k);
        }
        if (nulls > 0 || !dups.isEmpty()) {
            p.blocked = "The key (" + String.join(", ", p.key) + ") does not identify rows uniquely in the " + side
                + (nulls > 0 ? ": " + nulls + " rows have NULL in a key column" : "")
                + (!dups.isEmpty() ? (nulls > 0 ? ";" : ":") + " duplicates such as " + String.join("; ", dups) : "")
                + ". Choose a different key.";
        }
        return m;
    }

    public static String keyText(List<String> key, Map<String, Object> row) {
        List<String> parts = new ArrayList<>();
        for (String k : key) {
            Object v = row.get(k);
            parts.add(v instanceof BigDecimal b ? b.stripTrailingZeros().toPlainString() : String.valueOf(v));
        }
        return String.join(" / ", parts);
    }

    private static Object norm(Object v) {
        return v instanceof BigDecimal b ? b.stripTrailingZeros().toPlainString() : String.valueOf(v);
    }

    /** The value a newly added column takes on existing rows: its default when that is a plain literal. */
    static Object defaultValue(Column c) {
        String d = c.normalisedDefault();
        if (d == null) return null;
        String t = d.trim();
        if (t.startsWith("(") && t.endsWith(")")) t = t.substring(1, t.length() - 1).trim();
        if (t.matches("'([^']|'')*'")) return t.substring(1, t.length() - 1).replace("''", "'");
        try { return new BigDecimal(t); } catch (NumberFormatException e) { return null; }
    }
}
