package dbpromote.core;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * What people decided about each difference: apply or skip, and why.
 * Keyed by the difference's stable id, so a saved profile can carry standing
 * decisions ("never change A721's default") from one release to the next.
 */
public final class Decisions {

    public record Decision(boolean apply, String reason, String by, String at) {}

    private final Map<String, Decision> byId = new LinkedHashMap<>();

    public void set(String id, boolean apply, String reason, String by) {
        byId.put(id, new Decision(apply, reason, by, java.time.Instant.now().toString()));
    }

    public void clear(String id) { byId.remove(id); }

    public Decision get(String id) { return byId.get(id); }

    /** The outcome for a difference: an explicit decision, otherwise its default. */
    public boolean applies(String id, boolean byDefault) {
        Decision d = byId.get(id);
        return d == null ? byDefault : d.apply();
    }

    public Map<String, Decision> all() { return byId; }

    public Map<String, Object> toJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        byId.forEach((k, d) -> {
            Map<String, Object> x = new LinkedHashMap<>();
            x.put("apply", d.apply());
            x.put("reason", d.reason());
            x.put("by", d.by());
            x.put("at", d.at());
            m.put(k, x);
        });
        return m;
    }

    public static Decisions fromJson(Map<String, Object> m) {
        Decisions d = new Decisions();
        m.forEach((k, v) -> {
            Map<String, Object> x = Json.obj(v);
            d.byId.put(k, new Decision(Json.bool(x.get("apply")), Json.str(x.get("reason")),
                Json.str(x.get("by")), Json.str(x.get("at"))));
        });
        return d;
    }
}
