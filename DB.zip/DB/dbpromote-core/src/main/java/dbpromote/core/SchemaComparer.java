package dbpromote.core;

import dbpromote.core.Change.Category;
import dbpromote.core.Change.Phase;
import dbpromote.core.Model.Column;
import dbpromote.core.Model.Constraint;
import dbpromote.core.Model.Index;
import dbpromote.core.Model.Schema;
import dbpromote.core.Model.Sequence;
import dbpromote.core.Model.Table;
import dbpromote.core.Model.Trigger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import static dbpromote.core.Sql.q;

/**
 * Structural comparison: what the target needs so that the selected tables
 * (and sequences) match the source. Produces incremental changes only --
 * never drop-and-recreate -- and classifies each one as AUTO, REVIEW or INFO.
 *
 * Constraints and indexes are matched by what they enforce, not by name, so
 * Oracle's system names (SYS_C...) never show up as false differences.
 */
public final class SchemaComparer {

    private final Schema src;
    private final Schema tgt;
    private final CompareRequest req;
    private final String owner;                       // target schema, used in all SQL
    private final List<Change> changes = new ArrayList<>();
    /** P/U keys that will exist in the target after this run: "TABLE(COLS)" -> change id or "" if already there. */
    private final Map<String, String> keysAfter = new HashMap<>();
    private final Set<String> usedNames = new HashSet<>();

    public SchemaComparer(Schema source, Schema target, CompareRequest request) {
        this.src = source;
        this.tgt = target;
        this.req = request;
        this.owner = request.targetSchema;
        for (Table t : tgt.tables.values()) {
            for (Constraint c : t.constraints) usedNames.add(c.name);
            for (Index i : t.indexes) usedNames.add(i.name);
        }
    }

    public List<Change> compare() {
        // keys already present in the target
        for (Table t : tgt.tables.values())
            for (Constraint c : t.constraints)
                if (c.type.equals("P") || c.type.equals("U")) keysAfter.put(keyOf(t.name, c.columns), "");

        List<String> tables = new ArrayList<>(req.structureTables());
        // new tables first, so later phases can depend on them
        for (String name : tables) {
            Table s = src.tables.get(name), t = tgt.tables.get(name);
            if (s != null && t == null) createTable(s);
        }
        for (String name : tables) {
            Table s = src.tables.get(name), t = tgt.tables.get(name);
            if (s != null && t != null) {
                columns(s, t);
                keys(s, t);
            }
        }
        for (String name : tables) {
            Table s = src.tables.get(name), t = tgt.tables.get(name);
            if (s != null && t != null) {
                checks(s, t);
                indexes(s, t);
            }
            if (s != null) foreignKeys(s, t);
            if (s == null && t != null) targetOnlyTable(t);
            if (s == null && t == null) {
                changes.add(new Change("TABLE_MISSING:" + name, name, name, Category.INFO, Phase.NONE,
                    "Table " + name + " exists in neither environment").because("Check the selection."));
            }
        }
        triggers(tables);
        if (req.sequences) sequences();
        return changes;
    }

    // ================================================================ tables
    private void createTable(Table s) {
        String id = "TABLE_ADD:" + s.name;
        Change c = new Change(id, s.name, s.name, Category.AUTO, Phase.CREATE_TABLE, "Create table " + s.name)
            .from(s.columns.size() + " columns").to("missing");
        StringBuilder sb = new StringBuilder("CREATE TABLE ").append(Sql.qt(owner, s.name)).append(" (\n");
        List<String> items = new ArrayList<>();
        for (Column col : s.columns) items.add("    " + columnDef(col, true));
        List<String> inlineNames = new ArrayList<>();
        for (Constraint k : s.constraints) {
            if (k.isNotNullCheck() || k.type.equals("R")) continue;
            String name = constraintName(s.name, k);
            inlineNames.add(name);
            items.add("    CONSTRAINT " + q(name) + " " + constraintBody(k) + (k.enabled ? "" : " DISABLE"));
            if (k.type.equals("P") || k.type.equals("U")) keysAfter.put(keyOf(s.name, k.columns), id);
            c.creates("CONSTRAINT", name);
        }
        sb.append(String.join(",\n", items)).append("\n)");
        c.sql(sb.toString()).undo("DROP TABLE " + Sql.qt(owner, s.name));
        c.creates("TABLE", s.name).removes("TABLE", s.name);
        for (Column col : s.columns) {
            String seq = sequenceIn(col.normalisedDefault());
            if (seq != null && !tgt.sequences.containsKey(seq)) c.needs("SEQ_ADD:" + seq);
        }
        changes.add(c);
        // indexes that are not created by the inline keys
        for (Index ix : s.indexes) {
            if (backsKey(s, ix)) continue;
            String name = indexName(s.name, ix);
            changes.add(new Change("INDEX_ADD:" + s.name + ":" + ix.signature(), s.name, name, Category.AUTO,
                Phase.INDEX, "Create index " + name + " on new table " + s.name)
                .from(describe(ix)).to("missing")
                .sql(createIndex(s.name, name, ix)).undo("DROP INDEX " + Sql.qt(owner, name))
                .creates("INDEX", name).needs(id));
        }
    }

    private void targetOnlyTable(Table t) {
        changes.add(new Change("TABLE_DROP:" + t.name, t.name, t.name, Category.REVIEW, Phase.DROP,
            "Table " + t.name + " exists only in the target")
            .from("missing").to(t.columns.size() + " columns")
            .because("Never dropped automatically. Approve only if the table is genuinely obsolete; "
                + "the table goes to the recycle bin (no PURGE).")
            .sql("DROP TABLE " + Sql.qt(owner, t.name))
            .undo("FLASHBACK TABLE " + Sql.qt(owner, t.name) + " TO BEFORE DROP")
            .removes("TABLE", t.name));
    }

    // =============================================================== columns
    private void columns(Table s, Table t) {
        for (Column sc : s.columns) {
            Column tc = t.column(sc.name);
            if (tc == null) { addColumn(s, t, sc); continue; }
            columnType(s.name, sc, tc);
            nullability(s.name, sc, tc);
            columnDefault(s.name, sc, tc);
            if (sc.identity != tc.identity || (sc.identity && !Objects.equals(sc.identityGeneration, tc.identityGeneration))) {
                changes.add(new Change("COL_IDENTITY:" + s.name + "." + sc.name, s.name, sc.name, Category.REVIEW,
                    Phase.COLUMN, "Identity differs on " + s.name + "." + sc.name)
                    .from(identityText(sc)).to(identityText(tc))
                    .because("Identity columns cannot be converted in place; this needs a planned migration."));
            }
        }
        for (Column tc : t.columns) {
            if (s.column(tc.name) != null) continue;
            String tn = Sql.qt(owner, t.name);
            changes.add(new Change("COL_DROP:" + t.name + "." + tc.name, t.name, tc.name, Category.REVIEW, Phase.DROP,
                "Column " + t.name + "." + tc.name + " exists only in the target")
                .from("missing").to(tc.typeSql())
                .because("Never removed automatically. SET UNUSED hides the column instantly; its data is lost.")
                .sql("ALTER TABLE " + tn + " SET UNUSED (" + q(tc.name) + ")"));
        }
        // column order -- report only
        List<String> so = new ArrayList<>(), to = new ArrayList<>();
        for (Column c : s.columns) if (t.column(c.name) != null) so.add(c.name);
        for (Column c : t.columns) if (s.column(c.name) != null) to.add(c.name);
        if (!so.equals(to)) {
            changes.add(new Change("COL_ORDER:" + s.name, s.name, "column order", Category.INFO, Phase.NONE,
                "Column order differs on " + s.name)
                .because("Changing column order means rebuilding the table. It only matters to code that uses "
                    + "SELECT * or INSERT without a column list."));
        }
    }

    private void addColumn(Table s, Table t, Column sc) {
        String tn = Sql.qt(owner, t.name);
        boolean notNullNoDefault = !sc.nullable && sc.normalisedDefault() == null && !sc.identity;
        boolean emptyTable = t.rowCount != null && t.rowCount == 0;
        Category cat = (sc.identity || (notNullNoDefault && !emptyTable)) ? Category.REVIEW : Category.AUTO;
        Change c = new Change("COL_ADD:" + s.name + "." + sc.name, s.name, sc.name, cat, Phase.COLUMN,
            "Add column " + s.name + "." + sc.name)
            .from(columnDef(sc, false)).to("missing")
            .sql("ALTER TABLE " + tn + " ADD (" + columnDef(sc, true) + ")")
            .undo("ALTER TABLE " + tn + " SET UNUSED (" + q(sc.name) + ")");
        if (cat == Category.REVIEW) {
            c.because(sc.identity
                ? "Adding an identity column to an existing table fills it for every row; check the effect first."
                : "NOT NULL with no default fails on a table that has rows. Add it nullable, back-fill, then tighten -- "
                  + "or approve if the table is empty.");
            if (notNullNoDefault) c.pre("Rows in " + t.name + " (must be 0 for this to work)",
                "SELECT COUNT(*) AS row_count FROM " + tn, "0");
        } else if (!sc.nullable && sc.normalisedDefault() != null) {
            c.because("NOT NULL with a default: metadata-only on 19c, existing rows read the default.");
        }
        String seq = sequenceIn(sc.normalisedDefault());
        if (seq != null && !tgt.sequences.containsKey(seq)) c.needs("SEQ_ADD:" + seq);
        changes.add(c);
    }

    private void columnType(String table, Column sc, Column tc) {
        if (sc.typeSql().equals(tc.typeSql())) return;
        String tn = Sql.qt(owner, table);
        String id = "COL_TYPE:" + table + "." + sc.name;
        String title = "Change type of " + table + "." + sc.name;
        Change c;
        if (widens(sc, tc)) {
            c = new Change(id, table, sc.name, Category.AUTO, Phase.COLUMN, title)
                .because("Widening only: cannot fail and keeps every value.")
                .sql("ALTER TABLE " + tn + " MODIFY (" + q(sc.name) + " " + sc.typeSql() + ")")
                .undo("ALTER TABLE " + tn + " MODIFY (" + q(sc.name) + " " + tc.typeSql() + ")");
        } else {
            c = new Change(id, table, sc.name, Category.REVIEW, Phase.COLUMN, title)
                .because(sc.dataType.equals(tc.dataType)
                    ? "Narrowing or a scale change: fails if existing values do not fit."
                    : "Different data type: usually needs a planned migration.")
                .sql("ALTER TABLE " + tn + " MODIFY (" + q(sc.name) + " " + sc.typeSql() + ")")
                .undo("ALTER TABLE " + tn + " MODIFY (" + q(sc.name) + " " + tc.typeSql() + ")");
            if (sc.isChar() && tc.isChar() && sc.length != null) {
                c.pre("Values in " + table + "." + sc.name + " longer than " + sc.length,
                    "SELECT COUNT(*) AS too_long FROM " + tn + " WHERE LENGTH(" + q(sc.name) + ") > " + sc.length, "0");
            }
        }
        changes.add(c.from(sc.typeSql()).to(tc.typeSql()));
    }

    /** True when the source type holds every value of the target type. */
    static boolean widens(Column s, Column t) {
        if (s.isChar() && t.isChar()) {
            return s.dataType.equals(t.dataType) && Objects.equals(s.charUsed, t.charUsed)
                && s.length != null && t.length != null && s.length >= t.length;
        }
        if (s.dataType.equals("NUMBER") && t.dataType.equals("NUMBER")) {
            int ss = s.scale == null ? 0 : s.scale, ts = t.scale == null ? 0 : t.scale;
            if (s.precision == null && s.scale == null) return true;           // unconstrained NUMBER
            if (t.precision == null) return false;
            if (s.precision == null) return ss >= ts;
            return ss >= ts && (s.precision - ss) >= (t.precision - ts);
        }
        if (s.isTimestamp() && t.isTimestamp()) return fraction(s.dataType) >= fraction(t.dataType);
        if (s.dataType.equals("RAW") && t.dataType.equals("RAW")) return s.length >= t.length;
        return false;
    }

    private static int fraction(String ts) {
        int o = ts.indexOf('(');
        return o < 0 ? 6 : Integer.parseInt(ts.substring(o + 1, ts.indexOf(')')));
    }

    private void nullability(String table, Column sc, Column tc) {
        if (sc.nullable == tc.nullable || sc.identity || tc.identity) return;
        String tn = Sql.qt(owner, table);
        String id = "COL_NULL:" + table + "." + sc.name;
        if (sc.nullable) {
            changes.add(new Change(id, table, sc.name, Category.AUTO, Phase.COLUMN,
                "Allow NULL in " + table + "." + sc.name)
                .from("nullable").to("NOT NULL").because("Relaxing a constraint cannot fail.")
                .sql("ALTER TABLE " + tn + " MODIFY (" + q(sc.name) + " NULL)")
                .undo("ALTER TABLE " + tn + " MODIFY (" + q(sc.name) + " NOT NULL)"));
        } else {
            changes.add(new Change(id, table, sc.name, Category.AUTO, Phase.COLUMN,
                "Make " + table + "." + sc.name + " NOT NULL")
                .from("NOT NULL").to("nullable").because("Fails if the column holds NULLs; the pre-flight checks.")
                .pre("NULLs in " + table + "." + sc.name,
                    "SELECT COUNT(*) AS null_rows FROM " + tn + " WHERE " + q(sc.name) + " IS NULL", "0")
                .sql("ALTER TABLE " + tn + " MODIFY (" + q(sc.name) + " NOT NULL)")
                .undo("ALTER TABLE " + tn + " MODIFY (" + q(sc.name) + " NULL)"));
        }
    }

    private void columnDefault(String table, Column sc, Column tc) {
        String sd = sc.normalisedDefault(), td = tc.normalisedDefault();
        if (Objects.equals(sd, td) || sc.identity) return;
        String tn = Sql.qt(owner, table);
        changes.add(new Change("COL_DEFAULT:" + table + "." + sc.name, table, sc.name, Category.AUTO, Phase.COLUMN,
            "Change default of " + table + "." + sc.name)
            .from(sd == null ? "no default" : sd).to(td == null ? "no default" : td)
            .because("Affects future inserts only.")
            .sql("ALTER TABLE " + tn + " MODIFY (" + q(sc.name) + " DEFAULT " + (sd == null ? "NULL" : sc.defaultValue.trim()) + ")")
            .undo("ALTER TABLE " + tn + " MODIFY (" + q(sc.name) + " DEFAULT " + (td == null ? "NULL" : tc.defaultValue.trim()) + ")"));
    }

    // ======================================================= primary/unique
    private void keys(Table s, Table t) {
        List<Constraint> tUnmatched = new ArrayList<>();
        for (Constraint k : t.constraints)
            if ((k.type.equals("P") || k.type.equals("U")) && find(s, k) == null) tUnmatched.add(k);

        for (Constraint k : s.constraints) {
            if (!k.type.equals("P") && !k.type.equals("U")) continue;
            Constraint m = find(t, k);
            if (m != null) { sameConstraint(s.name, k, m); continue; }
            Constraint sameName = byName(tUnmatched, k.name);
            if (sameName != null && !k.generatedName) {
                replaceConstraint(s.name, k, sameName);
                tUnmatched.remove(sameName);
                continue;
            }
            addKey(s, t, k);
        }
        for (Constraint k : tUnmatched) targetOnlyConstraint(t.name, k);
    }

    private void addKey(Table s, Table t, Constraint k) {
        String tn = Sql.qt(owner, t.name);
        String name = constraintName(s.name, k);
        Index existing = indexOn(t, k.columns);
        boolean pk = k.type.equals("P");
        Constraint otherPk = pk ? t.primaryKey() : null;
        String id = (pk ? "PK_ADD:" : "UK_ADD:") + s.name + ":" + String.join(",", k.columns);
        Category cat = otherPk != null ? Category.REVIEW : Category.AUTO;
        Change c = new Change(id, s.name, name, cat, Phase.KEY,
            "Add " + k.typeName() + " " + name + " on " + s.name + " (" + String.join(", ", k.columns) + ")")
            .from(k.typeName() + " (" + String.join(", ", k.columns) + ")").to("missing");
        String using = existing != null ? " USING INDEX " + Sql.qt(owner, existing.name) : "";
        c.sql("ALTER TABLE " + tn + " ADD CONSTRAINT " + q(name) + " " + constraintBody(k) + using);
        c.undo("ALTER TABLE " + tn + " DROP CONSTRAINT " + q(name) + (existing != null ? " KEEP INDEX" : ""));
        c.creates("CONSTRAINT", name);
        if (existing != null)
            c.because("Declared on the existing index " + existing.name + ": metadata only, no index build. "
                + "Rollback keeps the index, restoring today's state exactly.");
        else
            c.because("Builds a unique index; locks the table while it builds.");
        if (otherPk != null)
            c.because("The target already has a different primary key (" + otherPk.name + " on "
                + String.join(", ", otherPk.columns) + "). Replacing a primary key needs a planned change.");
        String cl = Sql.cols(k.columns);
        c.pre("Duplicate " + String.join(", ", k.columns) + " in " + t.name + " (must return no rows)",
            "SELECT " + cl + ", COUNT(*) AS dup_count FROM " + tn + " GROUP BY " + cl + " HAVING COUNT(*) > 1", "no rows");
        if (pk) {
            List<String> nulls = new ArrayList<>();
            for (String col : k.columns) nulls.add(q(col) + " IS NULL");
            c.pre("NULLs in the key columns of " + t.name,
                "SELECT COUNT(*) AS null_keys FROM " + tn + " WHERE " + String.join(" OR ", nulls), "0");
        }
        keysAfter.put(keyOf(s.name, k.columns), id);
        changes.add(c);
    }

    // ================================================================ checks
    private void checks(Table s, Table t) {
        List<Constraint> tUnmatched = new ArrayList<>();
        for (Constraint k : t.constraints)
            if (k.type.equals("C") && !k.isNotNullCheck() && find(s, k) == null) tUnmatched.add(k);
        for (Constraint k : s.constraints) {
            if (!k.type.equals("C") || k.isNotNullCheck()) continue;
            Constraint m = find(t, k);
            if (m != null) { sameConstraint(s.name, k, m); continue; }
            Constraint sameName = byName(tUnmatched, k.name);
            if (sameName != null && !k.generatedName) {
                replaceConstraint(s.name, k, sameName);
                tUnmatched.remove(sameName);
                continue;
            }
            String tn = Sql.qt(owner, t.name);
            String name = constraintName(s.name, k);
            changes.add(new Change("CK_ADD:" + s.name + ":" + Constraint.normaliseCondition(k.condition), s.name, name,
                Category.AUTO, Phase.CHECK, "Add check " + name + " on " + s.name)
                .from(k.condition).to("missing")
                .pre("Rows in " + t.name + " violating " + name,
                    "SELECT COUNT(*) AS violations FROM " + tn + " WHERE NOT (" + k.condition + ")", "0")
                .sql("ALTER TABLE " + tn + " ADD CONSTRAINT " + q(name) + " CHECK (" + k.condition + ")")
                .undo("ALTER TABLE " + tn + " DROP CONSTRAINT " + q(name))
                .creates("CONSTRAINT", name)
                .needs(columnChangeFor(s.name, k.condition)));
        }
        for (Constraint k : tUnmatched) targetOnlyConstraint(t.name, k);
    }

    // =========================================================== foreign keys
    private void foreignKeys(Table s, Table t) {
        List<Constraint> tUnmatched = new ArrayList<>();
        if (t != null)
            for (Constraint k : t.constraints) if (k.type.equals("R") && find(s, k) == null) tUnmatched.add(k);
        for (Constraint k : s.constraints) {
            if (!k.type.equals("R")) continue;
            if (t != null) {
                Constraint m = find(t, k);
                if (m != null) { sameConstraint(s.name, k, m); continue; }
                Constraint sameName = byName(tUnmatched, k.name);
                if (sameName != null && !k.generatedName) {
                    replaceConstraint(s.name, k, sameName);
                    tUnmatched.remove(sameName);
                    continue;
                }
            }
            String tn = Sql.qt(owner, s.name);
            String name = constraintName(s.name, k);
            String parentKey = keysAfter.get(keyOf(k.refTable, k.refColumns));
            boolean parentKnown = parentKey != null;
            Change c = new Change("FK_ADD:" + s.name + ":" + k.signature(), s.name, name,
                parentKnown ? Category.AUTO : Category.REVIEW, Phase.FOREIGN_KEY,
                "Add foreign key " + name + " on " + s.name + " -> " + k.refTable)
                .from(String.join(", ", k.columns) + " -> " + k.refTable + "(" + String.join(", ", k.refColumns) + ")")
                .to("missing")
                .sql("ALTER TABLE " + tn + " ADD CONSTRAINT " + q(name) + " FOREIGN KEY (" + Sql.cols(k.columns)
                    + ") REFERENCES " + Sql.qt(owner, k.refTable) + " (" + Sql.cols(k.refColumns) + ")"
                    + deleteRule(k))
                .undo("ALTER TABLE " + tn + " DROP CONSTRAINT " + q(name))
                .creates("CONSTRAINT", name);
            if (!parentKnown) {
                c.because(k.refTable + "(" + String.join(", ", k.refColumns) + ") has no primary or unique key in the "
                    + "target, and none is added by this run -- select " + k.refTable + " for structure as well.");
            } else if (!parentKey.isEmpty()) {
                c.needs(parentKey);
            }
            if (t == null) c.needs("TABLE_ADD:" + s.name);
            if (t != null && tgt.tables.containsKey(k.refTable)) {
                List<String> join = new ArrayList<>(), notNull = new ArrayList<>();
                for (int i = 0; i < k.columns.size(); i++) {
                    join.add("p." + q(k.refColumns.get(i)) + " = c." + q(k.columns.get(i)));
                    notNull.add("c." + q(k.columns.get(i)) + " IS NOT NULL");
                }
                c.pre("Rows in " + s.name + " with no parent in " + k.refTable,
                    "SELECT COUNT(*) AS orphans FROM " + tn + " c WHERE " + String.join(" AND ", notNull)
                        + " AND NOT EXISTS (SELECT 1 FROM " + Sql.qt(owner, k.refTable) + " p WHERE "
                        + String.join(" AND ", join) + ")", "0");
            }
            if (!tgt.tables.containsKey(k.refTable)) c.needs("TABLE_ADD:" + k.refTable);
            changes.add(c);
        }
        for (Constraint k : tUnmatched) targetOnlyConstraint(t.name, k);
    }

    private static String deleteRule(Constraint k) {
        return switch (k.deleteRule == null ? "" : k.deleteRule) {
            case "CASCADE" -> " ON DELETE CASCADE";
            case "SET NULL" -> " ON DELETE SET NULL";
            default -> "";
        };
    }

    // ========================================================= shared helpers
    private void sameConstraint(String table, Constraint s, Constraint t) {
        if (s.enabled != t.enabled || s.validated != t.validated) {
            String tn = Sql.qt(owner, table);
            String verb = s.enabled ? (s.validated ? "ENABLE VALIDATE" : "ENABLE NOVALIDATE") : "DISABLE";
            String back = t.enabled ? (t.validated ? "ENABLE VALIDATE" : "ENABLE NOVALIDATE") : "DISABLE";
            changes.add(new Change("CONS_STATE:" + table + ":" + s.signature(), table, t.name, Category.REVIEW,
                Phase.FOREIGN_KEY, "State of " + t.typeName() + " " + t.name + " on " + table + " differs")
                .from(state(s)).to(state(t))
                .because("A disabled constraint is usually deliberate, for example during a load.")
                .sql("ALTER TABLE " + tn + " MODIFY CONSTRAINT " + q(t.name) + " " + verb)
                .undo("ALTER TABLE " + tn + " MODIFY CONSTRAINT " + q(t.name) + " " + back));
        }
        if (!s.generatedName && !t.generatedName && !s.name.equals(t.name)) {
            changes.add(new Change("CONS_NAME:" + table + ":" + s.signature(), table, t.name, Category.INFO,
                Phase.NONE, "Same " + s.typeName() + " on " + table + ", different name")
                .from(s.name).to(t.name).because("Cosmetic: the constraint does the same thing."));
        }
    }

    private void replaceConstraint(String table, Constraint s, Constraint t) {
        String tn = Sql.qt(owner, table);
        Change c = new Change("CONS_REPLACE:" + table + ":" + s.name, table, s.name, Category.REVIEW,
            s.type.equals("R") ? Phase.FOREIGN_KEY : s.type.equals("C") ? Phase.CHECK : Phase.KEY,
            s.typeName().substring(0, 1).toUpperCase() + s.typeName().substring(1) + " " + s.name + " on " + table + " differs")
            .from(describe(s)).to(describe(t))
            .because("Same name, different definition: replacing it means dropping the current one first.")
            .sql("ALTER TABLE " + tn + " DROP CONSTRAINT " + q(t.name))
            .sql("ALTER TABLE " + tn + " ADD CONSTRAINT " + q(s.name) + " " + constraintBody(s))
            // undo() prepends: give the undo of each forward statement in forward order
            .undo("ALTER TABLE " + tn + " ADD CONSTRAINT " + q(t.name) + " " + constraintBody(t))
            .undo("ALTER TABLE " + tn + " DROP CONSTRAINT " + q(s.name));
        changes.add(c);
    }

    private void targetOnlyConstraint(String table, Constraint k) {
        String tn = Sql.qt(owner, table);
        changes.add(new Change("CONS_DROP:" + table + ":" + k.signature(), table, k.name, Category.REVIEW, Phase.DROP,
            "The " + k.typeName() + " " + k.name + " on " + table + " exists only in the target")
            .from("missing").to(describe(k))
            .because("Never dropped automatically. A target-only constraint is often a deliberate local fix.")
            .sql("ALTER TABLE " + tn + " DROP CONSTRAINT " + q(k.name) + (k.type.matches("[PU]") ? " KEEP INDEX" : ""))
            .undo("ALTER TABLE " + tn + " ADD CONSTRAINT " + q(k.name) + " " + constraintBody(k)));
    }

    private static Constraint find(Table t, Constraint k) {
        String sig = k.signature();
        for (Constraint c : t.constraints) if (c.type.equals(k.type) && c.signature().equals(sig)) return c;
        return null;
    }

    private static Constraint byName(List<Constraint> l, String name) {
        for (Constraint c : l) if (c.name.equals(name)) return c;
        return null;
    }

    private static String constraintBody(Constraint k) {
        return switch (k.type) {
            case "P" -> "PRIMARY KEY (" + Sql.cols(k.columns) + ")";
            case "U" -> "UNIQUE (" + Sql.cols(k.columns) + ")";
            case "C" -> "CHECK (" + k.condition + ")";
            case "R" -> "FOREIGN KEY (" + Sql.cols(k.columns) + ") REFERENCES " + q(k.refTable)
                + " (" + Sql.cols(k.refColumns) + ")" + deleteRule(k);
            default -> throw new IllegalStateException(k.type);
        };
    }

    private static String describe(Constraint k) {
        return switch (k.type) {
            case "P", "U" -> k.typeName() + " (" + String.join(", ", k.columns) + ")";
            case "C" -> "CHECK (" + k.condition + ")";
            default -> String.join(", ", k.columns) + " -> " + k.refTable + "(" + String.join(", ", k.refColumns) + ")";
        } + (k.enabled ? "" : " DISABLED");
    }

    private static String state(Constraint k) {
        return k.enabled ? (k.validated ? "enabled, validated" : "enabled, not validated") : "disabled";
    }

    private static String keyOf(String table, List<String> cols) { return table + "(" + String.join(",", cols) + ")"; }

    /** An index on exactly these columns, preferring a unique one. */
    private static Index indexOn(Table t, List<String> columns) {
        String key = String.join(",", columns);
        Index found = null;
        for (Index i : t.indexes) {
            if (i.columnsKey().equals(key)) {
                if (i.unique) return i;
                if (found == null) found = i;
            }
        }
        return found;
    }

    /** The index exists only to enforce a primary or unique key. */
    private static boolean backsKey(Table t, Index ix) {
        for (Constraint c : t.constraints) {
            if (!c.type.equals("P") && !c.type.equals("U")) continue;
            if (ix.name.equals(c.indexName)) return true;
            if (c.indexName == null && ix.unique && ix.columnsKey().equals(String.join(",", c.columns))) return true;
        }
        return false;
    }

    private String columnChangeFor(String table, String condition) {
        if (condition == null) return null;
        for (Change c : changes)
            if (c.id.startsWith("COL_ADD:" + table + ".") && condition.contains(c.object)) return c.id;
        return null;
    }

    // ================================================================ indexes
    private void indexes(Table s, Table t) {
        Set<String> tMatched = new HashSet<>();
        for (Index ix : s.indexes) {
            Index m = null;
            for (Index ti : t.indexes) if (ti.signature().equals(ix.signature())) { m = ti; break; }
            if (m != null) {
                tMatched.add(m.name);
                if (!ix.generatedName && !m.generatedName && !ix.name.equals(m.name))
                    changes.add(new Change("INDEX_NAME:" + s.name + ":" + ix.signature(), s.name, m.name, Category.INFO,
                        Phase.NONE, "Same index on " + s.name + ", different name").from(ix.name).to(m.name)
                        .because("Cosmetic."));
                continue;
            }
            // created implicitly by a key this run adds?
            boolean implicit = false;
            for (Change c : changes) {
                if ((c.id.startsWith("PK_ADD:" + s.name + ":") || c.id.startsWith("UK_ADD:" + s.name + ":"))
                    && c.id.endsWith(":" + ix.columnsKey()) && c.sql.get(0).indexOf("USING INDEX") < 0) {
                    implicit = true;
                }
            }
            if (implicit) continue;
            Index sameCols = indexOn(t, ix.columns);
            String tn = Sql.qt(owner, s.name);
            if (sameCols != null) {
                tMatched.add(sameCols.name);
                if (backsKey(t, sameCols) || backsKey(s, ix)) continue;   // uniqueness enforced by the key itself
                changes.add(new Change("INDEX_KIND:" + s.name + ":" + ix.columnsKey(), s.name, sameCols.name,
                    Category.REVIEW, Phase.INDEX, "Index on " + s.name + " (" + ix.columnsKey() + ") differs in uniqueness")
                    .from(describe(ix)).to(describe(sameCols))
                    .because("Changing uniqueness means dropping and rebuilding the index.")
                    .sql("DROP INDEX " + Sql.qt(owner, sameCols.name))
                    .sql(createIndex(s.name, sameCols.name, ix))
                    .undo(createIndex(s.name, sameCols.name, sameCols))
                    .undo("DROP INDEX " + Sql.qt(owner, sameCols.name)));
                continue;
            }
            if (backsKey(s, ix)) continue;   // the key's own index; the key comparison covers it
            String name = indexName(s.name, ix);
            boolean clash = t.index(name) != null;
            Change c = new Change("INDEX_ADD:" + s.name + ":" + ix.signature(), s.name, name,
                clash ? Category.REVIEW : Category.AUTO, Phase.INDEX, "Create index " + name + " on " + s.name)
                .from(describe(ix)).to("missing")
                .sql(createIndex(s.name, name, ix)).undo("DROP INDEX " + Sql.qt(owner, name))
                .creates("INDEX", name);
            if (clash) c.because("The target already has a different index called " + name + ".");
            if (ix.unique) {
                String cl = String.join(", ", ix.columns);
                c.pre("Duplicates for unique index " + name + " (must return no rows)",
                    "SELECT " + cl + ", COUNT(*) AS dup_count FROM " + tn + " GROUP BY " + cl + " HAVING COUNT(*) > 1",
                    "no rows");
            }
            changes.add(c);
        }
        for (Index ti : t.indexes) {
            if (tMatched.contains(ti.name) || backsKey(t, ti)) continue;
            changes.add(new Change("INDEX_DROP:" + t.name + ":" + ti.signature(), t.name, ti.name, Category.REVIEW,
                Phase.DROP, "Index " + ti.name + " on " + t.name + " exists only in the target")
                .from("missing").to(describe(ti))
                .because("Never dropped automatically: a target-only index is often a deliberate performance fix.")
                .sql("DROP INDEX " + Sql.qt(owner, ti.name))
                .undo(createIndex(t.name, ti.name, ti)));
        }
    }

    private String createIndex(String table, String name, Index ix) {
        List<String> c = new ArrayList<>();
        for (String col : ix.columns) c.add(Sql.indexCol(col));
        return "CREATE " + (ix.unique ? "UNIQUE " : "") + "INDEX " + Sql.qt(owner, name) + " ON "
            + Sql.qt(owner, table) + " (" + String.join(", ", c) + ")";
    }

    private static String describe(Index ix) {
        return (ix.unique ? "unique " : "") + "index " + ix.name + " (" + String.join(", ", ix.columns) + ")";
    }

    // =============================================================== triggers
    private void triggers(List<String> tables) {
        Set<String> sel = new HashSet<>(tables);
        for (Trigger s : src.triggers.values()) {
            if (!sel.contains(s.table)) continue;
            Trigger t = tgt.triggers.get(s.name);
            if (t != null && t.normalised().equals(s.normalised())) {
                if (s.enabled != t.enabled) {
                    changes.add(new Change("TRG_STATE:" + s.name, s.table, s.name, Category.REVIEW, Phase.TRIGGER,
                        "Trigger " + s.name + " is " + (t.enabled ? "enabled" : "disabled") + " in the target")
                        .from(s.enabled ? "enabled" : "disabled").to(t.enabled ? "enabled" : "disabled")
                        .sql("ALTER TRIGGER " + Sql.qt(owner, s.name) + (s.enabled ? " ENABLE" : " DISABLE"))
                        .undo("ALTER TRIGGER " + Sql.qt(owner, s.name) + (t.enabled ? " ENABLE" : " DISABLE")));
                }
                continue;
            }
            Change c = new Change((t == null ? "TRG_ADD:" : "TRG_CHANGE:") + s.name, s.table, s.name, Category.REVIEW,
                Phase.TRIGGER, (t == null ? "Create trigger " : "Replace trigger ") + s.name + " on " + s.table)
                .from("trigger code (" + lines(s.body) + " lines)").to(t == null ? "missing" : "different code")
                .because("Trigger code is never applied automatically -- read it before approving.")
                .sql(triggerSql(s));
            if (t == null) c.undo("DROP TRIGGER " + Sql.qt(owner, s.name)).creates("TRIGGER", s.name);
            else c.undo(triggerSql(t));
            if (!tgt.tables.containsKey(s.table)) c.needs("TABLE_ADD:" + s.table);
            changes.add(c);
        }
        for (Trigger t : tgt.triggers.values()) {
            if (!sel.contains(t.table) || src.triggers.containsKey(t.name)) continue;
            changes.add(new Change("TRG_DROP:" + t.name, t.table, t.name, Category.REVIEW, Phase.DROP,
                "Trigger " + t.name + " on " + t.table + " exists only in the target")
                .from("missing").to("trigger").because("Never dropped automatically.")
                .sql("DROP TRIGGER " + Sql.qt(owner, t.name)).undo(triggerSql(t)));
        }
    }

    private String triggerSql(Trigger t) {
        String d = t.description == null ? t.name : t.description.trim();
        // re-point owner prefixes at the target schema
        d = d.replaceFirst("^\"?" + java.util.regex.Pattern.quote(src.owner == null ? "" : src.owner) + "\"?\\.", "");
        StringBuilder sb = new StringBuilder("CREATE OR REPLACE TRIGGER ");
        if (!d.toUpperCase().startsWith("\"" + owner + "\".") && !d.toUpperCase().startsWith(owner + "."))
            sb.append(q(owner)).append('.');
        sb.append(d).append('\n');
        if (t.whenClause != null && !t.whenClause.isBlank()) sb.append("WHEN (").append(t.whenClause.trim()).append(")\n");
        sb.append(t.body == null ? "" : t.body.trim());
        return sb.toString();
    }

    private static int lines(String s) { return s == null ? 0 : s.split("\n").length; }

    // ============================================================== sequences
    private void sequences() {
        for (Sequence s : src.sequences.values()) {
            if (!Sql.like(s.name, req.sequencePattern)) continue;
            Sequence t = tgt.sequences.get(s.name);
            String qn = Sql.qt(owner, s.name);
            if (t == null) {
                java.math.BigDecimal start = s.incrementBy.signum() < 0 ? s.maxValue : s.minValue.max(java.math.BigDecimal.ONE);
                changes.add(new Change("SEQ_ADD:" + s.name, null, s.name, Category.AUTO, Phase.SEQUENCE,
                    "Create sequence " + s.name)
                    .from(s.settings()).to("missing")
                    .because("Starts at " + start.toPlainString() + ", not at the source's position ("
                        + s.lastNumber.toPlainString() + "): the source's counter reflects the source's data. "
                        + "If a data script inserts IDs this sequence would generate, raise START WITH above them.")
                    .sql("CREATE SEQUENCE " + qn + " " + s.settings() + " START WITH " + start.toPlainString())
                    .undo("DROP SEQUENCE " + qn)
                    .creates("SEQUENCE", s.name));
            } else if (!s.settings().equals(t.settings())) {
                changes.add(new Change("SEQ_SETTINGS:" + s.name, null, s.name, Category.REVIEW, Phase.SEQUENCE,
                    "Settings of sequence " + s.name + " differ")
                    .from(s.settings()).to(t.settings())
                    .because("The current position is never changed; settings usually differ for a reason "
                        + "(cache sizing, history). Approve only if the source's settings are wanted.")
                    .sql("ALTER SEQUENCE " + qn + " " + s.settings())
                    .undo("ALTER SEQUENCE " + qn + " " + t.settings()));
            }
        }
        for (Sequence t : tgt.sequences.values()) {
            if (!Sql.like(t.name, req.sequencePattern) || src.sequences.containsKey(t.name)) continue;
            changes.add(new Change("SEQ_TARGET_ONLY:" + t.name, null, t.name, Category.INFO, Phase.NONE,
                "Sequence " + t.name + " exists only in the target").because("Never dropped."));
        }
    }

    // =============================================================== naming
    private String constraintName(String table, Constraint k) {
        if (!k.generatedName) { usedNames.add(k.name); return k.name; }
        String suffix = switch (k.type) { case "P" -> "_PK"; case "U" -> "_UK"; case "R" -> "_FK"; default -> "_CK"; };
        return unique(table, suffix);
    }

    private String indexName(String table, Index ix) {
        if (!ix.generatedName) { usedNames.add(ix.name); return ix.name; }
        return unique(table, "_IX");
    }

    private String unique(String table, String suffix) {
        String base = table.length() + suffix.length() > 125 ? table.substring(0, 125 - suffix.length()) : table;
        String n = base + suffix;
        int i = 2;
        while (usedNames.contains(n)) n = base + suffix + i++;
        usedNames.add(n);
        return n;
    }

    // ============================================================= rendering
    private String columnDef(Column c, boolean full) {
        StringBuilder sb = new StringBuilder(full ? q(c.name) + " " : "").append(c.typeSql());
        if (c.identity) {
            sb.append(" GENERATED ").append(c.identityGeneration == null ? "BY DEFAULT" : c.identityGeneration)
              .append(" AS IDENTITY");
        } else if (c.normalisedDefault() != null) {
            sb.append(" DEFAULT ").append(c.defaultValue.trim());
        }
        if (!c.nullable) sb.append(" NOT NULL");
        return sb.toString();
    }

    private static String identityText(Column c) {
        return c.identity ? "identity " + c.identityGeneration : "not identity";
    }

    private static String sequenceIn(String def) {
        if (def == null) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern
            .compile("(?:\"?[A-Z0-9_$#]+\"?\\.)?\"?([A-Z0-9_$#]+)\"?\\.NEXTVAL").matcher(def);
        return m.find() ? m.group(1) : null;
    }

    public static Map<Phase, List<Change>> byPhase(List<Change> changes) {
        Map<Phase, List<Change>> m = new LinkedHashMap<>();
        for (Phase p : Phase.values()) m.put(p, new ArrayList<>());
        for (Change c : changes) m.get(c.phase).add(c);
        return m;
    }
}
