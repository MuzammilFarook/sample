package dbpromote.core;

import dbpromote.core.Change.Category;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** The Markdown report that goes into the output zip alongside the scripts. */
final class Report {

    private static final int LIST_LIMIT = 300;

    private final Comparison c;
    private final Decisions d;
    private final DdlScript ddl;
    private final Map<String, DataScript> scripts;
    private final DdlScript.Header h;

    Report(Comparison c, Decisions d, DdlScript ddl, Map<String, DataScript> scripts, DdlScript.Header h) {
        this.c = c; this.d = d; this.ddl = ddl; this.scripts = scripts; this.h = h;
    }

    String render() {
        StringBuilder sb = new StringBuilder();
        sb.append("# ").append(h.source()).append(" → ").append(h.target()).append(" comparison\n\n");
        sb.append("**Source of truth:** ").append(h.source()).append(" (schema ").append(c.request.sourceSchema).append(")  \n");
        sb.append("**Target:** ").append(h.target()).append(" (schema ").append(c.request.targetSchema).append(")  \n");
        sb.append("**Generated:** ").append(h.generatedAt()).append(h.generatedBy() == null ? "" : " for " + h.generatedBy()).append("  \n");
        sb.append("**Read:** source ").append(nz(c.source.capturedAt)).append(", target ").append(nz(c.target.capturedAt)).append("\n\n");

        // ---- summary
        int applied = ddl.appliedChanges().size();
        int ins = 0, upd = 0, del = 0;
        for (DataScript s : scripts.values()) { ins += s.inserts.size(); upd += s.updates.size(); del += s.deletes.size(); }
        sb.append("## Summary\n\n| | Count |\n|---|---|\n");
        sb.append("| Tables compared | ").append(c.request.tables.size()).append(" |\n");
        sb.append("| Structural changes applied | ").append(applied).append(" |\n");
        sb.append("| Structural changes needing review | ").append(c.count(Category.REVIEW)).append(" |\n");
        sb.append("| Cosmetic / report-only | ").append(c.count(Category.INFO)).append(" |\n");
        sb.append("| Rows inserted | ").append(ins).append(" |\n");
        sb.append("| Values updated | ").append(upd).append(" |\n");
        sb.append("| Rows deleted | ").append(del).append(" |\n\n");

        List<String> broken = c.brokenDependencies(d);
        if (!broken.isEmpty() || !c.warnings.isEmpty()) {
            sb.append("## Read before running\n\n");
            for (String b : broken) sb.append("- **Dependency:** ").append(b).append('\n');
            for (String w : c.warnings) sb.append("- ").append(w).append('\n');
            sb.append('\n');
        }

        // ---- run order
        sb.append("## Run order\n\n");
        int step = 1;
        if (applied > 0) sb.append(step++).append(". `01_ddl.sql` — structure. Each statement commits on its own.\n");
        int n = 0;
        for (Map.Entry<String, DataScript> e : scripts.entrySet()) {
            if (e.getValue().isEmpty()) continue;
            n++;
            sb.append(step++).append(". `").append(String.format("02_data_%02d_%s.sql", n, e.getKey()))
              .append("` — manual commit; commit only if its verification passes.\n");
        }
        if (step == 1) sb.append("Nothing to run: the selection already matches.\n");
        sb.append("\nRollbacks run in reverse order: data scripts newest first, then the DDL rollback.\n\n");

        // ---- structure
        Map<String, List<Change>> byTable = new LinkedHashMap<>();
        for (Change ch : c.changes) byTable.computeIfAbsent(ch.table == null ? "(sequences)" : ch.table, k -> new ArrayList<>()).add(ch);
        sb.append("## Structure\n\n");
        if (byTable.isEmpty()) sb.append("The selected tables match.\n\n");
        for (Map.Entry<String, List<Change>> e : byTable.entrySet()) {
            sb.append("### ").append(e.getKey()).append("\n\n");
            sb.append("| Outcome | Change | Source | Target | Note |\n|---|---|---|---|---|\n");
            for (Change ch : e.getValue()) {
                sb.append("| ").append(outcome(ch)).append(" | ").append(cell(ch.title)).append(" | ")
                  .append(cell(ch.source)).append(" | ").append(cell(ch.target)).append(" | ")
                  .append(cell(note(ch))).append(" |\n");
            }
            sb.append('\n');
        }

        // ---- data
        if (!c.data.isEmpty()) {
            sb.append("## Data\n\n");
            sb.append("| Table | Key | Source rows | Target rows | Insert | Update | Delete | Left out |\n");
            sb.append("|---|---|---|---|---|---|---|---|\n");
            for (DataPlan p : c.data.values()) {
                DataScript s = scripts.get(p.table);
                if (p.blocked != null) {
                    sb.append("| ").append(p.table).append(" | — | — | — | — | — | — | not compared |\n");
                    continue;
                }
                sb.append("| ").append(p.table).append(" | ").append(String.join(", ", p.key)).append(" | ")
                  .append(p.sourceRows).append(" | ").append(p.targetRows).append(" | ").append(s.inserts.size())
                  .append(" | ").append(s.updates.size()).append(" | ").append(s.deletes.size()).append(" | ")
                  .append(s.skipped.size()).append(" |\n");
            }
            sb.append('\n');
            for (DataPlan p : c.data.values()) {
                DataScript s = scripts.get(p.table);
                sb.append("### ").append(p.table).append("\n\n");
                if (p.blocked != null) { sb.append("**Not compared:** ").append(p.blocked).append("\n\n"); continue; }
                if (!p.hasDifferences()) { sb.append("Identical in both environments.\n\n"); }
                for (String note : p.notes) sb.append("- ").append(note).append('\n');
                if (!p.ignored.isEmpty()) sb.append("- Ignored columns: ").append(String.join(", ", p.ignored)).append('\n');
                if (!p.notes.isEmpty() || !p.ignored.isEmpty()) sb.append('\n');
                if (!s.updates.isEmpty()) {
                    sb.append("**Updates**\n\n| Key | Column | Target now | Becomes |\n|---|---|---|---|\n");
                    int i = 0;
                    for (DataPlan.Update u : s.updates) {
                        if (i++ == LIST_LIMIT) { sb.append("| … ").append(s.updates.size() - LIST_LIMIT).append(" more | | | |\n"); break; }
                        sb.append("| ").append(cell(u.keyText())).append(" | ").append(u.column()).append(" | ")
                          .append(val(u.oldValue())).append(" | ").append(val(u.newValue()))
                          .append(u.whitespaceOnly() ? " *(spacing only)*" : "").append(" |\n");
                    }
                    sb.append('\n');
                }
                if (!s.inserts.isEmpty()) {
                    sb.append("**Inserts** (").append(s.inserts.size()).append("): ");
                    List<String> keys = new ArrayList<>();
                    for (DataPlan.Insert in : s.inserts) { if (keys.size() == 100) break; keys.add("`" + in.keyText() + "`"); }
                    sb.append(String.join(", ", keys));
                    if (s.inserts.size() > 100) sb.append(", … ").append(s.inserts.size() - 100).append(" more");
                    sb.append("\n\n");
                }
                if (!s.deletes.isEmpty()) {
                    sb.append("**Deletes** (").append(s.deletes.size()).append("): ");
                    List<String> keys = new ArrayList<>();
                    for (DataPlan.Delete x : s.deletes) keys.add("`" + x.keyText() + "`");
                    sb.append(String.join(", ", keys)).append("\n\n");
                }
                if (!s.skipped.isEmpty()) {
                    sb.append("**Left out** (").append(s.skipped.size()).append(")\n\n");
                    int i = 0;
                    for (String x : s.skipped) {
                        if (i++ == LIST_LIMIT) { sb.append("- … ").append(s.skipped.size() - LIST_LIMIT).append(" more\n"); break; }
                        sb.append("- ").append(x).append('\n');
                    }
                    sb.append('\n');
                }
            }
        }
        return sb.toString();
    }

    private String outcome(Change ch) {
        if (ch.category == Category.INFO) return "info";
        boolean a = ch.scriptable() && d.applies(ch.id, ch.appliedByDefault());
        if (a) return ch.category == Category.REVIEW ? "**applied (approved)**" : "applied";
        return ch.category == Category.REVIEW ? "*needs review — left out*" : "*skipped*";
    }

    private String note(Change ch) {
        Decisions.Decision dec = d.get(ch.id);
        if (dec != null && dec.reason() != null && !dec.reason().isBlank()) return "Decision: " + dec.reason();
        return ch.reason;
    }

    private static String nz(String s) { return s == null ? "unknown" : s; }

    private static String cell(String s) {
        if (s == null) return "";
        return s.replace("|", "\\|").replaceAll("\\s+", " ").trim();
    }

    private static String val(Object v) {
        if (v == null) return "NULL";
        String s = v.toString();
        if (s.length() > 80) s = s.substring(0, 77) + "…";
        return "`" + s.replace("|", "\\|").replace("`", "'") + "`";
    }
}
