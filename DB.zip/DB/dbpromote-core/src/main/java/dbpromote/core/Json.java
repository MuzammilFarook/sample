package dbpromote.core;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal JSON reader/writer, so the core has no third-party dependencies.
 * Objects become LinkedHashMap (key order kept), arrays ArrayList, numbers
 * BigDecimal (exact, never double), plus String, Boolean and null.
 */
public final class Json {
    private Json() {}

    // ------------------------------------------------------------------ write
    public static String write(Object v) {
        StringBuilder sb = new StringBuilder();
        write(sb, v, 0);
        return sb.append('\n').toString();
    }

    private static void write(StringBuilder sb, Object v, int ind) {
        if (v == null) sb.append("null");
        else if (v instanceof String s) str(sb, s);
        else if (v instanceof Boolean || v instanceof Integer || v instanceof Long) sb.append(v);
        else if (v instanceof BigDecimal b) sb.append(b.toPlainString());
        else if (v instanceof Number n) sb.append(new BigDecimal(n.toString()).toPlainString());
        else if (v instanceof Map<?, ?> m) {
            if (m.isEmpty()) { sb.append("{}"); return; }
            sb.append("{\n");
            int i = 0;
            for (Map.Entry<?, ?> e : m.entrySet()) {
                pad(sb, ind + 1); str(sb, String.valueOf(e.getKey())); sb.append(": ");
                write(sb, e.getValue(), ind + 1);
                if (++i < m.size()) sb.append(',');
                sb.append('\n');
            }
            pad(sb, ind); sb.append('}');
        } else if (v instanceof List<?> l) {
            if (l.isEmpty()) { sb.append("[]"); return; }
            boolean flat = l.stream().noneMatch(x -> x instanceof Map || x instanceof List);
            if (flat) {
                sb.append('[');
                for (int i = 0; i < l.size(); i++) { if (i > 0) sb.append(", "); write(sb, l.get(i), ind); }
                sb.append(']');
                return;
            }
            sb.append("[\n");
            for (int i = 0; i < l.size(); i++) {
                pad(sb, ind + 1); write(sb, l.get(i), ind + 1);
                if (i < l.size() - 1) sb.append(',');
                sb.append('\n');
            }
            pad(sb, ind); sb.append(']');
        } else str(sb, v.toString());
    }

    private static void pad(StringBuilder sb, int n) { sb.append("  ".repeat(n)); }

    private static void str(StringBuilder sb, String s) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20 || c > 0x7e) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
                }
            }
        }
        sb.append('"');
    }

    // ------------------------------------------------------------------- read
    public static Object parse(String s) {
        Parser p = new Parser(s);
        p.ws();
        Object v = p.value();
        p.ws();
        if (p.i < s.length()) throw p.err("trailing content");
        return v;
    }

    private static final class Parser {
        final String s; int i;
        Parser(String s) { this.s = s; }

        RuntimeException err(String m) {
            int line = 1;
            for (int k = 0; k < Math.min(i, s.length()); k++) if (s.charAt(k) == '\n') line++;
            return new IllegalArgumentException("JSON error at line " + line + ": " + m);
        }
        void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
        char peek() { if (i >= s.length()) throw err("unexpected end"); return s.charAt(i); }
        void expect(char c) { if (peek() != c) throw err("expected '" + c + "'"); i++; }

        Object value() {
            char c = peek();
            if (c == '{') return obj();
            if (c == '[') return arr();
            if (c == '"') return string();
            if (s.startsWith("null", i)) { i += 4; return null; }
            if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
            if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
            return num();
        }
        Map<String, Object> obj() {
            expect('{'); ws();
            Map<String, Object> m = new LinkedHashMap<>();
            if (peek() == '}') { i++; return m; }
            while (true) {
                ws(); String k = string(); ws(); expect(':'); ws();
                m.put(k, value()); ws();
                if (peek() == ',') { i++; continue; }
                expect('}'); return m;
            }
        }
        List<Object> arr() {
            expect('['); ws();
            List<Object> l = new ArrayList<>();
            if (peek() == ']') { i++; return l; }
            while (true) {
                ws(); l.add(value()); ws();
                if (peek() == ',') { i++; continue; }
                expect(']'); return l;
            }
        }
        String string() {
            expect('"');
            StringBuilder sb = new StringBuilder();
            while (true) {
                if (i >= s.length()) throw err("unterminated string");
                char c = s.charAt(i++);
                if (c == '"') return sb.toString();
                if (c != '\\') { sb.append(c); continue; }
                char e = s.charAt(i++);
                switch (e) {
                    case 'n' -> sb.append('\n'); case 'r' -> sb.append('\r'); case 't' -> sb.append('\t');
                    case 'b' -> sb.append('\b'); case 'f' -> sb.append('\f');
                    case 'u' -> { sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; }
                    default -> sb.append(e);   // \" \\ \/
                }
            }
        }
        BigDecimal num() {
            int st = i;
            while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
            if (st == i) throw err("unexpected character '" + s.charAt(i) + "'");
            return new BigDecimal(s.substring(st, i));
        }
    }

    // ------------------------------------------------------------- accessors
    @SuppressWarnings("unchecked")
    public static Map<String, Object> obj(Object o) { return o == null ? new LinkedHashMap<>() : (Map<String, Object>) o; }
    @SuppressWarnings("unchecked")
    public static List<Object> arr(Object o) { return o == null ? new ArrayList<>() : (List<Object>) o; }
    public static String str(Object o) { return o == null ? null : o.toString(); }
    public static Integer integer(Object o) { return o == null ? null : ((BigDecimal) o).intValueExact(); }
    public static boolean bool(Object o) { return o != null && (Boolean) o; }
    public static BigDecimal dec(Object o) { return o == null ? null : (BigDecimal) o; }
}
