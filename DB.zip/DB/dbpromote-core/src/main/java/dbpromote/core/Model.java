package dbpromote.core;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/**
 * Normalised picture of one schema: structure plus the rows of the tables
 * whose data was read. The Oracle reader produces it and snapshot files hold
 * it, so a live read and a file are interchangeable.
 */
public final class Model {
    private Model() {}

    public static final String FORMAT = "dbpromote-snapshot/1";

    // ================================================================== Schema
    public static final class Schema {
        public String owner;
        public String database;
        public String capturedAt;
        public final Map<String, Table> tables = new TreeMap<>();
        public final Map<String, Sequence> sequences = new TreeMap<>();
        public final Map<String, Trigger> triggers = new TreeMap<>();
        public final Map<String, TableData> data = new TreeMap<>();

        public Map<String, Object> toJson() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("format", FORMAT);
            m.put("owner", owner);
            m.put("database", database);
            m.put("capturedAt", capturedAt);
            Map<String, Object> t = new LinkedHashMap<>();
            tables.forEach((k, v) -> t.put(k, v.toJson()));
            m.put("tables", t);
            Map<String, Object> s = new LinkedHashMap<>();
            sequences.forEach((k, v) -> s.put(k, v.toJson()));
            m.put("sequences", s);
            Map<String, Object> g = new LinkedHashMap<>();
            triggers.forEach((k, v) -> g.put(k, v.toJson()));
            m.put("triggers", g);
            Map<String, Object> d = new LinkedHashMap<>();
            data.forEach((k, v) -> d.put(k, v.toJson()));
            m.put("data", d);
            return m;
        }

        public static Schema fromJson(Map<String, Object> m) {
            if (!FORMAT.equals(m.get("format")))
                throw new IllegalArgumentException("Not a dbpromote snapshot (missing \"format\": \"" + FORMAT + "\")");
            Schema s = new Schema();
            s.owner = Json.str(m.get("owner"));
            s.database = Json.str(m.get("database"));
            s.capturedAt = Json.str(m.get("capturedAt"));
            Json.obj(m.get("tables")).forEach((k, v) -> { Table t = Table.fromJson(Json.obj(v)); t.name = k; s.tables.put(k, t); });
            Json.obj(m.get("sequences")).forEach((k, v) -> { Sequence q = Sequence.fromJson(Json.obj(v)); q.name = k; s.sequences.put(k, q); });
            Json.obj(m.get("triggers")).forEach((k, v) -> { Trigger t = Trigger.fromJson(Json.obj(v)); t.name = k; s.triggers.put(k, t); });
            Json.obj(m.get("data")).forEach((k, v) -> { TableData d = TableData.fromJson(Json.obj(v)); d.table = k; s.data.put(k, d); });
            return s;
        }
    }

    // =================================================================== Table
    public static final class Table {
        public String name;
        public final List<Column> columns = new ArrayList<>();
        public final List<Constraint> constraints = new ArrayList<>();
        public final List<Index> indexes = new ArrayList<>();
        public Long rowCount;            // optional: 0 = empty, >0 = has rows, null = unknown
        /** Only keys and foreign keys were read (the table is outside the selection). */
        public boolean stub;

        public Column column(String n) {
            for (Column c : columns) if (c.name.equals(n)) return c;
            return null;
        }

        public Constraint primaryKey() {
            for (Constraint c : constraints) if (c.type.equals("P")) return c;
            return null;
        }

        public Index index(String n) {
            for (Index i : indexes) if (i.name.equals(n)) return i;
            return null;
        }

        public Map<String, Object> toJson() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("columns", columns.stream().map(Column::toJson).toList());
            m.put("constraints", constraints.stream().map(Constraint::toJson).toList());
            m.put("indexes", indexes.stream().map(Index::toJson).toList());
            if (rowCount != null) m.put("rowCount", rowCount);
            if (stub) m.put("stub", true);
            return m;
        }

        public static Table fromJson(Map<String, Object> m) {
            Table t = new Table();
            for (Object o : Json.arr(m.get("columns"))) t.columns.add(Column.fromJson(Json.obj(o)));
            for (Object o : Json.arr(m.get("constraints"))) t.constraints.add(Constraint.fromJson(Json.obj(o)));
            for (Object o : Json.arr(m.get("indexes"))) t.indexes.add(Index.fromJson(Json.obj(o)));
            BigDecimal rc = Json.dec(m.get("rowCount"));
            t.rowCount = rc == null ? null : rc.longValue();
            t.stub = Json.bool(m.get("stub"));
            return t;
        }
    }

    // ================================================================== Column
    public static final class Column {
        public String name;
        public String dataType;          // as ALL_TAB_COLUMNS: VARCHAR2, NUMBER, DATE, TIMESTAMP(6), CLOB ...
        public Integer length;           // characters for character types (bytes if charUsed=B), bytes for RAW
        public String charUsed;          // B or C, character types only
        public Integer precision;
        public Integer scale;
        public boolean nullable = true;
        public String defaultValue;      // trimmed DATA_DEFAULT; null when there is none
        public boolean identity;
        public String identityGeneration; // ALWAYS / BY DEFAULT / BY DEFAULT ON NULL
        public String identityOptions;

        public boolean isChar() {
            return dataType.equals("VARCHAR2") || dataType.equals("NVARCHAR2")
                || dataType.equals("CHAR") || dataType.equals("NCHAR");
        }
        public boolean isNumber() {
            return dataType.equals("NUMBER") || dataType.equals("FLOAT") || dataType.equals("INTEGER")
                || dataType.equals("BINARY_FLOAT") || dataType.equals("BINARY_DOUBLE");
        }
        public boolean isDate() { return dataType.equals("DATE"); }
        public boolean isTimestamp() { return dataType.startsWith("TIMESTAMP"); }
        public boolean isClob() { return dataType.equals("CLOB") || dataType.equals("NCLOB"); }
        /** Types the data comparison cannot handle; such columns are left out of it. */
        public boolean isUnsupportedForData() {
            return !(isChar() || isNumber() || isDate() || isTimestamp() || isClob());
        }

        /** Sequence- or identity-fed: the target must allocate its own values. */
        public boolean isGenerated() {
            return identity || (normalisedDefault() != null && normalisedDefault().contains("NEXTVAL"));
        }

        /** Default with Oracle's quirks removed: 'NULL' and blanks mean no default. */
        public String normalisedDefault() {
            if (defaultValue == null) return null;
            String d = defaultValue.trim();
            if (d.isEmpty() || d.equalsIgnoreCase("NULL")) return null;
            return d.toUpperCase(Locale.ROOT).startsWith("'") ? d : d.toUpperCase(Locale.ROOT).replaceAll("\\s+", " ");
        }

        /** The type exactly as it would be written in DDL. */
        public String typeSql() {
            switch (dataType) {
                case "VARCHAR2", "CHAR" -> {
                    return dataType + "(" + length + ("C".equals(charUsed) ? " CHAR" : "") + ")";
                }
                case "NVARCHAR2", "NCHAR", "RAW" -> { return dataType + "(" + length + ")"; }
                case "NUMBER" -> {
                    if (precision == null && scale == null) return "NUMBER";
                    if (precision == null) return "NUMBER(*," + scale + ")";
                    return scale == null || scale == 0 ? "NUMBER(" + precision + ")" : "NUMBER(" + precision + "," + scale + ")";
                }
                case "FLOAT" -> { return precision == null ? "FLOAT" : "FLOAT(" + precision + ")"; }
                default -> { return dataType; }
            }
        }

        public Map<String, Object> toJson() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("name", name);
            m.put("dataType", dataType);
            m.put("length", length);
            m.put("charUsed", charUsed);
            m.put("precision", precision);
            m.put("scale", scale);
            m.put("nullable", nullable);
            m.put("default", defaultValue);
            if (identity) {
                m.put("identity", true);
                m.put("identityGeneration", identityGeneration);
                m.put("identityOptions", identityOptions);
            }
            return m;
        }

        public static Column fromJson(Map<String, Object> m) {
            Column c = new Column();
            c.name = Json.str(m.get("name"));
            c.dataType = Json.str(m.get("dataType"));
            c.length = Json.integer(m.get("length"));
            c.charUsed = Json.str(m.get("charUsed"));
            c.precision = Json.integer(m.get("precision"));
            c.scale = Json.integer(m.get("scale"));
            c.nullable = Json.bool(m.get("nullable"));
            c.defaultValue = Json.str(m.get("default"));
            c.identity = Json.bool(m.get("identity"));
            c.identityGeneration = Json.str(m.get("identityGeneration"));
            c.identityOptions = Json.str(m.get("identityOptions"));
            return c;
        }
    }

    // ============================================================== Constraint
    public static final class Constraint {
        public String name;
        public String type;              // P, U, R, C
        public final List<String> columns = new ArrayList<>();
        public String refTable;          // R only
        public final List<String> refColumns = new ArrayList<>();
        public String deleteRule = "NO ACTION";
        public String condition;         // C only
        public String indexName;         // P/U: the index enforcing it
        public boolean generatedName;    // SYS_C... assigned by Oracle
        public boolean enabled = true;
        public boolean validated = true;

        public String typeName() {
            return switch (type) {
                case "P" -> "primary key"; case "U" -> "unique key"; case "R" -> "foreign key";
                case "C" -> "check constraint"; default -> type;
            };
        }

        /** What the constraint enforces, independent of its name. */
        public String signature() {
            return switch (type) {
                case "P", "U" -> type + "(" + String.join(",", columns) + ")";
                case "R" -> "R(" + String.join(",", columns) + ")->" + refTable + "(" + String.join(",", refColumns) + ")";
                case "C" -> "C(" + normaliseCondition(condition) + ")";
                default -> type + name;
            };
        }

        /** Oracle's own NOT NULL checks: carried by Column.nullable instead. */
        public boolean isNotNullCheck() {
            return type.equals("C") && condition != null
                && condition.trim().matches("(?i)\"?[A-Z0-9_$#]+\"?\\s+IS\\s+NOT\\s+NULL");
        }

        public static String normaliseCondition(String c) {
            if (c == null) return "";
            StringBuilder sb = new StringBuilder();
            boolean q = false;
            for (char ch : c.trim().toCharArray()) {
                if (ch == '\'') q = !q;
                if (!q && ch == '"') continue;
                if (!q && Character.isWhitespace(ch)) continue;
                sb.append(q ? ch : Character.toUpperCase(ch));
            }
            return sb.toString();
        }

        public Map<String, Object> toJson() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("name", name);
            m.put("type", type);
            m.put("columns", new ArrayList<Object>(columns));
            if (type.equals("R")) {
                m.put("refTable", refTable);
                m.put("refColumns", new ArrayList<Object>(refColumns));
                m.put("deleteRule", deleteRule);
            }
            if (type.equals("C")) m.put("condition", condition);
            if (indexName != null) m.put("index", indexName);
            m.put("generatedName", generatedName);
            m.put("enabled", enabled);
            m.put("validated", validated);
            return m;
        }

        public static Constraint fromJson(Map<String, Object> m) {
            Constraint c = new Constraint();
            c.name = Json.str(m.get("name"));
            c.type = Json.str(m.get("type"));
            for (Object o : Json.arr(m.get("columns"))) c.columns.add(Json.str(o));
            c.refTable = Json.str(m.get("refTable"));
            for (Object o : Json.arr(m.get("refColumns"))) c.refColumns.add(Json.str(o));
            if (m.get("deleteRule") != null) c.deleteRule = Json.str(m.get("deleteRule"));
            c.condition = Json.str(m.get("condition"));
            c.indexName = Json.str(m.get("index"));
            c.generatedName = Json.bool(m.get("generatedName"));
            c.enabled = !Boolean.FALSE.equals(m.get("enabled"));
            c.validated = !Boolean.FALSE.equals(m.get("validated"));
            return c;
        }
    }

    // =================================================================== Index
    public static final class Index {
        public String name;
        public boolean unique;
        public final List<String> columns = new ArrayList<>();   // "COL", "COL DESC" or an expression
        public boolean generatedName;

        public String signature() {
            List<String> c = new ArrayList<>();
            for (String s : columns) c.add(Constraint.normaliseCondition(s));
            return (unique ? "UNIQUE" : "INDEX") + "(" + String.join(",", c) + ")";
        }
        public String columnsKey() {
            List<String> c = new ArrayList<>();
            for (String s : columns) c.add(Constraint.normaliseCondition(s));
            return String.join(",", c);
        }

        public Map<String, Object> toJson() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("name", name);
            m.put("unique", unique);
            m.put("columns", new ArrayList<Object>(columns));
            m.put("generatedName", generatedName);
            return m;
        }

        public static Index fromJson(Map<String, Object> m) {
            Index i = new Index();
            i.name = Json.str(m.get("name"));
            i.unique = Json.bool(m.get("unique"));
            for (Object o : Json.arr(m.get("columns"))) i.columns.add(Json.str(o));
            i.generatedName = Json.bool(m.get("generatedName"));
            return i;
        }
    }

    // ================================================================ Sequence
    public static final class Sequence {
        public String name;
        public BigDecimal minValue, maxValue, incrementBy, lastNumber;
        public int cacheSize;
        public boolean cycle, order;

        /** Settings that should match; the current position never does. */
        public String settings() {
            return "INCREMENT BY " + incrementBy.toPlainString() + " MINVALUE " + minValue.toPlainString()
                + " MAXVALUE " + maxValue.toPlainString()
                + (cacheSize == 0 ? " NOCACHE" : " CACHE " + cacheSize)
                + (cycle ? " CYCLE" : " NOCYCLE") + (order ? " ORDER" : " NOORDER");
        }

        public Map<String, Object> toJson() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("name", name);
            m.put("minValue", minValue);
            m.put("maxValue", maxValue);
            m.put("incrementBy", incrementBy);
            m.put("cacheSize", cacheSize);
            m.put("cycle", cycle);
            m.put("order", order);
            m.put("lastNumber", lastNumber);
            return m;
        }

        public static Sequence fromJson(Map<String, Object> m) {
            Sequence s = new Sequence();
            s.name = Json.str(m.get("name"));
            s.minValue = Json.dec(m.get("minValue"));
            s.maxValue = Json.dec(m.get("maxValue"));
            s.incrementBy = Json.dec(m.get("incrementBy"));
            s.cacheSize = Json.integer(m.get("cacheSize"));
            s.cycle = Json.bool(m.get("cycle"));
            s.order = Json.bool(m.get("order"));
            s.lastNumber = Json.dec(m.get("lastNumber"));
            return s;
        }
    }

    // ================================================================= Trigger
    public static final class Trigger {
        public String name;
        public String table;
        public String description;       // ALL_TRIGGERS.DESCRIPTION: name, timing, event, table
        public String whenClause;
        public String body;
        public boolean enabled = true;

        /** Text used to decide whether two triggers are the same: case and spacing ignored. */
        public String normalised() {
            String d = description == null ? "" : description;
            int on = d.toUpperCase(Locale.ROOT).indexOf(name == null ? "\u0000" : name);
            if (on >= 0) d = d.substring(on + name.length());
            return (d + " WHEN " + (whenClause == null ? "" : whenClause) + " " + (body == null ? "" : body))
                .replace("\"", "").replaceAll("\\s+", " ").trim().toUpperCase(Locale.ROOT);
        }

        public Map<String, Object> toJson() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("name", name);
            m.put("table", table);
            m.put("description", description);
            m.put("when", whenClause);
            m.put("body", body);
            m.put("enabled", enabled);
            return m;
        }

        public static Trigger fromJson(Map<String, Object> m) {
            Trigger t = new Trigger();
            t.name = Json.str(m.get("name"));
            t.table = Json.str(m.get("table"));
            t.description = Json.str(m.get("description"));
            t.whenClause = Json.str(m.get("when"));
            t.body = Json.str(m.get("body"));
            t.enabled = !Boolean.FALSE.equals(m.get("enabled"));
            return t;
        }
    }

    // =============================================================== TableData
    /**
     * Rows of one table. Values are String, BigDecimal or null. DATE and
     * TIMESTAMP values are strings "YYYY-MM-DD HH24:MI:SS" and
     * "YYYY-MM-DD HH24:MI:SS.FFFFFFFFF"; CLOBs are plain strings.
     */
    public static final class TableData {
        public String table;
        public String filter;            // WHERE clause the rows were read with, if any
        public final List<String> columns = new ArrayList<>();
        public final List<Map<String, Object>> rows = new ArrayList<>();

        public Map<String, Object> toJson() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("table", table);
            if (filter != null) m.put("filter", filter);
            m.put("columns", new ArrayList<Object>(columns));
            List<Object> r = new ArrayList<>();
            for (Map<String, Object> row : rows) {
                List<Object> vals = new ArrayList<>();
                for (String c : columns) vals.add(row.get(c));
                r.add(vals);
            }
            m.put("rows", r);
            return m;
        }

        public static TableData fromJson(Map<String, Object> m) {
            TableData d = new TableData();
            d.table = Json.str(m.get("table"));
            d.filter = Json.str(m.get("filter"));
            for (Object o : Json.arr(m.get("columns"))) d.columns.add(Json.str(o));
            for (Object o : Json.arr(m.get("rows"))) {
                List<Object> vals = Json.arr(o);
                Map<String, Object> row = new LinkedHashMap<>();
                for (int i = 0; i < d.columns.size(); i++) row.put(d.columns.get(i), vals.get(i));
                d.rows.add(row);
            }
            return d;
        }
    }
}
