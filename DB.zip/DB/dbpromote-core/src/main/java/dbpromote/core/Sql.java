package dbpromote.core;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.Function;

/**
 * Oracle SQL text helpers. Every script the tool writes is plain ASCII:
 * other characters go through UNISTR, so DBeaver's or SQL*Plus's client
 * encoding can never mangle them.
 */
public final class Sql {
    private Sql() {}

    /** Oracle allows at most 1000 expressions in an IN list (ORA-01795). */
    public static final int IN_CHUNK = 500;

    public static String q(String identifier) { return "\"" + identifier.replace("\"", "\"\"") + "\""; }

    public static String qt(String schema, String object) { return q(schema) + "." + q(object); }

    public static String cols(List<String> columns) {
        List<String> out = new ArrayList<>();
        for (String c : columns) out.add(isExpression(c) ? c : q(c));
        return String.join(", ", out);
    }

    /** Index "columns" can be expressions or carry DESC; plain names get quoted. */
    public static boolean isExpression(String c) { return !c.matches("[A-Z][A-Z0-9_$#]*"); }

    public static String indexCol(String c) {
        if (c.matches("[A-Z][A-Z0-9_$#]* (ASC|DESC)")) {
            String[] p = c.split(" ");
            return q(p[0]) + " " + p[1];
        }
        return isExpression(c) ? c : q(c);
    }

    // ------------------------------------------------------------- literals
    /** A string literal, ASCII only, with UNISTR for anything else. */
    public static String str(String s) {
        if (s == null) return "NULL";
        if (s.isEmpty()) return "NULL";   // Oracle treats '' as NULL
        List<String> parts = new ArrayList<>();
        StringBuilder plain = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            String special = null;
            if (c == '\n') special = "CHR(10)";
            else if (c == '\r') special = "CHR(13)";
            else if (c == '\t') special = "CHR(9)";
            else if (c < 0x20 || c > 0x7e) special = "UNISTR('\\" + String.format("%04X", (int) c) + "')";
            if (special == null) {
                plain.append(c == '\'' ? "''" : String.valueOf(c));
            } else {
                if (plain.length() > 0) { parts.add("'" + plain + "'"); plain.setLength(0); }
                parts.add(special);
            }
        }
        if (plain.length() > 0) parts.add("'" + plain + "'");
        // merge adjacent UNISTR pieces to keep literals short
        List<String> merged = new ArrayList<>();
        for (String p : parts) {
            int last = merged.size() - 1;
            if (last >= 0 && p.startsWith("UNISTR('") && merged.get(last).startsWith("UNISTR('")) {
                String prev = merged.get(last);
                merged.set(last, prev.substring(0, prev.length() - 2) + p.substring(8, p.length() - 2) + "')");
            } else merged.add(p);
        }
        return String.join(" || ", merged);
    }

    public static boolean isAscii(String s) {
        if (s == null) return true;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c > 0x7e || (c < 0x20 && c != '\n' && c != '\r' && c != '\t')) return false;
        }
        return true;
    }

    /** A literal for a value of the given column, rendered for Oracle. */
    public static String lit(Model.Column col, Object v) {
        if (v == null) return "NULL";
        if (col.isNumber()) return num(v).toPlainString();
        if (col.isDate()) return "TO_DATE(" + str(dateText(v.toString())) + ", 'YYYY-MM-DD HH24:MI:SS')";
        if (col.isTimestamp()) return "TO_TIMESTAMP(" + str(tsText(v.toString())) + ", 'YYYY-MM-DD HH24:MI:SS.FF9')";
        if (col.isClob()) return clob(v.toString());
        return str(v.toString());
    }

    private static String clob(String s) {
        if (s.isEmpty()) return "EMPTY_CLOB()";
        List<String> parts = new ArrayList<>();
        for (int i = 0; i < s.length(); i += 1000)
            parts.add("TO_CLOB(" + str(s.substring(i, Math.min(s.length(), i + 1000))) + ")");
        return String.join(" || ", parts);
    }

    static String dateText(String v) {
        String t = v.trim().replace('T', ' ');
        if (t.length() == 10) t += " 00:00:00";
        int dot = t.indexOf('.');
        return dot > 0 ? t.substring(0, dot) : t;
    }

    static String tsText(String v) {
        String t = v.trim().replace('T', ' ');
        if (t.length() == 10) t += " 00:00:00";
        if (t.indexOf('.') < 0) t += ".0";
        return t;
    }

    public static BigDecimal num(Object v) {
        return v instanceof BigDecimal b ? b : new BigDecimal(v.toString().trim());
    }

    /** Equality as Oracle sees it: 1 = 1.0, trailing spaces significant, '' is NULL. */
    public static boolean same(Object a, Object b) {
        if (a instanceof String s && s.isEmpty()) a = null;
        if (b instanceof String s && s.isEmpty()) b = null;
        if (a == null || b == null) return a == b;
        if (a instanceof BigDecimal || b instanceof BigDecimal) {
            try { return num(a).compareTo(num(b)) == 0; } catch (NumberFormatException e) { return a.toString().equals(b.toString()); }
        }
        return a.toString().equals(b.toString());
    }

    /** True if two strings differ only in leading/trailing/repeated whitespace. */
    public static boolean whitespaceOnly(Object a, Object b) {
        if (!(a instanceof String x) || !(b instanceof String y)) return false;
        return !x.equals(y) && x.trim().replaceAll("\\s+", " ").equals(y.trim().replaceAll("\\s+", " "));
    }

    // ----------------------------------------------------------- predicates
    /** "col = lit" or "col IS NULL" -- safe for CLOBs too. */
    public static String eq(Model.Column col, String expr, Object v) {
        if (v == null) return expr + " IS NULL";
        if (col.isClob()) return "DBMS_LOB.COMPARE(" + expr + ", " + lit(col, v) + ") = 0";
        return expr + " = " + lit(col, v);
    }

    /**
     * "(c1, c2) IN ((..),(..)) OR (c1, c2) IN (...)" chunked under Oracle's
     * 1000-expression limit. For a single column the parentheses are dropped.
     */
    public static <R> String inList(List<String> keyCols, List<R> rows, Function<R, List<String>> literals, String indent) {
        if (rows.isEmpty()) return "1 = 0";
        String lhs = keyCols.size() == 1 ? q(keyCols.get(0)) : "(" + cols(keyCols) + ")";
        List<String> chunks = new ArrayList<>();
        for (int i = 0; i < rows.size(); i += IN_CHUNK) {
            List<String> items = new ArrayList<>();
            for (R r : rows.subList(i, Math.min(rows.size(), i + IN_CHUNK))) {
                List<String> l = literals.apply(r);
                items.add(l.size() == 1 ? l.get(0) : "(" + String.join(", ", l) + ")");
            }
            StringBuilder sb = new StringBuilder(lhs).append(" IN (\n");
            for (int k = 0; k < items.size(); k++) {
                sb.append(indent).append("    ").append(items.get(k));
                if (k < items.size() - 1) sb.append(',');
                sb.append('\n');
            }
            chunks.add(sb.append(indent).append(")").toString());
        }
        return chunks.size() == 1 ? chunks.get(0) : "(" + String.join("\n" + indent + " OR ", chunks) + ")";
    }

    /** Oracle reserved words that must never be used as aliases. */
    public static final Set<String> RESERVED = Set.of(
        "ACCESS", "ADD", "ALL", "ALTER", "AND", "ANY", "AS", "ASC", "AUDIT", "BETWEEN", "BY", "CHAR",
        "CHECK", "CLUSTER", "COLUMN", "COMMENT", "COMPRESS", "CONNECT", "CREATE", "CURRENT", "DATE",
        "DECIMAL", "DEFAULT", "DELETE", "DESC", "DISTINCT", "DROP", "ELSE", "EXCLUSIVE", "EXISTS", "FILE",
        "FLOAT", "FOR", "FROM", "GRANT", "GROUP", "HAVING", "IDENTIFIED", "IMMEDIATE", "IN", "INCREMENT",
        "INDEX", "INITIAL", "INSERT", "INTEGER", "INTERSECT", "INTO", "IS", "LEVEL", "LIKE", "LOCK", "LONG",
        "MAXEXTENTS", "MINUS", "MLSLABEL", "MODE", "MODIFY", "NOAUDIT", "NOCOMPRESS", "NOT", "NOWAIT",
        "NULL", "NUMBER", "OF", "OFFLINE", "ON", "ONLINE", "OPTION", "OR", "ORDER", "PCTFREE", "PRIOR",
        "PUBLIC", "RAW", "RENAME", "RESOURCE", "REVOKE", "ROW", "ROWID", "ROWNUM", "ROWS", "SELECT",
        "SESSION", "SET", "SHARE", "SIZE", "SMALLINT", "START", "SUCCESSFUL", "SYNONYM", "SYSDATE",
        "TABLE", "THEN", "TO", "TRIGGER", "UID", "UNION", "UNIQUE", "UPDATE", "USER", "VALIDATE", "VALUES",
        "VARCHAR", "VARCHAR2", "VIEW", "WHENEVER", "WHERE", "WITH");

    /** SQL LIKE semantics: % any run, _ one character. */
    public static boolean like(String s, String pattern) {
        if (pattern == null || pattern.isBlank()) return true;
        StringBuilder re = new StringBuilder();
        for (char ch : pattern.trim().toCharArray()) {
            if (ch == '%') re.append(".*");
            else if (ch == '_') re.append('.');
            else re.append(java.util.regex.Pattern.quote(String.valueOf(ch)));
        }
        return s.matches(re.toString());
    }

    public static String upper(String s) { return s == null ? null : s.trim().toUpperCase(Locale.ROOT); }
}
