package dbpromote.core;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Reads and writes snapshot files: a schema captured once, compared any time later. */
public final class Snapshots {
    private Snapshots() {}

    public static Model.Schema read(Path file) throws IOException {
        return Model.Schema.fromJson(Json.obj(Json.parse(Files.readString(file, StandardCharsets.UTF_8))));
    }

    public static Model.Schema read(String json) {
        return Model.Schema.fromJson(Json.obj(Json.parse(json)));
    }

    public static void write(Model.Schema schema, Path file) throws IOException {
        Files.writeString(file, Json.write(schema.toJson()), StandardCharsets.US_ASCII);
    }

    public static String toJson(Model.Schema schema) { return Json.write(schema.toJson()); }

    /** A snapshot narrowed to some tables, so a stored file can serve a partial selection. */
    public static Model.Schema select(Model.Schema s, java.util.Set<String> tables) {
        Model.Schema out = new Model.Schema();
        out.owner = s.owner;
        out.database = s.database;
        out.capturedAt = s.capturedAt;
        s.tables.forEach((k, v) -> {
            if (tables.contains(k)) out.tables.put(k, v);
            else {
                Model.Table stub = new Model.Table();
                stub.name = k;
                stub.stub = true;
                for (Model.Constraint c : v.constraints)
                    if (!c.type.equals("C")) stub.constraints.add(c);
                out.tables.put(k, stub);
            }
        });
        out.sequences.putAll(s.sequences);
        s.triggers.forEach((k, v) -> { if (tables.contains(v.table)) out.triggers.put(k, v); });
        s.data.forEach((k, v) -> { if (tables.contains(k)) out.data.put(k, v); });
        return out;
    }
}
