package dbpromote.core;

import dbpromote.core.Model.Column;
import dbpromote.core.Model.Constraint;
import dbpromote.core.Model.Index;
import dbpromote.core.Model.Schema;
import dbpromote.core.Model.Sequence;
import dbpromote.core.Model.Table;
import dbpromote.core.Model.TableData;
import dbpromote.core.Model.Trigger;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Reads one Oracle schema through the ALL_* dictionary views, strictly
 * read-only. Everything is read inside one READ ONLY transaction, so all of
 * it -- structure and rows of every table -- is from a single point in time.
 * Needs only SELECT on the tables (or SELECT ANY DICTIONARY for the views).
 */
public final class OracleReader implements AutoCloseable {

    /** Data comparison is meant for lookup tables; bigger ones are refused. */
    public static final int DEFAULT_MAX_ROWS = 200_000;

    public record TableInfo(String name, Long rows, String lastAnalyzed) {}

    private final Connection con;
    private final String owner;
    private int maxRows = DEFAULT_MAX_ROWS;
    private boolean inTransaction;

    public OracleReader(Connection con, String owner) {
        this.con = con;
        this.owner = owner.toUpperCase(Locale.ROOT);
    }

    public OracleReader maxRows(int n) { this.maxRows = n; return this; }

    /** Begins the read-only transaction; must come before any other query. */
    private void begin() throws SQLException {
        if (inTransaction) return;
        con.setAutoCommit(false);
        try (Statement s = con.createStatement()) { s.execute("SET TRANSACTION READ ONLY"); }
        inTransaction = true;
    }

    @Override
    public void close() throws SQLException {
        if (inTransaction) { con.rollback(); inTransaction = false; }
    }

    // ============================================================ discovery
    public List<String> schemas() throws SQLException {
        List<String> out = new ArrayList<>();
        try (Statement s = con.createStatement();
             ResultSet r = s.executeQuery("SELECT DISTINCT owner FROM all_tables ORDER BY owner")) {
            while (r.next()) out.add(r.getString(1));
        }
        return out;
    }

    public List<TableInfo> tables() throws SQLException {
        List<TableInfo> out = new ArrayList<>();
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT table_name, num_rows, TO_CHAR(last_analyzed, 'YYYY-MM-DD') FROM all_tables"
              + " WHERE owner = ? AND nested = 'NO' AND secondary = 'N' AND table_name NOT LIKE 'BIN$%'"
              + " AND (iot_type IS NULL OR iot_type = 'IOT') ORDER BY table_name")) {
            ps.setString(1, owner);
            try (ResultSet r = ps.executeQuery()) {
                while (r.next()) {
                    BigDecimal n = r.getBigDecimal(2);
                    out.add(new TableInfo(r.getString(1), n == null ? null : n.longValue(), r.getString(3)));
                }
            }
        }
        return out;
    }

    // ================================================================= read
    /**
     * Reads the structure of the given tables, the rows of the data tables
     * (with an optional WHERE filter each), every key and foreign key in the
     * schema (so dependencies outside the selection are known), the sequences
     * matching a LIKE pattern, and the triggers on the selected tables.
     */
    public Schema read(Set<String> tables, Map<String, String> dataFilters, String sequencePattern) throws SQLException {
        begin();
        Schema s = new Schema();
        s.owner = owner;
        try (Statement st = con.createStatement();
             ResultSet r = st.executeQuery("SELECT sys_context('USERENV', 'DB_NAME'),"
                 + " TO_CHAR(SYSTIMESTAMP, 'YYYY-MM-DD\"T\"HH24:MI:SSTZH:TZM') FROM dual")) {
            r.next();
            s.database = r.getString(1);
            s.capturedAt = r.getString(2);
        }
        Set<String> all = new java.util.LinkedHashSet<>(tables);
        all.addAll(dataFilters.keySet());
        Map<String, Long> stats = new HashMap<>();
        for (TableInfo t : tables()) stats.put(t.name(), t.rows());
        for (String t : all) {
            if (!stats.containsKey(t)) continue;           // not in this schema: the comparer reports it
            Table tb = new Table();
            tb.name = t;
            s.tables.put(t, tb);
        }
        columns(s);
        identity(s);
        constraints(s, stats.keySet());
        indexes(s);
        for (Table t : s.tables.values()) if (!t.stub) t.rowCount = hasRows(t.name, stats.get(t.name));
        if (sequencePattern != null) sequences(s, sequencePattern);
        triggers(s);
        for (Map.Entry<String, String> e : dataFilters.entrySet()) {
            Table t = s.tables.get(e.getKey());
            if (t != null) s.data.put(t.name, rows(t, e.getValue()));
        }
        return s;
    }

    private Long hasRows(String table, Long stat) throws SQLException {
        if (stat != null && stat > 0) return stat;
        try (Statement st = con.createStatement();
             ResultSet r = st.executeQuery("SELECT COUNT(*) FROM " + Sql.qt(owner, table) + " WHERE ROWNUM <= 1")) {
            r.next();
            return r.getLong(1);
        }
    }

    // -------------------------------------------------------------- columns
    private void columns(Schema s) throws SQLException {
        // DATA_DEFAULT is a LONG: it must be the last column and read in order
        String sql = "SELECT table_name, column_name, data_type, char_length, data_length, char_used,"
            + " data_precision, data_scale, nullable, data_default"
            + " FROM all_tab_columns WHERE owner = ? ORDER BY table_name, column_id";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, owner);
            try (ResultSet r = ps.executeQuery()) {
                while (r.next()) {
                    Table t = s.tables.get(r.getString(1));
                    if (t == null) continue;
                    Column c = new Column();
                    c.name = r.getString(2);
                    c.dataType = r.getString(3);
                    int charLen = r.getInt(4);
                    int dataLen = r.getInt(5);
                    c.charUsed = r.getString(6);
                    c.precision = (Integer) intOrNull(r, 7);
                    c.scale = (Integer) intOrNull(r, 8);
                    c.nullable = "Y".equals(r.getString(9));
                    String def = r.getString(10);
                    c.defaultValue = def == null || def.isBlank() ? null : def.trim();
                    if (c.isChar()) c.length = charLen;
                    else if (c.dataType.equals("RAW")) c.length = dataLen;
                    else c.charUsed = null;
                    if (c.dataType.equals("NUMBER") && c.precision == null && c.scale == null) { /* plain NUMBER */ }
                    t.columns.add(c);
                }
            }
        }
    }

    private static Object intOrNull(ResultSet r, int i) throws SQLException {
        int v = r.getInt(i);
        return r.wasNull() ? null : v;
    }

    private void identity(Schema s) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT table_name, column_name, generation_type, identity_options FROM all_tab_identity_cols WHERE owner = ?")) {
            ps.setString(1, owner);
            try (ResultSet r = ps.executeQuery()) {
                while (r.next()) {
                    Table t = s.tables.get(r.getString(1));
                    if (t == null || t.stub) continue;
                    Column c = t.column(r.getString(2));
                    if (c == null) continue;
                    c.identity = true;
                    c.identityGeneration = r.getString(3);
                    c.identityOptions = r.getString(4);
                    c.defaultValue = null;   // the identity's own sequence, not a real default
                }
            }
        }
    }

    // ---------------------------------------------------------- constraints
    private void constraints(Schema s, Set<String> schemaTables) throws SQLException {
        Map<String, List<String>> cols = new HashMap<>();
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT constraint_name, column_name FROM all_cons_columns WHERE owner = ? ORDER BY constraint_name, position")) {
            ps.setString(1, owner);
            try (ResultSet r = ps.executeQuery()) {
                while (r.next()) cols.computeIfAbsent(r.getString(1), k -> new ArrayList<>()).add(r.getString(2));
            }
        }
        record Raw(String name, String type, String table, String rOwner, String rName, String delete,
                   String status, String validated, String generated, String index, String condition) {}
        List<Raw> raws = new ArrayList<>();
        // SEARCH_CONDITION is a LONG: last column, read in order
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT constraint_name, constraint_type, table_name, r_owner, r_constraint_name, delete_rule,"
              + " status, validated, generated, index_name, search_condition FROM all_constraints"
              + " WHERE owner = ? AND constraint_type IN ('P', 'U', 'R', 'C') AND table_name NOT LIKE 'BIN$%'")) {
            ps.setString(1, owner);
            try (ResultSet r = ps.executeQuery()) {
                while (r.next()) {
                    raws.add(new Raw(r.getString(1), r.getString(2), r.getString(3), r.getString(4), r.getString(5),
                        r.getString(6), r.getString(7), r.getString(8), r.getString(9), r.getString(10), r.getString(11)));
                }
            }
        }
        Map<String, Raw> byName = new HashMap<>();
        for (Raw x : raws) byName.put(x.name(), x);
        for (Raw x : raws) {
            boolean selected = s.tables.containsKey(x.table()) && !s.tables.get(x.table()).stub;
            boolean keyOrFk = x.type().equals("P") || x.type().equals("U") || x.type().equals("R");
            if (!selected && !(keyOrFk && schemaTables.contains(x.table()))) continue;
            Constraint c = new Constraint();
            c.name = x.name();
            c.type = x.type();
            c.columns.addAll(cols.getOrDefault(x.name(), List.of()));
            c.generatedName = "GENERATED NAME".equals(x.generated());
            c.enabled = "ENABLED".equals(x.status());
            c.validated = "VALIDATED".equals(x.validated());
            c.indexName = x.index();
            c.condition = x.condition();
            if (c.type.equals("R")) {
                Raw ref = byName.get(x.rName());
                if (ref == null || !owner.equals(x.rOwner())) continue;   // cross-schema: out of scope
                c.refTable = ref.table();
                c.refColumns.addAll(cols.getOrDefault(ref.name(), List.of()));
                c.deleteRule = x.delete();
            }
            if (c.type.equals("C") && c.isNotNullCheck()) continue;   // carried by Column.nullable
            Table t = s.tables.computeIfAbsent(x.table(), n -> { Table st = new Table(); st.name = n; st.stub = true; return st; });
            t.constraints.add(c);
        }
    }

    // -------------------------------------------------------------- indexes
    private void indexes(Schema s) throws SQLException {
        Map<String, Index> byName = new LinkedHashMap<>();
        Map<String, String> tableOf = new HashMap<>();
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT index_name, table_name, uniqueness, generated FROM all_indexes"
              + " WHERE owner = ? AND table_owner = ? AND index_type <> 'LOB' AND index_name NOT LIKE 'BIN$%'")) {
            ps.setString(1, owner);
            ps.setString(2, owner);
            try (ResultSet r = ps.executeQuery()) {
                while (r.next()) {
                    Table t = s.tables.get(r.getString(2));
                    if (t == null || t.stub) continue;
                    Index i = new Index();
                    i.name = r.getString(1);
                    i.unique = "UNIQUE".equals(r.getString(3));
                    i.generatedName = "Y".equals(r.getString(4));
                    byName.put(i.name, i);
                    tableOf.put(i.name, t.name);
                }
            }
        }
        Map<String, String> expr = new HashMap<>();
        // COLUMN_EXPRESSION is a LONG: last column
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT index_name, column_position, column_expression FROM all_ind_expressions WHERE index_owner = ?")) {
            ps.setString(1, owner);
            try (ResultSet r = ps.executeQuery()) {
                while (r.next()) expr.put(r.getString(1) + "#" + r.getInt(2), r.getString(3));
            }
        }
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT index_name, column_name, column_position, descend FROM all_ind_columns"
              + " WHERE index_owner = ? ORDER BY index_name, column_position")) {
            ps.setString(1, owner);
            try (ResultSet r = ps.executeQuery()) {
                while (r.next()) {
                    Index i = byName.get(r.getString(1));
                    if (i == null) continue;
                    String col = r.getString(2);
                    String e = expr.get(i.name + "#" + r.getInt(3));
                    boolean desc = "DESC".equals(r.getString(4));
                    if (e != null) {
                        String t = e.trim();
                        if (t.matches("\"[A-Z][A-Z0-9_$#]*\"")) t = t.substring(1, t.length() - 1);   // DESC on a plain column
                        col = t;
                    }
                    i.columns.add(desc ? col + " DESC" : col);
                }
            }
        }
        for (Map.Entry<String, Index> e : byName.entrySet()) s.tables.get(tableOf.get(e.getKey())).indexes.add(e.getValue());
    }

    // ------------------------------------------------------------ sequences
    private void sequences(Schema s, String pattern) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT sequence_name, min_value, max_value, increment_by, cache_size, cycle_flag, order_flag, last_number"
              + " FROM all_sequences WHERE sequence_owner = ? AND sequence_name LIKE ? AND sequence_name NOT LIKE 'ISEQ$$%'")) {
            ps.setString(1, owner);
            ps.setString(2, pattern == null || pattern.isBlank() ? "%" : pattern);
            try (ResultSet r = ps.executeQuery()) {
                while (r.next()) {
                    Sequence q = new Sequence();
                    q.name = r.getString(1);
                    q.minValue = r.getBigDecimal(2);
                    q.maxValue = r.getBigDecimal(3);
                    q.incrementBy = r.getBigDecimal(4);
                    q.cacheSize = r.getInt(5);
                    q.cycle = "Y".equals(r.getString(6));
                    q.order = "Y".equals(r.getString(7));
                    q.lastNumber = r.getBigDecimal(8);
                    s.sequences.put(q.name, q);
                }
            }
        }
    }

    // ------------------------------------------------------------- triggers
    private void triggers(Schema s) throws SQLException {
        // TRIGGER_BODY is a LONG: last column
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT trigger_name, table_name, description, when_clause, status, trigger_body FROM all_triggers"
              + " WHERE owner = ? AND table_owner = ? AND base_object_type = 'TABLE'")) {
            ps.setString(1, owner);
            ps.setString(2, owner);
            try (ResultSet r = ps.executeQuery()) {
                while (r.next()) {
                    Table t = s.tables.get(r.getString(2));
                    if (t == null || t.stub) continue;
                    Trigger g = new Trigger();
                    g.name = r.getString(1);
                    g.table = r.getString(2);
                    g.description = r.getString(3);
                    g.whenClause = r.getString(4);
                    g.enabled = "ENABLED".equals(r.getString(5));
                    g.body = r.getString(6);
                    s.triggers.put(g.name, g);
                }
            }
        }
    }

    // ----------------------------------------------------------------- rows
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private TableData rows(Table t, String filter) throws SQLException {
        String where = filter == null || filter.isBlank() ? "" : " WHERE (" + filter + ")";
        try (Statement st = con.createStatement();
             ResultSet r = st.executeQuery("SELECT COUNT(*) FROM " + Sql.qt(owner, t.name) + where)) {
            r.next();
            long n = r.getLong(1);
            if (n > maxRows)
                throw new SQLException(t.name + " has " + n + " rows. Data comparison is meant for lookup tables "
                    + "(limit " + maxRows + "); compare its structure only, or add a row filter.");
        }
        TableData d = new TableData();
        d.table = t.name;
        d.filter = filter == null || filter.isBlank() ? null : filter;
        List<Column> cols = new ArrayList<>();
        for (Column c : t.columns) if (!c.isUnsupportedForData()) cols.add(c);
        for (Column c : cols) d.columns.add(c.name);
        String sql = "SELECT " + Sql.cols(d.columns) + " FROM " + Sql.qt(owner, t.name) + where;
        try (Statement st = con.createStatement()) {
            st.setFetchSize(1000);
            try (ResultSet r = st.executeQuery(sql)) {
                while (r.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    for (int i = 0; i < cols.size(); i++) {
                        Column c = cols.get(i);
                        Object v;
                        if (c.isNumber()) v = r.getBigDecimal(i + 1);
                        else if (c.isDate()) { Timestamp ts = r.getTimestamp(i + 1); v = ts == null ? null : ts.toLocalDateTime().format(DATE); }
                        else if (c.isTimestamp()) { Timestamp ts = r.getTimestamp(i + 1); v = ts == null ? null : timestamp(ts); }
                        else v = r.getString(i + 1);
                        row.put(c.name, v);
                    }
                    d.rows.add(row);
                }
            }
        }
        return d;
    }

    private static String timestamp(Timestamp ts) {
        return ts.toLocalDateTime().format(DATE) + "." + String.format("%09d", ts.getNanos());
    }
}
