package dbpromote.core;

import dbpromote.core.Model.Constraint;
import dbpromote.core.Model.Schema;
import dbpromote.core.Model.Table;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The result of comparing two schemas for a selection of tables: structural
 * changes, row-level data plans, the order the data scripts must run in, and
 * warnings. Scripts are generated from it together with people's decisions.
 */
public final class Comparison {

    public final Schema source;
    public final Schema target;
    public final CompareRequest request;
    public final List<Change> changes;
    public final Map<String, DataPlan> data = new LinkedHashMap<>();   // in run order
    public final List<String> warnings = new ArrayList<>();

    private Comparison(Schema source, Schema target, CompareRequest request, List<Change> changes) {
        this.source = source;
        this.target = target;
        this.request = request;
        this.changes = changes;
    }

    // ================================================================ compare
    public static Comparison run(Schema source, Schema target, CompareRequest req) {
        if (req.targetSchema == null) req.targetSchema = target.owner;
        if (req.sourceSchema == null) req.sourceSchema = source.owner;
        List<Change> changes = new SchemaComparer(source, target, req).compare();
        Comparison c = new Comparison(source, target, req, changes);

        Map<String, DataPlan> plans = new LinkedHashMap<>();
        for (String t : req.dataTables()) {
            CompareRequest.DataSettings s = req.settings(t);
            DataPlan p = DataPlan.compare(t, source.tables.get(t), target.tables.get(t),
                source.data.get(t), target.data.get(t), s);
            plans.put(t, p);
            if (p.blocked != null) c.warnings.add(t + ": data not compared -- " + p.blocked);
            if (!p.newColumns.isEmpty() || (p.targetDefinition == null && source.tables.containsKey(t))) {
                CompareRequest.TableChoice ch = req.choice(t);
                if (ch == null || !ch.structure)
                    c.warnings.add(t + ": the data uses columns the target does not have yet ("
                        + (p.targetDefinition == null ? "the whole table" : String.join(", ", p.newColumns))
                        + "). Tick \"structure\" for this table too, so the DDL script adds them.");
            }
        }
        for (String t : order(plans.keySet(), source, c.warnings)) c.data.put(t, plans.get(t));
        c.checkParents();
        c.dataQuality();
        return c;
    }

    /** Parents before children (by foreign key), so inserts never point at missing rows. */
    private static List<String> order(Set<String> tables, Schema src, List<String> warnings) {
        Map<String, Set<String>> parents = new HashMap<>();
        for (String t : tables) {
            Set<String> ps = new LinkedHashSet<>();
            Table def = src.tables.get(t);
            if (def != null)
                for (Constraint k : def.constraints)
                    if (k.type.equals("R") && tables.contains(k.refTable) && !k.refTable.equals(t)) ps.add(k.refTable);
            parents.put(t, ps);
        }
        List<String> out = new ArrayList<>();
        Set<String> done = new HashSet<>();
        while (out.size() < tables.size()) {
            boolean progress = false;
            for (String t : tables) {
                if (done.contains(t) || !done.containsAll(parents.get(t))) continue;
                out.add(t); done.add(t); progress = true;
            }
            if (!progress) {
                for (String t : tables) if (!done.contains(t)) { out.add(t); done.add(t); }
                warnings.add("The selected tables reference each other in a cycle; check the data script order.");
            }
        }
        return out;
    }

    /** New rows must point at parents that exist in the target or arrive in this run. */
    private void checkParents() {
        for (DataPlan p : data.values()) {
            if (p.blocked != null || p.inserts.isEmpty()) continue;
            for (Constraint fk : p.definition.constraints) {
                if (!fk.type.equals("R")) continue;
                DataPlan parent = data.get(fk.refTable);
                if (parent == null || parent.blocked != null) {
                    Model.TableData tgtParent = target.data.get(fk.refTable);
                    if (tgtParent == null) {
                        c(p.table + ": new rows reference " + fk.refTable + ", which is not selected for data. "
                            + "The pre-flight checks the parents exist; select " + fk.refTable + " to compare it here.");
                    }
                    continue;
                }
                Set<String> have = new HashSet<>();
                for (Map<String, Object> r : parent.targetRowsList) have.add(tuple(fk.refColumns, r));
                for (DataPlan.Insert i : parent.inserts) have.add(tuple(fk.refColumns, i.row()));
                int missing = 0;
                String example = null;
                for (DataPlan.Insert i : p.inserts) {
                    String t = tuple(fk.columns, i.row());
                    if (t == null || have.contains(t)) continue;
                    missing++;
                    if (example == null) example = i.keyText();
                }
                if (missing > 0)
                    c(p.table + ": " + missing + " new rows point at " + fk.refTable + " rows that will not exist "
                        + "(for example " + example + "). Their inserts would fail on " + fk.name + ".");
            }
        }
    }

    private void c(String w) { if (!warnings.contains(w)) warnings.add(w); }

    private static String tuple(List<String> cols, Map<String, Object> r) {
        List<String> parts = new ArrayList<>();
        for (String c : cols) {
            Object v = r.get(c);
            if (v == null) return null;
            parts.add(v instanceof BigDecimal b ? b.stripTrailingZeros().toPlainString() : v.toString());
        }
        return String.join("\u0001", parts);
    }

    /** Values that are almost certainly mistakes, so people see them before promoting them. */
    private void dataQuality() {
        for (DataPlan p : data.values()) {
            if (p.blocked != null) continue;
            int literalNull = 0, keySpace = 0;
            String nullEx = null, spaceEx = null;
            for (DataPlan.Insert i : p.inserts) {
                for (Map.Entry<String, Object> e : i.row().entrySet())
                    if ("null".equalsIgnoreCase(String.valueOf(e.getValue())) && e.getValue() instanceof String) {
                        literalNull++; if (nullEx == null) nullEx = i.keyText() + " " + e.getKey();
                    }
                for (String k : p.key)
                    if (i.row().get(k) instanceof String s && !s.equals(s.strip())) {
                        keySpace++; if (spaceEx == null) spaceEx = "'" + s + "'";
                    }
            }
            for (DataPlan.Update u : p.updates)
                if (u.newValue() instanceof String s && s.equalsIgnoreCase("null")) {
                    literalNull++; if (nullEx == null) nullEx = u.keyText() + " " + u.column();
                }
            if (literalNull > 0)
                c(p.table + ": " + literalNull + " values to be written are the text 'null', not a real NULL (e.g. "
                    + nullEx + "). Usually a loading bug in the source.");
            if (keySpace > 0)
                c(p.table + ": " + keySpace + " new keys have leading or trailing spaces (e.g. " + spaceEx
                    + "). They will not match the same key without the spaces.");
        }
    }

    // ============================================================== generate
    /** The script files, in run order, plus the report and an audit record. */
    public Map<String, String> generate(Decisions decisions, String sourceLabel, String targetLabel, String user) {
        DdlScript.Header h = new DdlScript.Header(sourceLabel, targetLabel, request.targetSchema,
            java.time.ZonedDateTime.now().withNano(0).toString(), user);
        Map<String, String> files = new LinkedHashMap<>();
        DdlScript ddl = new DdlScript(changes, decisions, h);
        boolean anyDdl = !ddl.appliedChanges().isEmpty();
        if (anyDdl) {
            files.put("01_ddl.sql", ddl.forward());
            files.put("01_ddl_ROLLBACK.sql", ddl.rollback());
        }
        int n = 0;
        Map<String, DataScript> scripts = new LinkedHashMap<>();
        for (DataPlan p : data.values()) {
            if (p.blocked != null) continue;
            List<Table> referencing = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (Schema s : List.of(source, target))
                for (Table t : s.tables.values())
                    for (Constraint k : t.constraints)
                        if (k.type.equals("R") && p.table.equals(k.refTable) && seen.add(t.name + "." + k.name)) {
                            Table only = new Table();
                            only.name = t.name;
                            only.constraints.add(k);
                            referencing.add(only);
                        }
            String filter = request.settings(p.table).filter;
            DataScript ds = new DataScript(p, decisions, h, referencing, filter);
            scripts.put(p.table, ds);
            if (ds.isEmpty()) continue;
            n++;
            String base = String.format("02_data_%02d_%s", n, p.table);
            files.put(base + ".sql", ds.forward(n));
            files.put(base + "_ROLLBACK.sql", ds.rollback(n));
        }
        files.put("report.md", new Report(this, decisions, ddl, scripts, h).render());
        Map<String, Object> audit = new LinkedHashMap<>();
        audit.put("generatedAt", h.generatedAt());
        audit.put("generatedBy", user);
        audit.put("source", sourceLabel);
        audit.put("target", targetLabel);
        audit.put("request", request.toJson());
        audit.put("decisions", decisions.toJson());
        files.put("decisions.json", Json.write(audit));
        return files;
    }

    // ============================================================== summary
    public int count(Change.Category cat) {
        int n = 0;
        for (Change c : changes) if (c.category == cat) n++;
        return n;
    }

    /** Applied changes whose prerequisites are not applied: the DDL would fail part-way. */
    public List<String> brokenDependencies(Decisions d) {
        Map<String, Change> byId = new HashMap<>();
        for (Change c : changes) byId.put(c.id, c);
        List<String> out = new ArrayList<>();
        for (Change c : changes) {
            if (!c.scriptable() || !d.applies(c.id, c.appliedByDefault())) continue;
            for (String r : c.requires) {
                Change req = byId.get(r);
                if (req == null) {
                    out.add("\"" + c.title + "\" needs a change that is not in this comparison (" + r
                        + "). Add the table it belongs to.");
                } else if (!d.applies(req.id, req.appliedByDefault())) {
                    out.add("\"" + c.title + "\" needs \"" + req.title + "\", which is left out.");
                }
            }
        }
        return out;
    }
}
