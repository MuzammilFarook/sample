package dbpromote.core;

import java.util.ArrayList;
import java.util.List;

/**
 * One structural difference and what to do about it. Data differences are
 * modelled separately in {@link DataPlan}, because they come in thousands.
 */
public final class Change {

    /** How the tool treats a difference until a person decides otherwise. */
    public enum Category {
        /** Safe to script: applied unless someone skips it. */
        AUTO,
        /** Scripted, but left out until someone approves it. */
        REVIEW,
        /** Reported only; nothing to script (cosmetic, or target-only by design). */
        INFO
    }

    /** Position in the DDL script. Order matters: earlier phases are prerequisites. */
    public enum Phase {
        SEQUENCE("Sequences"),
        CREATE_TABLE("New tables"),
        COLUMN("Columns on existing tables"),
        INDEX("Indexes"),
        KEY("Primary and unique keys"),
        CHECK("Check constraints"),
        FOREIGN_KEY("Foreign keys"),
        TRIGGER("Triggers"),
        DROP("Removals (target-only objects)"),
        NONE("Report only");

        public final String title;
        Phase(String title) { this.title = title; }
    }

    /** A query that must give a stated answer before or after the change. */
    public record Check(String description, String sql, String expect) {}

    public final String id;          // stable across runs: used to remember decisions
    public final String table;       // null for sequences
    public final String object;      // the column / constraint / index / sequence / trigger concerned
    public final Category category;
    public final Phase phase;
    public final String title;
    public String source;            // what the source has (for the report), or null
    public String target;            // what the target has, or null
    public String reason;            // why REVIEW / INFO, or a note for AUTO
    public final List<String> sql = new ArrayList<>();
    public final List<String> rollback = new ArrayList<>();
    public final List<Check> preflight = new ArrayList<>();
    public final List<Check> verify = new ArrayList<>();
    /** Ids of changes that must also be applied for this one to work. */
    public final List<String> requires = new ArrayList<>();
    /** Objects this change creates, as "TYPE NAME" (TABLE, INDEX, SEQUENCE, CONSTRAINT, TRIGGER). */
    public final List<String> creates = new ArrayList<>();
    /** Objects this change removes, as "TYPE NAME". */
    public final List<String> removes = new ArrayList<>();

    public Change(String id, String table, String object, Category category, Phase phase, String title) {
        this.id = id;
        this.table = table;
        this.object = object;
        this.category = category;
        this.phase = phase;
        this.title = title;
    }

    public Change from(String s) { this.source = s; return this; }
    public Change to(String t) { this.target = t; return this; }
    public Change because(String r) { this.reason = r; return this; }
    public Change sql(String s) { sql.add(s); return this; }
    public Change undo(String s) { rollback.add(0, s); return this; }
    public Change pre(String d, String s, String e) { preflight.add(new Check(d, s, e)); return this; }
    public Change post(String d, String s, String e) { verify.add(new Check(d, s, e)); return this; }
    public Change creates(String type, String name) { creates.add(type + " " + name); return this; }
    public Change removes(String type, String name) { removes.add(type + " " + name); return this; }
    public Change needs(String id) { if (id != null && !requires.contains(id)) requires.add(id); return this; }

    public boolean scriptable() { return category != Category.INFO && !sql.isEmpty(); }
    public boolean appliedByDefault() { return category == Category.AUTO && !sql.isEmpty(); }
}
