package dbpromote.web;

import jakarta.servlet.http.HttpSession;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.util.HtmlUtils;

/** Start page: saved environments, saved profiles, and starting a comparison. */
@Controller
public class HomeController {

    private final Store store;
    private final HttpSession session;   // Spring injects a proxy that resolves the current session

    public HomeController(Store store, HttpSession session) {
        this.store = store;
        this.session = session;
    }

    @GetMapping("/")
    public String index(@RequestParam(required = false) String edit, Model model) {
        model.addAttribute("connections", store.connections());
        model.addAttribute("profiles", store.profileNames());
        ConnectionDef form = edit == null ? null : store.connection(edit);
        model.addAttribute("form", form == null ? new ConnectionDef() : form);
        model.addAttribute("ws", ws());
        model.addAttribute("sourceId", ws().source.def == null ? null : ws().source.def.getId());
        model.addAttribute("targetId", ws().target.def == null ? null : ws().target.def.getId());
        model.addAttribute("home", store.home().toString());
        model.addAttribute("error", takeError());
        return "index";
    }

    // ------------------------------------------------------------ connections
    @PostMapping("/connections")
    public String saveConnection(ConnectionDef c) {
        if (c.getName() == null || c.getName().isBlank()) c.setName(c.isLive() ? c.getUser() + "@" + c.getUrl() : "snapshot");
        if (c.getSchema() != null) c.setSchema(c.getSchema().trim().toUpperCase());
        store.save(c);
        return "redirect:/";
    }

    @PostMapping("/connections/{id}/delete")
    public String deleteConnection(@PathVariable String id) {
        store.deleteConnection(id);
        return "redirect:/";
    }

    @PostMapping(value = "/connections/test", produces = MediaType.TEXT_HTML_VALUE)
    @ResponseBody
    public String test(ConnectionDef c, @RequestParam(required = false) String password) {
        String r = Workspace.test(c, password);
        String cls = r.startsWith("OK") ? "ok" : "bad";
        return "<span class=\"" + cls + "\">" + HtmlUtils.htmlEscape(r) + "</span>";
    }

    // --------------------------------------------------------------- start
    @PostMapping("/start")
    public String start(@RequestParam String sourceId, @RequestParam String targetId,
                        @RequestParam(required = false) String sourceSchema, @RequestParam(required = false) String targetSchema,
                        @RequestParam(required = false) String sourcePassword, @RequestParam(required = false) String targetPassword) {
        if (sourceId.equals(targetId)) {
            ws().lastError = "Source and target are the same environment.";
            return "redirect:/";
        }
        ws().reset();
        ws().source.def = store.connection(sourceId);
        ws().target.def = store.connection(targetId);
        ws().source.password = sourcePassword;
        ws().target.password = targetPassword;
        ws().source.schema = schema(sourceSchema, ws().source.def);
        ws().target.schema = schema(targetSchema, ws().target.def);
        try {
            ws().connect();
        } catch (Exception e) {
            ws().lastError = "Could not connect: " + e.getMessage();
            return "redirect:/";
        }
        return "redirect:/tables";
    }

    private static String schema(String typed, ConnectionDef def) {
        String s = typed == null || typed.isBlank() ? def.getSchema() : typed;
        return s == null ? null : s.trim().toUpperCase();
    }

    // -------------------------------------------------------------- profiles
    @PostMapping("/profiles/load")
    public String loadProfile(@RequestParam String name) {
        Store.Profile p = store.profile(name);
        if (p == null) { ws().lastError = "Profile " + name + " not found."; return "redirect:/"; }
        ws().reset();
        ws().request = p.request();
        ws().decisions = p.decisions();
        ws().profileName = p.name();
        if (p.sourceId() != null) ws().source.def = store.connection(p.sourceId());
        if (p.targetId() != null) ws().target.def = store.connection(p.targetId());
        ws().source.schema = p.request().sourceSchema;
        ws().target.schema = p.request().targetSchema;
        return "redirect:/";
    }

    @PostMapping("/profiles/delete")
    public String deleteProfile(@RequestParam String name) {
        store.deleteProfile(name);
        return "redirect:/";
    }

    @PostMapping("/new")
    public String fresh() {
        ws().reset();
        ws().request = new dbpromote.core.CompareRequest();
        ws().decisions = new dbpromote.core.Decisions();
        ws().profileName = null;
        return "redirect:/";
    }

    private String takeError() {
        String e = ws().lastError;
        ws().lastError = null;
        return e;
    }

    private Workspace ws() { return Workspace.of(session); }
}
