package dbpromote.web;

import dbpromote.core.CompareRequest;
import dbpromote.core.Comparison;
import dbpromote.core.Decisions;
import dbpromote.core.Model;
import dbpromote.core.OracleReader;
import dbpromote.core.Snapshots;

import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * One user's comparison in progress: the two environments, the tables chosen,
 * what was read, the result and the decisions taken. Lives in the browser
 * session (one per browser session, see {@link #of}); passwords are held here in memory only.
 */
public class Workspace {

    private static final String KEY = Workspace.class.getName();

    /** The workspace of the current browser session, created on first use. */
    public static Workspace of(HttpSession session) {
        synchronized (session) {
            Workspace w = (Workspace) session.getAttribute(KEY);
            if (w == null) {
                w = new Workspace();
                session.setAttribute(KEY, w);
            }
            return w;
        }
    }

    /** One environment as used in this comparison. */
    public static class Side {
        public ConnectionDef def;
        public String password;
        public String schema;
        public Model.Schema snapshotFile;     // when the environment is a snapshot

        public String label() { return def == null ? "?" : def.getName(); }
    }

    /** A table as offered on the selection screen. */
    public static class TableRow {
        private final String name;
        private Long sourceRows, targetRows;
        private boolean inSource, inTarget;
        public TableRow(String name) { this.name = name; }
        public String getName() { return name; }
        public Long getSourceRows() { return sourceRows; }
        public Long getTargetRows() { return targetRows; }
        public boolean isInSource() { return inSource; }
        public boolean isInTarget() { return inTarget; }
    }

    public final Side source = new Side();
    public final Side target = new Side();
    public final Map<String, TableRow> tables = new TreeMap<>();
    public CompareRequest request = new CompareRequest();
    public Decisions decisions = new Decisions();
    public Model.Schema sourceSchema, targetSchema;
    public Comparison comparison;
    public String profileName;
    public String lastError;

    public boolean connected() { return !tables.isEmpty(); }

    public void reset() {
        tables.clear();
        sourceSchema = targetSchema = null;
        comparison = null;
        lastError = null;
    }

    // ================================================================ connect
    /** Opens both environments and lists their tables. */
    public void connect() throws SQLException, IOException {
        tables.clear();
        comparison = null;
        sourceSchema = targetSchema = null;
        for (Side s : List.of(source, target)) {
            boolean isSource = s == source;
            for (OracleReader.TableInfo t : list(s)) {
                TableRow r = tables.computeIfAbsent(t.name(), TableRow::new);
                if (isSource) { r.inSource = true; r.sourceRows = t.rows(); }
                else { r.inTarget = true; r.targetRows = t.rows(); }
            }
        }
        request.sourceSchema = source.schema;
        request.targetSchema = target.schema;
        // a profile may name tables that no longer exist: keep only real ones
        request.tables.removeIf(c -> !tables.containsKey(c.table));
    }

    private List<OracleReader.TableInfo> list(Side s) throws SQLException, IOException {
        if (s.def.isLive()) {
            try (Connection c = open(s); OracleReader r = new OracleReader(c, s.schema)) {
                return r.tables();
            }
        }
        s.snapshotFile = Snapshots.read(Path.of(s.def.getSnapshotPath()));
        if (s.schema == null || s.schema.isBlank()) s.schema = s.snapshotFile.owner;
        List<OracleReader.TableInfo> out = new ArrayList<>();
        for (Model.Table t : s.snapshotFile.tables.values()) {
            if (t.stub) continue;
            Model.TableData d = s.snapshotFile.data.get(t.name);
            out.add(new OracleReader.TableInfo(t.name, d != null ? (long) d.rows.size() : t.rowCount, null));
        }
        return out;
    }

    public static Connection open(Side s) throws SQLException {
        return DriverManager.getConnection(s.def.getUrl(), s.def.getUser(), s.password);
    }

    /** Quick connection test for the connections screen. */
    public static String test(ConnectionDef def, String password) {
        if (!def.isLive()) {
            try {
                Model.Schema sc = Snapshots.read(Path.of(def.getSnapshotPath()));
                return "OK: snapshot of " + sc.owner + " on " + sc.database + ", taken " + sc.capturedAt + ".";
            } catch (Exception e) {
                return "Cannot read the snapshot: " + e.getMessage();
            }
        }
        Side s = new Side();
        s.def = def;
        s.password = password;
        try (Connection c = open(s)) {
            return "OK: connected to " + c.getMetaData().getDatabaseProductVersion().split("\n")[0] + ".";
        } catch (SQLException e) {
            return "Failed: " + e.getMessage();
        }
    }

    // ==================================================================== run
    /** Reads the selected tables from both environments and compares them. */
    public void read() throws SQLException, IOException {
        sourceSchema = readSide(source);
        targetSchema = readSide(target);
        compare();
    }

    /** Re-runs the comparison on what was already read (key or ignore changes). */
    public void compare() {
        if (sourceSchema == null || targetSchema == null) return;
        request.sourceSchema = source.schema;
        request.targetSchema = target.schema;
        comparison = Comparison.run(sourceSchema, targetSchema, request);
    }

    private Model.Schema readSide(Side s) throws SQLException, IOException {
        Set<String> all = request.allTables();
        Map<String, String> data = new LinkedHashMap<>();
        for (String t : request.dataTables()) data.put(t, request.settings(t).filter);
        if (s.def.isLive()) {
            try (Connection c = open(s); OracleReader r = new OracleReader(c, s.schema)) {
                return r.read(all, data, request.sequences ? request.sequencePattern : null);
            }
        }
        Model.Schema snap = s.snapshotFile != null ? s.snapshotFile : Snapshots.read(Path.of(s.def.getSnapshotPath()));
        Model.Schema sel = Snapshots.select(snap, all);
        if (!request.sequences) sel.sequences.clear();
        for (String t : request.dataTables()) {
            Model.TableData d = sel.data.get(t);
            String f = request.settings(t).filter;
            if (d != null && f != null && !f.isBlank() && !f.equals(d.filter))
                throw new IllegalStateException(s.label() + " is a snapshot: its rows of " + t
                    + " cannot be re-read with a new filter. Use a live connection, or take a new snapshot with that filter.");
        }
        return sel;
    }

    /** A full snapshot of the selected tables of one side, for saving. */
    public Model.Schema snapshot(boolean ofSource) {
        return ofSource ? sourceSchema : targetSchema;
    }

    public Set<String> selected() {
        Set<String> s = new LinkedHashSet<>();
        for (CompareRequest.TableChoice c : request.tables) s.add(c.table);
        return s;
    }
}
