package dbpromote.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * dbpromote: compare two Oracle schemas and generate reviewed promotion
 * scripts. Runs locally; open http://localhost:8080 once it has started.
 */
@SpringBootApplication
public class DbPromoteApplication {
    public static void main(String[] args) {
        SpringApplication.run(DbPromoteApplication.class, args);
    }
}
