package dbpromote.web;

import dbpromote.core.Json;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * A saved environment: a live Oracle connection or a snapshot file.
 * Passwords are never saved; they are typed in when connecting.
 */
public class ConnectionDef {

    public static final String LIVE = "LIVE";
    public static final String SNAPSHOT = "SNAPSHOT";

    private String id;
    private String name;
    private String kind = LIVE;
    private String url;
    private String user;
    private String schema;
    private String snapshotPath;

    public boolean isLive() { return LIVE.equals(kind); }

    /** What the screens show for this environment. */
    public String getDescription() {
        return isLive() ? user + " @ " + url : "snapshot " + snapshotPath;
    }

    public Map<String, Object> toJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("name", name);
        m.put("kind", kind);
        m.put("url", url);
        m.put("user", user);
        m.put("schema", schema);
        m.put("snapshotPath", snapshotPath);
        return m;
    }

    public static ConnectionDef fromJson(Map<String, Object> m) {
        ConnectionDef c = new ConnectionDef();
        c.id = Json.str(m.get("id"));
        c.name = Json.str(m.get("name"));
        c.kind = m.get("kind") == null ? LIVE : Json.str(m.get("kind"));
        c.url = Json.str(m.get("url"));
        c.user = Json.str(m.get("user"));
        c.schema = Json.str(m.get("schema"));
        c.snapshotPath = Json.str(m.get("snapshotPath"));
        return c;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getKind() { return kind; }
    public void setKind(String kind) { this.kind = kind; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public String getUser() { return user; }
    public void setUser(String user) { this.user = user; }
    public String getSchema() { return schema; }
    public void setSchema(String schema) { this.schema = schema; }
    public String getSnapshotPath() { return snapshotPath; }
    public void setSnapshotPath(String snapshotPath) { this.snapshotPath = snapshotPath; }
}
