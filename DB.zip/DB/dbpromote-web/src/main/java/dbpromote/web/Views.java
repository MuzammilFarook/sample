package dbpromote.web;

import dbpromote.core.Change;
import dbpromote.core.CompareRequest;
import dbpromote.core.Comparison;
import dbpromote.core.DataPlan;
import dbpromote.core.Decisions;
import dbpromote.core.Model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Plain getter-based view objects for the Thymeleaf templates. */
public final class Views {
    private Views() {}

    // ============================================================ structure
    public static class ChangeView {
        private final Change c;
        private final Decisions.Decision d;
        private final boolean applied;

        public ChangeView(Change c, Decisions decisions) {
            this.c = c;
            this.d = decisions.get(c.id);
            this.applied = c.scriptable() && decisions.applies(c.id, c.appliedByDefault());
        }
        public String getId() { return c.id; }
        public String getDomId() { return "c" + Integer.toHexString(c.id.hashCode()); }
        public String getCategory() { return c.category.name(); }
        public String getPhase() { return c.phase.title; }
        public String getTitle() { return c.title; }
        public String getTable() { return c.table; }
        public String getSource() { return c.source; }
        public String getTarget() { return c.target; }
        public String getReason() { return c.reason; }
        public boolean isScriptable() { return c.scriptable(); }
        public boolean isApplied() { return applied; }
        public boolean isChangedFromDefault() { return d != null && d.apply() != c.appliedByDefault(); }
        public String getDecisionReason() { return d == null || d.reason() == null ? "" : d.reason(); }
        public String getSql() { return String.join(";\n", c.sql) + (c.sql.isEmpty() ? "" : ";"); }
        public List<String> getChecks() {
            List<String> l = new ArrayList<>();
            for (Change.Check k : c.preflight) l.add(k.description() + " (expect " + k.expect() + ")");
            return l;
        }
    }

    public static class TableGroup {
        private final String table;
        private final List<ChangeView> changes = new ArrayList<>();
        TableGroup(String table) { this.table = table; }
        public String getTable() { return table; }
        public List<ChangeView> getChanges() { return changes; }
        public long getReviewCount() { return changes.stream().filter(c -> c.getCategory().equals("REVIEW")).count(); }
    }

    public static List<TableGroup> structure(Comparison cmp, Decisions d) {
        Map<String, TableGroup> m = new LinkedHashMap<>();
        for (Change c : cmp.changes)
            m.computeIfAbsent(c.table == null ? "(sequences)" : c.table, TableGroup::new).changes.add(new ChangeView(c, d));
        return new ArrayList<>(m.values());
    }

    // ================================================================= data
    public static class RowView {
        private final String id, key, column, oldValue, newValue, note;
        private final boolean applied, defaultApplied;
        public RowView(String id, String key, String column, Object oldValue, Object newValue, String note,
                       boolean defaultApplied, Decisions d) {
            this.id = id; this.key = key; this.column = column;
            this.oldValue = show(oldValue); this.newValue = show(newValue);
            this.note = note;
            this.defaultApplied = defaultApplied;
            this.applied = d.applies(id, defaultApplied);
        }
        public String getId() { return id; }
        public String getDomId() { return "r" + Integer.toHexString(id.hashCode()); }
        public String getKey() { return key; }
        public String getColumn() { return column; }
        public String getOldValue() { return oldValue; }
        public String getNewValue() { return newValue; }
        public String getNote() { return note; }
        public boolean isApplied() { return applied; }
        public boolean isChangedFromDefault() { return applied != defaultApplied; }
    }

    public static class DataView {
        private final DataPlan p;
        private final CompareRequest.DataSettings s;
        private final Decisions d;
        private final int page;
        public static final int PAGE = 100;

        public DataView(DataPlan p, CompareRequest.DataSettings s, Decisions d, int page) {
            this.p = p; this.s = s; this.d = d; this.page = page;
        }
        public String getTable() { return p.table; }
        public String getDomId() { return "t" + Integer.toHexString(p.table.hashCode()); }
        public String getBlocked() { return p.blocked; }
        public List<String> getNotes() { return p.notes; }
        public String getKey() { return String.join(", ", p.key); }
        public String getKeySetting() { return String.join(", ", s.key); }
        public String getIgnoreSetting() { return String.join(", ", s.ignore); }
        public String getFilter() { return s.filter == null ? "" : s.filter; }
        public boolean isScriptDeletes() { return s.scriptDeletes; }
        public int getSourceRows() { return p.sourceRows; }
        public int getTargetRows() { return p.targetRows; }
        public int getInsertCount() { return p.inserts.size(); }
        public int getUpdateCount() { return p.updates.size(); }
        public int getDeleteCount() { return p.deletes.size(); }
        public boolean isIdentical() { return p.blocked == null && !p.hasDifferences(); }
        public List<String> getColumns() {
            List<String> l = new ArrayList<>();
            if (p.definition != null) for (Model.Column c : p.definition.columns) l.add(c.name);
            return l;
        }
        public long getInsertsApplied() { return p.inserts.stream().filter(i -> d.applies(i.id(), i.conflict() == null)).count(); }
        public long getUpdatesApplied() { return p.updates.stream().filter(u -> d.applies(u.id(), true)).count(); }
        public long getDeletesApplied() { return p.deletes.stream().filter(x -> d.applies(x.id(), p.scriptDeletes)).count(); }

        public List<RowView> getUpdates() {
            List<RowView> l = new ArrayList<>();
            for (DataPlan.Update u : p.updates)
                l.add(new RowView(u.id(), u.keyText(), u.column(), u.oldValue(), u.newValue(),
                    u.whitespaceOnly() ? "spacing only" : null, true, d));
            return l;
        }
        public List<RowView> getInserts() {
            List<RowView> l = new ArrayList<>();
            int from = page * PAGE;
            for (int i = from; i < Math.min(p.inserts.size(), from + PAGE); i++) {
                DataPlan.Insert in = p.inserts.get(i);
                l.add(new RowView(in.id(), in.keyText(), null, null, null, in.conflict(), in.conflict() == null, d));
            }
            return l;
        }
        public List<RowView> getDeletes() {
            List<RowView> l = new ArrayList<>();
            for (DataPlan.Delete x : p.deletes) l.add(new RowView(x.id(), x.keyText(), null, null, null, null, p.scriptDeletes, d));
            return l;
        }
        public int getPage() { return page; }
        public int getPages() { return Math.max(1, (p.inserts.size() + PAGE - 1) / PAGE); }
        public boolean isHasPrev() { return page > 0; }
        public boolean isHasNext() { return (page + 1) * PAGE < p.inserts.size(); }
    }

    static String show(Object v) {
        if (v == null) return "NULL";
        String s = v.toString();
        return s.length() > 200 ? s.substring(0, 197) + "..." : s;
    }
}
