package dbpromote.web;

import jakarta.servlet.http.HttpSession;

import dbpromote.core.Change;
import dbpromote.core.CompareRequest;
import dbpromote.core.CompareRequest.TableChoice;
import dbpromote.core.Comparison;
import dbpromote.core.DataPlan;
import dbpromote.core.Snapshots;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Choosing tables, reviewing differences, deciding, and downloading scripts. */
@Controller
public class CompareController {

    private final HttpSession session;   // Spring injects a proxy that resolves the current session
    private final Store store;

    public CompareController(HttpSession session, Store store) {
        this.session = session;
        this.store = store;
    }

    // ================================================================ tables
    @GetMapping("/tables")
    public String tables(Model model) {
        if (!ws().connected()) return "redirect:/";
        model.addAttribute("ws", ws());
        model.addAttribute("rows", ws().tables.values());
        Map<String, Boolean> structure = new LinkedHashMap<>(), data = new LinkedHashMap<>();
        for (TableChoice c : ws().request.tables) { structure.put(c.table, c.structure); data.put(c.table, c.data); }
        model.addAttribute("structure", structure);
        model.addAttribute("data", data);
        model.addAttribute("error", takeError());
        return "tables";
    }

    @PostMapping("/tables")
    public String chooseTables(HttpServletRequest http,
                               @RequestParam(defaultValue = "false") boolean sequences,
                               @RequestParam(required = false) String sequencePattern) {
        if (!ws().connected()) return "redirect:/";
        List<TableChoice> chosen = new ArrayList<>();
        for (String t : ws().tables.keySet()) {
            boolean s = http.getParameter("s_" + t) != null, d = http.getParameter("d_" + t) != null;
            if (s || d) chosen.add(new TableChoice(t, s, d));
        }
        if (chosen.isEmpty()) { ws().lastError = "Choose at least one table."; return "redirect:/tables"; }
        ws().request.tables.clear();
        ws().request.tables.addAll(chosen);
        ws().request.sequences = sequences;
        ws().request.sequencePattern = sequencePattern == null || sequencePattern.isBlank() ? "%" : sequencePattern.trim().toUpperCase(Locale.ROOT);
        return read("/tables");
    }

    private String read(String onError) {
        try {
            ws().read();
        } catch (Exception e) {
            ws().lastError = "Reading failed: " + e.getMessage();
            return "redirect:" + onError;
        }
        return "redirect:/review";
    }

    // ================================================================ review
    @GetMapping("/review")
    public String review(Model model) {
        Comparison c = ws().comparison;
        if (c == null) return "redirect:/tables";
        model.addAttribute("ws", ws());
        model.addAttribute("groups", Views.structure(c, ws().decisions));
        List<Views.DataView> data = new ArrayList<>();
        for (DataPlan p : c.data.values()) data.add(new Views.DataView(p, ws().request.settings(p.table), ws().decisions, 0));
        model.addAttribute("data", data);
        model.addAttribute("warnings", c.warnings);
        model.addAttribute("broken", c.brokenDependencies(ws().decisions));
        model.addAttribute("missingParents", missingParents(c));
        summary(model);
        model.addAttribute("error", takeError());
        return "review";
    }

    /** Parent tables the selection depends on but did not include. */
    private List<String> missingParents(Comparison c) {
        Set<String> sel = ws().selected();
        Set<String> out = new LinkedHashSet<>();
        for (Change ch : c.changes)
            for (String r : ch.requires)
                if (r.startsWith("TABLE_ADD:") && !sel.contains(r.substring(10)) && ws().tables.containsKey(r.substring(10)))
                    out.add(r.substring(10));
        for (DataPlan p : c.data.values()) {
            if (p.definition == null) continue;
            for (dbpromote.core.Model.Constraint k : p.definition.constraints)
                if (k.type.equals("R") && !p.inserts.isEmpty() && !ws().request.dataTables().contains(k.refTable)
                    && ws().tables.containsKey(k.refTable)) out.add(k.refTable);
        }
        return new ArrayList<>(out);
    }

    private void summary(Model model) {
        Comparison c = ws().comparison;
        int applied = 0, review = 0, reviewApproved = 0, info = 0;
        for (Change ch : c.changes) {
            boolean a = ch.scriptable() && ws().decisions.applies(ch.id, ch.appliedByDefault());
            if (ch.category == Change.Category.INFO) info++;
            if (ch.category == Change.Category.REVIEW) { review++; if (a) reviewApproved++; }
            if (a) applied++;
        }
        long ins = 0, upd = 0, del = 0;
        for (DataPlan p : c.data.values()) {
            ins += p.inserts.stream().filter(i -> ws().decisions.applies(i.id(), i.conflict() == null)).count();
            upd += p.updates.stream().filter(u -> ws().decisions.applies(u.id(), true)).count();
            del += p.deletes.stream().filter(x -> ws().decisions.applies(x.id(), p.scriptDeletes)).count();
        }
        model.addAttribute("sApplied", applied);
        model.addAttribute("sReview", review);
        model.addAttribute("sReviewApproved", reviewApproved);
        model.addAttribute("sInfo", info);
        model.addAttribute("sIns", ins);
        model.addAttribute("sUpd", upd);
        model.addAttribute("sDel", del);
        model.addAttribute("sBroken", c.brokenDependencies(ws().decisions).size());
    }

    /** One decision: apply or skip a difference, with an optional reason. Returns the refreshed summary. */
    @PostMapping("/decide")
    public String decide(@RequestParam String id, @RequestParam(defaultValue = "false") boolean apply,
                         @RequestParam(required = false) String reason, Model model) {
        if (ws().comparison == null) return "redirect:/tables";
        ws().decisions.set(id, apply, reason == null || reason.isBlank() ? null : reason.trim(), user());
        summary(model);
        return "fragments :: summary";
    }

    @PostMapping("/data/{table}/settings")
    public String dataSettings(@PathVariable String table, @RequestParam(required = false) String key,
                               @RequestParam(required = false) String ignore, @RequestParam(required = false) String filter,
                               @RequestParam(defaultValue = "false") boolean scriptDeletes) {
        CompareRequest.DataSettings s = ws().request.settings(table);
        String oldFilter = s.filter == null ? "" : s.filter;
        s.key = csv(key);
        s.ignore = new LinkedHashSet<>(csv(ignore));
        s.filter = filter == null || filter.isBlank() ? null : filter.trim();
        s.scriptDeletes = scriptDeletes;
        if (!oldFilter.equals(s.filter == null ? "" : s.filter)) return read("/review");   // rows must be read again
        ws().compare();
        return "redirect:/review#" + "t" + Integer.toHexString(table.hashCode());
    }

    @PostMapping("/data/{table}/bulk")
    public String bulk(@PathVariable String table, @RequestParam String kind, @RequestParam boolean apply,
                       @RequestParam(required = false) String reason) {
        DataPlan p = ws().comparison == null ? null : ws().comparison.data.get(table);
        if (p == null) return "redirect:/review";
        String r = reason == null || reason.isBlank() ? null : reason.trim();
        switch (kind) {
            case "INS" -> p.inserts.forEach(i -> ws().decisions.set(i.id(), apply, r, user()));
            case "UPD" -> p.updates.forEach(u -> ws().decisions.set(u.id(), apply, r, user()));
            case "DEL" -> p.deletes.forEach(x -> ws().decisions.set(x.id(), apply, r, user()));
            default -> throw new IllegalArgumentException(kind);
        }
        return "redirect:/review#" + "t" + Integer.toHexString(table.hashCode());
    }

    @GetMapping("/data/{table}/inserts")
    public String insertsPage(@PathVariable String table, @RequestParam(defaultValue = "0") int page, Model model) {
        DataPlan p = ws().comparison.data.get(table);
        model.addAttribute("d", new Views.DataView(p, ws().request.settings(table), ws().decisions, page));
        return "fragments :: inserts";
    }

    /** Adds a table the selection depends on, then reads again. */
    @PostMapping("/add-table")
    public String addTable(@RequestParam String table, @RequestParam(defaultValue = "false") boolean data) {
        TableChoice c = ws().request.choice(table);
        if (c == null) ws().request.tables.add(new TableChoice(table, true, data));
        else { c.structure = true; c.data = c.data || data; }
        return read("/review");
    }

    @PostMapping("/reread")
    public String reread() { return read("/review"); }

    // ============================================================== outputs
    @GetMapping("/download")
    public ResponseEntity<byte[]> download() throws IOException {
        Comparison c = ws().comparison;
        Map<String, String> files = c.generate(ws().decisions, ws().source.label(), ws().target.label(), user());
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        String folder = folderName();
        try (ZipOutputStream zip = new ZipOutputStream(bytes)) {
            for (Map.Entry<String, String> e : files.entrySet()) {
                zip.putNextEntry(new ZipEntry(folder + "/" + e.getKey()));
                zip.write(e.getValue().getBytes(e.getKey().endsWith(".md") ? StandardCharsets.UTF_8 : StandardCharsets.US_ASCII));
                zip.closeEntry();
            }
        }
        return ResponseEntity.ok()
            .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(folder + ".zip").build().toString())
            .contentType(MediaType.APPLICATION_OCTET_STREAM)
            .body(bytes.toByteArray());
    }

    @GetMapping("/report")
    public ResponseEntity<String> report() {
        Map<String, String> files = ws().comparison.generate(ws().decisions, ws().source.label(), ws().target.label(), user());
        return ResponseEntity.ok().contentType(new MediaType("text", "markdown", StandardCharsets.UTF_8)).body(files.get("report.md"));
    }

    @GetMapping("/snapshot/{side}")
    public ResponseEntity<byte[]> snapshot(@PathVariable String side) {
        boolean src = side.equals("source");
        dbpromote.core.Model.Schema s = ws().snapshot(src);
        String name = (src ? ws().source.label() : ws().target.label()).replaceAll("[^A-Za-z0-9_-]", "_") + "_"
            + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm")) + ".json";
        return ResponseEntity.ok()
            .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(name).build().toString())
            .contentType(MediaType.APPLICATION_JSON)
            .body(Snapshots.toJson(s).getBytes(StandardCharsets.US_ASCII));
    }

    @PostMapping("/profile/save")
    public String saveProfile(@RequestParam String name) {
        if (name == null || name.isBlank()) { ws().lastError = "Give the profile a name."; return "redirect:/review"; }
        store.saveProfile(name.trim(), ws().request, ws().decisions,
            ws().source.def == null ? null : ws().source.def.getId(), ws().target.def == null ? null : ws().target.def.getId());
        ws().profileName = name.trim();
        return "redirect:/review";
    }

    // =============================================================== helpers
    private String folderName() {
        return "dbpromote_" + ws().source.label().replaceAll("[^A-Za-z0-9_-]", "_") + "_to_"
            + ws().target.label().replaceAll("[^A-Za-z0-9_-]", "_") + "_"
            + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"));
    }

    private static List<String> csv(String s) {
        if (s == null || s.isBlank()) return new ArrayList<>();
        List<String> out = new ArrayList<>();
        for (String x : Arrays.asList(s.split(","))) if (!x.isBlank()) out.add(x.trim().toUpperCase(Locale.ROOT));
        return out;
    }

    private static String user() { return System.getProperty("user.name"); }

    private String takeError() {
        String e = ws().lastError;
        ws().lastError = null;
        return e;
    }

    private Workspace ws() { return Workspace.of(session); }
}
