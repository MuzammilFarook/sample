package dbpromote.web;

import dbpromote.core.CompareRequest;
import dbpromote.core.Decisions;
import dbpromote.core.Json;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;

/**
 * Saved connections and profiles, as JSON files in a local folder
 * (default ~/.dbpromote). No passwords are ever written.
 */
@Component
public class Store {

    /** A saved selection with its data settings and standing decisions. */
    public record Profile(String name, CompareRequest request, Decisions decisions, String savedAt,
                          String sourceId, String targetId) {}

    private final Path base;

    public Store(@Value("${dbpromote.home:${user.home}/.dbpromote}") String home) {
        this.base = Path.of(home);
        try {
            Files.createDirectories(base.resolve("profiles"));
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot create " + base, e);
        }
    }

    public Path home() { return base; }

    // ------------------------------------------------------------ connections
    public synchronized List<ConnectionDef> connections() {
        Path f = base.resolve("connections.json");
        List<ConnectionDef> out = new ArrayList<>();
        if (!Files.exists(f)) return out;
        for (Object o : Json.arr(Json.parse(read(f)))) out.add(ConnectionDef.fromJson(Json.obj(o)));
        return out;
    }

    public ConnectionDef connection(String id) {
        for (ConnectionDef c : connections()) if (c.getId().equals(id)) return c;
        return null;
    }

    public synchronized void save(ConnectionDef c) {
        List<ConnectionDef> all = connections();
        if (c.getId() == null || c.getId().isBlank()) c.setId(UUID.randomUUID().toString());
        all.removeIf(x -> x.getId().equals(c.getId()));
        all.add(c);
        all.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        writeConnections(all);
    }

    public synchronized void deleteConnection(String id) {
        List<ConnectionDef> all = connections();
        all.removeIf(x -> x.getId().equals(id));
        writeConnections(all);
    }

    private void writeConnections(List<ConnectionDef> all) {
        List<Object> l = new ArrayList<>();
        for (ConnectionDef c : all) l.add(c.toJson());
        write(base.resolve("connections.json"), Json.write(l));
    }

    // --------------------------------------------------------------- profiles
    public synchronized List<String> profileNames() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(base.resolve("profiles"))) {
            s.filter(p -> p.toString().endsWith(".json")).sorted()
             .forEach(p -> out.add(Json.str(Json.obj(Json.parse(read(p))).get("name"))));
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        return out;
    }

    public synchronized Profile profile(String name) {
        Path f = profileFile(name);
        if (!Files.exists(f)) return null;
        Map<String, Object> m = Json.obj(Json.parse(read(f)));
        return new Profile(Json.str(m.get("name")), CompareRequest.fromJson(Json.obj(m.get("request"))),
            Decisions.fromJson(Json.obj(m.get("decisions"))), Json.str(m.get("savedAt")),
            Json.str(m.get("sourceId")), Json.str(m.get("targetId")));
    }

    public synchronized void saveProfile(String name, CompareRequest request, Decisions decisions,
                                         String sourceId, String targetId) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("name", name);
        m.put("savedAt", Instant.now().toString());
        m.put("sourceId", sourceId);
        m.put("targetId", targetId);
        m.put("request", request.toJson());
        m.put("decisions", decisions.toJson());
        write(profileFile(name), Json.write(m));
    }

    public synchronized void deleteProfile(String name) {
        try { Files.deleteIfExists(profileFile(name)); } catch (IOException e) { throw new UncheckedIOException(e); }
    }

    private Path profileFile(String name) {
        return base.resolve("profiles").resolve(name.replaceAll("[^A-Za-z0-9._-]", "_") + ".json");
    }

    // ------------------------------------------------------------------- io
    private static String read(Path f) {
        try { return Files.readString(f, StandardCharsets.UTF_8); } catch (IOException e) { throw new UncheckedIOException(e); }
    }

    private static void write(Path f, String s) {
        try {
            Path tmp = f.resolveSibling(f.getFileName() + ".tmp");
            Files.writeString(tmp, s, StandardCharsets.UTF_8);
            Files.move(tmp, f, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
