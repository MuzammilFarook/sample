# dbpromote

dbpromote compares two Oracle schemas. One is the **source of truth** (for example PREPROD) and the other is the **target** (for example PROD). It writes the scripts that make the target look like the source. You pick which tables to compare and whether to compare their **structure**, their **data**, or both.

Phase 1 is Oracle to Oracle only, and it runs on your own machine at `http://localhost:8080`.

## What it produces

You get a zip that contains:

| File | What it is |
|---|---|
| `01_ddl.sql` | Structural changes in a safe order: sequences, then new tables, columns, indexes, keys, checks, foreign keys and triggers. It starts with pre-flight queries and ends with verification queries. Anything you chose not to apply is listed at the end, commented out, with your reason. |
| `01_ddl_ROLLBACK.sql` | Undoes `01_ddl.sql`. |
| `02_data_NN_<TABLE>.sql` | One file per table with data changes, numbered so parent tables run before their children. Inserts, guarded updates and optional deletes. Pre-flight checks that parent rows exist. Fingerprint checks at the end. |
| `02_data_NN_<TABLE>_ROLLBACK.sql` | Undoes the data script for that table. |
| `report.md` | What was compared, what differs, what was decided and why, and the order to run the scripts in. |
| `decisions.json` | Every tick and untick, with the reason, who made it and when. |

Script rules:

- Scripts are ASCII only. Non-ASCII text is written with `UNISTR`.
- `COMMIT` is commented out, so the person running a script decides when to commit.
- Each `UPDATE` and `DELETE` only touches a row if that row still holds the old value. It stops with an error if it doesn't hit exactly one row.
- Nothing is dropped automatically. Columns that exist only in the target, and constraints that need a person to look at them, are marked **REVIEW**.

## Build

You need **Java 21** and **Maven 3.9+** (through your Nexus or Artifactory mirror). Spring Boot 3.3.5, Thymeleaf, HTMX and the Oracle driver (`ojdbc11`) are pulled in by the poms.

```
cd C:\Bismillah\AIB\DB_Comparison_Tool
mvn -DskipTests package
```

In IntelliJ, open the folder as a Maven project. It is a multi-module project:

- `dbpromote-core`: the comparison engine. Plain Java with no dependencies.
- `dbpromote-web`: the screens.

## Run

```
java -jar dbpromote-web\target\dbpromote.jar
```

Then open http://localhost:8080. In IntelliJ you can run `dbpromote.web.DbPromoteApplication` instead.

Saved environments and profiles are kept in `%USERPROFILE%\.dbpromote`. To keep them somewhere else, start the tool with `--dbpromote.home=D:\somewhere`. Passwords are never written to disk. They live only in the browser session.

## Using it

1. **Environments.** Add each database: a name, a JDBC URL such as `jdbc:oracle:thin:@//host:1521/SERVICE`, a user and a default schema. Use **Test connection** to check it. A read-only account is enough, because the tool only runs `SELECT` statements against the `ALL_*` dictionary views and the chosen tables. An environment can also be a **snapshot file** (.json) saved from an earlier run.
2. **Start.** Choose the source and the target, enter the passwords and click Connect.
3. **Tables.** Filter the list (`GRADE_*`). Tick **Structure** and/or **Data** for each table. Data comparison is meant for lookup and reference tables, up to 200,000 rows per table. Only the ticked tables are read.
4. **Review.**
   - **Structure differences** are grouped by table. Items marked AUTO are ticked by default, items marked REVIEW are not, and items marked INFO are notes only. Open **SQL** to see the exact statements and their pre-flight checks.
   - **Data differences** are shown per table: updates as old value next to new value, then inserts, then rows that exist only in the target.
   - **Matching settings** set the business key. When the key is left empty, the tool uses the primary key, or the only unique key if there is no primary key. You can also set columns to ignore, a row filter, and whether deletes are ticked by default.
   - Every tick or untick is saved immediately. Add a reason when you leave something out, because it ends up in the scripts and the report.
   - If a parent table is missing from your selection, the tool offers to add it.
5. **Download** the zip. **Save profile** keeps the table selection, the keys and every decision, so next release you only review what is new.

## Before trusting it on PROD

Do a known-answer run first. Point it at PREPROD (source) and DEV (target), where DEV was rebuilt from PROD for the November release. The counts should match what we found by hand for that release. Then run the scripts in DEV and check that the verification sections pass.

## Phase 1 limits

- Oracle to Oracle only. Azure SQL is a later phase.
- No login or encryption. It is for local use by the team.
- Data comparison reads whole tables into memory, which is fine for lookups and refuses anything over 200,000 rows. LONG, BLOB, RAW, XMLTYPE and object columns are not compared.
- Values cannot be changed during review, for example trimming spaces. You can apply or skip a change, but not edit it.
- Not covered yet: partitions, materialized views, views, packages, grants and synonyms.
