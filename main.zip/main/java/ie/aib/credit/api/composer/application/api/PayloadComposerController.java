
package ie.aib.credit.api.composer.application.api;

import ie.aib.credit.api.composer.application.service.CollateApiOrchestratorService;
import ie.aib.credit.api.composer.application.service.PayloadOrchestrationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("{region}/v1/api-composer")
@Slf4j
public class PayloadComposerController {

    private final PayloadOrchestrationService payloadOrchestrationService;
    private final CollateApiOrchestratorService collateApiOrchestratorService;

    @PostMapping({"/submit", "/submit/{actionCode}", "/submit/{actionCode}/{actionSubCode}"})
    public ResponseEntity<Map<String, Object>> composeAndSyncToCollate(
            @PathVariable(required = false) String actionCode,
            @PathVariable(required = false) String actionSubCode,
            @RequestBody Map<String, Object> requestBody
    ) {
        log.info("Processing request with actionCode: {}, actionSubCode: {}", actionCode, actionSubCode);

        var transformedPayload = payloadOrchestrationService.processData(requestBody, actionCode, actionSubCode);
        var apiResponse = collateApiOrchestratorService.sendToCollateWithResourceLookup(transformedPayload);

        log.info("Successfully processed request. Status: {}", apiResponse.get("status"));
        return ResponseEntity.ok(Map.of(
                "transformedPayload", transformedPayload,
                "collateApiResponse", apiResponse
        ));
    }
}
