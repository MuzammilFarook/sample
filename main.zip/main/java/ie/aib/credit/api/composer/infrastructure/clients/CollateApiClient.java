
package ie.aib.credit.api.composer.infrastructure.clients;

import java.util.Map;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "collate-api", url = "${collate.api.url}")
public interface CollateApiClient {

    @PutMapping("/save")
    ResponseEntity<String> callCollateApi(
            @RequestHeader("Authorization") String bearerToken,
            @RequestBody Map<String, Object> payload
    );
}
