
package ie.aib.credit.api.composer.config;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class FieldMappingConfig {

    private String apiPath;
    private List<String> apiPaths;
    private String translation;
    private String key;
    private boolean asKeyValuePair;
    private Map<String, Object> objectTemplate;
    private Map<String, FieldMappingConfig> actionMappings;
    private Map<String, FieldMappingConfig> subActions;
    private FieldEnrichmentConfig fieldEnrichmentConfig;

    /** Unified accessor used by composer. */
    public List<String> getAllApiPaths() {
        if (apiPaths != null && !apiPaths.isEmpty()) return apiPaths;
        if (apiPath != null && !apiPath.isBlank())   return List.of(apiPath);
        return Collections.emptyList();
    }
}
