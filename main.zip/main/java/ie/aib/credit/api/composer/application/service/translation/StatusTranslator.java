
package ie.aib.credit.api.composer.application.service.translation;

public class StatusTranslator implements FieldValueTranslator {

    @Override
    public Object translate(Object input) {
        return input != null ? input.toString().equalsIgnoreCase("RELE") ? "I" : "A" : null;
    }
}
