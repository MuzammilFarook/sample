
package ie.aib.credit.api.composer.application.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import ie.aib.credit.api.composer.infrastructure.clients.CollateApiClient;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class CollateApiOrchestratorService {

    private final KeycloakTokenService tokenService;
    private final CollateApiClient collateApiClient;
    private final ResourceLookupService resourceLookupService;
    private final ObjectMapper objectMapper;

    /**
     * Syncs data to Collate API.
     * Looks up existing resources and sends the payload to Collate.
     * Linking requests should be sent as separate API calls.
     */
    public Map<String, Object> sendToCollateWithResourceLookup(Map<String, Object> payload) {
        log.info("Executing Collate API sync.");

        log.info("Looking up existing resources...");
        var enrichedPayload = resourceLookupService.enrichWithExistingIds(payload);
        log.info("Resource lookup complete. Proceeding with API call.");

        var response = sendToCollate(enrichedPayload);
        var responseBody = parseResponseBody(response.getBody());

        var result = Map.of(
                "request", enrichedPayload,
                "response", responseBody,
                "statusCode", response.getStatusCode().value(),
                "status", response.getStatusCode().toString(),
                "timestamp", java.time.LocalDateTime.now().toString()
        );

        log.info("API call completed with status: {}", response.getStatusCode());
        return result;
    }

    /**
     * Sends payload to Collate API and returns the response.
     * Even in case of errors, returns the Collate API response as-is with the status code.
     */
    public ResponseEntity<String> sendToCollate(Map<String, Object> payload) {
        var bearerToken = "Bearer " + tokenService.getAccessToken();

        try {
            var payloadJson = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(payload);
            log.info("Sending payload to Collate API:\n{}", payloadJson);

            var response = collateApiClient.callCollateApi(bearerToken, payload);
            log.info("Collate API response status: {}", response.getStatusCode());
            log.debug("Collate API response body: {}", response.getBody());
            return response;

        } catch (FeignException feignEx) {
            var statusCode = feignEx.status();
            var responseBody = extractResponseBody(feignEx);

            log.error("Collate API returned error status {}: {}", statusCode, responseBody);
            return ResponseEntity.status(statusCode).body(responseBody);

        } catch (Exception ex) {
            log.error("Error calling Collate API: {}", ex.getMessage(), ex);

            var errorResponse = Map.of(
                    "error", "Failed to communicate with Collate API",
                    "message", ex.getMessage(),
                    "exceptionType", ex.getClass().getSimpleName(),
                    "timestamp", java.time.LocalDateTime.now().toString()
            );

            try {
                var errorBody = objectMapper.writeValueAsString(errorResponse);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorBody);
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("""
                                {"error":"Failed to communicate with Collate API"}
                                """);
            }
        }
    }

    /**
     * Extracts the response body from a FeignException
     */
    private String extractResponseBody(FeignException feignException) {
        return feignException.responseBody()
                .map(body -> new String(body.array(), StandardCharsets.UTF_8))
                .filter(content -> !content.isEmpty())
                .or(() -> Optional.ofNullable(feignException.contentUTF8()))
                .orElse("");
    }

    /**
     * Parse response body string into Map
     */
    private Map<String, Object> parseResponseBody(String responseBody) {
        if (responseBody == null || responseBody.trim().isEmpty()) {
            return Map.of();
        }

        try {
            return objectMapper.readValue(responseBody, new TypeReference<>() {});
        } catch (Exception e) {
            log.warn("Failed to parse response body as JSON. Returning raw string.", e);
            return Map.of("rawResponse", responseBody);
        }
    }
}
