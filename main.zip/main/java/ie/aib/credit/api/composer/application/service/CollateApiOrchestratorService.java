
package ie.aib.credit.api.composer.application.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import ie.aib.credit.api.composer.infrastructure.clients.CollateApiClient;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
@Slf4j
public class CollateApiOrchestratorService {

    private final KeycloakTokenService tokenService;
    private final CollateApiClient collateApiClient;
    private final ResourceLookupService resourceLookupService;
    private final ObjectMapper objectMapper;

    /**
     * Single-phase sync to Collate API.
     * Looks up existing resources and sends the payload to Collate.
     * Linking requests should be sent as separate API calls.
     */
    public Map<String, Object> sendToCollateWithResourceLookup(Map<String, Object> payload) {
        log.info("Executing single-phase API call.");

        // Lookup existing resources and enrich with IDs to prevent duplicates
        log.info("Looking up existing resources...");
        Map<String, Object> enrichedPayload = resourceLookupService.enrichWithExistingIds(payload);
        log.info("Resource lookup complete. Proceeding with API call.");

        // Send to Collate API
        ResponseEntity<String> response = sendToCollate(enrichedPayload);
        Map<String, Object> responseBody = parseResponseBody(response.getBody());

        // Build response
        Map<String, Object> result = new HashMap<>();
        result.put("request", enrichedPayload);
        result.put("response", responseBody);
        result.put("statusCode", response.getStatusCode().value());
        result.put("status", response.getStatusCode().toString());
        result.put("timestamp", java.time.LocalDateTime.now().toString());

        log.info("API call completed with status: {}", response.getStatusCode());
        return result;
    }

    /**
     * Sends payload to Collate API and returns the response.
     * Even in case of errors, returns the Collate API response as-is with the status code.
     */
    public ResponseEntity<String> sendToCollate(Map<String, Object> payload) {
        String token = tokenService.getAccessToken();
        String bearerToken = "Bearer " + token;

        try {
            // Log the payload as JSON
            String payloadJson = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(payload);
            log.info("Sending payload to Collate API:\n{}", payloadJson);

            ResponseEntity<String> response = collateApiClient.callCollateApi(bearerToken, payload);
            log.info("Collate API response status: {}", response.getStatusCode());
            log.debug("Collate API response body: {}", response.getBody());
            return response;

        } catch (FeignException feignException) {
            // Extract status code and response body from Feign exception
            int statusCode = feignException.status();
            String responseBody = extractResponseBody(feignException);

            log.error("Collate API returned error status {}: {}", statusCode, responseBody);

            // Return the actual Collate API error response with its status code
            return ResponseEntity.status(statusCode).body(responseBody);

        } catch (Exception exception) {
            // Handle non-Feign exceptions (e.g., network issues, JSON serialization errors)
            log.error("Error calling Collate API: {}", exception.getMessage(), exception);

            // Build a fallback error response
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "Failed to communicate with Collate API");
            errorResponse.put("message", exception.getMessage());
            errorResponse.put("exceptionType", exception.getClass().getSimpleName());
            errorResponse.put("timestamp", java.time.LocalDateTime.now().toString());

            try {
                String errorBody = objectMapper.writeValueAsString(errorResponse);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorBody);
            } catch (Exception e) {
                // Last resort fallback
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("{\"error\":\"Failed to communicate with Collate API\"}");
            }
        }
    }

    /**
     * Extracts the response body from a FeignException
     */
    private String extractResponseBody(FeignException feignException) {
        try {
            byte[] content = feignException.responseBody()
                    .map(body -> body.array())
                    .orElse(new byte[0]);

            if (content.length > 0) {
                return new String(content, StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            log.warn("Failed to extract response body from FeignException", e);
        }

        // Fallback: try to get from exception message
        return feignException.contentUTF8();
    }

    /**
     * Parse response body string into Map
     */
    private Map<String, Object> parseResponseBody(String responseBody) {
        if (responseBody == null || responseBody.trim().isEmpty()) {
            return new HashMap<>();
        }

        try {
            return objectMapper.readValue(responseBody, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) {
            log.warn("Failed to parse response body as JSON. Returning raw string.", e);
            Map<String, Object> fallback = new HashMap<>();
            fallback.put("rawResponse", responseBody);
            return fallback;
        }
    }
}
