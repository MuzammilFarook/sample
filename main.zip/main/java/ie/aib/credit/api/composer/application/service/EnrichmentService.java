
package ie.aib.credit.api.composer.application.service;

import ie.aib.credit.api.composer.config.EnrichmentApiCall;
import java.util.List;
import java.util.Map;

public interface EnrichmentService {

    Map<String, Object> enrich(String inputValue, List<EnrichmentApiCall> enrichmentApiCalls);
}
