
package ie.aib.credit.api.composer.application.service.translation;

public interface FieldValueTranslator {
    Object translate(Object input);
}
