package ie.aib.credit.api.composer.config;

import java.util.Map;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "api-mappings")
@RefreshScope
@Data
public class MappingConfigProperties {

    private Map<String, Map<String, FieldMappingConfig>> mappings;

}
