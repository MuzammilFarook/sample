
package ie.aib.credit.api.composer.config;

import lombok.Data;

@Data
public class EnrichmentApiCall {

    private String url;
    private String responsePath;
    private String fieldAs;

}
