
package ie.aib.credit.api.composer.application.service.translation;

public class UppercaseTranslator implements FieldValueTranslator {

    @Override
    public Object translate(Object input) {
        return input != null ? input.toString().toUpperCase() : null;
    }
}
