
package ie.aib.credit.api.composer.application.service;

import ie.aib.credit.api.composer.config.KeycloakProperties;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
@RequiredArgsConstructor
public class KeycloakTokenService {

    private final KeycloakProperties keycloakProperties;

    public String getAccessToken() {
        var webClient = WebClient.create();

        var form = Map.of(
                "grant_type", "client_credentials",
                "client_id", keycloakProperties.getClientId(),
                "client_secret", keycloakProperties.getClientSecret()
        );

        return webClient.post()
                .uri(keycloakProperties.getTokenUrl())
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .bodyValue(form.entrySet().stream()
                        .map(e -> e.getKey() + "=" + e.getValue())
                        .collect(Collectors.joining("&"))
                )
                .retrieve()
                .bodyToMono(Map.class)
                .map(resp -> (String) resp.get("access_token"))
                .block();
    }
}
