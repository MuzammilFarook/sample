
package ie.aib.credit.api.composer.application.service;

import ie.aib.credit.api.composer.config.MappingConfigProperties;
import ie.aib.credit.api.composer.application.service.translation.TranslationRegistry;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PayloadOrchestrationService {

    private final PayloadComposer builder;

    @Autowired
    public PayloadOrchestrationService(MappingConfigProperties properties, TranslationRegistry registry,
            EnrichmentService enrichment) {
        this.builder = new PayloadComposer(properties.getMappings(), registry, enrichment);
    }

    public Map<String, Object> processData(Map<String, Object> rowData, String actionCode, String actionSubCode) {
        return builder.build(rowData, actionCode, actionSubCode);
    }
}
