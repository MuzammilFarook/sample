
package ie.aib.credit.api.composer.application.service;

import ie.aib.credit.api.composer.config.MappingConfigProperties;
import ie.aib.credit.api.composer.application.service.translation.TranslationRegistry;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PayloadOrchestrationService {

    private final MappingConfigProperties properties;
    private final TranslationRegistry registry;
    private final EnrichmentService enrichment;

    public Map<String, Object> processData(Map<String, Object> rowData, String actionCode, String actionSubCode) {
        return new PayloadComposer(properties.getMappings(), registry, enrichment)
                .build(rowData, actionCode, actionSubCode);
    }
}
