
package ie.aib.credit.api.composer.application.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.*;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

/**
 * Service to check if resources already exist in Collate system via GET endpoints.
 * If a resource exists, attaches its ID to avoid duplication.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ResourceLookupService {

    private final RestTemplate restTemplate;
    private final KeycloakTokenService tokenService;
    private final ObjectMapper objectMapper;
    private final ie.aib.credit.api.composer.config.CollateApiProperties collateApiProperties;

    private String getCollateBaseUrl() {
        return collateApiProperties.getUrl();
    }

    /**
     * Enriches payload by looking up existing resources and attaching their IDs.
     *
     * @param payload The payload containing resources to be created
     * @return Updated payload with existing IDs attached where resources already exist
     */
    public Map<String, Object> enrichWithExistingIds(Map<String, Object> payload) {
        if (payload == null || payload.isEmpty()) {
            log.info("Payload is empty. Nothing to enrich.");
            return payload;
        }

        log.info("Starting resource lookup. Entity types: {}", payload.keySet());
        var bearerToken = "Bearer " + tokenService.getAccessToken();

        Map<String, Object> enrichedPayload = payload.entrySet().stream()
                .collect(HashMap::new,
                        (map, entry) -> map.put(entry.getKey(),
                            switch (entry.getValue()) {
                                case List<?> list -> lookupAndEnrichEntities(entry.getKey(), list, bearerToken);
                                default -> entry.getValue();
                            }),
                        HashMap::putAll);

        log.info("Resource lookup complete. Enriched payload ready.");
        return enrichedPayload;
    }

    /**
     * Looks up existing resources for a list of entities and enriches them with IDs if found
     */
    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> lookupAndEnrichEntities(String entityType, List<?> entities,
            String bearerToken) {

        var enrichedEntities = entities.stream()
                .filter(Map.class::isInstance)
                .map(entity -> (Map<String, Object>) entity)
                .map(HashMap::new)
                .map(entityMap -> enrichEntityWithId(entityType, entityMap, bearerToken))
                .toList();

        var foundCount = enrichedEntities.stream()
                .filter(entity -> entity.containsKey("id") && entity.get("id") != null)
                .count();

        log.info("Lookup for {}: {} out of {} resources already exist", entityType, foundCount, entities.size());
        return enrichedEntities;
    }

    /**
     * Enriches a single entity with existing ID if found, otherwise removes ID field
     */
    private Map<String, Object> enrichEntityWithId(String entityType, Map<String, Object> entityMap,
            String bearerToken) {
        // Skip if entity already has an ID
        if (entityMap.containsKey("id") && entityMap.get("id") != null) {
            return entityMap;
        }

        // Try to find existing resource by refs
        return findExistingResourceByRefs(entityType, entityMap, bearerToken)
                .map(existingId -> {
                    entityMap.put("id", existingId);
                    log.info("Found existing {} with ID: {}", entityType, existingId);
                    return entityMap;
                })
                .orElseGet(() -> {
                    log.debug("No existing {} found. Will be created as new resource.", entityType);
                    entityMap.remove("id");
                    return entityMap;
                });
    }

    /**
     * Finds an existing resource by searching using reference values (refs[])
     */
    @SuppressWarnings("unchecked")
    private Optional<String> findExistingResourceByRefs(String entityType, Map<String, Object> entityMap,
                                                        String bearerToken) {

        return switch (entityMap.get("refs")) {
            case null -> Optional.empty();
            case List<?> refsList -> {
                var refs = (List<Map<String, Object>>) refsList;

                // Try primary references first
                var primaryResult = refs.stream()
                        .filter(ref -> Boolean.TRUE.equals(ref.get("primary")))
                        .map(ref -> queryCollateByReference(entityType,
                                (String) ref.get("source"),
                                (String) ref.get("value"),
                                bearerToken))
                        .flatMap(Optional::stream)
                        .findFirst();

                // If no primary found, try all references
                yield primaryResult.or(() -> refs.stream()
                        .map(ref -> queryCollateByReference(entityType,
                                (String) ref.get("source"),
                                (String) ref.get("value"),
                                bearerToken))
                        .flatMap(Optional::stream)
                        .findFirst());
            }
            default -> Optional.empty();
        };
    }

    /**
     * Queries Collate API to find a resource by reference source and value
     */
    private Optional<String> queryCollateByReference(String entityType, String source, String value,
            String bearerToken) {
        if (source == null || value == null) {
            return Optional.empty();
        }

        return buildSearchUrl(entityType, source, value)
                .flatMap(searchUrl -> {
                    try {
                        log.debug("Searching for existing {}: {}|{} at {}", entityType, source, value, searchUrl);

                        var headers = new HttpHeaders();
                        headers.set("Authorization", bearerToken);
                        var requestEntity = new HttpEntity<String>(headers);

                        var response = restTemplate.exchange(searchUrl, HttpMethod.GET, requestEntity, String.class);

                        return response.getStatusCode().is2xxSuccessful() && response.getBody() != null
                                ? extractIdFromSearchResponse(response.getBody(), source, value)
                                : Optional.empty();

                    } catch (HttpClientErrorException.NotFound e) {
                        log.debug("Resource not found for {}|{} in {}", source, value, entityType);
                        return Optional.empty();
                    } catch (Exception e) {
                        log.warn("Error querying Collate for {}|{}: {}", source, value, e.getMessage());
                        return Optional.empty();
                    }
                });
    }

    /**
     * Builds the search URL for different entity types
     */
    private Optional<String> buildSearchUrl(String entityType, String source, String value) {
        var endpoint = switch (entityType) {
            case "legalEntitiesPersonal", "legalEntitiesJuristic", "legalEntitiesServiceProviders" ->
                    "/legal-entities";
            case "assetLifeInsurances", "assetCash", "assetRealEstates", "assetMiscellaneous" ->
                    "/assets";
            case "legalEnforceableDocumentSecurityInterests", "legalEnforceableDocumentGuarantees" ->
                    "/legal-enforceable-documents";
            case "collections" -> "/collections";
            case "facilities" -> "/facilities";
            case "generalInsurances" -> "/general-insurances";
            case "addresses" -> "/addresses";
            case "documents" -> "/documents";
            case "folders" -> "/folders";
            default -> {
                log.warn("No search endpoint mapping for entity type: {}", entityType);
                yield null;
            }
        };

        return Optional.ofNullable(endpoint)
                .map(ep -> "%s%s?source=%s&value=%s".formatted(getCollateBaseUrl(), ep, source, value));
    }

    /**
     * Extracts the ID from Collate search response
     */
    @SuppressWarnings("unchecked")
    private Optional<String> extractIdFromSearchResponse(String responseBody, String source, String value) {
        try {
            var response = objectMapper.readValue(responseBody, new TypeReference<Map<String, Object>>() {});

            return switch (response.get("data")) {
                // Handle array response (list of matching resources)
                case List<?> list when !list.isEmpty() -> {
                    var results = (List<Map<String, Object>>) list;
                    yield Optional.ofNullable(results.getFirst().get("id"))
                            .map(Object::toString);
                }
                // No data array, check for direct id field
                case null -> Optional.ofNullable(response.get("id"))
                        .map(Object::toString);
                default -> Optional.empty();
            };

        } catch (Exception e) {
            log.warn("Failed to parse search response for {}|{}: {}", source, value, e.getMessage());
            return Optional.empty();
        }
    }
}
