
package ie.aib.credit.api.composer.application.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

/**
 * Service to check if resources already exist in Collate system via GET endpoints.
 * If a resource exists, attaches its ID to avoid duplication.
 */
@Service
@Slf4j
public class ResourceLookupService {

    private final RestTemplate restTemplate;
    private final KeycloakTokenService tokenService;
    private final ObjectMapper objectMapper;
    private final String collateBaseUrl;

    public ResourceLookupService(RestTemplate restTemplate,
            KeycloakTokenService tokenService,
            ObjectMapper objectMapper,
            ie.aib.credit.api.composer.config.CollateApiProperties collateApiProperties) {
        this.restTemplate = restTemplate;
        this.tokenService = tokenService;
        this.objectMapper = objectMapper;
        this.collateBaseUrl = collateApiProperties.getUrl();
    }

    /**
     * Enriches Phase 1 payload by looking up existing resources and attaching their IDs.
     *
     * @param phase1Payload The payload containing resources to be created
     * @return Updated payload with existing IDs attached where resources already exist
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> enrichWithExistingIds(Map<String, Object> phase1Payload) {
        if (phase1Payload == null || phase1Payload.isEmpty()) {
            log.info("Phase 1 payload is empty. Nothing to enrich.");
            return phase1Payload;
        }

        log.info("Starting resource lookup for Phase 1 payload. Entity types: {}", phase1Payload.keySet());

        String bearerToken = "Bearer " + tokenService.getAccessToken();
        Map<String, Object> enrichedPayload = new HashMap<>();

        phase1Payload.forEach((entityType, value) -> {
            if (value instanceof List) {
                List<Map<String, Object>> enrichedEntities = lookupAndEnrichEntities(entityType,
                        (List<?>) value, bearerToken);
                enrichedPayload.put(entityType, enrichedEntities);
            } else {
                enrichedPayload.put(entityType, value);
            }
        });

        log.info("Resource lookup complete. Enriched payload ready.");
        return enrichedPayload;
    }

    /**
     * Looks up existing resources for a list of entities and enriches them with IDs if found
     */
    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> lookupAndEnrichEntities(String entityType, List<?> entities,
            String bearerToken) {

        List<Map<String, Object>> enrichedEntities = new ArrayList<>();
        int foundCount = 0;

        for (Object entity : entities) {
            if (!(entity instanceof Map)) {
                continue;
            }

            Map<String, Object> entityMap = new HashMap<>((Map<String, Object>) entity);

            // Skip if entity already has an ID (already resolved)
            if (entityMap.containsKey("id") && entityMap.get("id") != null) {
                enrichedEntities.add(entityMap);
                continue;
            }

            // Try to find existing resource by refs
            String existingId = findExistingResourceByRefs(entityType, entityMap, bearerToken);

            if (existingId != null) {
                entityMap.put("id", existingId);
                foundCount++;
                log.info("Found existing {} with ID: {}", entityType, existingId);
            } else {
                log.debug("No existing {} found. Will be created as new resource.", entityType);
                // Ensure no 'id' field exists so Collate auto-generates one
                entityMap.remove("id");
            }

            enrichedEntities.add(entityMap);
        }

        log.info("Lookup for {}: {} out of {} resources already exist", entityType, foundCount, entities.size());
        return enrichedEntities;
    }

    /**
     * Finds an existing resource by searching using reference values (refs[])
     */
    @SuppressWarnings("unchecked")
    private String findExistingResourceByRefs(String entityType, Map<String, Object> entityMap, String bearerToken) {
        Object refsObj = entityMap.get("refs");

        if (!(refsObj instanceof List)) {
            return null;
        }

        List<Map<String, Object>> refs = (List<Map<String, Object>>) refsObj;

        // Try to find by primary reference first
        for (Map<String, Object> ref : refs) {
            Boolean primary = (Boolean) ref.get("primary");
            if (Boolean.TRUE.equals(primary)) {
                String source = (String) ref.get("source");
                String value = (String) ref.get("value");

                if (source != null && value != null) {
                    String existingId = queryCollateByReference(entityType, source, value, bearerToken);
                    if (existingId != null) {
                        return existingId;
                    }
                }
            }
        }

        // If no primary found, try all references
        for (Map<String, Object> ref : refs) {
            String source = (String) ref.get("source");
            String value = (String) ref.get("value");

            if (source != null && value != null) {
                String existingId = queryCollateByReference(entityType, source, value, bearerToken);
                if (existingId != null) {
                    return existingId;
                }
            }
        }

        return null;
    }

    /**
     * Queries Collate API to find a resource by reference source and value
     */
    private String queryCollateByReference(String entityType, String source, String value, String bearerToken) {
        try {
            // Build search endpoint URL
            String searchUrl = buildSearchUrl(entityType, source, value);

            if (searchUrl == null) {
                return null;
            }

            log.debug("Searching for existing {}: {}|{} at {}", entityType, source, value, searchUrl);

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", bearerToken);
            HttpEntity<String> requestEntity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    searchUrl,
                    HttpMethod.GET,
                    requestEntity,
                    String.class
            );

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                return extractIdFromSearchResponse(response.getBody(), source, value);
            }

        } catch (HttpClientErrorException.NotFound e) {
            log.debug("Resource not found for {}|{} in {}", source, value, entityType);
        } catch (Exception e) {
            log.warn("Error querying Collate for {}|{}: {}", source, value, e.getMessage());
        }

        return null;
    }

    /**
     * Builds the search URL for different entity types
     */
    private String buildSearchUrl(String entityType, String source, String value) {
        // Map entity types to their search endpoints
        switch (entityType) {
            case "legalEntitiesPersonal":
            case "legalEntitiesJuristic":
            case "legalEntitiesServiceProviders":
                return collateBaseUrl + "/legal-entities?source=" + source + "&value=" + value;

            case "assetLifeInsurances":
            case "assetCash":
            case "assetRealEstates":
            case "assetMiscellaneous":
                return collateBaseUrl + "/assets?source=" + source + "&value=" + value;

            case "legalEnforceableDocumentSecurityInterests":
            case "legalEnforceableDocumentGuarantees":
                return collateBaseUrl + "/legal-enforceable-documents?source=" + source + "&value=" + value;

            case "collections":
                return collateBaseUrl + "/collections?source=" + source + "&value=" + value;

            case "facilities":
                return collateBaseUrl + "/facilities?source=" + source + "&value=" + value;

            case "generalInsurances":
                return collateBaseUrl + "/general-insurances?source=" + source + "&value=" + value;

            case "addresses":
                return collateBaseUrl + "/addresses?source=" + source + "&value=" + value;

            case "documents":
                return collateBaseUrl + "/documents?source=" + source + "&value=" + value;

            case "folders":
                return collateBaseUrl + "/folders?source=" + source + "&value=" + value;

            default:
                log.warn("No search endpoint mapping for entity type: {}", entityType);
                return null;
        }
    }

    /**
     * Extracts the ID from Collate search response
     */
    @SuppressWarnings("unchecked")
    private String extractIdFromSearchResponse(String responseBody, String source, String value) {
        try {
            Map<String, Object> response = objectMapper.readValue(responseBody, new TypeReference<>() {});

            // Handle array response (list of matching resources)
            if (response.containsKey("data") && response.get("data") instanceof List) {
                List<Map<String, Object>> results = (List<Map<String, Object>>) response.get("data");

                if (!results.isEmpty()) {
                    // Return the first matching resource ID
                    Map<String, Object> firstResult = results.get(0);
                    Object id = firstResult.get("id");
                    return id != null ? id.toString() : null;
                }
            }

            // Handle single object response
            if (response.containsKey("id")) {
                Object id = response.get("id");
                return id != null ? id.toString() : null;
            }

        } catch (Exception e) {
            log.warn("Failed to parse search response for {}|{}: {}", source, value, e.getMessage());
        }

        return null;
    }
}
