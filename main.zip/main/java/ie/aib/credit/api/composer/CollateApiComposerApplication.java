package ie.aib.credit.api.composer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication(scanBasePackages = {"ie.aib.credit"})
@EnableFeignClients
public class CollateApiComposerApplication {

    public static void main(String[] args) {
        SpringApplication.run(CollateApiComposerApplication.class, args);
    }
}
