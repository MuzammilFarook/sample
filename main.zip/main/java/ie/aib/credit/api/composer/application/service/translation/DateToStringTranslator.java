
package ie.aib.credit.api.composer.application.service.translation;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateToStringTranslator implements FieldValueTranslator {

    @Override
    public Object translate(Object input) {
        if (input instanceof LocalDate) {
            return ((LocalDate) input).format(DateTimeFormatter.ISO_DATE);
        }
        return input;
    }
}
