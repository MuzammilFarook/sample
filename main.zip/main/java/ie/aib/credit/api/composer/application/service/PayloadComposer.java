
package ie.aib.credit.api.composer.application.service;


import ie.aib.credit.api.composer.application.service.translation.TranslationRegistry;
import ie.aib.credit.api.composer.config.FieldMappingConfig;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public class PayloadComposer {

    private final Map<String, Map<String, FieldMappingConfig>> config;
    private final TranslationRegistry translationRegistry;
    private final EnrichmentService enrichmentService;

    // --- Index-aware injection wrappers ---
    public void injectIntoRequestAtIndex(Map<String, Object> root, String path, Object value, int index) {
        navigateAndInsert(root, path, value, null, false, index);
    }

    public void injectKeyValueIntoPathAtIndex(Map<String, Object> root, String path, String key, Object value,
            boolean asKeyValuePair, int index) {
        navigateAndInsert(root, path, value, key, asKeyValuePair, index);
    }

    // Keep the original wrappers, but route to the 6-arg variant with null index
    public void injectIntoRequest(Map<String, Object> root, String path, Object value) {
        navigateAndInsert(root, path, value, null, false, null);
    }


    public void injectKeyValueIntoPath(Map<String, Object> root, String path, String key, Object value,
            boolean asKeyValuePair) {
        navigateAndInsert(root, path, value, key, asKeyValuePair, null);
    }

    // Ensure a list has an object at the given index and return it
    @SuppressWarnings("unchecked")
    private static Map<String, Object> ensureListIndex(List<Object> list, int index) {
        while (list.size() <= index) list.add(new HashMap<>());
        Object at = list.get(index);
        if (!(at instanceof Map)) {
            at = new HashMap<>();
            list.set(index, at);
        }
        return (Map<String, Object>) at;
    }


    public static Object getValueFromNestedMap(Map<String, Object> map, String fullKey) {
        String[] parts = fullKey.split("\\.");
        Object current = map;

        for (String part : parts) {
            if (current == null) return null;

            // If at a List, apply recursively to each element
            if (current instanceof List<?> list) {
                List<Object> results = new ArrayList<>();
                for (Object elem : list) {
                    if (elem instanceof Map<?, ?> elemMap) {
                        Object v = getValueFromNestedMap((Map<String, Object>) elemMap, String.join(".", Arrays.copyOfRange(parts, 1, parts.length)));
                        if (v != null) results.add(v);
                    }
                }
                if (results.size() == 1) return results.get(0);
                return results.isEmpty() ? null : results;
            }

            if (current instanceof Map<?, ?> mapObj) {
                current = mapObj.get(part);
            } else {
                return null;
            }
        }
        return current;
    }

    public Map<String, Object> build(Map<String, Object> dbRowMap, String actionCode, String actionSubCode) {
        Map<String, Object> requestBody = new HashMap<>();

        config.forEach((tableName, columnMappings) -> {
            Object section = dbRowMap.get(tableName);

            // ---- FAN-OUT: when the table section is a list, write one target element per source element ----
            if (section instanceof List<?> srcList) {
                for (int i = 0; i < srcList.size(); i++) {
                    final int idx = i; // <-- add this line

                    Object el = srcList.get(idx);
                    if (!(el instanceof Map<?, ?> elMapRaw)) continue;
                    Map<String, Object> elMap = (Map<String, Object>) elMapRaw;

                    columnMappings.forEach((columnName, baseMapping) -> {
                        FieldMappingConfig mapping = resolveMapping(baseMapping, actionCode, actionSubCode);
                        if (mapping == null || mapping.getAllApiPaths().isEmpty()) return;

                        // read from THIS element only
                        Object rawValue = getValueFromNestedMap(elMap, columnName);
                        if (rawValue == null) return;

                        if (mapping.getFieldEnrichmentConfig() != null) {
                            Map<String, Object> enriched = enrichmentService.enrich(
                                    rawValue.toString(),
                                    mapping.getFieldEnrichmentConfig().getApis()
                            );
                            if (enriched == null) enriched = Collections.emptyMap();

                            Map<String, Object> finalEnriched = enriched;
                            Map<String, Object> enrichedObject = mapping.getFieldEnrichmentConfig().getObjectTemplate()
                                    .entrySet()
                                    .stream()
                                    .collect(Collectors.toMap(Map.Entry::getKey, entry -> {
                                        Object v = entry.getValue();
                                        if (v instanceof String s && s.startsWith("$")) {
                                            return finalEnriched.getOrDefault(s.substring(1), null);
                                        }
                                        return v;
                                    }));

                            for (String path : mapping.getAllApiPaths()) {
                                injectIntoRequestAtIndex(requestBody, path, enrichedObject, idx); // use idx
                            }
                            return;
                        }

                        Object translated = translationRegistry.get(mapping.getTranslation()).translate(rawValue);
                        if (translated == null) return;

                        if (mapping.getObjectTemplate() != null) {
                            handleObjectTemplateInjectionWithIndex(requestBody, mapping, translated, idx); // use idx
                        } else if (mapping.isAsKeyValuePair()) {
                            for (String path : mapping.getAllApiPaths()) {
                                injectKeyValueIntoPathAtIndex(requestBody, path, mapping.getKey(), translated, true, idx); // use idx
                            }
                        } else {
                            for (String path : mapping.getAllApiPaths()) {
                                injectIntoRequestAtIndex(requestBody, path, translated, idx); // use idx
                            }
                        }
                    });
                }
                return;
            }


            // ---- Original behavior (single object or missing section) ----
            columnMappings.forEach((columnName, baseMapping) -> {
                FieldMappingConfig mapping = resolveMapping(baseMapping, actionCode, actionSubCode);
                if (mapping == null || mapping.getAllApiPaths().isEmpty()) return;

                String fullKey = tableName + "." + columnName;
                Object rawValue = getValueFromNestedMap(dbRowMap, fullKey);
                if (rawValue == null) return;

                // Enrichment Handling
                if (mapping.getFieldEnrichmentConfig() != null) {
                    Map<String, Object> enriched = enrichmentService.enrich(rawValue.toString(),
                            mapping.getFieldEnrichmentConfig().getApis());
                    if (enriched == null) {
                        enriched = Collections.emptyMap();
                    }
                    Map<String, Object> finalEnriched = enriched;
                    Map<String, Object> enrichedObject = mapping.getFieldEnrichmentConfig().getObjectTemplate().entrySet()
                            .stream()
                            .collect(Collectors.toMap(Map.Entry::getKey, entry -> {
                                Object v = entry.getValue();
                                if (v instanceof String s && s.startsWith("$")) {
                                    return finalEnriched.getOrDefault(s.substring(1), null);
                                }
                                return v;
                            }));

                    for (String path : mapping.getAllApiPaths()) {
                        injectIntoRequest(requestBody, path, enrichedObject);
                    }
                    return;
                }

                Object translated = translationRegistry.get(mapping.getTranslation()).translate(rawValue);
                if (translated == null) {
                    return;
                }

                if (mapping.getObjectTemplate() != null) {
                    handleObjectTemplateInjection(requestBody, mapping, translated);
                } else if (mapping.isAsKeyValuePair()) {
                    for (String path : mapping.getAllApiPaths()) {
                        injectKeyValueIntoPath(requestBody, path, mapping.getKey(), translated, true);
                    }
                } else {
                    for (String path : mapping.getAllApiPaths()) {
                        injectIntoRequest(requestBody, path, translated);
                    }
                }
            });
        });

        return requestBody;
    }

    private void handleObjectTemplateInjectionWithIndex(Map<String, Object> requestBody,
            FieldMappingConfig mapping,
            Object translated,
            int fixedIndex) {
        if (translated instanceof List<?> list) {
            // Preserve your existing "expand translated list" behavior (append mode)
            for (int i = 0; i < list.size(); i++) {
                Object item = list.get(i);
                boolean isFirst = (i == 0);

                Map<String, Object> obj = mapping.getObjectTemplate().entrySet().stream()
                        .collect(Collectors.toMap(
                                Map.Entry::getKey,
                                tpl -> {
                                    Object v = tpl.getValue();
                                    if (v instanceof String s) {
                                        if (s.equals("$input")) return item;
                                        if (s.equals("$isFirst")) return isFirst;
                                        return s;
                                    }
                                    return normalizeYamlSequences(v);
                                }
                        ));
                for (String path : mapping.getAllApiPaths()) {
                    // Append, do not bind index when translated is a list
                    injectIntoRequest(requestBody, path, obj);
                }
            }
        } else {
            // Scalar per element -> bind to this element's index
            Map<String, Object> obj = mapping.getObjectTemplate().entrySet().stream()
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            tpl -> {
                                Object v = tpl.getValue();
                                if (v instanceof String str) {
                                    if (str.contains("$input")) {
                                        return str.replace("$input", translated.toString());
                                    }
                                    if (str.equals("$isFirst")) {
                                        return true;
                                    }
                                    return str;
                                }
                                return normalizeYamlSequences(v);
                            }
                    ));
            for (String path : mapping.getAllApiPaths()) {
                injectIntoRequestAtIndex(requestBody, path, obj, fixedIndex);
            }
        }
    }


    private FieldMappingConfig resolveMapping(FieldMappingConfig baseMapping, String actionCode, String actionSubCode) {
        if (baseMapping.getActionMappings() == null) {
            return baseMapping;
        }

        FieldMappingConfig mapping = baseMapping.getActionMappings()
                .getOrDefault(actionCode, baseMapping.getActionMappings().get("DEFAULT"));

        if (mapping != null && mapping.getSubActions() != null && actionSubCode != null && mapping.getSubActions()
                .containsKey(actionSubCode)) {
            return mapping.getSubActions().get(actionSubCode);
        }

        return mapping;
    }

    private void handleObjectTemplateInjection(Map<String, Object> requestBody, FieldMappingConfig mapping,
            Object translated) {
        if (translated instanceof List<?> list) {
            for (int i = 0; i < list.size(); i++) {
                Object item = list.get(i);
                boolean isFirst = (i == 0);

                Map<String, Object> obj = mapping.getObjectTemplate().entrySet().stream()
                        .collect(Collectors.toMap(
                                Map.Entry::getKey,
                                tpl -> {
                                    Object v = tpl.getValue();
                                    if (v instanceof String s) {
                                        if (s.equals("$input")) return item;
                                        if (s.equals("$isFirst")) return isFirst;
                                        return s;
                                    }
                                    return normalizeYamlSequences(v);
                                }
                        ));
                for (String path : mapping.getAllApiPaths()) {
                    injectIntoRequest(requestBody, path, obj);
                }
            }

        } else {
            Map<String, Object> obj = mapping.getObjectTemplate().entrySet().stream()
                    .collect(Collectors.toMap(
                            Map.Entry::getKey,
                            tpl -> {
                                Object v = tpl.getValue();
                                if (v instanceof String str) {
                                    if (str.contains("$input")) {
                                        return str.replace("$input", translated.toString());
                                    }
                                    if (str.equals("$isFirst")) {
                                        // Non-list injection => treat as the first (true)
                                        return true;
                                    }
                                    return str;
                                }
                                return normalizeYamlSequences(v);
                            }
                    ));
            for (String path : mapping.getAllApiPaths()) {
                injectIntoRequest(requestBody, path, obj);
            }
        }
    }

    @SuppressWarnings({"unchecked", "unchecked"})
    private void navigateAndInsert(Map<String, Object> root, String path, Object value, String key,
            boolean asKeyValuePair, Integer fixedIndex) {
        if (path == null || path.isBlank()) return;

        String[] parts = path.split("\\.");
        Object current = root;
        boolean indexConsumed = false;

        for (int i = 0; i < parts.length; i++) {
            String part = parts[i];
            boolean isList = part.endsWith("[]");
            String cleanKey = isList ? part.substring(0, part.length() - 2) : part;
            boolean isLast = (i == parts.length - 1);

            if (current instanceof Map<?, ?> map) {
                Map<String, Object> mapObj = (Map<String, Object>) map;

                if (isList) {
                    List<Object> list = (List<Object>) mapObj.computeIfAbsent(cleanKey, k -> new ArrayList<>());

                    if (isLast) {
                        Object insertValue = (key != null)
                                ? (asKeyValuePair ? Map.of("key", key, "value", value) : Map.of(key, value))
                                : value;

                        if (fixedIndex != null && !indexConsumed) {
                            ensureListIndex(list, fixedIndex);
                            list.set(fixedIndex, insertValue);
                            indexConsumed = true;
                        } else {
                            list.add(insertValue);
                        }
                        return;

                    } else {
                        if (fixedIndex != null && !indexConsumed) {
                            current = ensureListIndex(list, fixedIndex);
                            indexConsumed = true;
                        } else {
                            // descend into the last object (or create one)
                            if (list.isEmpty() || !(list.get(list.size() - 1) instanceof Map)) {
                                Map<String, Object> next = new HashMap<>();
                                list.add(next);
                                current = next;
                            } else {
                                current = list.get(list.size() - 1);
                            }
                        }
                    }

                } else {
                    if (isLast) {
                        mapObj.put(cleanKey, key != null ? Map.of(key, value) : value);
                        return;
                    } else {
                        current = mapObj.computeIfAbsent(cleanKey, k -> new HashMap<>());
                    }
                }

            } else if (current instanceof List<?> rawList) {
                // Fallback safety: if we ever end up at a list unexpectedly, bind or descend sanely.
                List<Object> list = (List<Object>) rawList;

                if (isLast) {
                    Object insertValue = (key != null)
                            ? (asKeyValuePair ? Map.of("key", key, "value", value) : Map.of(key, value))
                            : value;

                    if (fixedIndex != null && !indexConsumed) {
                        ensureListIndex(list, fixedIndex);
                        list.set(fixedIndex, insertValue);
                        indexConsumed = true;
                    } else {
                        list.add(insertValue);
                    }
                    return;

                } else {
                    if (fixedIndex != null && !indexConsumed) {
                        current = ensureListIndex(list, fixedIndex);
                        indexConsumed = true;
                    } else {
                        if (list.isEmpty() || !(list.get(list.size() - 1) instanceof Map)) {
                            Map<String, Object> next = new HashMap<>();
                            list.add(next);
                            current = next;
                        } else {
                            current = list.get(list.size() - 1);
                        }
                    }
                }
            }
        }
    }


    private Object normalizeYamlSequences(Object v) {
        if (v instanceof List<?> l) return l;

        if (v instanceof Map<?, ?> m) {
            // If all keys are 0..N (as strings), convert to a List in order
            boolean allNumeric = m.keySet().stream().allMatch(k -> k.toString().matches("\\d+"));
            if (allNumeric) {
                return m.entrySet().stream()
                        .sorted(java.util.Comparator.comparingInt(e -> Integer.parseInt(e.getKey().toString())))
                        .map(Map.Entry::getValue)
                        .toList();
            }
        }
        return v;
    }


}
