# PropertyAsset: example messages

**Schema:** `PropertyAsset.avsc` · **Status:** draft v0.1, 27 Nov 2026

One example per case. Every example has been validated against the schema and round-tripped through Avro binary.
Ids, addresses and amounts are made up. Code values and descriptions come from the AMD and security reference data.

Each example is shown as the message a consumer sees after decoding:
- amounts as decimal strings
- dates as `YYYY-MM-DD`
- timestamps in UTC
- `_case` and `_kafkaKey` are notes for the reader, not message fields

For `kafka-avro-console-producer`, use the Avro-JSON files in `avro-json/`. They're the same messages in the Avro JSON encoding, with unions wrapped and decimals as bytes.

| # | Case | actionType | lifecycle.state | propertyClass | Components | Security links | Quality issues | Avro bytes |
|---|---|---|---|---|---|---|---|---|
| 01 | [residential house active](#01_residential_house_active) | UPSERT | ACTIVE | RESIDENTIAL | 1 | 1 | 0 | 965 |
| 02 | [residential buy to let block](#02_residential_buy_to_let_block) | UPSERT | ACTIVE | RESIDENTIAL | 1 | 1 | 0 | 1313 |
| 03 | [commercial office with tenants](#03_commercial_office_with_tenants) | UPSERT | ACTIVE | COMMERCIAL | 1 | 2 | 0 | 1325 |
| 04 | [commercial hotel with trading](#04_commercial_hotel_with_trading) | UPSERT | ACTIVE | COMMERCIAL | 1 | 1 | 0 | 872 |
| 05 | [land agricultural with planning](#05_land_agricultural_with_planning) | UPSERT | ACTIVE | LAND | 1 | 1 | 0 | 811 |
| 06 | [development with units](#06_development_with_units) | UPSERT | ACTIVE | DEVELOPMENT | 1 | 1 | 0 | 1112 |
| 07 | [mixed use retail and flats](#07_mixed_use_retail_and_flats) | UPSERT | ACTIVE | MIXED | 2 | 1 | 0 | 1189 |
| 08 | [header only with quality issues](#08_header_only_with_quality_issues) | UPSERT | UNENCUMBERED | COMMERCIAL | 0 | 0 | 3 | 483 |
| 09 | [security links not valid](#09_security_links_not_valid) | UPSERT | UNENCUMBERED | RESIDENTIAL | 1 | 2 | 4 | 936 |
| 10 | [mortgage released unencumbered](#10_mortgage_released_unencumbered) | UPSERT | UNENCUMBERED | RESIDENTIAL | 1 | 1 | 0 | 773 |
| 11 | [under bank control receiver](#11_under_bank_control_receiver) | UPSERT | UNDER_BANK_CONTROL | COMMERCIAL | 1 | 1 | 0 | 764 |
| 12 | [disposed sale closed](#12_disposed_sale_closed) | UPSERT | DISPOSED | LAND | 1 | 1 | 0 | 714 |
| 13 | [proposed on lending application](#13_proposed_on_lending_application) | UPSERT | PROPOSED | RESIDENTIAL | 1 | 0 | 1 | 680 |
| 14 | [deleted retired](#14_deleted_retired) | DELETE | RETIRED | RESIDENTIAL | 0 | 0 | 0 | 265 |

---

## 01_residential_house_active

Owner-occupied semi-detached house, one live mortgage. A house is one residential component with one unit; the valuation sits on the unit.

```json
{
  "_case": "Owner-occupied semi-detached house, one live mortgage. A house is one residential component with one unit; the valuation sits on the unit.",
  "_kafkaKey": "PROPERTY:1000514034",
  "header": {
    "eventId": "PROPERTY:1000514034:9912",
    "actionType": "UPSERT",
    "aggregateVersion": 9912,
    "sourceChangedAt": "2026-11-20T14:02:11Z",
    "publishedAt": "2026-11-27T09:30:00Z",
    "sourceSystem": "AMD",
    "correlationId": "00-0000000000000000000000003ba2a1f2-00000000000026b8-01"
  },
  "assetKey": "PROPERTY:1000514034",
  "assetClass": "PROPERTY",
  "propertyId": 1000514034,
  "lifecycle": {
    "state": "ACTIVE",
    "reason": "live SIN 5551234 (PROPERTY, APPR)"
  },
  "classification": {
    "propertyClass": "RESIDENTIAL",
    "classConfirmed": true,
    "enteredPropertyType": {
      "code": "R",
      "description": "Residential"
    },
    "economicSector": null
  },
  "location": {
    "unitNumber": null,
    "propertyName": null,
    "streetTownland1": "12 Example Road",
    "streetTownland2": null,
    "townCity": "Naas",
    "county": {
      "code": "KE",
      "description": "Kildare"
    },
    "postCode": "W91 X0X0",
    "country": {
      "code": "IE",
      "description": "Ireland"
    },
    "region": null,
    "areaType": {
      "code": "TWN",
      "description": "Town"
    },
    "locationQuality": null,
    "latitude": "53.21580000000000000",
    "longitude": "-6.6667000000000000"
  },
  "originalSize": null,
  "currentSize": null,
  "currencyCode": "EUR",
  "risk": null,
  "insurance": null,
  "syndication": null,
  "registrations": [
    {
      "registrationId": 220031,
      "registrationNumber": "KE12345F",
      "jurisdiction": {
        "code": "ROI",
        "description": "Republic Of Ireland"
      },
      "county": null,
      "tenureType": {
        "code": "FH",
        "description": "Freehold"
      },
      "leasehold": null,
      "commercialLease": null
    }
  ],
  "components": [
    {
      "componentKey": "RESIDENTIAL:29001",
      "componentType": "RESIDENTIAL",
      "componentId": 29001,
      "componentSubType": {
        "code": "SD",
        "description": "Semi-detached"
      },
      "commercial": null,
      "residential": {
        "condition": {
          "code": "AQ",
          "description": "Adequate for intended use"
        },
        "occupancy": {
          "type": {
            "code": "OD",
            "description": "Owner Occupier/Dependent occupied"
          },
          "status": {
            "code": "OC",
            "description": "Occupied"
          }
        },
        "numberOfUnits": 1,
        "constructionYear": 1998,
        "numberOfFloors": 2,
        "squareMetres": "118.00",
        "measurement": null,
        "floodRisk": null,
        "ratingBPercent": null,
        "energyRating": {
          "rating": {
            "code": "C1",
            "description": "C1"
          },
          "certificateNumber": "100123456",
          "expiryDate": "2031-05-01",
          "kilowattHoursPerSqMetrePerYear": null,
          "co2EmissionKg": null,
          "co2EmissionTonnes": null
        }
      },
      "development": null,
      "land": null,
      "units": [
        {
          "unitKey": "RESIDENTIAL_UNIT:34001",
          "unitType": "RESIDENTIAL_UNIT",
          "unitId": 34001,
          "unitSubType": {
            "code": "SD",
            "description": "Semi-detached"
          },
          "residential": {
            "numberOfBedrooms": 3,
            "numberOfUnits": 1,
            "numberOfRentedUnits": 0,
            "size": null,
            "occupiedSpace": null,
            "numberOfCarSpaces": null,
            "actualPassingRentalIncome": null,
            "marketRent": null,
            "totalAnnualCost": null,
            "totalMaintenanceCost": null,
            "propertyManagementCost": null,
            "mudCompliant": null
          },
          "development": null,
          "valuations": [
            {
              "valuationId": 88123,
              "valuationDate": "2025-03-14",
              "source": {
                "code": "EX",
                "description": "External"
              },
              "sourceSystem": "AMD",
              "externalValuationType": {
                "code": "FI",
                "description": "Full Inspection"
              },
              "reason": null,
              "basis": {
                "code": "RRB",
                "description": "Reduced Red Book"
              },
              "rvaCompliant": null,
              "valuer": {
                "name": null,
                "company": "Example Valuers Ltd",
                "registrationNumber": "PSRA-000123"
              },
              "values": {
                "openMarketValue": {
                  "amount": "425000.00",
                  "currencyCode": "EUR"
                },
                "estimatedRentalValue": null,
                "existingUseValue": null,
                "reinstatementValue": {
                  "amount": "310000.00",
                  "currencyCode": "EUR"
                }
              },
              "percentages": {
                "transactionCosts": null,
                "recovery": null,
                "estimatedRentalValueRecovery": null,
                "uplift": null,
                "existingUseValueYield": null,
                "rentalYield": null,
                "reversionaryYield": null,
                "inputYield": null,
                "equivalentYield": null,
                "indexFactor": null
              },
              "propertyPriceIndex": null,
              "rentalAmount": null,
              "valuationCurrency": {
                "currencyCode": "EUR",
                "exchangeRate": "1.000000"
              },
              "fee": null,
              "sourceUpdatedAt": "2025-03-14T12:00:00Z"
            }
          ],
          "workout": null,
          "sourceUpdatedAt": "2025-03-14T12:00:00Z"
        }
      ],
      "valuations": [],
      "workout": null,
      "sourceUpdatedAt": "2025-03-14T12:00:00Z"
    }
  ],
  "securityLinks": [
    {
      "securityItemNumber": 5551234,
      "buildingType": {
        "code": "1",
        "description": "Res Owner/Dependent Occ"
      },
      "legacyPropertyId": 700123,
      "security": {
        "securityType": {
          "code": "PROPERTY",
          "description": "Mortgage over Property"
        },
        "status": {
          "code": "APPR",
          "description": "Approved"
        },
        "lenderStatus": {
          "code": "LAPR",
          "description": "Held Approved"
        },
        "isLive": true
      },
      "pledge": {
        "extent": {
          "code": "FP",
          "description": "Full Pledge"
        },
        "pledgedSize": null,
        "ownershipType": {
          "code": "JT",
          "description": "Joint"
        },
        "chargeRegisteredEntryNumber": null,
        "chargeRegisteredDate": null
      },
      "linkQuality": "VALID"
    }
  ],
  "workout": null,
  "aliases": [
    {
      "system": {
        "code": "SCP",
        "description": "Security database property"
      },
      "aliasId": 700123
    }
  ],
  "migratedPropertyReference": null,
  "qualityIssues": [],
  "sourceUpdatedAt": "2026-11-20T14:02:11Z"
}
```

---

## 02_residential_buy_to_let_block

Buy-to-let building with three rented flats: one residential component, three units, each valued separately. Property value = sum of unit values.

```json
{
  "_case": "Buy-to-let building with three rented flats: one residential component, three units, each valued separately. Property value = sum of unit values.",
  "_kafkaKey": "PROPERTY:1000600771",
  "header": {
    "eventId": "PROPERTY:1000600771:4410",
    "actionType": "UPSERT",
    "aggregateVersion": 4410,
    "sourceChangedAt": "2026-10-02T09:12:40Z",
    "publishedAt": "2026-11-27T09:30:00Z",
    "sourceSystem": "AMD",
    "correlationId": "00-0000000000000000000000003ba3f4c3-000000000000113a-01"
  },
  "assetKey": "PROPERTY:1000600771",
  "assetClass": "PROPERTY",
  "propertyId": 1000600771,
  "lifecycle": {
    "state": "ACTIVE",
    "reason": "live SIN 5560077 (PROPERTY, OTLA)"
  },
  "classification": {
    "propertyClass": "RESIDENTIAL",
    "classConfirmed": true,
    "enteredPropertyType": {
      "code": "R",
      "description": "Residential"
    },
    "economicSector": null
  },
  "location": {
    "unitNumber": null,
    "propertyName": null,
    "streetTownland1": "3 Example Terrace",
    "streetTownland2": null,
    "townCity": "Cork",
    "county": {
      "code": "CK",
      "description": "Cork"
    },
    "postCode": "T12 X0X0",
    "country": {
      "code": "IE",
      "description": "Ireland"
    },
    "region": null,
    "areaType": {
      "code": "CTY",
      "description": "City"
    },
    "locationQuality": null,
    "latitude": null,
    "longitude": null
  },
  "originalSize": null,
  "currentSize": null,
  "currencyCode": "EUR",
  "risk": null,
  "insurance": null,
  "syndication": null,
  "registrations": [],
  "components": [
    {
      "componentKey": "RESIDENTIAL:29140",
      "componentType": "RESIDENTIAL",
      "componentId": 29140,
      "componentSubType": {
        "code": "MF",
        "description": "Multi Family/PRS"
      },
      "commercial": null,
      "residential": {
        "condition": null,
        "occupancy": {
          "type": {
            "code": "BT",
            "description": "BTL"
          },
          "status": {
            "code": "OC",
            "description": "Occupied"
          }
        },
        "numberOfUnits": 3,
        "constructionYear": 2006,
        "numberOfFloors": 3,
        "squareMetres": null,
        "measurement": null,
        "floodRisk": null,
        "ratingBPercent": null,
        "energyRating": null
      },
      "development": null,
      "land": null,
      "units": [
        {
          "unitKey": "RESIDENTIAL_UNIT:34110",
          "unitType": "RESIDENTIAL_UNIT",
          "unitId": 34110,
          "unitSubType": {
            "code": "AP",
            "description": "Apartment/Flat"
          },
          "residential": {
            "numberOfBedrooms": 1,
            "numberOfUnits": 1,
            "numberOfRentedUnits": 1,
            "size": null,
            "occupiedSpace": null,
            "numberOfCarSpaces": null,
            "actualPassingRentalIncome": {
              "amount": "1650.00",
              "currencyCode": "EUR"
            },
            "marketRent": {
              "amount": "1650.00",
              "currencyCode": "EUR"
            },
            "totalAnnualCost": null,
            "totalMaintenanceCost": null,
            "propertyManagementCost": null,
            "mudCompliant": null
          },
          "development": null,
          "valuations": [
            {
              "valuationId": 88200,
              "valuationDate": "2026-02-10",
              "source": {
                "code": "EX",
                "description": "External"
              },
              "sourceSystem": "AMD",
              "externalValuationType": {
                "code": "FI",
                "description": "Full Inspection"
              },
              "reason": null,
              "basis": {
                "code": "FRB",
                "description": "Full Red Book"
              },
              "rvaCompliant": null,
              "valuer": {
                "name": null,
                "company": "Example Valuers Ltd",
                "registrationNumber": "PSRA-000123"
              },
              "values": {
                "openMarketValue": {
                  "amount": "295000.00",
                  "currencyCode": "EUR"
                },
                "estimatedRentalValue": null,
                "existingUseValue": null,
                "reinstatementValue": null
              },
              "percentages": {
                "transactionCosts": null,
                "recovery": null,
                "estimatedRentalValueRecovery": null,
                "uplift": null,
                "existingUseValueYield": null,
                "rentalYield": null,
                "reversionaryYield": null,
                "inputYield": null,
                "equivalentYield": null,
                "indexFactor": null
              },
              "propertyPriceIndex": null,
              "rentalAmount": null,
              "valuationCurrency": {
                "currencyCode": "EUR",
                "exchangeRate": "1.000000"
              },
              "fee": null,
              "sourceUpdatedAt": "2026-02-10T12:00:00Z"
            }
          ],
          "workout": null,
          "sourceUpdatedAt": "2026-02-10T12:00:00Z"
        },
        {
          "unitKey": "RESIDENTIAL_UNIT:34111",
          "unitType": "RESIDENTIAL_UNIT",
          "unitId": 34111,
          "unitSubType": {
            "code": "AP",
            "description": "Apartment/Flat"
          },
          "residential": {
            "numberOfBedrooms": 2,
            "numberOfUnits": 1,
            "numberOfRentedUnits": 1,
            "size": null,
            "occupiedSpace": null,
            "numberOfCarSpaces": null,
            "actualPassingRentalIncome": {
              "amount": "2100.00",
              "currencyCode": "EUR"
            },
            "marketRent": {
              "amount": "2100.00",
              "currencyCode": "EUR"
            },
            "totalAnnualCost": null,
            "totalMaintenanceCost": null,
            "propertyManagementCost": null,
            "mudCompliant": null
          },
          "development": null,
          "valuations": [
            {
              "valuationId": 88201,
              "valuationDate": "2026-02-10",
              "source": {
                "code": "EX",
                "description": "External"
              },
              "sourceSystem": "AMD",
              "externalValuationType": {
                "code": "FI",
                "description": "Full Inspection"
              },
              "reason": null,
              "basis": {
                "code": "FRB",
                "description": "Full Red Book"
              },
              "rvaCompliant": null,
              "valuer": {
                "name": null,
                "company": "Example Valuers Ltd",
                "registrationNumber": "PSRA-000123"
              },
              "values": {
                "openMarketValue": {
                  "amount": "380000.00",
                  "currencyCode": "EUR"
                },
                "estimatedRentalValue": null,
                "existingUseValue": null,
                "reinstatementValue": null
              },
              "percentages": {
                "transactionCosts": null,
                "recovery": null,
                "estimatedRentalValueRecovery": null,
                "uplift": null,
                "existingUseValueYield": null,
                "rentalYield": null,
                "reversionaryYield": null,
                "inputYield": null,
                "equivalentYield": null,
                "indexFactor": null
              },
              "propertyPriceIndex": null,
              "rentalAmount": null,
              "valuationCurrency": {
                "currencyCode": "EUR",
                "exchangeRate": "1.000000"
              },
              "fee": null,
              "sourceUpdatedAt": "2026-02-10T12:00:00Z"
            }
          ],
          "workout": null,
          "sourceUpdatedAt": "2026-02-10T12:00:00Z"
        },
        {
          "unitKey": "RESIDENTIAL_UNIT:34112",
          "unitType": "RESIDENTIAL_UNIT",
          "unitId": 34112,
          "unitSubType": {
            "code": "AP",
            "description": "Apartment/Flat"
          },
          "residential": {
            "numberOfBedrooms": 2,
            "numberOfUnits": 1,
            "numberOfRentedUnits": 1,
            "size": null,
            "occupiedSpace": null,
            "numberOfCarSpaces": null,
            "actualPassingRentalIncome": {
              "amount": "2150.00",
              "currencyCode": "EUR"
            },
            "marketRent": {
              "amount": "2150.00",
              "currencyCode": "EUR"
            },
            "totalAnnualCost": null,
            "totalMaintenanceCost": null,
            "propertyManagementCost": null,
            "mudCompliant": null
          },
          "development": null,
          "valuations": [
            {
              "valuationId": 88202,
              "valuationDate": "2026-02-10",
              "source": {
                "code": "EX",
                "description": "External"
              },
              "sourceSystem": "AMD",
              "externalValuationType": {
                "code": "FI",
                "description": "Full Inspection"
              },
              "reason": null,
              "basis": {
                "code": "FRB",
                "description": "Full Red Book"
              },
              "rvaCompliant": null,
              "valuer": {
                "name": null,
                "company": "Example Valuers Ltd",
                "registrationNumber": "PSRA-000123"
              },
              "values": {
                "openMarketValue": {
                  "amount": "385000.00",
                  "currencyCode": "EUR"
                },
                "estimatedRentalValue": null,
                "existingUseValue": null,
                "reinstatementValue": null
              },
              "percentages": {
                "transactionCosts": null,
                "recovery": null,
                "estimatedRentalValueRecovery": null,
                "uplift": null,
                "existingUseValueYield": null,
                "rentalYield": null,
                "reversionaryYield": null,
                "inputYield": null,
                "equivalentYield": null,
                "indexFactor": null
              },
              "propertyPriceIndex": null,
              "rentalAmount": null,
              "valuationCurrency": {
                "currencyCode": "EUR",
                "exchangeRate": "1.000000"
              },
              "fee": null,
              "sourceUpdatedAt": "2026-02-10T12:00:00Z"
            }
          ],
          "workout": null,
          "sourceUpdatedAt": "2026-02-10T12:00:00Z"
        }
      ],
      "valuations": [],
      "workout": null,
      "sourceUpdatedAt": "2026-02-10T12:00:00Z"
    }
  ],
  "securityLinks": [
    {
      "securityItemNumber": 5560077,
      "buildingType": {
        "code": "2",
        "description": "Res Non-Owner Occ"
      },
      "legacyPropertyId": 701990,
      "security": {
        "securityType": {
          "code": "PROPERTY",
          "description": "Mortgage over Property"
        },
        "status": {
          "code": "OTLA",
          "description": "Outstanding-Lender To Arrange"
        },
        "lenderStatus": {
          "code": "LOUT",
          "description": "Offered & Outstanding"
        },
        "isLive": true
      },
      "pledge": {
        "extent": {
          "code": "FP",
          "description": "Full Pledge"
        },
        "pledgedSize": null,
        "ownershipType": {
          "code": "SO",
          "description": "Sole"
        },
        "chargeRegisteredEntryNumber": null,
        "chargeRegisteredDate": null
      },
      "linkQuality": "VALID"
    }
  ],
  "workout": null,
  "aliases": [
    {
      "system": {
        "code": "SCP",
        "description": "Security database property"
      },
      "aliasId": 701990
    }
  ],
  "migratedPropertyReference": null,
  "qualityIssues": [],
  "sourceUpdatedAt": "2026-10-02T09:12:40Z"
}
```

---

## 03_commercial_office_with_tenants

Multi-let office: the commercial component carries tenants (one unit vacant) and the valuation. Two securities: a mortgage and a solicitor's undertaking.

```json
{
  "_case": "Multi-let office: the commercial component carries tenants (one unit vacant) and the valuation. Two securities: a mortgage and a solicitor's undertaking.",
  "_kafkaKey": "PROPERTY:1000702210",
  "header": {
    "eventId": "PROPERTY:1000702210:1288",
    "actionType": "UPSERT",
    "aggregateVersion": 1288,
    "sourceChangedAt": "2026-11-25T16:40:03Z",
    "publishedAt": "2026-11-27T09:30:00Z",
    "sourceSystem": "AMD",
    "correlationId": "00-0000000000000000000000003ba58102-0000000000000508-01"
  },
  "assetKey": "PROPERTY:1000702210",
  "assetClass": "PROPERTY",
  "propertyId": 1000702210,
  "lifecycle": {
    "state": "ACTIVE",
    "reason": "live SIN 5570311 (PROPERTY, APPR)"
  },
  "classification": {
    "propertyClass": "COMMERCIAL",
    "classConfirmed": true,
    "enteredPropertyType": {
      "code": "C",
      "description": "Commercial"
    },
    "economicSector": null
  },
  "location": {
    "unitNumber": null,
    "propertyName": null,
    "streetTownland1": "Block B, Example Business Park",
    "streetTownland2": null,
    "townCity": "Dublin 18",
    "county": {
      "code": "D18",
      "description": " - Dublin 18"
    },
    "postCode": "D18 X0X0",
    "country": {
      "code": "IE",
      "description": "Ireland"
    },
    "region": null,
    "areaType": {
      "code": "SBR",
      "description": "Suburban"
    },
    "locationQuality": {
      "code": "SE",
      "description": "Secondary"
    },
    "latitude": null,
    "longitude": null
  },
  "originalSize": null,
  "currentSize": null,
  "currencyCode": "EUR",
  "risk": null,
  "insurance": {
    "firePolicyInPlace": null,
    "aibNotedOnFireInsurance": true,
    "fireInsuranceExpiryDate": "2027-06-30",
    "fireInsuranceCompanyName": null,
    "floodInsuranceInPlace": true
  },
  "syndication": null,
  "registrations": [],
  "components": [
    {
      "componentKey": "COMMERCIAL:7431",
      "componentType": "COMMERCIAL",
      "componentId": 7431,
      "componentSubType": {
        "code": "OF",
        "description": "Office"
      },
      "commercial": {
        "specialistUse": null,
        "condition": {
          "code": "MP",
          "description": "Modern, Purpose built, State of the Art"
        },
        "size": {
          "value": "2450.000",
          "unit": {
            "code": "SQMT",
            "description": "Sq Metres"
          }
        },
        "lettableSpace": {
          "value": "2300.000",
          "unit": {
            "code": "SQMT",
            "description": "Sq Metres"
          }
        },
        "squareMetres": null,
        "measurement": null,
        "ownerOperated": false,
        "occupancy": null,
        "liquorLicence": null,
        "constructionYear": 2008,
        "numberOfUnits": 3,
        "numberOfVacantUnits": 1,
        "numberOfBedrooms": null,
        "numberOfCarSpaces": 60,
        "ancillaryIncome": null,
        "operatingPropertyCosts": {
          "amount": "85000.00",
          "currencyCode": "EUR"
        },
        "marketRent": {
          "amount": "690000.00",
          "currencyCode": "EUR"
        },
        "weightedAverageLeaseLength": 6,
        "weightedAverageTenantQuality": null,
        "geographicalLocation": null,
        "yieldClassification": null,
        "floodRisk": null,
        "ratingBPercent": null,
        "energyRating": {
          "rating": {
            "code": "B3",
            "description": "B3"
          },
          "certificateNumber": null,
          "expiryDate": "2030-01-31",
          "kilowattHoursPerSqMetrePerYear": null,
          "co2EmissionKg": null,
          "co2EmissionTonnes": null
        },
        "tenants": [
          {
            "tenantId": 5080,
            "unitIdentifier": "Ground floor",
            "vacant": false,
            "aggregate": null,
            "tenantType": {
              "code": "CO",
              "description": "Core"
            },
            "tenantQuality": null,
            "tenantClassification": null,
            "companyIdentifier": "IE1234567X",
            "size": {
              "value": "900.000",
              "unit": {
                "code": "SQMT",
                "description": "Sq Metres"
              }
            },
            "lease": {
              "leaseType": null,
              "startDate": "2021-01-01",
              "expiryDate": "2031-12-31",
              "nextBreakDate": "2026-12-31",
              "breakOption": true,
              "rentFreePeriodMonths": null,
              "specificTerms": null
            },
            "rent": {
              "actualPassingRentalIncome": {
                "amount": "270000.00",
                "currencyCode": "EUR"
              },
              "contractRentalIncome": {
                "amount": "270000.00",
                "currencyCode": "EUR"
              },
              "marketRent": null,
              "frequency": {
                "code": "Qtr",
                "description": "Quarterly"
              },
              "collectionPercent": 100,
              "mostRecentRentalIncomeDate": null,
              "nextReviewDate": "2026-01-01",
              "reviewType": null
            },
            "energyRating": null,
            "energyRatingExpiryDate": null,
            "sourceUpdatedAt": null
          },
          {
            "tenantId": 5081,
            "unitIdentifier": "First floor",
            "vacant": false,
            "aggregate": null,
            "tenantType": {
              "code": "NC",
              "description": "Non-Core"
            },
            "tenantQuality": null,
            "tenantClassification": null,
            "companyIdentifier": null,
            "size": {
              "value": "700.000",
              "unit": {
                "code": "SQMT",
                "description": "Sq Metres"
              }
            },
            "lease": {
              "leaseType": null,
              "startDate": "2023-07-01",
              "expiryDate": "2033-06-30",
              "nextBreakDate": null,
              "breakOption": null,
              "rentFreePeriodMonths": null,
              "specificTerms": null
            },
            "rent": {
              "actualPassingRentalIncome": {
                "amount": "196000.00",
                "currencyCode": "EUR"
              },
              "contractRentalIncome": null,
              "marketRent": null,
              "frequency": {
                "code": "Qtr",
                "description": "Quarterly"
              },
              "collectionPercent": 95,
              "mostRecentRentalIncomeDate": null,
              "nextReviewDate": null,
              "reviewType": null
            },
            "energyRating": null,
            "energyRatingExpiryDate": null,
            "sourceUpdatedAt": null
          },
          {
            "tenantId": 5082,
            "unitIdentifier": "Second floor",
            "vacant": true,
            "aggregate": null,
            "tenantType": null,
            "tenantQuality": null,
            "tenantClassification": null,
            "companyIdentifier": null,
            "size": {
              "value": "700.000",
              "unit": {
                "code": "SQMT",
                "description": "Sq Metres"
              }
            },
            "lease": {
              "leaseType": null,
              "startDate": null,
              "expiryDate": null,
              "nextBreakDate": null,
              "breakOption": null,
              "rentFreePeriodMonths": null,
              "specificTerms": null
            },
            "rent": {
              "actualPassingRentalIncome": null,
              "contractRentalIncome": null,
              "marketRent": {
                "amount": "210000.00",
                "currencyCode": "EUR"
              },
              "frequency": null,
              "collectionPercent": null,
              "mostRecentRentalIncomeDate": null,
              "nextReviewDate": null,
              "reviewType": null
            },
            "energyRating": null,
            "energyRatingExpiryDate": null,
            "sourceUpdatedAt": null
          }
        ],
        "hotels": [],
        "trading": []
      },
      "residential": null,
      "development": null,
      "land": null,
      "units": [],
      "valuations": [
        {
          "valuationId": 41007,
          "valuationDate": "2026-06-30",
          "source": {
            "code": "EX",
            "description": "External"
          },
          "sourceSystem": "AMD",
          "externalValuationType": {
            "code": "FI",
            "description": "Full Inspection"
          },
          "reason": null,
          "basis": {
            "code": "FRB",
            "description": "Full Red Book"
          },
          "rvaCompliant": null,
          "valuer": {
            "name": null,
            "company": "Example Valuers Ltd",
            "registrationNumber": "PSRA-000123"
          },
          "values": {
            "openMarketValue": {
              "amount": "8200000.00",
              "currencyCode": "EUR"
            },
            "estimatedRentalValue": {
              "amount": "690000.00",
              "currencyCode": "EUR"
            },
            "existingUseValue": null,
            "reinstatementValue": {
              "amount": "6100000.00",
              "currencyCode": "EUR"
            }
          },
          "percentages": {
            "transactionCosts": "9.960",
            "recovery": null,
            "estimatedRentalValueRecovery": null,
            "uplift": null,
            "existingUseValueYield": null,
            "rentalYield": null,
            "reversionaryYield": "7.900",
            "inputYield": null,
            "equivalentYield": "7.250",
            "indexFactor": null
          },
          "propertyPriceIndex": null,
          "rentalAmount": null,
          "valuationCurrency": {
            "currencyCode": "EUR",
            "exchangeRate": "1.000000"
          },
          "fee": null,
          "sourceUpdatedAt": "2026-06-30T12:00:00Z"
        }
      ],
      "workout": null,
      "sourceUpdatedAt": "2026-11-25T16:40:03Z"
    }
  ],
  "securityLinks": [
    {
      "securityItemNumber": 5570311,
      "buildingType": {
        "code": "4",
        "description": "Comm-Non Owner Oper"
      },
      "legacyPropertyId": 702330,
      "security": {
        "securityType": {
          "code": "PROPERTY",
          "description": "Mortgage over Property"
        },
        "status": {
          "code": "APPR",
          "description": "Approved"
        },
        "lenderStatus": {
          "code": "LAPR",
          "description": "Held Approved"
        },
        "isLive": true
      },
      "pledge": {
        "extent": {
          "code": "FP",
          "description": "Full Pledge"
        },
        "pledgedSize": null,
        "ownershipType": {
          "code": "SO",
          "description": "Sole"
        },
        "chargeRegisteredEntryNumber": null,
        "chargeRegisteredDate": null
      },
      "linkQuality": "VALID"
    },
    {
      "securityItemNumber": 5570312,
      "buildingType": {
        "code": "4",
        "description": "Comm-Non Owner Oper"
      },
      "legacyPropertyId": null,
      "security": {
        "securityType": {
          "code": "UNDERTAKE",
          "description": "Solicitors Undertaking"
        },
        "status": {
          "code": "APPR",
          "description": "Approved"
        },
        "lenderStatus": {
          "code": "LAPR",
          "description": "Held Approved"
        },
        "isLive": true
      },
      "pledge": null,
      "linkQuality": "VALID"
    }
  ],
  "workout": null,
  "aliases": [
    {
      "system": {
        "code": "SCP",
        "description": "Security database property"
      },
      "aliasId": 702330
    },
    {
      "system": {
        "code": "CAM",
        "description": null
      },
      "aliasId": 90014422
    }
  ],
  "migratedPropertyReference": null,
  "qualityIssues": [],
  "sourceUpdatedAt": "2026-11-25T16:40:03Z"
}
```

---

## 04_commercial_hotel_with_trading

Hotel: a commercial component (leisure, hotel suite) with hotel details and three years of trading figures. Owner-operated, secured by a mortgage debenture.

```json
{
  "_case": "Hotel: a commercial component (leisure, hotel suite) with hotel details and three years of trading figures. Owner-operated, secured by a mortgage debenture.",
  "_kafkaKey": "PROPERTY:1000810455",
  "header": {
    "eventId": "PROPERTY:1000810455:702",
    "actionType": "UPSERT",
    "aggregateVersion": 702,
    "sourceChangedAt": "2026-09-18T11:05:52Z",
    "publishedAt": "2026-11-27T09:30:00Z",
    "sourceSystem": "AMD",
    "correlationId": "00-0000000000000000000000003ba727d7-00000000000002be-01"
  },
  "assetKey": "PROPERTY:1000810455",
  "assetClass": "PROPERTY",
  "propertyId": 1000810455,
  "lifecycle": {
    "state": "ACTIVE",
    "reason": "live SIN 5581020 (DEBENTURE, APPR)"
  },
  "classification": {
    "propertyClass": "COMMERCIAL",
    "classConfirmed": true,
    "enteredPropertyType": {
      "code": "C",
      "description": "Commercial"
    },
    "economicSector": {
      "code": "181",
      "description": "Hotels"
    }
  },
  "location": {
    "unitNumber": null,
    "propertyName": null,
    "streetTownland1": "Example Quay",
    "streetTownland2": null,
    "townCity": "Galway",
    "county": {
      "code": "GY",
      "description": "Galway"
    },
    "postCode": "H91 X0X0",
    "country": {
      "code": "IE",
      "description": "Ireland"
    },
    "region": null,
    "areaType": {
      "code": "CTY",
      "description": "City"
    },
    "locationQuality": {
      "code": "PR",
      "description": "Prime"
    },
    "latitude": null,
    "longitude": null
  },
  "originalSize": null,
  "currentSize": null,
  "currencyCode": "EUR",
  "risk": null,
  "insurance": null,
  "syndication": null,
  "registrations": [],
  "components": [
    {
      "componentKey": "COMMERCIAL:7502",
      "componentType": "COMMERCIAL",
      "componentId": 7502,
      "componentSubType": {
        "code": "LS",
        "description": "Leisure"
      },
      "commercial": {
        "specialistUse": {
          "code": "HS",
          "description": "Hotel Suite"
        },
        "condition": null,
        "size": null,
        "lettableSpace": null,
        "squareMetres": null,
        "measurement": null,
        "ownerOperated": true,
        "occupancy": {
          "type": null,
          "status": {
            "code": "OC",
            "description": "Occupied"
          }
        },
        "liquorLicence": null,
        "constructionYear": 2001,
        "numberOfUnits": null,
        "numberOfVacantUnits": null,
        "numberOfBedrooms": 96,
        "numberOfCarSpaces": null,
        "ancillaryIncome": null,
        "operatingPropertyCosts": null,
        "marketRent": null,
        "weightedAverageLeaseLength": null,
        "weightedAverageTenantQuality": null,
        "geographicalLocation": null,
        "yieldClassification": null,
        "floodRisk": null,
        "ratingBPercent": null,
        "energyRating": null,
        "tenants": [],
        "hotels": [
          {
            "hotelId": 434,
            "hotelType": {
              "code": "GP",
              "description": "Group"
            },
            "name": "Example Quay Hotel",
            "brand": "Example Hotels",
            "starRating": 4,
            "occupancyRatePercent": "78.500",
            "numberOfBedrooms": 96
          }
        ],
        "trading": [
          {
            "yearOffset": 0,
            "sales": {
              "amount": "7400000.00",
              "currencyCode": "EUR"
            },
            "ebitda": {
              "amount": "1850000.00",
              "currencyCode": "EUR"
            }
          },
          {
            "yearOffset": 1,
            "sales": {
              "amount": "7050000.00",
              "currencyCode": "EUR"
            },
            "ebitda": {
              "amount": "1690000.00",
              "currencyCode": "EUR"
            }
          },
          {
            "yearOffset": 2,
            "sales": {
              "amount": "6600000.00",
              "currencyCode": "EUR"
            },
            "ebitda": {
              "amount": "1510000.00",
              "currencyCode": "EUR"
            }
          }
        ]
      },
      "residential": null,
      "development": null,
      "land": null,
      "units": [],
      "valuations": [
        {
          "valuationId": 41210,
          "valuationDate": "2026-04-30",
          "source": {
            "code": "EX",
            "description": "External"
          },
          "sourceSystem": "AMD",
          "externalValuationType": {
            "code": "FI",
            "description": "Full Inspection"
          },
          "reason": null,
          "basis": {
            "code": "FRB",
            "description": "Full Red Book"
          },
          "rvaCompliant": null,
          "valuer": {
            "name": null,
            "company": "Example Valuers Ltd",
            "registrationNumber": "PSRA-000123"
          },
          "values": {
            "openMarketValue": {
              "amount": "21500000.00",
              "currencyCode": "EUR"
            },
            "estimatedRentalValue": null,
            "existingUseValue": {
              "amount": "21500000.00",
              "currencyCode": "EUR"
            },
            "reinstatementValue": null
          },
          "percentages": {
            "transactionCosts": null,
            "recovery": null,
            "estimatedRentalValueRecovery": null,
            "uplift": null,
            "existingUseValueYield": null,
            "rentalYield": null,
            "reversionaryYield": null,
            "inputYield": null,
            "equivalentYield": null,
            "indexFactor": null
          },
          "propertyPriceIndex": null,
          "rentalAmount": null,
          "valuationCurrency": {
            "currencyCode": "EUR",
            "exchangeRate": "1.000000"
          },
          "fee": null,
          "sourceUpdatedAt": "2026-04-30T12:00:00Z"
        }
      ],
      "workout": null,
      "sourceUpdatedAt": "2026-09-18T11:05:52Z"
    }
  ],
  "securityLinks": [
    {
      "securityItemNumber": 5581020,
      "buildingType": {
        "code": "3",
        "description": "Comm Owner Oper"
      },
      "legacyPropertyId": 703455,
      "security": {
        "securityType": {
          "code": "DEBENTURE",
          "description": "Mortgage Debenture"
        },
        "status": {
          "code": "APPR",
          "description": "Approved"
        },
        "lenderStatus": {
          "code": "LAPR",
          "description": "Held Approved"
        },
        "isLive": true
      },
      "pledge": {
        "extent": {
          "code": "FP",
          "description": "Full Pledge"
        },
        "pledgedSize": null,
        "ownershipType": {
          "code": "SO",
          "description": "Sole"
        },
        "chargeRegisteredEntryNumber": null,
        "chargeRegisteredDate": null
      },
      "linkQuality": "VALID"
    }
  ],
  "workout": null,
  "aliases": [
    {
      "system": {
        "code": "SCP",
        "description": "Security database property"
      },
      "aliasId": 703455
    }
  ],
  "migratedPropertyReference": null,
  "qualityIssues": [],
  "sourceUpdatedAt": "2026-09-18T11:05:52Z"
}
```

---

## 05_land_agricultural_with_planning

Agricultural land with outline planning: a land component valued at component level. Part pledge: only 40 of 52 acres are charged.

```json
{
  "_case": "Agricultural land with outline planning: a land component valued at component level. Part pledge: only 40 of 52 acres are charged.",
  "_kafkaKey": "PROPERTY:1000900318",
  "header": {
    "eventId": "PROPERTY:1000900318:233",
    "actionType": "UPSERT",
    "aggregateVersion": 233,
    "sourceChangedAt": "2026-07-07T08:44:19Z",
    "publishedAt": "2026-11-27T09:30:00Z",
    "sourceSystem": "AMD",
    "correlationId": "00-0000000000000000000000003ba886de-00000000000000e9-01"
  },
  "assetKey": "PROPERTY:1000900318",
  "assetClass": "PROPERTY",
  "propertyId": 1000900318,
  "lifecycle": {
    "state": "ACTIVE",
    "reason": "live SIN 5590118 (PROPERTY, EXSR)"
  },
  "classification": {
    "propertyClass": "LAND",
    "classConfirmed": true,
    "enteredPropertyType": {
      "code": "L",
      "description": "Land"
    },
    "economicSector": null
  },
  "location": {
    "unitNumber": null,
    "propertyName": null,
    "streetTownland1": "Example Townland",
    "streetTownland2": null,
    "townCity": "Kilkenny",
    "county": {
      "code": "KK",
      "description": "Kilkenny"
    },
    "postCode": null,
    "country": {
      "code": "IE",
      "description": "Ireland"
    },
    "region": null,
    "areaType": {
      "code": "RL",
      "description": "Rural"
    },
    "locationQuality": null,
    "latitude": null,
    "longitude": null
  },
  "originalSize": {
    "value": "52.000",
    "unit": {
      "code": "ACR",
      "description": "Acres"
    }
  },
  "currentSize": {
    "value": "52.000",
    "unit": {
      "code": "ACR",
      "description": "Acres"
    }
  },
  "currencyCode": "EUR",
  "risk": null,
  "insurance": null,
  "syndication": null,
  "registrations": [],
  "components": [
    {
      "componentKey": "LAND:2210",
      "componentType": "LAND",
      "componentId": 2210,
      "componentSubType": {
        "code": "A",
        "description": "Unzoned Land\\Agri Land"
      },
      "commercial": null,
      "residential": null,
      "development": null,
      "land": {
        "size": {
          "value": "52.000",
          "unit": {
            "code": "ACR",
            "description": "Acres"
          }
        },
        "planning": {
          "status": {
            "code": "CR",
            "description": "Current"
          },
          "type": {
            "code": "OT",
            "description": "Outline Planning"
          },
          "propertyType": null,
          "size": {
            "value": "6.000",
            "unit": {
              "code": "ACR",
              "description": "Acres"
            }
          },
          "expiryDate": "2029-03-31"
        },
        "numberOfUnits": null,
        "occupancyStatus": {
          "code": "NA",
          "description": "N/A"
        },
        "marketRent": null,
        "actualPassingRentalIncome": {
          "amount": "14000.00",
          "currencyCode": "EUR"
        },
        "floodRisk": null
      },
      "units": [],
      "valuations": [
        {
          "valuationId": 17330,
          "valuationDate": "2025-11-03",
          "source": {
            "code": "EX",
            "description": "External"
          },
          "sourceSystem": "AMD",
          "externalValuationType": {
            "code": "DT",
            "description": "Desktop"
          },
          "reason": null,
          "basis": null,
          "rvaCompliant": true,
          "valuer": {
            "name": null,
            "company": "Example Valuers Ltd",
            "registrationNumber": "PSRA-000123"
          },
          "values": {
            "openMarketValue": {
              "amount": "780000.00",
              "currencyCode": "EUR"
            },
            "estimatedRentalValue": null,
            "existingUseValue": null,
            "reinstatementValue": null
          },
          "percentages": {
            "transactionCosts": null,
            "recovery": "85.000",
            "estimatedRentalValueRecovery": null,
            "uplift": null,
            "existingUseValueYield": null,
            "rentalYield": null,
            "reversionaryYield": null,
            "inputYield": null,
            "equivalentYield": null,
            "indexFactor": null
          },
          "propertyPriceIndex": null,
          "rentalAmount": null,
          "valuationCurrency": {
            "currencyCode": "EUR",
            "exchangeRate": "1.000000"
          },
          "fee": null,
          "sourceUpdatedAt": "2025-11-03T12:00:00Z"
        }
      ],
      "workout": null,
      "sourceUpdatedAt": "2026-07-07T08:44:19Z"
    }
  ],
  "securityLinks": [
    {
      "securityItemNumber": 5590118,
      "buildingType": {
        "code": "9",
        "description": "No Buildings"
      },
      "legacyPropertyId": 704118,
      "security": {
        "securityType": {
          "code": "PROPERTY",
          "description": "Mortgage over Property"
        },
        "status": {
          "code": "EXSR",
          "description": "Executed-With Solr For Reg"
        },
        "lenderStatus": {
          "code": "LEXE",
          "description": "Effective & Not Yet Approved"
        },
        "isLive": true
      },
      "pledge": {
        "extent": {
          "code": "PP",
          "description": "Part Pledge"
        },
        "pledgedSize": {
          "value": "40.000",
          "unit": {
            "code": "ACR",
            "description": "Acres"
          }
        },
        "ownershipType": {
          "code": "SO",
          "description": "Sole"
        },
        "chargeRegisteredEntryNumber": null,
        "chargeRegisteredDate": null
      },
      "linkQuality": "VALID"
    }
  ],
  "workout": null,
  "aliases": [
    {
      "system": {
        "code": "SCP",
        "description": "Security database property"
      },
      "aliasId": 704118
    }
  ],
  "migratedPropertyReference": null,
  "qualityIssues": [],
  "sourceUpdatedAt": "2026-07-07T08:44:19Z"
}
```

---

## 06_development_with_units

Residential scheme under construction: a development component with two unit types, each with its own counts and valuation.

```json
{
  "_case": "Residential scheme under construction: a development component with two unit types, each with its own counts and valuation.",
  "_kafkaKey": "PROPERTY:1001002244",
  "header": {
    "eventId": "PROPERTY:1001002244:1904",
    "actionType": "UPSERT",
    "aggregateVersion": 1904,
    "sourceChangedAt": "2026-11-12T15:20:00Z",
    "publishedAt": "2026-11-27T09:30:00Z",
    "sourceSystem": "AMD",
    "correlationId": "00-0000000000000000000000003baa1504-0000000000000770-01"
  },
  "assetKey": "PROPERTY:1001002244",
  "assetClass": "PROPERTY",
  "propertyId": 1001002244,
  "lifecycle": {
    "state": "ACTIVE",
    "reason": "live SIN 5600244 (PROPERTY, APPR)"
  },
  "classification": {
    "propertyClass": "DEVELOPMENT",
    "classConfirmed": true,
    "enteredPropertyType": {
      "code": "D",
      "description": "Development"
    },
    "economicSector": null
  },
  "location": {
    "unitNumber": null,
    "propertyName": null,
    "streetTownland1": "Example Fields",
    "streetTownland2": null,
    "townCity": "Navan",
    "county": {
      "code": "MH",
      "description": "Meath"
    },
    "postCode": "C15 X0X0",
    "country": {
      "code": "IE",
      "description": "Ireland"
    },
    "region": null,
    "areaType": {
      "code": "TWN",
      "description": "Town"
    },
    "locationQuality": null,
    "latitude": null,
    "longitude": null
  },
  "originalSize": null,
  "currentSize": null,
  "currencyCode": "EUR",
  "risk": null,
  "insurance": null,
  "syndication": null,
  "registrations": [],
  "components": [
    {
      "componentKey": "DEVELOPMENT:1720",
      "componentType": "DEVELOPMENT",
      "componentId": 1720,
      "componentSubType": {
        "code": "1",
        "description": "Part Built"
      },
      "commercial": null,
      "residential": null,
      "development": {
        "developmentSize": {
          "value": "4.500",
          "unit": {
            "code": "ACR",
            "description": "Acres"
          }
        },
        "landUnderDevelopmentSize": null,
        "status": {
          "code": "1",
          "description": "Developer Active & Appropriately Managed"
        },
        "startYear": 2025,
        "endYear": 2027,
        "planningCompliant": true,
        "planningExpiryDate": "2028-09-30",
        "siteResolutionPlan": null,
        "expectedOutcome": {
          "code": "1",
          "description": "Full completion as originally proposed"
        },
        "costToDate": {
          "amount": "6200000.00",
          "currencyCode": "EUR"
        },
        "estimatedCostToComplete": {
          "amount": "4800000.00",
          "currencyCode": "EUR"
        },
        "numberOfUnitsNotStarted": 8,
        "floodRisk": null
      },
      "land": null,
      "units": [
        {
          "unitKey": "DEVELOPMENT_UNIT:2601",
          "unitType": "DEVELOPMENT_UNIT",
          "unitId": 2601,
          "unitSubType": {
            "code": "RI",
            "description": "Residential"
          },
          "residential": null,
          "development": {
            "socialAffordableHousing": null,
            "planningPermissionUnitCount": 24,
            "unitCounts": {
              "completeNotSold": 4,
              "partiallyCompleted": 12,
              "sold": 6,
              "notYetStarted": 2
            },
            "estimatedCostToComplete": null,
            "estimatedCostToDate": null,
            "grossDevelopmentValue": {
              "amount": "9600000.00",
              "currencyCode": "EUR"
            },
            "expectedOutcomePostCompletion": {
              "code": "SA",
              "description": "Sales"
            },
            "estimatedSalesPrice": {
              "amount": "400000.00",
              "currencyCode": "EUR"
            },
            "estimatedRentalValue": null,
            "contractSalesCount": 9,
            "contractSalesTotalPrice": {
              "amount": "3555000.00",
              "currencyCode": "EUR"
            },
            "contractPreletsCount": null,
            "contractPreletsTotalRentalValue": null,
            "marketRent": null,
            "proposedAnchorTenant": null
          },
          "valuations": [
            {
              "valuationId": 9101,
              "valuationDate": "2026-08-31",
              "source": {
                "code": "EX",
                "description": "External"
              },
              "sourceSystem": "AMD",
              "externalValuationType": {
                "code": "FI",
                "description": "Full Inspection"
              },
              "reason": null,
              "basis": null,
              "rvaCompliant": null,
              "valuer": {
                "name": null,
                "company": "Example Valuers Ltd",
                "registrationNumber": "PSRA-000123"
              },
              "values": {
                "openMarketValue": {
                  "amount": "5900000.00",
                  "currencyCode": "EUR"
                },
                "estimatedRentalValue": null,
                "existingUseValue": null,
                "reinstatementValue": null
              },
              "percentages": {
                "transactionCosts": null,
                "recovery": null,
                "estimatedRentalValueRecovery": null,
                "uplift": "12.500",
                "existingUseValueYield": null,
                "rentalYield": null,
                "reversionaryYield": null,
                "inputYield": null,
                "equivalentYield": null,
                "indexFactor": null
              },
              "propertyPriceIndex": null,
              "rentalAmount": null,
              "valuationCurrency": {
                "currencyCode": "EUR",
                "exchangeRate": "1.000000"
              },
              "fee": null,
              "sourceUpdatedAt": "2026-08-31T12:00:00Z"
            }
          ],
          "workout": null,
          "sourceUpdatedAt": null
        },
        {
          "unitKey": "DEVELOPMENT_UNIT:2602",
          "unitType": "DEVELOPMENT_UNIT",
          "unitId": 2602,
          "unitSubType": {
            "code": "RT",
            "description": "Retail"
          },
          "residential": null,
          "development": {
            "socialAffordableHousing": null,
            "planningPermissionUnitCount": 2,
            "unitCounts": {
              "completeNotSold": null,
              "partiallyCompleted": 2,
              "sold": null,
              "notYetStarted": null
            },
            "estimatedCostToComplete": null,
            "estimatedCostToDate": null,
            "grossDevelopmentValue": {
              "amount": "900000.00",
              "currencyCode": "EUR"
            },
            "expectedOutcomePostCompletion": {
              "code": "LE",
              "description": "Lease"
            },
            "estimatedSalesPrice": null,
            "estimatedRentalValue": {
              "amount": "60000.00",
              "currencyCode": "EUR"
            },
            "contractSalesCount": null,
            "contractSalesTotalPrice": null,
            "contractPreletsCount": null,
            "contractPreletsTotalRentalValue": null,
            "marketRent": null,
            "proposedAnchorTenant": null
          },
          "valuations": [
            {
              "valuationId": 9102,
              "valuationDate": "2026-08-31",
              "source": {
                "code": "EX",
                "description": "External"
              },
              "sourceSystem": "AMD",
              "externalValuationType": {
                "code": "FI",
                "description": "Full Inspection"
              },
              "reason": null,
              "basis": null,
              "rvaCompliant": null,
              "valuer": {
                "name": null,
                "company": "Example Valuers Ltd",
                "registrationNumber": "PSRA-000123"
              },
              "values": {
                "openMarketValue": {
                  "amount": "520000.00",
                  "currencyCode": "EUR"
                },
                "estimatedRentalValue": null,
                "existingUseValue": null,
                "reinstatementValue": null
              },
              "percentages": {
                "transactionCosts": null,
                "recovery": null,
                "estimatedRentalValueRecovery": null,
                "uplift": null,
                "existingUseValueYield": null,
                "rentalYield": null,
                "reversionaryYield": null,
                "inputYield": null,
                "equivalentYield": null,
                "indexFactor": null
              },
              "propertyPriceIndex": null,
              "rentalAmount": null,
              "valuationCurrency": {
                "currencyCode": "EUR",
                "exchangeRate": "1.000000"
              },
              "fee": null,
              "sourceUpdatedAt": "2026-08-31T12:00:00Z"
            }
          ],
          "workout": null,
          "sourceUpdatedAt": null
        }
      ],
      "valuations": [],
      "workout": null,
      "sourceUpdatedAt": "2026-11-12T15:20:00Z"
    }
  ],
  "securityLinks": [
    {
      "securityItemNumber": 5600244,
      "buildingType": {
        "code": "9",
        "description": "No Buildings"
      },
      "legacyPropertyId": 705244,
      "security": {
        "securityType": {
          "code": "PROPERTY",
          "description": "Mortgage over Property"
        },
        "status": {
          "code": "APPR",
          "description": "Approved"
        },
        "lenderStatus": {
          "code": "LAPR",
          "description": "Held Approved"
        },
        "isLive": true
      },
      "pledge": {
        "extent": {
          "code": "FP",
          "description": "Full Pledge"
        },
        "pledgedSize": null,
        "ownershipType": {
          "code": "SO",
          "description": "Sole"
        },
        "chargeRegisteredEntryNumber": null,
        "chargeRegisteredDate": null
      },
      "linkQuality": "VALID"
    }
  ],
  "workout": null,
  "aliases": [
    {
      "system": {
        "code": "SCP",
        "description": "Security database property"
      },
      "aliasId": 705244
    }
  ],
  "migratedPropertyReference": null,
  "qualityIssues": [],
  "sourceUpdatedAt": "2026-11-12T15:20:00Z"
}
```

---

## 07_mixed_use_retail_and_flats

Shop on the ground floor, two flats above: one commercial and one residential component, so propertyClass is derived as MIXED although it was keyed in as Commercial.

```json
{
  "_case": "Shop on the ground floor, two flats above: one commercial and one residential component, so propertyClass is derived as MIXED although it was keyed in as Commercial.",
  "_kafkaKey": "PROPERTY:1001105512",
  "header": {
    "eventId": "PROPERTY:1001105512:611",
    "actionType": "UPSERT",
    "aggregateVersion": 611,
    "sourceChangedAt": "2026-10-21T10:00:00Z",
    "publishedAt": "2026-11-27T09:30:00Z",
    "sourceSystem": "AMD",
    "correlationId": "00-0000000000000000000000003baba868-0000000000000263-01"
  },
  "assetKey": "PROPERTY:1001105512",
  "assetClass": "PROPERTY",
  "propertyId": 1001105512,
  "lifecycle": {
    "state": "ACTIVE",
    "reason": "live SIN 5610512 (PROPERTY, APPR)"
  },
  "classification": {
    "propertyClass": "MIXED",
    "classConfirmed": true,
    "enteredPropertyType": {
      "code": "C",
      "description": "Commercial"
    },
    "economicSector": null
  },
  "location": {
    "unitNumber": null,
    "propertyName": null,
    "streetTownland1": "45 Example Street",
    "streetTownland2": null,
    "townCity": "Sligo",
    "county": {
      "code": "SO",
      "description": "Sligo"
    },
    "postCode": "F91 X0X0",
    "country": {
      "code": "IE",
      "description": "Ireland"
    },
    "region": null,
    "areaType": {
      "code": "TWN",
      "description": "Town"
    },
    "locationQuality": null,
    "latitude": null,
    "longitude": null
  },
  "originalSize": null,
  "currentSize": null,
  "currencyCode": "EUR",
  "risk": null,
  "insurance": null,
  "syndication": null,
  "registrations": [],
  "components": [
    {
      "componentKey": "COMMERCIAL:7610",
      "componentType": "COMMERCIAL",
      "componentId": 7610,
      "componentSubType": {
        "code": "RT",
        "description": "Retail"
      },
      "commercial": {
        "specialistUse": null,
        "condition": null,
        "size": {
          "value": "140.000",
          "unit": {
            "code": "SQMT",
            "description": "Sq Metres"
          }
        },
        "lettableSpace": null,
        "squareMetres": null,
        "measurement": null,
        "ownerOperated": true,
        "occupancy": null,
        "liquorLicence": null,
        "constructionYear": null,
        "numberOfUnits": 1,
        "numberOfVacantUnits": null,
        "numberOfBedrooms": null,
        "numberOfCarSpaces": null,
        "ancillaryIncome": null,
        "operatingPropertyCosts": null,
        "marketRent": null,
        "weightedAverageLeaseLength": null,
        "weightedAverageTenantQuality": null,
        "geographicalLocation": null,
        "yieldClassification": null,
        "floodRisk": null,
        "ratingBPercent": null,
        "energyRating": null,
        "tenants": [],
        "hotels": [],
        "trading": []
      },
      "residential": null,
      "development": null,
      "land": null,
      "units": [],
      "valuations": [
        {
          "valuationId": 41390,
          "valuationDate": "2026-05-20",
          "source": {
            "code": "EX",
            "description": "External"
          },
          "sourceSystem": "AMD",
          "externalValuationType": {
            "code": "FI",
            "description": "Full Inspection"
          },
          "reason": null,
          "basis": null,
          "rvaCompliant": null,
          "valuer": {
            "name": null,
            "company": "Example Valuers Ltd",
            "registrationNumber": "PSRA-000123"
          },
          "values": {
            "openMarketValue": {
              "amount": "310000.00",
              "currencyCode": "EUR"
            },
            "estimatedRentalValue": null,
            "existingUseValue": null,
            "reinstatementValue": null
          },
          "percentages": {
            "transactionCosts": null,
            "recovery": null,
            "estimatedRentalValueRecovery": null,
            "uplift": null,
            "existingUseValueYield": null,
            "rentalYield": null,
            "reversionaryYield": null,
            "inputYield": null,
            "equivalentYield": null,
            "indexFactor": null
          },
          "propertyPriceIndex": null,
          "rentalAmount": null,
          "valuationCurrency": {
            "currencyCode": "EUR",
            "exchangeRate": "1.000000"
          },
          "fee": null,
          "sourceUpdatedAt": "2026-05-20T12:00:00Z"
        }
      ],
      "workout": null,
      "sourceUpdatedAt": null
    },
    {
      "componentKey": "RESIDENTIAL:29550",
      "componentType": "RESIDENTIAL",
      "componentId": 29550,
      "componentSubType": {
        "code": "AP",
        "description": "Apartment/Flat"
      },
      "commercial": null,
      "residential": {
        "condition": null,
        "occupancy": {
          "type": {
            "code": "BT",
            "description": "BTL"
          },
          "status": {
            "code": "OC",
            "description": "Occupied"
          }
        },
        "numberOfUnits": 2,
        "constructionYear": null,
        "numberOfFloors": null,
        "squareMetres": null,
        "measurement": null,
        "floodRisk": null,
        "ratingBPercent": null,
        "energyRating": null
      },
      "development": null,
      "land": null,
      "units": [
        {
          "unitKey": "RESIDENTIAL_UNIT:35001",
          "unitType": "RESIDENTIAL_UNIT",
          "unitId": 35001,
          "unitSubType": {
            "code": "AP",
            "description": "Apartment/Flat"
          },
          "residential": {
            "numberOfBedrooms": 2,
            "numberOfUnits": 1,
            "numberOfRentedUnits": 1,
            "size": null,
            "occupiedSpace": null,
            "numberOfCarSpaces": null,
            "actualPassingRentalIncome": {
              "amount": "1300.00",
              "currencyCode": "EUR"
            },
            "marketRent": null,
            "totalAnnualCost": null,
            "totalMaintenanceCost": null,
            "propertyManagementCost": null,
            "mudCompliant": null
          },
          "development": null,
          "valuations": [
            {
              "valuationId": 88501,
              "valuationDate": "2026-05-20",
              "source": {
                "code": "EX",
                "description": "External"
              },
              "sourceSystem": "AMD",
              "externalValuationType": {
                "code": "FI",
                "description": "Full Inspection"
              },
              "reason": null,
              "basis": null,
              "rvaCompliant": null,
              "valuer": {
                "name": null,
                "company": "Example Valuers Ltd",
                "registrationNumber": "PSRA-000123"
              },
              "values": {
                "openMarketValue": {
                  "amount": "195000.00",
                  "currencyCode": "EUR"
                },
                "estimatedRentalValue": null,
                "existingUseValue": null,
                "reinstatementValue": null
              },
              "percentages": {
                "transactionCosts": null,
                "recovery": null,
                "estimatedRentalValueRecovery": null,
                "uplift": null,
                "existingUseValueYield": null,
                "rentalYield": null,
                "reversionaryYield": null,
                "inputYield": null,
                "equivalentYield": null,
                "indexFactor": null
              },
              "propertyPriceIndex": null,
              "rentalAmount": null,
              "valuationCurrency": {
                "currencyCode": "EUR",
                "exchangeRate": "1.000000"
              },
              "fee": null,
              "sourceUpdatedAt": "2026-05-20T12:00:00Z"
            }
          ],
          "workout": null,
          "sourceUpdatedAt": null
        },
        {
          "unitKey": "RESIDENTIAL_UNIT:35002",
          "unitType": "RESIDENTIAL_UNIT",
          "unitId": 35002,
          "unitSubType": {
            "code": "AP",
            "description": "Apartment/Flat"
          },
          "residential": {
            "numberOfBedrooms": 2,
            "numberOfUnits": 1,
            "numberOfRentedUnits": 1,
            "size": null,
            "occupiedSpace": null,
            "numberOfCarSpaces": null,
            "actualPassingRentalIncome": {
              "amount": "1300.00",
              "currencyCode": "EUR"
            },
            "marketRent": null,
            "totalAnnualCost": null,
            "totalMaintenanceCost": null,
            "propertyManagementCost": null,
            "mudCompliant": null
          },
          "development": null,
          "valuations": [
            {
              "valuationId": 88502,
              "valuationDate": "2026-05-20",
              "source": {
                "code": "EX",
                "description": "External"
              },
              "sourceSystem": "AMD",
              "externalValuationType": {
                "code": "FI",
                "description": "Full Inspection"
              },
              "reason": null,
              "basis": null,
              "rvaCompliant": null,
              "valuer": {
                "name": null,
                "company": "Example Valuers Ltd",
                "registrationNumber": "PSRA-000123"
              },
              "values": {
                "openMarketValue": {
                  "amount": "195000.00",
                  "currencyCode": "EUR"
                },
                "estimatedRentalValue": null,
                "existingUseValue": null,
                "reinstatementValue": null
              },
              "percentages": {
                "transactionCosts": null,
                "recovery": null,
                "estimatedRentalValueRecovery": null,
                "uplift": null,
                "existingUseValueYield": null,
                "rentalYield": null,
                "reversionaryYield": null,
                "inputYield": null,
                "equivalentYield": null,
                "indexFactor": null
              },
              "propertyPriceIndex": null,
              "rentalAmount": null,
              "valuationCurrency": {
                "currencyCode": "EUR",
                "exchangeRate": "1.000000"
              },
              "fee": null,
              "sourceUpdatedAt": "2026-05-20T12:00:00Z"
            }
          ],
          "workout": null,
          "sourceUpdatedAt": null
        }
      ],
      "valuations": [],
      "workout": null,
      "sourceUpdatedAt": null
    }
  ],
  "securityLinks": [
    {
      "securityItemNumber": 5610512,
      "buildingType": {
        "code": "8",
        "description": "Res Owner-Occ/Comm Rented"
      },
      "legacyPropertyId": 706512,
      "security": {
        "securityType": {
          "code": "PROPERTY",
          "description": "Mortgage over Property"
        },
        "status": {
          "code": "APPR",
          "description": "Approved"
        },
        "lenderStatus": {
          "code": "LAPR",
          "description": "Held Approved"
        },
        "isLive": true
      },
      "pledge": {
        "extent": {
          "code": "FP",
          "description": "Full Pledge"
        },
        "pledgedSize": null,
        "ownershipType": {
          "code": "SO",
          "description": "Sole"
        },
        "chargeRegisteredEntryNumber": null,
        "chargeRegisteredDate": null
      },
      "linkQuality": "VALID"
    }
  ],
  "workout": null,
  "aliases": [
    {
      "system": {
        "code": "SCP",
        "description": "Security database property"
      },
      "aliasId": 706512
    }
  ],
  "migratedPropertyReference": null,
  "qualityIssues": [],
  "sourceUpdatedAt": "2026-10-21T10:00:00Z"
}
```

---

## 08_header_only_with_quality_issues

What 26,611 AMD properties look like today: a header with no components and no security number. Class unconfirmed, country is a dropdown default, so the publisher reports Q2, Q3 and Q5.

```json
{
  "_case": "What 26,611 AMD properties look like today: a header with no components and no security number. Class unconfirmed, country is a dropdown default, so the publisher reports Q2, Q3 and Q5.",
  "_kafkaKey": "PROPERTY:1001206610",
  "header": {
    "eventId": "PROPERTY:1001206610:15",
    "actionType": "UPSERT",
    "aggregateVersion": 15,
    "sourceChangedAt": "2019-03-04T13:22:51Z",
    "publishedAt": "2026-11-27T09:30:00Z",
    "sourceSystem": "AMD",
    "correlationId": "00-0000000000000000000000003bad3352-000000000000000f-01"
  },
  "assetKey": "PROPERTY:1001206610",
  "assetClass": "PROPERTY",
  "propertyId": 1001206610,
  "lifecycle": {
    "state": "UNENCUMBERED",
    "reason": "no security link"
  },
  "classification": {
    "propertyClass": "COMMERCIAL",
    "classConfirmed": false,
    "enteredPropertyType": {
      "code": "C",
      "description": "Commercial"
    },
    "economicSector": null
  },
  "location": {
    "unitNumber": null,
    "propertyName": null,
    "streetTownland1": "Unit 4, Example Estate",
    "streetTownland2": null,
    "townCity": "Athlone",
    "county": {
      "code": "WH",
      "description": "Westmeath"
    },
    "postCode": null,
    "country": {
      "code": "AQ",
      "description": "Antarctica"
    },
    "region": null,
    "areaType": {
      "code": "TWN",
      "description": "Town"
    },
    "locationQuality": null,
    "latitude": null,
    "longitude": null
  },
  "originalSize": null,
  "currentSize": null,
  "currencyCode": "EUR",
  "risk": null,
  "insurance": null,
  "syndication": null,
  "registrations": [],
  "components": [],
  "securityLinks": [],
  "workout": null,
  "aliases": [],
  "migratedPropertyReference": null,
  "qualityIssues": [
    {
      "rule": "Q2",
      "path": "location.country",
      "detail": "country AQ (Antarctica) with an Irish county: likely a dropdown default"
    },
    {
      "rule": "Q3",
      "path": "components",
      "detail": "Commercial property with no live component"
    },
    {
      "rule": "Q5",
      "path": "securityLinks",
      "detail": "No security number (AM_BUILDINGS_TYPE)"
    }
  ],
  "sourceUpdatedAt": "2019-03-04T13:22:51Z"
}
```

---

## 09_security_links_not_valid

Two security numbers, neither usable: one doesn't exist in the security database, the other was entered in error. No live security, so UNENCUMBERED, with Q6 reported twice.

```json
{
  "_case": "Two security numbers, neither usable: one doesn't exist in the security database, the other was entered in error. No live security, so UNENCUMBERED, with Q6 reported twice.",
  "_kafkaKey": "PROPERTY:1001307789",
  "header": {
    "eventId": "PROPERTY:1001307789:377",
    "actionType": "UPSERT",
    "aggregateVersion": 377,
    "sourceChangedAt": "2024-02-15T09:41:00Z",
    "publishedAt": "2026-11-27T09:30:00Z",
    "sourceSystem": "AMD",
    "correlationId": "00-0000000000000000000000003baebe8d-0000000000000179-01"
  },
  "assetKey": "PROPERTY:1001307789",
  "assetClass": "PROPERTY",
  "propertyId": 1001307789,
  "lifecycle": {
    "state": "UNENCUMBERED",
    "reason": "no live security: SIN 5129001 not found, SIN 5129002 entered in error"
  },
  "classification": {
    "propertyClass": "RESIDENTIAL",
    "classConfirmed": true,
    "enteredPropertyType": {
      "code": "R",
      "description": "Residential"
    },
    "economicSector": null
  },
  "location": {
    "unitNumber": null,
    "propertyName": null,
    "streetTownland1": "7 Example Close",
    "streetTownland2": null,
    "townCity": "Ennis",
    "county": {
      "code": "CE",
      "description": "Clare"
    },
    "postCode": "V95 X0X0",
    "country": {
      "code": "IE",
      "description": "Ireland"
    },
    "region": null,
    "areaType": {
      "code": "TWN",
      "description": "Town"
    },
    "locationQuality": null,
    "latitude": null,
    "longitude": null
  },
  "originalSize": null,
  "currentSize": null,
  "currencyCode": "EUR",
  "risk": null,
  "insurance": null,
  "syndication": null,
  "registrations": [],
  "components": [
    {
      "componentKey": "RESIDENTIAL:29711",
      "componentType": "RESIDENTIAL",
      "componentId": 29711,
      "componentSubType": {
        "code": "DT",
        "description": "Detached"
      },
      "commercial": null,
      "residential": {
        "condition": null,
        "occupancy": null,
        "numberOfUnits": 1,
        "constructionYear": null,
        "numberOfFloors": null,
        "squareMetres": null,
        "measurement": null,
        "floodRisk": null,
        "ratingBPercent": null,
        "energyRating": null
      },
      "development": null,
      "land": null,
      "units": [
        {
          "unitKey": "RESIDENTIAL_UNIT:35211",
          "unitType": "RESIDENTIAL_UNIT",
          "unitId": 35211,
          "unitSubType": null,
          "residential": {
            "numberOfBedrooms": null,
            "numberOfUnits": 1,
            "numberOfRentedUnits": null,
            "size": null,
            "occupiedSpace": null,
            "numberOfCarSpaces": null,
            "actualPassingRentalIncome": null,
            "marketRent": null,
            "totalAnnualCost": null,
            "totalMaintenanceCost": null,
            "propertyManagementCost": null,
            "mudCompliant": null
          },
          "development": null,
          "valuations": [],
          "workout": null,
          "sourceUpdatedAt": null
        }
      ],
      "valuations": [],
      "workout": null,
      "sourceUpdatedAt": null
    }
  ],
  "securityLinks": [
    {
      "securityItemNumber": 5129001,
      "buildingType": {
        "code": "1",
        "description": "Res Owner/Dependent Occ"
      },
      "legacyPropertyId": null,
      "security": null,
      "pledge": null,
      "linkQuality": "SECURITY_NOT_FOUND"
    },
    {
      "securityItemNumber": 5129002,
      "buildingType": {
        "code": "1",
        "description": "Res Owner/Dependent Occ"
      },
      "legacyPropertyId": 707789,
      "security": {
        "securityType": {
          "code": "PROPERTY",
          "description": "Mortgage over Property"
        },
        "status": {
          "code": "ERRO",
          "description": "Entered In Error/Not Required"
        },
        "lenderStatus": {
          "code": "LERR",
          "description": "Entered in Error"
        },
        "isLive": false
      },
      "pledge": {
        "extent": {
          "code": "FP",
          "description": "Full Pledge"
        },
        "pledgedSize": null,
        "ownershipType": {
          "code": "SO",
          "description": "Sole"
        },
        "chargeRegisteredEntryNumber": null,
        "chargeRegisteredDate": null
      },
      "linkQuality": "SECURITY_ENTERED_IN_ERROR"
    }
  ],
  "workout": null,
  "aliases": [],
  "migratedPropertyReference": null,
  "qualityIssues": [
    {
      "rule": "Q4",
      "path": "components[RESIDENTIAL:29711].units[RESIDENTIAL_UNIT:35211].unitSubType",
      "detail": "Unit type empty"
    },
    {
      "rule": "Q6",
      "path": "securityLinks[5129001]",
      "detail": "SIN not found in SECURITY_ITEM"
    },
    {
      "rule": "Q6",
      "path": "securityLinks[5129002]",
      "detail": "Security status ERRO (entered in error)"
    },
    {
      "rule": "Q7",
      "path": "components[RESIDENTIAL:29711].units[RESIDENTIAL_UNIT:35211].valuations",
      "detail": "No valuation"
    }
  ],
  "sourceUpdatedAt": "2024-02-15T09:41:00Z"
}
```

---

## 10_mortgage_released_unencumbered

Loan repaid and the mortgage released: the asset still exists, the link stays as history with SECURITY_RELEASED, and the state becomes UNENCUMBERED.

```json
{
  "_case": "Loan repaid and the mortgage released: the asset still exists, the link stays as history with SECURITY_RELEASED, and the state becomes UNENCUMBERED.",
  "_kafkaKey": "PROPERTY:1001408820",
  "header": {
    "eventId": "PROPERTY:1001408820:2050",
    "actionType": "UPSERT",
    "aggregateVersion": 2050,
    "sourceChangedAt": "2026-11-26T17:15:30Z",
    "publishedAt": "2026-11-27T09:30:00Z",
    "sourceSystem": "AMD",
    "correlationId": "00-0000000000000000000000003bb04934-0000000000000802-01"
  },
  "assetKey": "PROPERTY:1001408820",
  "assetClass": "PROPERTY",
  "propertyId": 1001408820,
  "lifecycle": {
    "state": "UNENCUMBERED",
    "reason": "only security SIN 5418820 is released"
  },
  "classification": {
    "propertyClass": "RESIDENTIAL",
    "classConfirmed": true,
    "enteredPropertyType": {
      "code": "R",
      "description": "Residential"
    },
    "economicSector": null
  },
  "location": {
    "unitNumber": null,
    "propertyName": null,
    "streetTownland1": "21 Example Avenue",
    "streetTownland2": null,
    "townCity": "Dublin 9",
    "county": {
      "code": "D9",
      "description": " - Dublin 9"
    },
    "postCode": "D09 X0X0",
    "country": {
      "code": "IE",
      "description": "Ireland"
    },
    "region": null,
    "areaType": {
      "code": "SBR",
      "description": "Suburban"
    },
    "locationQuality": null,
    "latitude": null,
    "longitude": null
  },
  "originalSize": null,
  "currentSize": null,
  "currencyCode": "EUR",
  "risk": null,
  "insurance": null,
  "syndication": null,
  "registrations": [],
  "components": [
    {
      "componentKey": "RESIDENTIAL:29820",
      "componentType": "RESIDENTIAL",
      "componentId": 29820,
      "componentSubType": {
        "code": "TH",
        "description": "Terraced House"
      },
      "commercial": null,
      "residential": {
        "condition": null,
        "occupancy": {
          "type": {
            "code": "OD",
            "description": "Owner Occupier/Dependent occupied"
          },
          "status": {
            "code": "OC",
            "description": "Occupied"
          }
        },
        "numberOfUnits": 1,
        "constructionYear": null,
        "numberOfFloors": null,
        "squareMetres": null,
        "measurement": null,
        "floodRisk": null,
        "ratingBPercent": null,
        "energyRating": null
      },
      "development": null,
      "land": null,
      "units": [
        {
          "unitKey": "RESIDENTIAL_UNIT:35320",
          "unitType": "RESIDENTIAL_UNIT",
          "unitId": 35320,
          "unitSubType": {
            "code": "TH",
            "description": "Terraced House"
          },
          "residential": {
            "numberOfBedrooms": 3,
            "numberOfUnits": 1,
            "numberOfRentedUnits": null,
            "size": null,
            "occupiedSpace": null,
            "numberOfCarSpaces": null,
            "actualPassingRentalIncome": null,
            "marketRent": null,
            "totalAnnualCost": null,
            "totalMaintenanceCost": null,
            "propertyManagementCost": null,
            "mudCompliant": null
          },
          "development": null,
          "valuations": [
            {
              "valuationId": 88760,
              "valuationDate": "2016-09-01",
              "source": {
                "code": "IN",
                "description": "Internal"
              },
              "sourceSystem": "AMD",
              "externalValuationType": null,
              "reason": null,
              "basis": null,
              "rvaCompliant": null,
              "valuer": {
                "name": null,
                "company": "Example Valuers Ltd",
                "registrationNumber": "PSRA-000123"
              },
              "values": {
                "openMarketValue": {
                  "amount": "355000.00",
                  "currencyCode": "EUR"
                },
                "estimatedRentalValue": null,
                "existingUseValue": null,
                "reinstatementValue": null
              },
              "percentages": {
                "transactionCosts": null,
                "recovery": null,
                "estimatedRentalValueRecovery": null,
                "uplift": null,
                "existingUseValueYield": null,
                "rentalYield": null,
                "reversionaryYield": null,
                "inputYield": null,
                "equivalentYield": null,
                "indexFactor": null
              },
              "propertyPriceIndex": null,
              "rentalAmount": null,
              "valuationCurrency": {
                "currencyCode": "EUR",
                "exchangeRate": "1.000000"
              },
              "fee": null,
              "sourceUpdatedAt": "2016-09-01T12:00:00Z"
            }
          ],
          "workout": null,
          "sourceUpdatedAt": null
        }
      ],
      "valuations": [],
      "workout": null,
      "sourceUpdatedAt": null
    }
  ],
  "securityLinks": [
    {
      "securityItemNumber": 5418820,
      "buildingType": {
        "code": "1",
        "description": "Res Owner/Dependent Occ"
      },
      "legacyPropertyId": 708820,
      "security": {
        "securityType": {
          "code": "PROPERTY",
          "description": "Mortgage over Property"
        },
        "status": {
          "code": "RELE",
          "description": "Released"
        },
        "lenderStatus": {
          "code": "LREL",
          "description": "Released"
        },
        "isLive": false
      },
      "pledge": {
        "extent": {
          "code": "FP",
          "description": "Full Pledge"
        },
        "pledgedSize": null,
        "ownershipType": {
          "code": "SO",
          "description": "Sole"
        },
        "chargeRegisteredEntryNumber": null,
        "chargeRegisteredDate": null
      },
      "linkQuality": "SECURITY_RELEASED"
    }
  ],
  "workout": null,
  "aliases": [
    {
      "system": {
        "code": "SCP",
        "description": "Security database property"
      },
      "aliasId": 708820
    }
  ],
  "migratedPropertyReference": null,
  "qualityIssues": [],
  "sourceUpdatedAt": "2026-11-26T17:15:30Z"
}
```

---

## 11_under_bank_control_receiver

Fixed asset receiver appointed over a retail park: the property-level workout shows bank control and the sale process, so the state is UNDER_BANK_CONTROL. The mortgage has gone to IDRU.

```json
{
  "_case": "Fixed asset receiver appointed over a retail park: the property-level workout shows bank control and the sale process, so the state is UNDER_BANK_CONTROL. The mortgage has gone to IDRU.",
  "_kafkaKey": "PROPERTY:1001509031",
  "header": {
    "eventId": "PROPERTY:1001509031:3301",
    "actionType": "UPSERT",
    "aggregateVersion": 3301,
    "sourceChangedAt": "2026-11-03T12:00:00Z",
    "publishedAt": "2026-11-27T09:30:00Z",
    "sourceSystem": "AMD",
    "correlationId": "00-0000000000000000000000003bb1d0a7-0000000000000ce5-01"
  },
  "assetKey": "PROPERTY:1001509031",
  "assetClass": "PROPERTY",
  "propertyId": 1001509031,
  "lifecycle": {
    "state": "UNDER_BANK_CONTROL",
    "reason": "workout control FAR (Fixed Asset Receiver)"
  },
  "classification": {
    "propertyClass": "COMMERCIAL",
    "classConfirmed": true,
    "enteredPropertyType": {
      "code": "C",
      "description": "Commercial"
    },
    "economicSector": null
  },
  "location": {
    "unitNumber": null,
    "propertyName": null,
    "streetTownland1": "Example Retail Park",
    "streetTownland2": null,
    "townCity": "Limerick",
    "county": {
      "code": "LK",
      "description": "Limerick"
    },
    "postCode": "V94 X0X0",
    "country": {
      "code": "IE",
      "description": "Ireland"
    },
    "region": null,
    "areaType": {
      "code": "CTY",
      "description": "City"
    },
    "locationQuality": null,
    "latitude": null,
    "longitude": null
  },
  "originalSize": null,
  "currentSize": null,
  "currencyCode": "EUR",
  "risk": null,
  "insurance": null,
  "syndication": null,
  "registrations": [],
  "components": [
    {
      "componentKey": "COMMERCIAL:7901",
      "componentType": "COMMERCIAL",
      "componentId": 7901,
      "componentSubType": {
        "code": "RB",
        "description": "Retail Business Park"
      },
      "commercial": {
        "specialistUse": null,
        "condition": null,
        "size": null,
        "lettableSpace": null,
        "squareMetres": null,
        "measurement": null,
        "ownerOperated": null,
        "occupancy": null,
        "liquorLicence": null,
        "constructionYear": null,
        "numberOfUnits": 8,
        "numberOfVacantUnits": 3,
        "numberOfBedrooms": null,
        "numberOfCarSpaces": null,
        "ancillaryIncome": null,
        "operatingPropertyCosts": null,
        "marketRent": null,
        "weightedAverageLeaseLength": null,
        "weightedAverageTenantQuality": null,
        "geographicalLocation": null,
        "yieldClassification": null,
        "floodRisk": null,
        "ratingBPercent": null,
        "energyRating": null,
        "tenants": [],
        "hotels": [],
        "trading": []
      },
      "residential": null,
      "development": null,
      "land": null,
      "units": [],
      "valuations": [
        {
          "valuationId": 41888,
          "valuationDate": "2026-09-15",
          "source": {
            "code": "EX",
            "description": "External"
          },
          "sourceSystem": "AMD",
          "externalValuationType": {
            "code": "FI",
            "description": "Full Inspection"
          },
          "reason": null,
          "basis": null,
          "rvaCompliant": null,
          "valuer": {
            "name": null,
            "company": "Example Valuers Ltd",
            "registrationNumber": "PSRA-000123"
          },
          "values": {
            "openMarketValue": {
              "amount": "4300000.00",
              "currencyCode": "EUR"
            },
            "estimatedRentalValue": null,
            "existingUseValue": null,
            "reinstatementValue": null
          },
          "percentages": {
            "transactionCosts": null,
            "recovery": "70.000",
            "estimatedRentalValueRecovery": null,
            "uplift": null,
            "existingUseValueYield": null,
            "rentalYield": null,
            "reversionaryYield": null,
            "inputYield": null,
            "equivalentYield": null,
            "indexFactor": null
          },
          "propertyPriceIndex": null,
          "rentalAmount": null,
          "valuationCurrency": {
            "currencyCode": "EUR",
            "exchangeRate": "1.000000"
          },
          "fee": null,
          "sourceUpdatedAt": "2026-09-15T12:00:00Z"
        }
      ],
      "workout": null,
      "sourceUpdatedAt": null
    }
  ],
  "securityLinks": [
    {
      "securityItemNumber": 5519031,
      "buildingType": {
        "code": "4",
        "description": "Comm-Non Owner Oper"
      },
      "legacyPropertyId": 709031,
      "security": {
        "securityType": {
          "code": "PROPERTY",
          "description": "Mortgage over Property"
        },
        "status": {
          "code": "IDRU",
          "description": "Sent to IDRU"
        },
        "lenderStatus": {
          "code": "LIDR",
          "description": "Sent to IDRU"
        },
        "isLive": true
      },
      "pledge": {
        "extent": {
          "code": "FP",
          "description": "Full Pledge"
        },
        "pledgedSize": null,
        "ownershipType": {
          "code": "SO",
          "description": "Sole"
        },
        "chargeRegisteredEntryNumber": null,
        "chargeRegisteredDate": null
      },
      "linkQuality": "VALID"
    }
  ],
  "workout": {
    "controlOfAsset": {
      "code": "FAR",
      "description": "Fixed Asset Receiver"
    },
    "basisOfDisposal": null,
    "saleStatus": {
      "code": "FS",
      "description": "For Sale"
    },
    "saleStatusSubCategory": {
      "code": "OI",
      "description": "Offers in"
    },
    "saleStatusDate": "2026-10-28",
    "dateOfSale": null,
    "grossSalesProceeds": null
  },
  "aliases": [
    {
      "system": {
        "code": "SCP",
        "description": "Security database property"
      },
      "aliasId": 709031
    }
  ],
  "migratedPropertyReference": null,
  "qualityIssues": [],
  "sourceUpdatedAt": "2026-11-03T12:00:00Z"
}
```

---

## 12_disposed_sale_closed

Sold by the receiver: sale closed with proceeds recorded, so the state is DISPOSED even though the mortgage isn't yet marked released.

```json
{
  "_case": "Sold by the receiver: sale closed with proceeds recorded, so the state is DISPOSED even though the mortgage isn't yet marked released.",
  "_kafkaKey": "PROPERTY:1001609112",
  "header": {
    "eventId": "PROPERTY:1001609112:3420",
    "actionType": "UPSERT",
    "aggregateVersion": 3420,
    "sourceChangedAt": "2026-11-24T10:30:00Z",
    "publishedAt": "2026-11-27T09:30:00Z",
    "sourceSystem": "AMD",
    "correlationId": "00-0000000000000000000000003bb35798-0000000000000d5c-01"
  },
  "assetKey": "PROPERTY:1001609112",
  "assetClass": "PROPERTY",
  "propertyId": 1001609112,
  "lifecycle": {
    "state": "DISPOSED",
    "reason": "workout sale status SC (Sale Closed)"
  },
  "classification": {
    "propertyClass": "LAND",
    "classConfirmed": true,
    "enteredPropertyType": {
      "code": "L",
      "description": "Land"
    },
    "economicSector": null
  },
  "location": {
    "unitNumber": null,
    "propertyName": null,
    "streetTownland1": "Example Road",
    "streetTownland2": null,
    "townCity": "Mullingar",
    "county": {
      "code": "WH",
      "description": "Westmeath"
    },
    "postCode": null,
    "country": {
      "code": "IE",
      "description": "Ireland"
    },
    "region": null,
    "areaType": {
      "code": "RL",
      "description": "Rural"
    },
    "locationQuality": null,
    "latitude": null,
    "longitude": null
  },
  "originalSize": null,
  "currentSize": null,
  "currencyCode": "EUR",
  "risk": null,
  "insurance": null,
  "syndication": null,
  "registrations": [],
  "components": [
    {
      "componentKey": "LAND:2301",
      "componentType": "LAND",
      "componentId": 2301,
      "componentSubType": {
        "code": "H",
        "description": "Development Site"
      },
      "commercial": null,
      "residential": null,
      "development": null,
      "land": {
        "size": {
          "value": "3.200",
          "unit": {
            "code": "HEC",
            "description": "Hectares"
          }
        },
        "planning": null,
        "numberOfUnits": null,
        "occupancyStatus": null,
        "marketRent": null,
        "actualPassingRentalIncome": null,
        "floodRisk": null
      },
      "units": [],
      "valuations": [
        {
          "valuationId": 17410,
          "valuationDate": "2026-01-12",
          "source": {
            "code": "EX",
            "description": "External"
          },
          "sourceSystem": "AMD",
          "externalValuationType": {
            "code": "FI",
            "description": "Full Inspection"
          },
          "reason": null,
          "basis": null,
          "rvaCompliant": null,
          "valuer": {
            "name": null,
            "company": "Example Valuers Ltd",
            "registrationNumber": "PSRA-000123"
          },
          "values": {
            "openMarketValue": {
              "amount": "610000.00",
              "currencyCode": "EUR"
            },
            "estimatedRentalValue": null,
            "existingUseValue": null,
            "reinstatementValue": null
          },
          "percentages": {
            "transactionCosts": null,
            "recovery": null,
            "estimatedRentalValueRecovery": null,
            "uplift": null,
            "existingUseValueYield": null,
            "rentalYield": null,
            "reversionaryYield": null,
            "inputYield": null,
            "equivalentYield": null,
            "indexFactor": null
          },
          "propertyPriceIndex": null,
          "rentalAmount": null,
          "valuationCurrency": {
            "currencyCode": "EUR",
            "exchangeRate": "1.000000"
          },
          "fee": null,
          "sourceUpdatedAt": "2026-01-12T12:00:00Z"
        }
      ],
      "workout": null,
      "sourceUpdatedAt": null
    }
  ],
  "securityLinks": [
    {
      "securityItemNumber": 5619112,
      "buildingType": {
        "code": "9",
        "description": "No Buildings"
      },
      "legacyPropertyId": 710112,
      "security": {
        "securityType": {
          "code": "PROPERTY",
          "description": "Mortgage over Property"
        },
        "status": {
          "code": "IDRU",
          "description": "Sent to IDRU"
        },
        "lenderStatus": {
          "code": "LIDR",
          "description": "Sent to IDRU"
        },
        "isLive": true
      },
      "pledge": {
        "extent": {
          "code": "FP",
          "description": "Full Pledge"
        },
        "pledgedSize": null,
        "ownershipType": {
          "code": "SO",
          "description": "Sole"
        },
        "chargeRegisteredEntryNumber": null,
        "chargeRegisteredDate": null
      },
      "linkQuality": "VALID"
    }
  ],
  "workout": {
    "controlOfAsset": {
      "code": "FAR",
      "description": "Fixed Asset Receiver"
    },
    "basisOfDisposal": null,
    "saleStatus": {
      "code": "SC",
      "description": "Sale Closed"
    },
    "saleStatusSubCategory": null,
    "saleStatusDate": "2026-11-21",
    "dateOfSale": "2026-11-21",
    "grossSalesProceeds": {
      "amount": "585000.00",
      "currencyCode": "EUR"
    }
  },
  "aliases": [
    {
      "system": {
        "code": "SCP",
        "description": "Security database property"
      },
      "aliasId": 710112
    }
  ],
  "migratedPropertyReference": null,
  "qualityIssues": [],
  "sourceUpdatedAt": "2026-11-24T10:30:00Z"
}
```

---

## 13_proposed_on_lending_application

Offered as security on a new lending application, not yet charged: no security number yet, the application id is an alias, and the state is PROPOSED.

```json
{
  "_case": "Offered as security on a new lending application, not yet charged: no security number yet, the application id is an alias, and the state is PROPOSED.",
  "_kafkaKey": "PROPERTY:1001709400",
  "header": {
    "eventId": "PROPERTY:1001709400:3",
    "actionType": "UPSERT",
    "aggregateVersion": 3,
    "sourceChangedAt": "2026-11-26T15:02:44Z",
    "publishedAt": "2026-11-27T09:30:00Z",
    "sourceSystem": "AMD",
    "correlationId": "00-0000000000000000000000003bb4df58-0000000000000003-01"
  },
  "assetKey": "PROPERTY:1001709400",
  "assetClass": "PROPERTY",
  "propertyId": 1001709400,
  "lifecycle": {
    "state": "PROPOSED",
    "reason": "on lending application NAPS 000045512301, no security yet"
  },
  "classification": {
    "propertyClass": "RESIDENTIAL",
    "classConfirmed": true,
    "enteredPropertyType": {
      "code": "R",
      "description": "Residential"
    },
    "economicSector": null
  },
  "location": {
    "unitNumber": null,
    "propertyName": null,
    "streetTownland1": "2 Example Lane",
    "streetTownland2": null,
    "townCity": "Wexford",
    "county": {
      "code": "WX",
      "description": "Wexford"
    },
    "postCode": "Y35 X0X0",
    "country": {
      "code": "IE",
      "description": "Ireland"
    },
    "region": null,
    "areaType": {
      "code": "TWN",
      "description": "Town"
    },
    "locationQuality": null,
    "latitude": null,
    "longitude": null
  },
  "originalSize": null,
  "currentSize": null,
  "currencyCode": "EUR",
  "risk": null,
  "insurance": null,
  "syndication": null,
  "registrations": [],
  "components": [
    {
      "componentKey": "RESIDENTIAL:29990",
      "componentType": "RESIDENTIAL",
      "componentId": 29990,
      "componentSubType": {
        "code": "BG",
        "description": "Bungalow"
      },
      "commercial": null,
      "residential": {
        "condition": null,
        "occupancy": null,
        "numberOfUnits": 1,
        "constructionYear": null,
        "numberOfFloors": null,
        "squareMetres": null,
        "measurement": null,
        "floodRisk": null,
        "ratingBPercent": null,
        "energyRating": null
      },
      "development": null,
      "land": null,
      "units": [
        {
          "unitKey": "RESIDENTIAL_UNIT:35990",
          "unitType": "RESIDENTIAL_UNIT",
          "unitId": 35990,
          "unitSubType": {
            "code": "BG",
            "description": "Bungalow"
          },
          "residential": {
            "numberOfBedrooms": 4,
            "numberOfUnits": 1,
            "numberOfRentedUnits": null,
            "size": null,
            "occupiedSpace": null,
            "numberOfCarSpaces": null,
            "actualPassingRentalIncome": null,
            "marketRent": null,
            "totalAnnualCost": null,
            "totalMaintenanceCost": null,
            "propertyManagementCost": null,
            "mudCompliant": null
          },
          "development": null,
          "valuations": [
            {
              "valuationId": 88990,
              "valuationDate": "2026-11-20",
              "source": {
                "code": "EX",
                "description": "External"
              },
              "sourceSystem": "AMD",
              "externalValuationType": {
                "code": "FI",
                "description": "Full Inspection"
              },
              "reason": null,
              "basis": {
                "code": "RRB",
                "description": "Reduced Red Book"
              },
              "rvaCompliant": null,
              "valuer": {
                "name": null,
                "company": "Example Valuers Ltd",
                "registrationNumber": "PSRA-000123"
              },
              "values": {
                "openMarketValue": {
                  "amount": "365000.00",
                  "currencyCode": "EUR"
                },
                "estimatedRentalValue": null,
                "existingUseValue": null,
                "reinstatementValue": null
              },
              "percentages": {
                "transactionCosts": null,
                "recovery": null,
                "estimatedRentalValueRecovery": null,
                "uplift": null,
                "existingUseValueYield": null,
                "rentalYield": null,
                "reversionaryYield": null,
                "inputYield": null,
                "equivalentYield": null,
                "indexFactor": null
              },
              "propertyPriceIndex": null,
              "rentalAmount": null,
              "valuationCurrency": {
                "currencyCode": "EUR",
                "exchangeRate": "1.000000"
              },
              "fee": null,
              "sourceUpdatedAt": "2026-11-20T12:00:00Z"
            }
          ],
          "workout": null,
          "sourceUpdatedAt": null
        }
      ],
      "valuations": [],
      "workout": null,
      "sourceUpdatedAt": null
    }
  ],
  "securityLinks": [],
  "workout": null,
  "aliases": [
    {
      "system": {
        "code": "NAPS",
        "description": "Lending application"
      },
      "aliasId": 45512301
    }
  ],
  "migratedPropertyReference": null,
  "qualityIssues": [
    {
      "rule": "Q5",
      "path": "securityLinks",
      "detail": "No security number yet (expected while PROPOSED)"
    }
  ],
  "sourceUpdatedAt": "2026-11-26T15:02:44Z"
}
```

---

## 14_deleted_retired

Property removed from AMD (created in error): actionType DELETE, state RETIRED. The body carries the last known state so consumers can close it off.

```json
{
  "_case": "Property removed from AMD (created in error): actionType DELETE, state RETIRED. The body carries the last known state so consumers can close it off.",
  "_kafkaKey": "PROPERTY:1001806001",
  "header": {
    "eventId": "PROPERTY:1001806001:58",
    "actionType": "DELETE",
    "aggregateVersion": 58,
    "sourceChangedAt": "2026-11-27T08:55:10Z",
    "publishedAt": "2026-11-27T09:30:00Z",
    "sourceSystem": "AMD",
    "correlationId": "00-0000000000000000000000003bb658b1-000000000000003a-01"
  },
  "assetKey": "PROPERTY:1001806001",
  "assetClass": "PROPERTY",
  "propertyId": 1001806001,
  "lifecycle": {
    "state": "RETIRED",
    "reason": "AM_PROPERTY row deleted"
  },
  "classification": {
    "propertyClass": "RESIDENTIAL",
    "classConfirmed": false,
    "enteredPropertyType": {
      "code": "R",
      "description": "Residential"
    },
    "economicSector": null
  },
  "location": {
    "unitNumber": null,
    "propertyName": null,
    "streetTownland1": "Example Street",
    "streetTownland2": null,
    "townCity": "Tralee",
    "county": {
      "code": "KY",
      "description": "Kerry"
    },
    "postCode": null,
    "country": {
      "code": "IE",
      "description": "Ireland"
    },
    "region": null,
    "areaType": {
      "code": "TWN",
      "description": "Town"
    },
    "locationQuality": null,
    "latitude": null,
    "longitude": null
  },
  "originalSize": null,
  "currentSize": null,
  "currencyCode": "EUR",
  "risk": null,
  "insurance": null,
  "syndication": null,
  "registrations": [],
  "components": [],
  "securityLinks": [],
  "workout": null,
  "aliases": [],
  "migratedPropertyReference": null,
  "qualityIssues": [],
  "sourceUpdatedAt": "2026-11-27T08:55:10Z"
}
```
